package arquitetura.funcional.base.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public interface IAction
{
	public ActionForward prepararConsultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception;

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception;

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception;

	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception;

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception;
	
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception;

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception;
}
