package arquitetura.funcional.base.persistencia;

import java.io.Serializable;
import java.util.List;

import arquitetura.funcional.base.excecao.SerproException;

public class GenericDAOHealth implements IDAO
{
	private IDAO oDAO;

	public GenericDAOHealth(Class classe) throws SerproException
	{
		// Verifica nas configura��es
		// qual framework de persistencia
		oDAO = new HibernateDAOHealth(classe);
	}

	public Class getVO()
	{
		return oDAO.getVO();
	}

	public void setVO(Class classe)
	{
		oDAO.setVO(classe);
	}

	public Object getConnection()
	{
		return oDAO.getConnection();
	}

	public Object getTransaction()
	{
		return oDAO.getTransaction();
	}

	public void closeConnection()
	{
		oDAO.closeConnection();
	}

	public boolean hasTransaction()
	{
		return oDAO.hasTransaction();
	}

	public void commit()
	{
		oDAO.commit();
	}

	public void rollback()
	{
		oDAO.rollback();
	}

	// --- M�todos de manuten��o de dados ------------
	public Object inserir(Object o) throws SerproException
	{
		return oDAO.inserir(o);
	}

	public Object alterar(Object o) throws SerproException
	{
		return oDAO.alterar(o);
	}

	public Object salvar(Object o) throws SerproException
	{
		return oDAO.salvar(o);
	}

	public void excluir(Object o) throws SerproException
	{
		oDAO.excluir(o);
	}

	// --- M�todos de consulta ---------------------
	public Object consultarID(Serializable id) throws SerproException
	{
		return oDAO.consultarID(id);
	}

	public List consultarTodos() throws SerproException
	{
		return oDAO.consultarTodos();
	}

	public List consultarTodos(String[][] orderBy) throws SerproException
	{
		return oDAO.consultarTodos(orderBy);
	}
	
	public List consultarQBE(Object o) throws SerproException
	{
		return oDAO.consultarQBE(o);
	}

	public List consultarQBE(Object o, Object g) throws SerproException
	{
		return oDAO.consultarQBE(o, g);
	}

	public List consultarHabilitados(String[][] orderBy, List lstObj) throws SerproException
	{
		return oDAO.consultarHabilitados(orderBy, lstObj);
	}

}
