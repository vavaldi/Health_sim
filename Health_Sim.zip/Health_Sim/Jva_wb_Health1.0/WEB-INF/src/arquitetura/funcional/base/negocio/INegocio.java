package arquitetura.funcional.base.negocio;

import java.io.Serializable;
import java.util.List;

import arquitetura.funcional.base.excecao.SerproException;

public interface INegocio
{

// 	 --- M�todo de Valida��o dos Dados ---
	public boolean valida(Object o) throws SerproException;
//	 --- M�todos de manuten��o de dados ------------
	public Object inserir(Object o) throws SerproException;

	public Object alterar(Object o) throws SerproException;

	public Object salvar(Object o) throws SerproException;

	public void excluir(Object o) throws SerproException;

	// --- M�todos de consulta ---------------------
	public Object consultarID(Serializable id) throws SerproException;

	public List consultarTodos() throws SerproException;

	public List consultarTodos(String[][] orderBy) throws SerproException;
	
	public List consultarQBE(Object o) throws SerproException;
}
