package arquitetura.funcional.base.bean;

public class BtpGrupoBase
{ 
	private String titulo;

	private String campo;

	private String ordem;

	private String grupo;

	private String nulo;

	public String getCampo()
	{
		return campo;
	}

	public void setCampo(String campo)
	{
		this.campo = campo;
	}

	public String getOrdem()
	{
		return ordem;
	}

	public void setOrdem(String ordem)
	{
		this.ordem = ordem;
	}

	public String getTitulo()
	{
		return titulo;
	}

	public void setTitulo(String titulo)
	{
		this.titulo = titulo;
	}

	public String getGrupo()
	{
		return grupo;
	}

	public void setGrupo(String grupo)
	{
		this.grupo = grupo;
	}

	public String getNulo()
	{
		return nulo;
	}

	public void setNulo(String nulo)
	{
		this.nulo = nulo;
	}


}
