package arquitetura.funcional.base.token;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SynchronizerToken
{
	public static void GerarToken(HttpServletRequest req)
	{
		Random random = new Random();
		String token = Long.toString(random.nextLong());
		while (Long.parseLong(token) == 0)
		{
			token = Long.toString(random.nextLong());
		}
		req.getSession().setAttribute("token", token);
	}

	public static boolean isTokenValid(HttpServletRequest req)
	{
		String tokenClient = req.getParameter("token");
		String tokenServer = (String) req.getSession().getAttribute("token");
		//Primeira Requisi��o do Sistema
		if (tokenClient == null && tokenServer == null)
		{
			return true; 
		}			
		if (tokenClient == null || tokenServer == null)
			return false;
		return (tokenClient.equals(tokenServer));
	}

	public static boolean doIt(HttpServletRequest request, HttpServletResponse response)
	{
		if (isTokenValid(request))
		{
			GerarToken(request);
		}
		else
		{
			return false;
		}
		return true;
	}

}
