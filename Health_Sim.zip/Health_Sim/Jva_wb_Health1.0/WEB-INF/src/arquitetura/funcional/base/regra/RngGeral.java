package arquitetura.funcional.base.regra;

import java.util.ArrayList;
import java.util.List;

import arquitetura.funcional.base.excecao.SerproException;

public class RngGeral
{
}
