package arquitetura.funcional.base.util;

import java.io.InputStream;
import java.util.Properties;

import arquitetura.funcional.base.excecao.SerproException;

/**
 * Classe singleton para armazenar as configura��es
 * id�nticas para todo o sistema 
 * @author franze
 */

public class Configuracao {
	private static Configuracao instanciaUnica = null;
	
	// Configura��es para valida��o de login de usu�rios
	private static String loginPerfil;
	private static String loginServidor;
	
	// Configura��es para consultas ao SRH
	private static String consultaSrhUsuario;
	private static String consultaSrhSenha;
	private static String consultaSrhPerfil;
	private static String consultaSrhServidor;
	
	// Configura��es do banco de dados do sistema
	private static String bancoHisaqServidor;
	private static String bancoHisaqNome;
	private static String bancoHisaqUsuario;
	private static String bancoHisaqSenha;	
	
	private static String versaoSistema;
	private static String dataVersao;
	
	private static String servidorNotes;	

	// Configura��es para o sistema de Acesso
	private static String acessoSistema;  // Inserir o c�digo do sistema na tabela SIS_SISTEMA (ACESSO)
	
	@SuppressWarnings("static-access")
	private Configuracao() throws SerproException {
		try {
		    Properties props = new Properties();
			InputStream in = getClass().getClassLoader().getResourceAsStream("configuracao.properties"); 
            props.load(in);
            
            this.loginPerfil = props.getProperty("sqlada.login.perfil");
            this.loginServidor = props.getProperty("sqlada.login.servidor");
            
            this.consultaSrhPerfil = props.getProperty("sqlada.consulta.perfil");
            this.consultaSrhSenha = props.getProperty("sqlada.consulta.senha");
            this.consultaSrhServidor = props.getProperty("sqlada.consulta.servidor");
            this.consultaSrhUsuario = props.getProperty("sqlada.consulta.usuario");
            
            this.bancoHisaqServidor = props.getProperty("bd.hisaq.servidor");
            this.bancoHisaqNome = props.getProperty("bd.hisaq.nome");
            this.bancoHisaqUsuario = props.getProperty("bd.hisaq.usuario");
            this.bancoHisaqSenha = props.getProperty("bd.hisaq.senha");
            
            this.servidorNotes = props.getProperty("servidor.notes");
                                             
        	// Configura��es para o sistema de Acesso
            this.acessoSistema = props.getProperty("acesso.sistema");
            
            in.close();
            

            //Ler a vers�o e data da vers�o
		    props = new Properties();
			in = getClass().getClassLoader().getResourceAsStream("release.properties"); 
            props.load(in);
            
            this.versaoSistema = props.getProperty("versao.release");
            this.dataVersao = props.getProperty("data.release");
                                             
            in.close();
            
		} catch (Exception e){
			throw new SerproException(e);
		}
		
                     		
	} // o compilador n�o vai gerar um construtor default p�blico

	public static Configuracao getInstance() throws SerproException {
		if (instanciaUnica == null) {
			instanciaUnica = new Configuracao();
		}
		return instanciaUnica;
	}

	public static String getConsultaSrhPerfil() {
		return consultaSrhPerfil;
	}

	public static String getConsultaSrhSenha() {
		return consultaSrhSenha;
	}

	public  static String getConsultaSrhServidor() {
		return consultaSrhServidor;
	}

	public  static String getConsultaSrhUsuario() {
		return consultaSrhUsuario;
	}

	public static String getLoginPerfil() {
		return loginPerfil;
	}

	public  static String getLoginServidor() {
		return loginServidor;
	}

	public static String getBancoHisaqNome() {
		return bancoHisaqNome;
	}

	public static String getBancoHisaqSenha() {
		return bancoHisaqSenha;
	}

	public static String getBancoHisaqServidor() {
		return bancoHisaqServidor;
	}

	public static String getBancoHisaqUsuario() {
		return bancoHisaqUsuario;
	}

	public static String getDataVersao() {
		return dataVersao;
	}

	public static String getVersaoSistema() {
		return versaoSistema;
	}

	public static String getServidorNotes() {
		return servidorNotes;
	}
}
