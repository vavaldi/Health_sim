package arquitetura.funcional.base.persistencia;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.hibernate.Criteria;
import org.hibernate.EntityMode;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.impl.CriteriaImpl;
import org.hibernate.impl.CriteriaImpl.Subcriteria;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.sql.JoinFragment;
import org.hibernate.type.BagType;

import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntRegraNegocio;
import arquitetura.funcional.health.entidades.EntTipoRegra;


public class HibernateDAOHealth implements IDAO
{

	private static SessionFactory sessionFactory = null;

	private static ThreadLocal _session = new ThreadLocal();

	private static ThreadLocal _transaction = new ThreadLocal();

	private Class _vo;

	public Class getVO()
	{
		return _vo; 
	}

	public SessionFactory getSessionFactory()
	{
		return sessionFactory; 
	}
	
	public void setVO(Class classe)
	{
		this._vo = classe;
	}

	public HibernateDAOHealth(Class classe) throws SerproException
	{
		if (sessionFactory == null)
		{
			try
			{
				//sessionFactory = new Configuration().configure("/resources/hibernate.cfg.xml").buildSessionFactory();
				sessionFactory = new AnnotationConfiguration().configure("hibernateHealth.cfg.xml").buildSessionFactory();
			}
			catch (Exception e)
			{
				System.out.println("Hibernate : " + e.toString()); 
				e.printStackTrace(); 
				throw new SerproException(e); 
			}
		}
		setVO(classe);
	}

	@SuppressWarnings("unchecked")
	public Object getConnection()
	{
		Session s = (Session) _session.get();
		if (s == null)
		{
			if (sessionFactory == null)
			{
				throw new RuntimeException(
						"SessionFactory has to be initialized.");
			}
			try
			{
				s = sessionFactory.openSession();
			}
			catch (HibernateException e)
			{
				throw new RuntimeException(e);
			}
			_session.set(s);
		}
		return s;
	}

	@SuppressWarnings("unchecked")
	public Object getTransaction()
	{
		Transaction t = (Transaction) _transaction.get();
		if (t == null)
		{
			try
			{
				t = ((Session) getConnection()).beginTransaction();
			}
			catch (HibernateException e)
			{
				throw new RuntimeException(e);
			}
			_transaction.set(t);
		}
		return t;
	}

	@SuppressWarnings("unchecked")
	public void closeConnection()
	{
		Session s = (Session) _session.get();
		if (s != null)
		{
			try
			{
				s.close();
			}
			catch (HibernateException e)
			{
				throw new RuntimeException(e);
			}
		}
		_session.set(null);
	}

	public boolean hasTransaction()
	{
		return (_transaction.get() != null);
	}

	@SuppressWarnings("unchecked")
	public void commit()
	{
		if (hasTransaction())
		{
			((Transaction) getTransaction()).commit();
			_transaction.set(null);
		}
		closeConnection();
	}

	@SuppressWarnings("unchecked")
	public void rollback()
	{
		if (hasTransaction())
		{
			((Transaction) getTransaction()).rollback();
			_transaction.set(null);
		}
		closeConnection();
	}

	// --- M�todos de manuten��o de dados ------------

	public Object inserir(Object o) throws SerproException
	{
		try
		{
			getTransaction();
			return ((Session) getConnection()).save(o);
		}
		catch (Exception e)
		{
			rollback();			
			throw new SerproException(e);
		}
	}

	public Object alterar(Object o) throws SerproException
	{
		try
		{
			getTransaction();
			((Session) getConnection()).update(o);
			return o;
		}
		catch (Exception e)
		{
			rollback();
			throw new SerproException(e);
		}
	}

	public Object salvar(Object o) throws SerproException
	{
		try
		{
			getTransaction();
			((Session) getConnection()).saveOrUpdate(o);
			return o;
		}
		catch (Exception e)
		{
			rollback();
			throw new SerproException(e);
		}

	}

	public void excluir(Object o) throws SerproException
	{
		try
		{
			getTransaction();
			((Session) getConnection()).delete(o);
		}
		catch (Exception e)
		{
			rollback();
			throw new SerproException(e);
		}
	}

	// --- M�todos de consulta ---------------------

	public Object consultarID(Serializable id) throws SerproException
	{
		try
		{
			//return ((Session) getConnection()).get(getVO(), id);
			Object objExemplo = getVO().newInstance();
			ClassMetadata classMetadata = sessionFactory.getClassMetadata(objExemplo.getClass());
			
			String identifierPropertyName = classMetadata.getIdentifierPropertyName();
			PropertyUtils.setProperty(objExemplo, identifierPropertyName, id);
			
			List res = consultarQBE(objExemplo, null);
			
			if (res.size() > 0)
				return res.get(0);
			else
				return null;
		}
		catch (Exception e)
		{
			rollback();
			throw new SerproException(e);
		}
	}

	public List consultarTodos() throws SerproException
	{
		try
		{
			((Session) getConnection()).createCriteria(getVO()).list();
			return ((Session) getConnection()).createCriteria(getVO()).list(); 
		}
		catch (Exception e)
		{
			rollback();
			throw new SerproException(e);
		}
	}
    
	public List consultarTodos(String[][] orderBy) throws SerproException
	{
		// Cria lista e inclui a ordena��o
        List<BtpGrupo> ordenacao = new ArrayList<BtpGrupo>();
		for (int i = 0; i < orderBy.length; i++)
		{
			String campo = orderBy[i][0];
			String ordem = orderBy[i][1];
			BtpGrupo btpGrp = new BtpGrupo();
			btpGrp.setCampo(campo);
			btpGrp.setOrdem(ordem);
			ordenacao.add(btpGrp);
		}
        
		try {
			return consultarQBE(getVO().newInstance(), ordenacao);
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	public List consultarQBE(Object o) throws SerproException
	{
		List lst = null; 
		try
		{
			//Example oExample = Example.create(o).ignoreCase().enableLike(MatchMode.ANYWHERE);
			Example oExample = Example.create(o).ignoreCase().enableLike(MatchMode.ANYWHERE);
			
			//Example oExample2 = Example.create(p).ignoreCase().enableLike(
			//		MatchMode.ANYWHERE);
			
			ClassMetadata classMetadata = sessionFactory.getClassMetadata(o.getClass());
			Criteria oCriteria = ((Session) getConnection()).createCriteria(o.getClass()).add(oExample);
			//oCriteria.add(oExample2);
			
			
			// Adiciona o Campo Chave
			String identifierPropertyName = classMetadata.getIdentifierPropertyName();
			Object identifierPropertyValue = PropertyUtils.getProperty(o, identifierPropertyName);
			if (identifierPropertyValue != null)
				oCriteria.add(Expression.eq(identifierPropertyName,identifierPropertyValue ));
			
			// Pesquisa pelos filhos
			String[] listProperty = classMetadata.getPropertyNames();
			for( int i = 0; i < listProperty.length; i++)
			{
				if (classMetadata.getPropertyType(listProperty[i]).isEntityType())
				{
					Object propertyValue = PropertyUtils.getProperty(o, listProperty[i]);
					if (propertyValue != null)
						investigarDescendentes(listProperty[i], propertyValue, oCriteria);
				}
			}
			return oCriteria.list(); 
		}			
		catch (Exception e)
		{
			rollback();
			throw new SerproException(e);						   
		}			
	}

	public boolean adicionarRegra(Criteria oCriteria, EntRegraNegocio entRng) throws ClassNotFoundException
	{
		// Vari�veis de controle
		String classeAlvo = oCriteria.getAlias();
		String strAlvo = "";
		String[] vetAlvo = {};
		String raiz = "";
		String item = "";
		Object objValor = new Object();

		// Extrai o primeiro token da regra
		if (null != entRng && null != entRng.getRngDscAlvo())
		{
			strAlvo = entRng.getRngDscAlvo();
			if (strAlvo.length() > 0)
			{
				vetAlvo = strAlvo.split("\\.");
				raiz = vetAlvo[0].trim();
			}
		}

		// Extrai o primeiro token da regra
		String strValor = "";
		String[] vetValor = {};
		if (null != entRng && null != entRng.getRngDscValor())
		{
			strValor = entRng.getRngDscValor();
			if (strValor.length() > 0)
			{
				vetValor = strValor.split("\\.");
			}

			// Identifica a origem do token
			if (null != vetValor[0])
			{
				String strRaizValor = vetValor[0].trim();
//				if (strRaizValor.length() > 5 && strRaizValor.toLowerCase().substring(0, 6).contains("thread"))
				if (strRaizValor.length() > 5 && strRaizValor.toLowerCase().contains("thread"))
				{
					int cont = 1;
					// Adiciona as restri��es oriundas das regras de neg�cio
					BtpListaRegras btpListaRegras = BtpContainerRegras.get();
					objValor = btpListaRegras;
					while (cont <= vetValor.length-1)
					{
						// Captura o item a ser processado
						item = vetValor[cont].trim();
						
						Class<?>[] args = new Class[0];
			            //args[0] = String.class;
						try {
							Method metodo = objValor.getClass().getMethod("get" + item.substring(0, 1).toUpperCase() + item.substring(1), args);
							objValor = metodo.invoke(objValor);
						} catch (NoSuchMethodException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (SecurityException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IllegalAccessException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (InvocationTargetException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						// Incrementa contador
						cont++;
					}
				} 
				else if (strRaizValor.toLowerCase().contains("session"))
				{
					// Puxar elementos da sess�o
				}
			}
			

		}

		// Identifica a entidade do oCriteria passado
		ClassMetadata metadados = sessionFactory.getClassMetadata("arquitetura.funcional.health.entidades." + raiz.substring(0, 1).toUpperCase() + raiz.substring(1));
		
		// Extrai o tipo de regra
		EntTipoRegra entTrn = new EntTipoRegra();
		entTrn = entRng.getEntTipoRegra();
		if (null != entTrn)
		{
			Conjunction conjuncao = Restrictions.conjunction();
			// TODO: O pacote onde se encontra a classe n�o pode ser fixo. 
			DetachedCriteria detCriteria = DetachedCriteria.forClass(Class.forName("arquitetura.funcional.health.entidades." + raiz.substring(0, 1).toUpperCase() + raiz.substring(1)), "sub1");
			Boolean flgDetached = false;
			int cont = 0;
			while (cont <= vetAlvo.length-1) 
			{
				if (cont == 0) 
				{
					// Verifica se Raiz � igual a ClasseAlvo
				} else
				{
					// Captura o item a ser processado
					item = vetAlvo[cont].trim();
					
					// 1. O elemento � uma lista... 
					if (item.substring(0, 3).toLowerCase().contains("lst"))
					{
						try 
						{
							
							conjuncao = Restrictions.conjunction();
							detCriteria = DetachedCriteria.forClass(Class.forName("arquitetura.funcional.health.entidades.Ent" + item.substring(3)), "sub1");
							detCriteria.setProjection(Projections.id());
							detCriteria.add(Restrictions.eqProperty(oCriteria.getAlias() + "." + metadados.getIdentifierPropertyName(), "sub1." + raiz + "." + metadados.getIdentifierPropertyName()));
							
							conjuncao.add(Subqueries.exists(detCriteria));
							
							// Confirma o uso da Detached Criteria
							flgDetached = true;
							
							oCriteria.add(conjuncao);
						} catch (ClassNotFoundException e1) 
						{
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					} else 
						// 2. O elemento � uma entidade... 
						if (item.substring(0, 3).toLowerCase().contains("ent")) 
						{
							if (flgDetached)
							{
								ClassMetadata defEntidade = sessionFactory.getClassMetadata("arquitetura.funcional.health.entidades." + item.substring(0, 1).toUpperCase() + item.substring(1));
								detCriteria.add(Restrictions.eq("sub1." + item, objValor));
								//detCriteria.add(Restrictions.eq("sub1." + item + "." + defEntidade.getIdentifierPropertyName(), new java.lang.Long(1)));
							} else
							{
								ClassMetadata defEntidade = sessionFactory.getClassMetadata("arquitetura.funcional.health.entidades." + item.substring(0, 1).toUpperCase() + item.substring(1));
								//oCriteria.add(Restrictions.eq(item, new java.lang.Long(1)));
	//							oCriteria.add(Restrictions.eq(item + "." + defEntidade.getIdentifierPropertyName(), new java.lang.Long(1)));
							}
							flgDetached = false;
						}
				}
				
				// Incrementa contador
				cont++;
			}
			
			// Aplica a f�rmula de acordo com o tipo de regra
			if (entTrn.getTrnFlgIgual().intValue() == 1)
			{
				if (vetAlvo[1].contains("Flg"))
					oCriteria.add(Restrictions.eq(vetAlvo[1], Integer.valueOf(vetValor[0])));
			}
		}

		return true;
	}

	public Object gerarInstancia(Criteria oCriteria, EntRegraNegocio entRng) throws ClassNotFoundException
	{
		// Vari�veis de controle
		String strAlvo = "";
		String strValor = "";
		String[] vetAlvo = {};
		String[] vetValor = {};
		Class<?> clsAlvoRaiz = Class.class;
		Class<?> clsAlvo = Class.class;
		Class<?> clsTmp = Class.class;
		Object objAlvoRaiz = new Object(); 
		Object objAlvo = new Object(); 
		Object objTmp = new Object();
		objAlvo = new Object();
		objTmp = new Object();
		boolean lista = false;
		int cont = 0;

		// Extrai o primeiro token da regra
		if (null != entRng && null != entRng.getRngDscAlvo())
		{
			strAlvo = entRng.getRngDscAlvo();
			if (strAlvo.length() > 0)
			{
				// Quebra a string da regra...
				vetAlvo = strAlvo.split("\\.");
				//raiz = vetAlvo[0].trim();
				
				// Itera��o para montar o objeto Alvo
				while (cont <= vetAlvo.length-1)
				{
					// Captura o item a ser processado
					strAlvo = vetAlvo[cont].trim();
					
					//if (null != strAlvo && !strAlvo.isEmpty())
					if (null != strAlvo && strAlvo.length() > 0)
					{
						if (cont == 0)
						{
							clsAlvo = Class.forName("arquitetura.funcional.health.entidades." + strAlvo);
							clsAlvoRaiz = clsAlvo;
							try {
								objAlvoRaiz = clsAlvoRaiz.newInstance();
								//objAlvo = clsAlvo.newInstance();
								objAlvo = objAlvoRaiz;
							} catch (InstantiationException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IllegalAccessException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						else
 						{
							Class<?>[] args = new Class[1];
					        //args[0] = String.class;
							try {
								// Nova classe
								if (strAlvo.startsWith("lst"))
								{
									lista = true;
									clsTmp = Class.forName("arquitetura.funcional.health.entidades.Ent" + strAlvo.substring(3));
							        //args[0] = clsTmp;
									args[0] = List.class;
								} else
								{
									clsTmp = Class.forName("arquitetura.funcional.health.entidades." + strAlvo);
							        args[0] = clsTmp;
								}
								
								Method metodo = clsAlvo.getMethod("set" + strAlvo.substring(0, 1).toUpperCase() + strAlvo.substring(1), args);
								try {
									// Instancia objeto Alvo
									//objAlvo = clsAlvo.newInstance();
									if (lista == true)
									{
										objTmp = new ArrayList();
										((ArrayList)objTmp).add(clsTmp.newInstance());
										//objTmp = clsTmp.newInstance();
									} else
										objTmp = clsTmp.newInstance();
									
									// Faz a associa��o entre os objetos
									metodo.invoke(objAlvo, objTmp);
								} catch (InstantiationException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

								// Atribui ao clsAlvo e objAlvo os valores do *Tmp
								clsAlvo = clsTmp;
								if (lista)
								{
									objAlvo = ((ArrayList<?>)objTmp).get(0);
									lista = false;
								} else
								{
									objAlvo = objTmp;
								}
								
								//Method metodo = Class.forName("arquitetura.funcional.health.entidades." + itemAlvo).getClass().getMethod("set" + itemAlvo.substring(0, 1).toUpperCase() + itemAlvo.substring(1), args);
								//objAlvo = metodo.invoke(objTmp); 
							} catch (NoSuchMethodException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (SecurityException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IllegalAccessException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IllegalArgumentException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (InvocationTargetException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
					cont++;
				}
				// Insere o objeto valor
				if (null != objAlvo)
				{
					Object objValor = gerarValorInstancia(entRng);
					try {
						if (null != objValor)
							PropertyUtils.copyProperties(objAlvo, objValor);
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (NoSuchMethodException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}	
		}
		return objAlvoRaiz;
	}

				
	public Object gerarValorInstancia(EntRegraNegocio entRng) throws ClassNotFoundException
	{
		// Vari�veis de controle
		String strValor = "";
		String[] vetValor = {};
		int cont = 0;

		// Captura o valor passado e o aplica a regra
		Object objValor = new Object(); 
		if (null != entRng && null != entRng.getRngDscValor())
		{
			strValor = entRng.getRngDscValor();
			if (strValor.length() > 0)
			{
				vetValor = strValor.split("\\.");
			}

			// Identifica a origem do token
			if (null != vetValor[0])
			{
				String strRaizValor = vetValor[0].trim();
				//if (strRaizValor.length() > 5 && strRaizValor.toLowerCase().contains("thread"))
				if (strRaizValor.length() > 5 && strRaizValor.toLowerCase().substring(0, 6).contains("thread"))
				{
					// Muda contador para 1
					cont = 1;
					// Adiciona as restri��es oriundas das regras de neg�cio
					BtpListaRegras btpListaRegras = BtpContainerRegras.get();
					objValor = btpListaRegras;
					while (cont <= vetValor.length-1)
					{
						// Captura o item a ser processado
						strValor = vetValor[cont].trim();
						
						Class<?>[] args = new Class[0];
			            //args[0] = String.class;
						try {
							if (null != objValor)
							{
								Method metodo = objValor.getClass().getMethod("get" + strValor.substring(0, 1).toUpperCase() + strValor.substring(1), args);
								objValor = metodo.invoke(objValor);
							}
							
//							-------------- COLOCAR ISSO PARA ELIMINAR PROBLEMAS COM LAZY LOAD...
//							HibernateDAOJudo hibDao = new HibernateDAOJudo(Class.forName("arquitetura.funcional.judo.entidades.EntRegraNegocio"));
//							Session hibSession = hibDao.getSessionFactory().openSession();
//							hibSession.beginTransaction();
//
//							for (Iterator iterator = entCmd.getLstComandoPerfil().iterator(); iterator.hasNext();) 
//							{
//								EntComandoPerfil entComandoPerfil = (EntComandoPerfil) iterator.next();
//								EntComandoPerfil entCmp = (EntComandoPerfil) hibSession.load(EntComandoPerfil.class, entComandoPerfil.getCmpIdtChave());
//								
//								if (null != entCmp && null != entCmp.getLstRegraNegocio())
//								{
//									for (Iterator iterator2 = entCmp.getLstRegraNegocio().iterator(); iterator2.hasNext();) 
//									{
//										EntRegraNegocio entRng = (EntRegraNegocio) iterator2.next();
//										
//										// A partir dos perfis do usu�rio logado, coloca na lista as respectivas restri��es...
//										// N�o funcionou com a compara��o de objetos
////										if (lstPerfis.contains(entRng.getEntComandoPerfil().getEntPerfil()))
////											lstRegras.getLstRegraNegocio().add(entRng);
//										if (null != lstPerfis && lstPerfis.size() > 0)
//										{
//											for (Iterator iterator3 = lstPerfis.iterator(); iterator3.hasNext();) 
//											{
//												EntPerfil entPer = (EntPerfil)iterator3.next();
//												if (entPer.getPerIdtChave().longValue() == entRng.getEntComandoPerfil().getEntPerfil().getPerIdtChave().longValue())
//													lstRegras.getLstRegraNegocio().add(entRng);
//											}
//										}
//										
//									} 
//								}
////								sessionFactory.close();
//							} 
//							hibSession.close();
//							---------------
							
						} catch (NoSuchMethodException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (SecurityException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IllegalAccessException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (InvocationTargetException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						// Incrementa contador
						cont++;
					}
				} 
				else if (strRaizValor.toLowerCase().contains("session"))
				{
					// Puxar elementos da sess�o
				}
				
				// Caso objValor exista, cria a regra
			}
		}
		return objValor;
	}
	
	public List consultarQBE(Object objExemplo, Object grupos) throws SerproException
	{
		List<Object> lstObjetos = new ArrayList<Object>(); 
		try
		{
			// Cria o crit�rio raiz
			Example expUsu = Example.create(objExemplo).ignoreCase().enableLike(MatchMode.ANYWHERE);
			ClassMetadata classMetadata = sessionFactory.getClassMetadata(objExemplo.getClass());
			//Criteria oCriteria = ((Session) getConnection()).createCriteria(o.getClass()).add(oExample);
			Criteria raizCriteria = ((Session) getConnection()).createCriteria(objExemplo.getClass());
			
			// Cria a primeira conjun��o para considerar as regras de neg�cio e as regras do exemplo
			Conjunction regras = Restrictions.conjunction();
			raizCriteria.add(regras);
			
			// Adiciona as regras do Exemplo passado 
			regras.add(expUsu);
			lstObjetos.add(objExemplo);
			
			// Monta os objetos com as regras de neg�cio
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			if (null != btpListaRegras && null != btpListaRegras.getLstRegraNegocio() && btpListaRegras.getLstRegraNegocio().size() > 0)
			{
				for (Iterator regrasNegocio = btpListaRegras.getLstRegraNegocio().iterator(); regrasNegocio.hasNext();) 
				{
					EntRegraNegocio entRng = (EntRegraNegocio) regrasNegocio.next();
					
					// Adiciona as restri��es oriundas das regras de neg�cio
					//adicionarRegra(raizCriteria, entRng);
					Object objRng = gerarInstancia(raizCriteria, entRng);
					if (objExemplo.getClass().getName().equals(objRng.getClass().getName()))
					{
						Example expRng = Example.create(objRng).ignoreCase().enableLike(MatchMode.ANYWHERE);
						regras.add(expRng);
						lstObjetos.add(objRng);
					}
				}
			}
			
			// Verifica as chaves prim�rias e as entidades filhas para cada exemplo
			List<String> lstObjetoCriterio = new ArrayList<String>();
			Iterator<Object> itObj = lstObjetos.iterator();
			while (itObj.hasNext()) 
			{
				Object objRegra = itObj.next();

				// Adiciona o Campo Chave
				String identifierPropertyName = classMetadata.getIdentifierPropertyName();
				Object identifierPropertyValue = PropertyUtils.getProperty(objRegra, identifierPropertyName);
				if (identifierPropertyValue != null)
					raizCriteria.add(Expression.eq(identifierPropertyName,identifierPropertyValue ));
				
				// Pesquisa pelos filhos
				String[] listProperty = classMetadata.getPropertyNames();
				for( int i = 0; i < listProperty.length; i++)
				{
					if (classMetadata.getPropertyType(listProperty[i]).isEntityType())
					{
						Object propertyValue = PropertyUtils.getProperty(objRegra, listProperty[i]);

						if (propertyValue != null)
						{
							lstObjetoCriterio.add(listProperty[i]);
							
							investigarDescendentes(listProperty[i], propertyValue, raizCriteria);
						}
					} else 
						if (classMetadata.getPropertyType(listProperty[i]).isCollectionType())
						{
							Object propertyValue = PropertyUtils.getProperty(objRegra, listProperty[i]);
							List l = new ArrayList();
							if (propertyValue != null)
							{
								try {
									l = (List)propertyValue;
									for (Iterator iterator = l.iterator(); iterator.hasNext();) 
									{
										Object itemLista = (Object) iterator.next();
										lstObjetoCriterio.add(listProperty[i]);
										investigarDescendentes(listProperty[i], itemLista, raizCriteria);
									}
										
								} catch (Exception e) {
									// TODO: handle exception
									e.printStackTrace();
								}
							}
						}
				}
			}

			// Adiciona a ordena��o pelos grupos.
			if (grupos != null && ((List)grupos).size() > 0)
			{
				for (Iterator lstGrupos = ((List)grupos).iterator(); lstGrupos.hasNext();)
				{
					BtpGrupo grupo = (BtpGrupo) lstGrupos.next();

					// Verifica se o grupo est� na entidade "principal". 
					if (grupo.getCampo().contains("."))
					{
						String tabela = grupo.getCampo().substring(0, grupo.getCampo().indexOf("."));
						if (!lstObjetoCriterio.contains(tabela))
						{
							raizCriteria.createAlias(tabela, tabela, JoinFragment.LEFT_OUTER_JOIN);
						}
					}

					// Adiciona ordena��o
					if (grupo != null && grupo.getOrdem().toUpperCase().equals("ASC"))
						raizCriteria.addOrder(Order.asc(grupo.getCampo()));
					if (grupo != null && grupo.getOrdem().toUpperCase().equals("DESC"))
						raizCriteria.addOrder(Order.desc(grupo.getCampo()));
				}
			}

			return raizCriteria.list(); 
		}			
		catch (Exception e)
		{
			rollback();
			throw new SerproException(e);						   
		}			
	}

	private Subcriteria buscaCriteria(Criteria oCriteria, String pAlias) {
	    try {
			Iterator<?> iter = null;
	    	if (oCriteria.getClass().equals(Class.forName("org.hibernate.impl.CriteriaImpl")))
	    	{
				Criteria c = ((Criteria)oCriteria);
				CriteriaImpl ci = ((CriteriaImpl)c);
				iter = ci.iterateSubcriteria();
	    		
	    	} else if (oCriteria.getClass().equals(Class.forName("org.hibernate.impl.CriteriaImpl$Subcriteria")))
	    	{
	    		Method m = oCriteria.getClass().getMethod("getParent");
				Criteria ci = (CriteriaImpl)m.invoke(oCriteria);
				ci = buscaCriteria(ci, pAlias);
				//iter = ci.iterateSubcriteria();
	    	}
			while (iter.hasNext()){
			    Subcriteria sub = (Subcriteria)iter.next();
			    if (pAlias.equals(sub.getAlias())){
			        return sub;
			    }
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return null;
	}

	public Criteria investigarDescendentes(String propriedade, Object o, Criteria oCriteria) throws SerproException
	{
		try
		{
			// Pesquisa as propriedades do objeto passado. 
			//Object propertyValue = PropertyUtils.getProperty(o, listProperty[i]);
			ClassMetadata propertyClassMetadata = sessionFactory.getClassMetadata(o.getClass());
			String _identifierPropertyName = propertyClassMetadata.getIdentifierPropertyName();
			Object _identifierPropertyValue = PropertyUtils.getProperty(o, _identifierPropertyName);
			if (_identifierPropertyValue != null)
			{
//				Criteria _oCriteria = oCriteria.createCriteria(propriedade, propriedade);
				Criteria _oCriteria = buscaCriteria(oCriteria, propriedade);
				if (null == _oCriteria)
					_oCriteria = oCriteria.createCriteria(propriedade, propriedade);
				_oCriteria.add(Expression.eq(_identifierPropertyName , _identifierPropertyValue) );
			}
			else
			{
				String[] _oProperty = propertyClassMetadata.getPropertyNames();
//				Criteria _oCriteria =  oCriteria.createCriteria(propriedade, propriedade); 							
				Criteria _oCriteria = buscaCriteria(oCriteria, propriedade);
				if (null == _oCriteria)
					_oCriteria = oCriteria.createCriteria(propriedade, propriedade);
				for (int j =0; j < _oProperty.length; j++ )
				{
					if (propertyClassMetadata.getPropertyType(_oProperty[j]).isEntityType())
					{
						// Aciona a recurs�o.
						if (PropertyUtils.getProperty(o, _oProperty[j]) != null)
							investigarDescendentes(_oProperty[j], PropertyUtils.getProperty(o, _oProperty[j]), _oCriteria);
					} else
					if (propertyClassMetadata.getPropertyType(_oProperty[j]) instanceof BagType)									
					{
						// Para cada item da lista, aciona a recurs�o para buscar os descendentes
						if (PropertyUtils.getProperty(o, _oProperty[j]) != null)
						{
							ArrayList lst = (ArrayList)PropertyUtils.getProperty(o, _oProperty[j]);
							for (Iterator iterator = lst.iterator(); iterator.hasNext();) 
							{
								Object obj = (Object) iterator.next();
								investigarDescendentes(_oProperty[j], obj, _oCriteria);
							} 
						}
					} else
					if (!propertyClassMetadata.getPropertyType(_oProperty[j]).isEntityType() && !(propertyClassMetadata.getPropertyType(_oProperty[j]) instanceof BagType) )									
						{
							Object _oPropertyValue = propertyClassMetadata.getPropertyValue(o, _oProperty[j], EntityMode.POJO);
							//Object _oPropertyValue = propertyClassMetadata.getPropertyValue(o, _oProperty[j]);

							// Se for string sem valor "" seta o valor para null, pois isso n�o far� parte do crit�rio
							if (_oPropertyValue != null)
							{
								if (_oPropertyValue instanceof String)
								{
									String valor = (String)_oPropertyValue;
									if (!valor.equals(""))
										_oCriteria.add(Expression.like(_oProperty[j] , (String) _oPropertyValue, MatchMode.ANYWHERE ));
								}									  
								else
								{
									_oCriteria.add(Expression.eq(_oProperty[j] , _oPropertyValue) );
								}
							}
						}							 
				}
			}
			return oCriteria; 
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return oCriteria;
	}

		// M�todo consultarHabilitados
	// Retorna apenas os registros que est�o habilitados
	public List consultarHabilitados(String[][] orderBy, List lstObj) throws SerproException
	{
		try
		{
			// Cria lista e inclui a ordena��o
	        List<BtpGrupo> ordenacao = new ArrayList<BtpGrupo>();
			for (int i = 0; i < orderBy.length; i++)
			{
				String campo = orderBy[i][0];
				String ordem = orderBy[i][1];
				BtpGrupo btpGrp = new BtpGrupo();
				btpGrp.setCampo(campo);
				btpGrp.setOrdem(ordem);
				ordenacao.add(btpGrp);
			}
	        
			List res = consultarQBE(getVO().newInstance(), ordenacao);

			// Adiciona a lista de objetos passada
			for (Iterator iterator = lstObj.iterator(); iterator.hasNext();) 
			{
				Object elemento = (Object) iterator.next();

				// Verifica se o objeto passado j� existe na lista 
				if (elemento != null && !res.contains(elemento))
					res.add(elemento);
			}
			return res; 
		}
		catch (Exception e)
		{
			rollback();
			throw new SerproException(e);
		}
	}	
}

