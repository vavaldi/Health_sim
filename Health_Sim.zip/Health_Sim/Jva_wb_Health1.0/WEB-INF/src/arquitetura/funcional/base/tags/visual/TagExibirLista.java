/*
 * Criada em 03/12/2004
 * Reformulada pela �ltima vez em 12/06/2013
 * F�bio Borges
 * 
 */
package arquitetura.funcional.base.tags.visual;


import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyTagSupport;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.struts.taglib.tiles.util.TagUtils;
import org.hibernate.collection.PersistentBag;

import com.mysql.jdbc.EscapeTokenizer;


/**
 * @author FABIOB
 *
 * Objetivo: Montar a estrutura do menu buscando  
 * as permiss�es do usu�rio na sess�o
 */
public class TagExibirLista extends BodyTagSupport 
{
	/**
	 * Chave do bean de sess�o que cont�m a lista de permiss�es.
	 */
	private String tipo;
	private String acao;
	private String objeto;
	private String sufixo;
	private String lista;
	private String nome; // Propriedade Name do HTML
	private String valor_id; // Propriedade ID do HTML
	private String valor_dest; // Campo que receber� o valor.
	private String descricao_dest; // Campo que receber� a descri��o.
	private String valor_orig; // Campo de origem do valor.
	private String descricao_orig; // Campo de origem da descri��o. 
	private String chave;
	private String readonly;
	private String retorno;

	public int doStartTag()
	{
		// Prepara vari�veis
		String strRet = "";

		// Tipo 
		Object tp = new Object();
		if (null == tipo)
		{
			tp = "L";
		} else
		{
			tp = tipo;
		}
//		else
//		{
//			try
//			{
//			  tp = TagUtils.getAttribute(tipo, 1, pageContext);
//			}
//			catch (Exception e)
//			{
//				System.out.println("Erro ! Imposs�vel definir o tipo.");
//			}
//		}

		// A��o
		if (null == acao)
			acao = ""; 

		// Objeto
		if (null == objeto)
			objeto = ""; 

		// Sufixo
		if (null == sufixo)
			sufixo = ""; 

		// Nome
		if (null == nome)
			nome = valor_dest + sufixo;

		// Id 
		if (null == valor_id)
			valor_id = "";

		// Destino_valor 
		if (null == valor_dest)
			valor_dest = "";

		// Destino_valor 
		if (null == descricao_dest)
			descricao_dest = "";

		// Origem_valor 
		if (null == valor_orig)
			valor_orig = "";

		// Origem_descri��o 
		if (null == descricao_orig)
			descricao_orig = "";

		// Chave 
		if (null == chave)
			chave = "";

		// Readonly 
		if (null == readonly)
			readonly = "false";

		// Valor e Descri��o passados no request para realimenta��o dos componentes
		// Verifica se o campo que receber� o valor j� est� setado.
		// 1. Passado via par�metro (m�todo get)
		// 20071126 - FEAB - Comentado para n�o alimentar os Combos e Lovs ap�s edi��o ou exclus�o.  
		String v_cod = ""; //(String)pageContext.getRequest().getParameter(valor_dest + sufixo);
		if (null == v_cod || v_cod.equals(""))
		{
			// 2. Passado via form (m�todo post)
			Object obj = TagUtils.findAttribute("org.apache.struts.taglib.html.BEAN", pageContext);
			try
			{
				v_cod = (String)PropertyUtils.getProperty(obj, valor_dest + sufixo);
			} catch (Exception e)
			{
		    	v_cod = "";
			}
			if (null == v_cod || v_cod.equals(""))
			{
				// 3. Passado via objeto do request (ent).
				Object ent = new Object();
				if (null != objeto + sufixo)
				{
					try
					{
						ent = PropertyUtils.getProperty(pageContext.getRequest().getAttribute("ent"), objeto + sufixo);
						v_cod = (String)PropertyUtils.getProperty(ent, valor_dest).toString();
					} catch (Exception e1)
					{
						v_cod = "";
					}
				}
			}
		} 

		// Valor e Descri��o passados no request para realimenta��o dos componentes
		// Verifica se o campo que receber� o valor j� est� setado.
		// 1. Passado via par�metro (m�todo get)
		// 20071126 - FEAB - Comentado para n�o alimentar os Combos e Lovs ap�s edi��o ou exclus�o.  
		String v_dsc = ""; //(String)pageContext.getRequest().getParameter(descricao_dest + sufixo);
		if (null == v_dsc || v_dsc.equals(""))
		{
			// 2. Passado via form (m�todo post)
			Object obj = TagUtils.findAttribute("org.apache.struts.taglib.html.BEAN", pageContext);
			try
			{
				v_dsc = (String)PropertyUtils.getProperty(obj, descricao_dest + sufixo);
			} catch (Exception e)
			{
		    	v_dsc = "";
			}
			if (null == v_dsc || v_dsc.equals(""))
			{
				// 3. Passado via objeto do request (ent).
				Object ent = new Object();
				if (null != objeto + sufixo)
				{
					try
					{
						ent = PropertyUtils.getProperty(pageContext.getRequest().getAttribute("ent"), objeto + sufixo);
						v_dsc = (String)PropertyUtils.getProperty(ent, descricao_dest).toString();
					} catch (Exception e1)
					{
						v_dsc = "";
					}
				}
			}
		} 

		//		// Valor e Descri��o passados no request para realimenta��o dos componentes
//		// Verifica se o campo que receber� a descri��o j� est� setado.
//		String v_dsc = (String)pageContext.getRequest().getParameter(descricao_dest);
//		// Verifica se foi passado um objeto
//		if (null != objeto)
//		{
//			v_dsc = objeto;
//		} else
//		if (null == v_dsc)
//		{
//			try
//			{
//				Object obj = TagUtils.findAttribute("org.apache.struts.taglib.html.BEAN", pageContext);
//				v_dsc = (String) PropertyUtils.getProperty(obj, descricao_dest);
//				if (null == v_dsc)
//				{
//					v_dsc = "";
//				}
//			} catch (Exception e)
//			{
//				v_dsc = "";
//			}
//		} 

		// Flag para marca��o do valor de entrada
		String marcado = "";

		// Caso o par�metro Tipo seja LOV (n�o faz uso da lista)
		if ("H".equals(((String)tp).toUpperCase())) 
		{
			if (null != pageContext.getRequest().getParameter("tipoDetalhe") && !pageContext.getRequest().getParameter("tipoDetalhe").equals(""))
			{
				strRet += "<input type=\"hidden\" size=\"1\" id=\"" + valor_id + "#'+ indice +'\" name=\"" + nome + "\" value=\"" + v_cod + "\" readonly=\"" + readonly + "\"/> "; 
			} else
			{
				strRet += "<input type=\"hidden\" size=\"1\" id=\"" + valor_id + "\" name=\"" + nome + "\" value=\"" + v_cod + "\" readonly=\"" + readonly + "\"/> "; 
			}
		} else
		if ("F".equals(((String)tp).toUpperCase())) // Fixo - Label da descri��o + Hidden do c�digo. 
		{
			if (null != pageContext.getRequest().getParameter("tipoDetalhe") && !pageContext.getRequest().getParameter("tipoDetalhe").equals(""))
			{
				strRet += "<input type=\"hidden\" size=\"1\" id=\"" + valor_id + "#'+ indice +'\" name=\"" + nome + "\" value=\"" + v_cod + "\" readonly=\"" + readonly + "\"/><input type=\"text\" size=\"40\" id=\"" + valor_id + "Dsc#'+ indice +'\" name=\"" + nome + "Dsc\" value=\"" + v_cod + "\" readonly=\"" + readonly + "\"/>";
			} else
			{
				strRet += "<input type=\"hidden\" size=\"1\" id=\"" + valor_id + "\" name=\"" + nome + "\" value=\"" + v_cod + "\" readonly=\"" + readonly + "\"/><input type=\"text\" size=\"40\" id=\"" + valor_id + "Dsc\" name=\"" + nome + "Dsc\" class=\"leitura\" value=\"" + v_dsc + "\" readonly=\"true\" /> ";
			}
		} else
		if ("L".equals(((String)tp).toUpperCase())) 
		{
			if (null != pageContext.getRequest().getParameter("tipoDetalhe") && !pageContext.getRequest().getParameter("tipoDetalhe").equals(""))
			{
//				strRet += "<input type=\"text\" size=\"5\" id=\"" + valor_dest + sufixo + "#'+ indice +'\" name=\"" + valor_dest + sufixo + "\" value=\"" + v_cod + "\" readonly=\"" + readonly + "\"/> <input type=\"text\" size=\"57\" id=\"" + descricao_dest + sufixo + "#'+ indice +'\" name=\"" + descricao_dest + sufixo + "\" class=\"leitura\" value=\"" + v_dsc + "\" readonly=\"" + readonly + "\" />";
//				strRet += "<input type=\"hidden\" size=\"1\" id=\"" + valor_dest + sufixo + "#'+ indice +'\" name=\"" + nome + "\" value=\"" + v_cod + "\" readonly=\"" + readonly + "\"/> <input type=\"text\" size=\"45\" id=\"" + valor_dest + sufixo + "Dsc#'+ indice +'\" name=\"" + nome + "Dsc\" class=\"leitura\" value=\"" + v_dsc + "\" readonly=\"" + readonly + "\" /> ";
				strRet += "<input type=\"hidden\" size=\"1\" id=\"" + valor_id + sufixo + "#'+ indice +'\" name=\"" + nome + "\" value=\"" + v_cod + "\" readonly=\"" + readonly + "\"/> <input type=\"text\" size=\"45\" id=\"" + valor_id + sufixo + "Dsc#'+ indice +'\" name=\"" + nome + "Dsc\" class=\"leitura\" value=\"" + v_dsc + "\" readonly=\"" + readonly + "\" /> ";
				strRet += ("<input type=\"button\" name=\"bt" + acao + "\" value=\"Localizar\" class=\"button\" alt=\"Localizar\" " + 
						  " onclick=\"window.open('" + acao + "Consulta.do?metodo=prepararSelecionar&chv=" + chave).replaceAll("\n", "").replaceAll("'", "\\\\'") ;
				strRet += "&linhaLOV=' + indice +'"; 
				strRet += ("', '', '')\" /> " +  
						  "<input type=\"button\" name=\"btResetar\" value=\"Limpar\" class=\"button\" alt=\"Limpar\" " + 
						  " onclick=\"document.getElementById('" + valor_dest + sufixo + "#").replaceAll("\n", "").replaceAll("'", "\\\\'") ;
				strRet += "' + indice + '";
				strRet += ("').value = ''; document.getElementById('" + valor_dest + sufixo + "Dsc#").replaceAll("\n", "").replaceAll("'", "\\\\'") ;
				strRet += "' + indice + '";
				strRet += ("').value = '';\" /> ").replaceAll("\n", "").replaceAll("'", "\\\\'") ;
//				strRet += ("<input type=\"button\" name=\"bt" + acao + "\" value=\"Localizar\" class=\"button\" alt=\"Localizar\" " + 
//						  " onclick=\"window.open('" + acao + "Consulta.do?metodo=prepararSelecionar&chv=" + chave + "', '', '')\" /> " + //'height=400, width=720, scrollbars=yes')\" /> " ;  
//						  "<input type=\"button\" name=\"btResetar\" value=\"Limpar\" class=\"button\" alt=\"Limpar\" " + 
//						  " onclick=\"document.getElementById('" + valor_dest + sufixo + "#' + indice + ').value = ''; document.getElementById('" + descricao_dest + sufixo + "#' + indice + ').value = '';\" /> ").replaceAll("\n", "").replaceAll("'", "\\\\'") ;//'height=400, width=720, scrollbars=yes')\" /> " ;

			} else 
			{
				strRet += "<input type=\"hidden\" size=\"1\" id=\"" + valor_dest + sufixo + "\" name=\"" + nome + "\" value=\"" + v_cod + "\" readonly=\"" + readonly + "\"/> " + 
//				"<input type=\"text\" size=\"57\" name=\"" + descricao_dest + "\" class=\"leitura\" value=\"" + v_dsc + "\" readonly=\"" + readonly + "\" /> " + 
				"<input type=\"text\" size=\"45\" id=\"" + valor_dest + sufixo + "Dsc\" name=\"" + nome + "Dsc\" class=\"leitura\" value=\"" + v_dsc + "\" readonly=\"" + readonly + "\" /> " + 
				"<input type=\"button\" name=\"bt" + acao + "\" value=\"Localizar\" class=\"button\" alt=\"Localizar\" " + 
				" onclick=\"window.open('" + acao + "Consulta.do?metodo=prepararSelecionar&chv=" + chave + "', '', '')\" /> " + //'height=400, width=720, scrollbars=yes')\" /> " ;  
				"<input type=\"button\" name=\"btResetar\" value=\"Limpar\" class=\"button\" alt=\"Limpar\" " + 
//				" onclick=\"document.forms[0]." + valor_dest + ".value = ''; document.forms[0]." + descricao_dest + ".value = '';\" /> " ;//'height=400, width=720, scrollbars=yes')\" /> " ;
//				" onclick=\"document.forms[0]." + valor_dest + ".value = ''; document.forms[0]." + valor_dest + "Dsc.value = '';\" /> " ;//'height=400, width=720, scrollbars=yes')\" /> " ;
				" onclick=\"document.getElementById('" + valor_dest + sufixo + "').value = ''; document.getElementById('" + valor_dest + sufixo + "Dsc').value = '';\" /> " ;//'height=400, width=720, scrollbars=yes')\" /> " ;
			}

			//	" onclick=\"window.open('" + acao + "Listar.do?cmd=lov&cmp=" + lista + "&vlr=" + origem_valor + "&dsc=" + origem_descricao + "', '', '')\" /> " ;//'height=400, width=720, scrollbars=yes')\" /> " ;  
		  		//"<html:hidden property=\"" + origem_valor + "\" /> " +
		  		        //"<html:text property=\"origem_descricao\" readonly=\"true\" /> ";
		} else 
		// Caso Tipo seja Combo ou Radio...
		{
			// Prepara a lista
			if (lista != null) 
			{
				// Caso Tipo seja Combo, cria o "select"  
				if ("C".equals(((String)tp).toUpperCase()))
				{
					if (null != pageContext.getRequest().getParameter("tipoDetalhe") && !pageContext.getRequest().getParameter("tipoDetalhe").equals(""))
					{
						// Inclui a tag select e a op��o vazia
						//strRet += "          <select name=\"" + valor_dest + "\" readonly=\"" + readonly + "\" class=\"form-campos\"> " + 
						strRet += "          <select id=\"" + valor_id + "#'+ indice +'\" name=\"" + nome + "\" class=\"text\" size=\"1\"> ";
						strRet += "              <option value=\"\">&nbsp;</option>" ;
					} else
					{
						// Inclui a tag select e a op��o vazia
						//strRet += "          <select name=\"" + valor_dest + "\" readonly=\"" + readonly + "\" class=\"form-campos\"> " + 
						strRet += "          <select id=\"" + valor_id + "\" name=\"" + nome + "\" class=\"text\" size=\"1\"> ";
						strRet += "              <option value=\"\">&nbsp;</option>" ;
					}
				} else
				if ("R".equals(((String)tp).toUpperCase()))
				{
					if (null != pageContext.getRequest().getParameter("tipoDetalhe") && !pageContext.getRequest().getParameter("tipoDetalhe").equals(""))
					{
						// Inclui a tag select e a op��o vazia 
						strRet += "            <input type=\"radio\" id=\"" + valor_dest + sufixo + "#'+ indice +'\" name=\"" + nome + "\" value=\"\"><font class=\"fonte-normal\">Todos</font><br> ";
					} else
					{
						// Inclui a tag select e a op��o vazia 
						strRet += "            <input type=\"radio\" name=\"" + nome + "\" value=\"\"><font class=\"fonte-normal\">Todos</font><br> ";
					}
				}
  			
				// Varre a lista - itera��o
				//ArrayList lst = (ArrayList)TagUtils.getAttribute(lista, 1, pageContext);
				//Object lst = TagUtils.findAttribute(lista, pageContext);
				Object objLst = TagUtils.findAttribute(lista, pageContext);
				if (null != objLst)
				{
  	  				Iterator lst;
  	  				if (objLst instanceof PersistentBag)
  	  					lst = ((PersistentBag)objLst).iterator();
  	  				else
  	  					lst = ((ArrayList)objLst).iterator();
  	  				//Iterator lst = ((ArrayList)TagUtils.findAttribute(lista, pageContext)).iterator();
  	  				while (lst.hasNext()) 
  	  				{
  	  					// Recebe pr�ximo elemento da lista
  	  					Object elemento = lst.next();
  	  					// Inicializa vari�veis que receber�o cada bean
  	  					Object val = null;
  	  					Object dsc = null;
  			
  	  					try 
  						{
  	  						// Busca o campo origem_valor entre as propriedades do elemento 
  	  						val = PropertyUtils.getProperty(elemento, valor_orig);
  	  						// Caso origem_valor seja nulo, atribui vazio
  	  						if (val == null) 
  	  						{
  	  							val = "";
  	  						}
  			        
  	  						// Busca o campo Descri��o entre as propriedades do elemento
  	  						if (null != descricao_dest && null != PropertyUtils.getProperty(elemento, descricao_orig)) 
  	  						{
  	  							dsc = PropertyUtils.getProperty(elemento, descricao_orig); 
  	  						} else 
  	  						{
  	  							dsc = "";
  	  						}
  	            
  	  						// Conforme o Tipo, constr�i o componente
  	  						if ("C".equals(((String)tp).toUpperCase()))
  	  						{
  	  							// Verifica se deve ser marcado
  	  							// if (!"".equals(val) && val.equals(v_cod))
  	  							if (!"".equals(val) && val.toString().equals(v_cod))
  	  								marcado = " selected";
  	  							else
  	  								marcado = "";
  	  							// Inclui as op��es 
  	  							// 20130610 - Ajuste para tratar o dsc como texto.
  	  							strRet += "            <option value=\""+ val.toString() + "\" " + marcado + ">" + StringEscapeUtils.escapeHtml4((dsc.toString()).replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n")) + "</option>" ;
  	  							//strRet += "            <option value=\""+ val + "\" " + marcado + ">" + StringEscapeUtils.escapeHtml4(((String)dsc).replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n")) + "</option>" ;
  	  							//strRet += "            <option value=\""+ val + "\" " + marcado + ">" + ((String)dsc).replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n") + "</option>" ;
  	  						}	else 
  	  						if ("R".equals(((String)tp).toUpperCase()))
  	  						{
  	  							// Verifica se deve ser marcado
  	  							if (!"".equals(val) && val.equals(v_cod))
  	  								marcado = " checked";
  	  							else
  	  								marcado = "";
  	  							if (null != pageContext.getRequest().getParameter("tipoDetalhe") && !pageContext.getRequest().getParameter("tipoDetalhe").equals(""))
  	  							{
  	  	  							// Inclui as op��es
  	  	  							strRet += "            <input type=\"radio\" id=\"" + valor_dest + sufixo + "#'+ indice +'\" name=\"" + nome + "\" value=\"" + val + "\" " + marcado + "><font class=\"fonte-normal\">" + dsc + "</font><br> ";
  	  							} else
  	  							{
  	  	  							// Inclui as op��es
  	  	  							strRet += "            <input type=\"radio\" name=\"" + nome + "\" value=\"" + val + "\" " + marcado + "><font class=\"fonte-normal\">" + dsc + "</font><br> ";
  	  							}
  	  						}	 
  						} catch (Exception e)
  						{
  							System.out.println("Erro ! N�o � poss�vel extrair informa��es de um elemento da lista.");
  						}
  	  				}
				}
			
				// Caso Tipo seja Combo, fecha o "select"  
				if ("C".equals(((String)tp).toUpperCase()))
				{
					// Inclui a tag select e a op��o vazia 
					strRet += "          </select>"; 
				}
			}
		}
		// Apresenta na tela
		JspWriter out = pageContext.getOut();
		try
		{
			out.print(strRet);
			//strRet = URLEncoder.encode(strRet, "UTF-8");
			//strRet = StringEscapeUtils.escapeCsv(strRet);
			retorno = strRet;
		}
catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 	
		// Retorno 
		return (SKIP_BODY);
	}
   
  public int doEndTag() 
  {
	  return EVAL_PAGE;
  }

	/**
	 * @return Returns the tipo.
	 */
	public String getTipo() {
		return tipo;
	}
	/**
	 * @param tipo The tipo to set.
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	/**
	 * @return Returns the acao.
	 */
	public String getAcao() {
		return acao;
	}
	/**
	 * @param acao The acao to set.
	 */
	public void setAcao(String acao) {
		this.acao = acao;
	}
	/**
	 * @return Returns the lista.
	 */
	public String getLista() {
		return lista;
	}
	/**
	 * @param lista The lista to set.
	 */
	public void setLista(String lista) {
		this.lista = lista;
	}
	/**
	 * @return Returns the chave.
	 */
	public String getChave() {
		return chave;
	}
	/**
	 * @param chave The chave to set.
	 */
	public void setChave(String chave) {
		this.chave = chave;
	}
	/**
	 * @return Returns the readonly.
	 */
	public String getReadonly() {
		return readonly;
	}
	/**
	 * @param readonly The readonly to set.
	 */
	public void setReadonly(String readonly) {
		this.readonly = readonly;
	}

	/**
	 * @return Returns the descricao_dest.
	 */
	public String getDescricao_dest() {
		return descricao_dest;
	}
	/**
	 * @param descricao_dest The descricao_dest to set.
	 */
	public void setDescricao_dest(String descricao_dest) {
		this.descricao_dest = descricao_dest;
	}
	/**
	 * @return Returns the valor_dest.
	 */
	public String getValor_dest() {
		return valor_dest;
	}
	/**
	 * @param valor_dest The valor_dest to set.
	 */
	public void setValor_dest(String valor_dest) {
		this.valor_dest = valor_dest;
	}
	/**
	 * @return Returns the descricao_orig.
	 */
	public String getDescricao_orig() {
		return descricao_orig;
	}
	/**
	 * @param descricao_orig The descricao_orig to set.
	 */
	public void setDescricao_orig(String descricao_orig) {
		this.descricao_orig = descricao_orig;
	}
	/**
	 * @return Returns the valor_orig.
	 */
	public String getValor_orig() {
		return valor_orig;
	}
	/**
	 * @param valor_orig The valor_orig to set.
	 */
	public void setValor_orig(String valor_orig) {
		this.valor_orig = valor_orig;
	}

	public String getValor_id()
	{
		return valor_id;
	}

	public void setValor_id(String valor_id)
	{
		this.valor_id = valor_id;
	}

	public String getObjeto()
	{
		return objeto;
	}

	public void setObjeto(String objeto)
	{
		this.objeto = objeto;
	}

	public String getSufixo()
	{
		return sufixo;
	}

	public void setSufixo(String sufixo)
	{
		this.sufixo = sufixo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
