package arquitetura.funcional.base.regra;

import java.io.Serializable;
import java.util.List;

import arquitetura.funcional.base.excecao.SerproException;

public interface IRegra
{
}
