package arquitetura.funcional.base.filtros;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.persistencia.GenericDAOHealth;
import arquitetura.funcional.base.persistencia.IDAO;

public class TransactionFilterHealth implements Filter
{ 

	public void init(FilterConfig config) throws ServletException
	{
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException
	{

		IDAO oDAO = null;
		
		try
		{
			chain.doFilter(request, response);
            
			ActBase oCritica = new ActBase();
			oDAO = new GenericDAOHealth(null);			

			if (oCritica.hasCriticas())
			{
				
				System.out.println(oCritica.printCriticas());
				oCritica.limpaCriticas();
				oDAO.rollback();
			}
			else
			{
				oDAO.commit();
			}

		}
		catch (SerproException e) 
		{
			// Exce��es tratadas pelo Sistema
			ActBase oc = new ActBase(); 
			System.out.println(oc.printCriticas());
			// Erros tratados com a chave
			
		}
		catch (Exception e)
		{
	        // Erros n�o tratados pela Aplica��o Deve ser gerada um exce��o com a chave
			// para ser tratrada pela Aplica��o			
			System.out.println("Erro  Filter " + e.toString());			
			e.printStackTrace();
			if (oDAO != null) oDAO.rollback();
			// Ler a mensagem do Arquivos de Recursos
			Properties props = new Properties();
			InputStream in = getClass().getClassLoader().getResourceAsStream("Recursos.properties"); 
	        props.load(in);
	        // Chave
	 		String[] chave = e.toString().split(":");
	 		for (int i = 0; i < chave.length; i++)
			{
	 			String mensagem = props.getProperty(chave[i].trim());
	 			if (mensagem != null)
		        	throw new ServletException(mensagem);		        	
			}
	 		throw new ServletException(e.toString());
		}
	}
	
	public void destroy()
	{
	}

}
