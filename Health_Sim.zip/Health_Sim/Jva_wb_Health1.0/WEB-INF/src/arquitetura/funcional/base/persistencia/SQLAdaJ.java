package arquitetura.funcional.base.persistencia;
//Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
//Jad home page: http://kpdus.tripod.com/jad.html
//Decompiler options: packimports(3) 
//Source File Name:   SQLAdaJ.java

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

public class SQLAdaJ
{

 private int fnSetaRC(int rc)
 {
     String strTabMsg[] = {
         "SSA600 - RESERVADO", "SSA601 - ERRO NO ENVIO DA MENSAGEM", "SSA602 - ERRO NO RECEBIMENTO DA MENSAGEM", "SSA603 - ESTACAO SEM CONECTIVIDADE", "SSA604 - IDENTIFICACAO DO SERVIDOR INVALIDA", "SSA605 - EXCESSO DE CONEXOES TCP/IP", "SSA606 - TAMANHO DO COMANDO EXCEDIDO", "SSA607 - FALHA NA CONEXAO", "SSA608 - SERVIDOR SQLADA INATIVO", "SSA609 - SEQUENCIA DE ATUALIZACOES SEM COMMIT", 
         "SSA610 - NAO HA REGISTROS SELECIONADOS PARA LEITURA", "SSA611 - REGISTRO INVALIDO", "SSA612 - COMANDO INVALIDO", "SSA613 - CONEXAO NAO INICIALIZADA", "SSA614 - PARAMETROS INVALIDOS", "SSA615 - MEMORIA INSUFICIENTE", "SSA616 - EXCECAO INTERNA IDENTIFICADA"
     };
     try
     {
         if(rc < -16 || rc > 0)
             rc = -16;
         strMsgErro = strTabMsg[-rc].toString();
         return rc;
     }
     catch(Exception eErro)
     {
         strMetodoErro = ".fnSetaRC";
         strException = eErro.toString();
         return -16;
     }
 }

 private void fnEncripta(StringBuffer sbBufferACodificar, StringBuffer sbBufferCodificado)
 {
     StringBuffer resultado = new StringBuffer(240);
     int AsciiToEbcdic[] = {
         64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 
         64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 
         64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 
         64, 64, 64, 90, 127, 123, 91, 108, 80, 125, 
         77, 93, 92, 78, 107, 96, 75, 97, 240, 241, 
         242, 243, 244, 245, 246, 247, 248, 249, 122, 94, 
         76, 126, 110, 111, 124, 193, 194, 195, 196, 197, 
         198, 199, 200, 201, 209, 210, 211, 212, 213, 214, 
         215, 216, 217, 226, 227, 228, 229, 230, 231, 232, 
         233, 64, 64, 64, 64, 64, 64, 64, 64, 64, 
         64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 
         64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 
         64, 64, 64, 64, 64, 64, 64, 64
     };
     int TbIda[] = {
         1, 109, 36, 3, 38, 23, 58, 21, 76, 103, 
         29, 48, 11, 61, 4, 18, 88, 74, 83, 90, 
         104, 46, 91, 100, 49, 65, 72, 59, 78, 12, 
         44, 13, 73, 51, 53, 37, 94, 28, 19, 75, 
         17, 70, 67, 85, 50, 42, 41, 63, 30, 87, 
         32, 26, 45, 5, 107, 7, 8, 27, 106, 82, 
         96, 98, 80, 57, 14, 52, 95, 60, 55, 84, 
         25, 66, 68, 77, 79, 62, 89, 108, 31, 69, 
         15, 71, 102, 86, 47, 24, 33, 97, 92, 99, 
         35, 16, 10, 9, 56, 6, 39, 2, 22, 81, 
         93, 105, 64, 20, 101, 43, 40, 54, 34, 1, 
         109, 36, 3, 38, 23, 58, 21, 76, 103
     };
     try
     {
         resultado.append(sbBufferACodificar.toString().substring(0, 11));
         int i;
         for(i = 11; i < sbBufferACodificar.length(); i++)
         {
             sbHex = new StringBuffer(Integer.toHexString(AsciiToEbcdic[Character.toUpperCase(sbBufferACodificar.charAt(i))]));
             if(sbHex.length() < 2)
                 resultado.append("0");
             resultado.append(sbHex);
         }

         sbBufferCodificado.setLength(111);
         for(i = 1; i < 111; i++)
             sbBufferCodificado.append(' ');

         sbBufferCodificado.setCharAt(0, '0');
         i = 0;
         int j = i + 109;
         for(int s = 0; i < j; s++)
         {
             sbBufferCodificado.setCharAt(TbIda[i], resultado.charAt(s));
             i++;
         }

         sbBufferCodificado.insert(0, sbBufferCodificado.toString().toUpperCase());
         sbBufferCodificado.setLength(110);
     }
     catch(Exception eErro)
     {
         strMetodoErro = ".fnEncripta";
         strException = eErro.toString();
         fnSetaRC(-16);
     }
 }

 private int fnCompacta(StringBuffer sbBufferCompactado, StringBuffer sbBufferACompactar)
 {
     int tamcompr = 1;
     try
     {
         sbBufferCompactado.setLength(sbBufferACompactar.length());
         int i = 0;
         int j = 0;
         for(; sbBufferACompactar.charAt(i) != 0; i++)
             if(sbBufferACompactar.charAt(i) == '@')
             {
                 sbBufferCompactado.setCharAt(j, '@');
                 sbBufferCompactado.setCharAt(j + 1, '@');
                 j += 2;
             } else
             if(sbBufferACompactar.charAt(i) == '\'' || sbBufferACompactar.charAt(i) == '"' || sbBufferACompactar.charAt(i) == '>' || sbBufferACompactar.charAt(i) == '<' || sbBufferACompactar.charAt(i) == '(' || sbBufferACompactar.charAt(i) == ')' || sbBufferACompactar.charAt(i) == '=')
             {
                 sbBufferCompactado.setCharAt(j, sbBufferACompactar.charAt(i));
                 j++;
             } else
             if(sbBufferACompactar.charAt(i) == sbBufferACompactar.charAt(i + 1) && tamcompr < 36)
                 tamcompr++;
             else
             if(tamcompr > 3)
             {
                 sbBufferCompactado.setCharAt(j, '@');
                 sbBufferCompactado.setCharAt(j + 1, TabComp.charAt(tamcompr - 1));
                 sbBufferCompactado.setCharAt(j + 2, sbBufferACompactar.charAt(i));
                 j += 3;
                 tamcompr = 1;
             } else
             {
                 for(int k = 0; k < tamcompr;)
                 {
                     sbBufferCompactado.setCharAt(j, sbBufferACompactar.charAt(i));
                     k++;
                     j++;
                 }

                 tamcompr = 1;
             }

         return j;
     }
     catch(Exception eErro)
     {
         strMetodoErro = ".fnCompacta";
         strException = eErro.toString();
         return -16;
     }
 }

 public int SAConnect(String strUsuario, String strSenha, String strAplicacao, String strHost)
     throws IOException
 {
     String CmdCICS = "SQLT";
     int iIndiceAT = 0;
     StringBuffer sbMsgIn = new StringBuffer("");
     StringBuffer sbWKCmdID = new StringBuffer(63);
     StringBuffer sbCodificado = new StringBuffer(111);
     try
     {
         for(iIndiceAT = 0; SocketNum[iIndiceAT] != null && iIndiceAT < MaxSocket; iIndiceAT++);
         if(iIndiceAT >= MaxSocket)
             return fnSetaRC(-5);
         MaxResp[iIndiceAT] = InitMaxResp;
         sbMsgIn.setLength(MaxResp[iIndiceAT]);
         if(strUsuario == null || strSenha == null || strAplicacao == null || strHost == null)
             return fnSetaRC(-14);
         if(strUsuario.length() > 11 || strUsuario.length() == 0 || strSenha.length() > 24 || strSenha.length() == 0 || strAplicacao.length() > 25 || strAplicacao.length() == 0 || strHost.length() == 0)
             return fnSetaRC(-14);
         int ptrPos = strHost.indexOf(':');
         String strWKHost;
         if(ptrPos > 0)
         {
             strWKHost = strHost.substring(0, ptrPos);
             String strWKPort = strHost.substring(ptrPos + 1);
             PortNumber = Integer.parseInt(strWKPort);
         } else
         {
             strWKHost = strHost;
         }
         try
         {
             SocketNum[iIndiceAT] = new Socket(strWKHost, PortNumber);
         }
         catch(IOException e)
         {
             strMetodoErro = "SAConnect";
             strException = e.toString();
             return fnSetaRC(-3);
         }
         int rc;
         try
         {
             rc = fnSend(iIndiceAT, CmdCICS);
             if(rc < 0)
                 return fnSetaRC(rc);
             rc = fnRecv(iIndiceAT, sbMsgIn);
             if(rc < 0)
                 return fnSetaRC(rc);
         }
         catch(Exception e)
         {
             strMetodoErro = "SAConnect";
             strException = e.toString();
             return fnSetaRC(-1);
         }
         String sCmdID;
         try
         {
             for(int i = 1; i < 64; i++)
                 sbWKCmdID.append(' ');

             sbWKCmdID.insert(0, strUsuario);
             sbWKCmdID.insert(11, strSenha);
             sbWKCmdID.insert(35, strAplicacao);
             fnEncripta(sbWKCmdID, sbCodificado);
             sCmdID = "ID " + sbCodificado.toString() + "2.5";
         }
         catch(Exception e)
         {
             strMetodoErro = "SAConnect";
             strException = e.toString();
             return fnSetaRC(-16);
         }
         try
         {
             rc = fnSend(iIndiceAT, sCmdID);
             if(rc < 0)
             {
                 SADisconnect(iIndiceAT);
                 return fnSetaRC(rc);
             }
             rc = fnRecv(iIndiceAT, sbMsgIn);
             if(rc < 0)
             {
                 SADisconnect(iIndiceAT);
                 return fnSetaRC(rc);
             }
         }
         catch(Exception e)
         {
             strMetodoErro = "SAConnect";
             strException = e.toString();
             SADisconnect(iIndiceAT);
             return fnSetaRC(-1);
         }
         try
         {
             int len = rc;
             String strMsg = sbMsgIn.toString();
             if(!strMsg.regionMatches(6, "0000", 0, 4))
             {
                 strMsgErro = strMsg.substring(10, len - 6);
                 rc = -Integer.parseInt(strMsg.substring(6, 10));
                 SADisconnect(iIndiceAT);
             } else
             {
                 fnTrataComandoID(iIndiceAT, sbMsgIn);
                 rc = fnVerificaMemoria(iIndiceAT, sbMsgIn);
                 strArea = strMsg.substring(10, len - 6);
                 rc = iIndiceAT;
             }
         }
         catch(Exception e)
         {
             strMetodoErro = "SAConnect";
             strException = e.toString();
             return fnSetaRC(-1);
         }
         return rc;
     }
     catch(Exception eErro)
     {
         strMetodoErro = "SAConnect";
         strException = eErro.toString();
         return fnSetaRC(-16);
     }
 }

 public int SACommand(int iIndiceAT, String strComandoRecebido)
 {
     StringBuffer sbMsgIn = new StringBuffer("");
     String strCmdAuth = "COMMIT DELETE EXEC INSERT ROLLBACK SELECT UPDATE PARM SET GETSET ";
     try
     {
         if(iIndiceAT < 0)
             return fnSetaRC(-13);
         String strComando;
         String strCmd;
         try
         {
             strComando = strComandoRecebido.concat(" ");
             strCmd = strComando.substring(0, strComando.indexOf(' ') + 1);
             if(strCmdAuth.indexOf(strCmd) < 0)
                 return fnSetaRC(-12);
             QtdeReg[iIndiceAT] = 0;
             RegTela[iIndiceAT] = 0;
             TamanhoReg[iIndiceAT] = 0;
         }
         catch(Exception e)
         {
             strMetodoErro = "SACommand";
             strException = e.toString();
             return fnSetaRC(-16);
         }
         try
         {
             if(strCmd.compareTo("GETSET ") == 0)
             {
                 if(strComando.indexOf("CLIENTID") > 0)
                 {
                     strArea = InetAddress.getLocalHost().getHostAddress();
                     return strArea.length();
                 }
                 if(strComando.indexOf("SERVERINFO") > 0)
                 {
                     strArea = strSVInfo[iIndiceAT];
                     return strArea.length();
                 }
             }
         }
         catch(Exception e)
         {
             strMetodoErro = "SACommand";
             strException = e.toString();
             return fnSetaRC(-16);
         }
         int rc;
         try
         {
             rc = fnSend(iIndiceAT, strComando);
             if(rc < 0)
             {
                 SADisconnect(iIndiceAT);
                 return fnSetaRC(rc);
             }
             rc = fnRecv(iIndiceAT, sbMsgIn);
             if(rc < 0)
             {
                 SADisconnect(iIndiceAT);
                 return fnSetaRC(rc);
             }
         }
         catch(Exception e)
         {
             strMetodoErro = "SACommand";
             strException = e.toString();
             return fnSetaRC(-16);
         }
         int ptrfim;
         try
         {
             if(strCmd.compareTo("SELECT ") == 0)
             {
                 if(sbMsgIn.toString().regionMatches(6, "0000", 0, 4))
                 {
                     ptrfim = sbMsgIn.toString().indexOf('.') + 1;
                     strArea = sbMsgIn.toString().substring(18, ptrfim);
                     QtdeReg[iIndiceAT] = rc = Integer.parseInt(sbMsgIn.toString().substring(10, 18));
                     TamanhoReg[iIndiceAT] = Integer.parseInt(sbMsgIn.toString().substring(18, 23));
                 } else
                 {
                     ptrfim = sbMsgIn.length() - 7;
                     strMsgErro = sbMsgIn.toString().substring(10, rc - 6);
                     strArea = "";
                     rc = -Integer.parseInt(sbMsgIn.toString().substring(6, 10));
                     return rc;
                 }
             } else
             {
                 ptrfim = sbMsgIn.length() - 7;
                 strArea = sbMsgIn.toString().substring(10, sbMsgIn.length() - 6);
             }
         }
         catch(Exception e)
         {
             strMetodoErro = "SACommand";
             strException = e.toString();
             return fnSetaRC(-16);
         }
         try
         {
             int wkrc = -Integer.parseInt(sbMsgIn.toString().substring(6, 10));
             if(wkrc >= 0)
             {
                 rc = wkrc;
                 if(strCmd.compareTo("SELECT ") == 0)
                 {
                     if(sbMsgIn.toString().regionMatches(ptrfim + 1, "SSAEOB", 0, 6))
                     {
                         NextReg[iIndiceAT] = ++ptrfim;
                         RegTela[iIndiceAT] = 1;
                     } else
                     {
                         RegTela[iIndiceAT] = 0;
                     }
                     rc = Integer.parseInt(sbMsgIn.toString().substring(10, 18));
                 } else
                 if(strCmd.compareTo("EXEC ") == 0 && rc == 0)
                     rc = sbMsgIn.length() - 16;
                 else
                 if(strCmd.compareTo("GETSET ") == 0 && rc >= 0)
                     rc = sbMsgIn.length() - 16;
                 else
                 if(strCmd.compareTo("SET ") == 0 && rc >= 0)
                 {
                     rc = fnVerificaMemoria(iIndiceAT, sbMsgIn);
                     if(rc < 0)
                         rc = fnSetaRC(rc);
                 }
             } else
             {
                 strMsgErro = sbMsgIn.toString().substring(10, rc - 6);
                 strArea = "";
                 rc = -Integer.parseInt(sbMsgIn.toString().substring(6, 10));
             }
         }
         catch(Exception e)
         {
             strMetodoErro = "SACommand";
             strException = e.toString();
             return fnSetaRC(-16);
         }
         return rc;
     }
     catch(Exception eErro)
     {
         strMetodoErro = "SACommand";
         strException = eErro.toString();
         return fnSetaRC(-16);
     }
 }

 public int SAGetNext(int iIndiceAT)
 {
     int rc = 0;
     String CmdCont = "CONT=001";
     String SeqAnt = "SSA001";
     StringBuffer sbMsgIn = new StringBuffer("");
     StringBuffer sbRegistro = new StringBuffer("");
     try
     {
         try
         {
             if(iIndiceAT < 0)
                 return fnSetaRC(-13);
             if(QtdeReg[iIndiceAT] == 0)
                 return fnSetaRC(-10);
             sbRegistro.setLength(TamanhoReg[iIndiceAT]);
         }
         catch(Exception e)
         {
             strMetodoErro = "SAGetNext";
             strException = e.toString();
             return fnSetaRC(-16);
         }
         try
         {
             if(RegTela[iIndiceAT] == 0)
             {
                 rc = fnSend(iIndiceAT, CmdCont);
                 if(rc < 0)
                 {
                     SADisconnect(iIndiceAT);
                     return fnSetaRC(rc);
                 }
                 rc = fnRecv(iIndiceAT, sbMsgIn);
                 if(rc < 0)
                 {
                     SADisconnect(iIndiceAT);
                     return fnSetaRC(rc);
                 }
                 if(!sbMsgIn.toString().regionMatches(0, SeqAnt, 0, 6))
                 {
                     strMsgErro = sbMsgIn.toString().substring(10, rc - 6);
                     strArea = "";
                     rc = -Integer.parseInt(sbMsgIn.toString().substring(6, 10));
                 } else
                 {
                     NextReg[iIndiceAT] = 6;
                     RegTela[iIndiceAT] = 1;
                     strRegistros[iIndiceAT] = sbMsgIn.toString();
                     rc = 0;
                 }
             }
         }
         catch(Exception e)
         {
             strMetodoErro = "SAGetNext";
             strException = e.toString();
             return fnSetaRC(-16);
         }
         try
         {
             if(rc == 0)
             {
                 int i = 0;
                 int j = 0;
                 for(; i < TamanhoReg[iIndiceAT]; i++)
                     if(strRegistros[iIndiceAT].charAt(NextReg[iIndiceAT] + j) == '@')
                     {
                         if(strRegistros[iIndiceAT].charAt(NextReg[iIndiceAT] + j + 1) == '@')
                         {
                             sbRegistro.setCharAt(i, strRegistros[iIndiceAT].charAt(NextReg[iIndiceAT] + j + 1));
                             j += 2;
                         } else
                         {
                             int tamcompr = 36 * TabComp.indexOf(strRegistros[iIndiceAT].charAt(NextReg[iIndiceAT] + j + 1));
                             tamcompr += TabComp.indexOf(strRegistros[iIndiceAT].charAt(NextReg[iIndiceAT] + j + 2));
                             for(int k = 0; k < tamcompr; k++)
                                 sbRegistro.setCharAt(i + k, strRegistros[iIndiceAT].charAt(NextReg[iIndiceAT] + j + 3));

                             i += tamcompr - 1;
                             j += 4;
                         }
                     } else
                     {
                         sbRegistro.setCharAt(i, strRegistros[iIndiceAT].charAt(NextReg[iIndiceAT] + j));
                         j++;
                     }

                 NextReg[iIndiceAT] += j;
                 strArea = sbRegistro.toString();
                 if(strRegistros[iIndiceAT].regionMatches(NextReg[iIndiceAT], "SSAEOB", 0, 6))
                     RegTela[iIndiceAT] = 0;
                 QtdeReg[iIndiceAT]--;
                 rc = TamanhoReg[iIndiceAT];
             } else
             {
                 QtdeReg[iIndiceAT] = 0;
             }
         }
         catch(Exception e)
         {
             strMetodoErro = "SAGetNext";
             strException = e.toString();
             return fnSetaRC(-16);
         }
         return rc;
     }
     catch(Exception eErro)
     {
         strMetodoErro = "SAGetNext";
         strException = eErro.toString();
         return fnSetaRC(-16);
     }
 }

 public int SADisconnect(int iIndiceAT)
     throws IOException, Exception
 {
     String CmdFIM = "FIM,SQLAda";
     StringBuffer sbMsgIn = new StringBuffer("");
     try
     {
         if(iIndiceAT < 0)
             return fnSetaRC(-13);
         int rc = fnSend(iIndiceAT, CmdFIM);
         if(rc < 0)
             return fnSetaRC(rc);
         rc = fnRecv(iIndiceAT, sbMsgIn);
         if(rc < 0)
         {
             return fnSetaRC(rc);
         } else
         {
             strArea = sbMsgIn.toString().substring(10, rc - 6);
             SocketNum[iIndiceAT].close();
             SocketNum[iIndiceAT] = null;
             return 0;
         }
     }
     catch(Exception eErro)
     {
         strMetodoErro = "SADisconnect";
         strException = eErro.toString();
         return -16;
     }
 }

 private int fnSend(int iIndiceAT, String strMsg)
     throws Exception
 {
     java.io.OutputStream s1out = SocketNum[iIndiceAT].getOutputStream();
     String sMsgOut = " ";
     try
     {
         PrintWriter output = new PrintWriter(SocketNum[iIndiceAT].getOutputStream());
         if(!strMsg.startsWith("ID ") && !strMsg.startsWith("EBCDIC"))
             sMsgOut = new String(strMsg + "SSAEOB");
         else
             sMsgOut = new String(strMsg);
         int longMsgOut = sMsgOut.length();
         output.write(sMsgOut, 0, sMsgOut.length());
         output.flush();
         return 0;
     }
     catch(Exception eErro)
     {
         strMetodoErro = ".fnSend";
         strException = eErro.toString();
         return -1;
     }
 }

 private int fnRecv(int iIndiceAT, StringBuffer sbMsg)
 {
     int c = 0;
     int iCount = 0;
     try
     {
         sbMsg.setLength(MaxResp[iIndiceAT]);
         InputStream s1In;
         try
         {
             s1In = SocketNum[iIndiceAT].getInputStream();
         }
         catch(IOException _ex)
         {
             return -1;
         }
         iCount = 0;
         try
         {
             while((c = s1In.read()) != -1) 
             {
                 sbMsg.setCharAt(iCount, (char)c);
                 if(++iCount > 6 && sbMsg.toString().regionMatches(iCount - 6, "SSAEOB", 0, 6))
                     break;
             }
         }
         catch(IOException e)
         {
             strMetodoErro = ".fnRecv[1]";
             strException = e.toString();
             return -2;
         }
         sbMsg.setLength(iCount);
         if(!sbMsg.toString().regionMatches(0, "SSA", 0, 3))
             return -8;
         else
             return iCount;
     }
     catch(Exception eErro)
     {
         strMetodoErro = ".fnRecv[2]";
         strException = eErro.toString();
         return -2;
     }
 }

 private int fnVerificaMemoria(int iIndiceAT, StringBuffer sbMsg)
 {
     try
     {
         int iPosParametro = sbMsg.toString().indexOf(",ML=");
         if(iPosParametro != -1)
             MaxResp[iIndiceAT] = Integer.parseInt(sbMsg.toString().substring(iPosParametro + 4, iPosParametro + 9));
         return 0;
     }
     catch(Exception eErro)
     {
         strMetodoErro = ".fnVerificaMemoria";
         strException = eErro.toString();
         return -16;
     }
 }

 private void fnTrataComandoID(int iIndiceAT, StringBuffer sbMsg)
 {
     String strWKSVInfo = "";
     try
     {
         int iPosParametro = sbMsg.toString().indexOf(",SV=");
         if(iPosParametro > 0)
             strWKSVInfo = strWKSVInfo.concat("Versao ") + sbMsg.toString().substring(iPosParametro + 4, iPosParametro + 9);
         else
             strWKSVInfo = strWKSVInfo.concat("Versao 0.0.0");
         iPosParametro = sbMsg.toString().indexOf(",OS=");
         if(iPosParametro > 0)
         {
             iPosParametro += 4;
             if(sbMsg.toString().substring(iPosParametro, iPosParametro + 3).startsWith("MVS"))
             {
                 if(sbMsg.charAt(iPosParametro + 3) == 'E')
                     strWKSVInfo = strWKSVInfo.concat(", Sistema Operacional MVS-ESA");
                 else
                     strWKSVInfo = strWKSVInfo.concat(", Sistema Operacional MVS-XA");
             } else
             {
                 strWKSVInfo = strWKSVInfo.concat(", Sistema Operacional ") + sbMsg.toString().substring(iPosParametro, iPosParametro + 4);
             }
         } else
         {
             strWKSVInfo = strWKSVInfo.concat(", Sistema Operacional     ");
         }
         iPosParametro = sbMsg.toString().indexOf(",MR=");
         if(iPosParametro > 0)
         {
             iPosParametro += 4;
             strWKSVInfo = strWKSVInfo.concat(", Monitor de Teleprocessamento ") + sbMsg.toString().substring(iPosParametro, iPosParametro + 4) + " " + sbMsg.toString().substring(iPosParametro + 4, iPosParametro + 9);
         } else
         {
             strWKSVInfo = strWKSVInfo.concat(", Monitor de Teleprocessamento  0.0.0");
         }
         iPosParametro = sbMsg.toString().indexOf(",BD=");
         if(iPosParametro > 0)
             strWKSVInfo = strWKSVInfo.concat(", Adabas ") + sbMsg.toString().substring(iPosParametro + 4, iPosParametro + 9);
         else
             strWKSVInfo = strWKSVInfo.concat(", Adabas 0.0.0");
         iPosParametro = sbMsg.toString().indexOf(",SK=");
         if(iPosParametro > 0)
         {
             if(sbMsg.toString().substring(iPosParametro, iPosParametro + 3).startsWith("SNA"))
                 strWKSVInfo = strWKSVInfo.concat(", Comunicacao SNA 0.0.0");
             else
             if(sbMsg.toString().substring(iPosParametro, iPosParametro + 3).startsWith("ILK"))
                 strWKSVInfo = strWKSVInfo.concat(", Comunicacao TCP/IP INTERLINK ") + sbMsg.toString().substring(iPosParametro + 4, iPosParametro + 9);
             else
                 strWKSVInfo = strWKSVInfo.concat(", Comunicacao TCP/IP IBM ") + sbMsg.toString().substring(iPosParametro + 4, iPosParametro + 9);
         } else
         {
             strWKSVInfo = strWKSVInfo.concat(", Comunicacao  0.0.0");
         }
         strSVInfo[iIndiceAT] = strWKSVInfo;
         return;
     }
     catch(Exception eErro)
     {
         strMetodoErro = ".fnTrataComandoID";
         strException = eErro.toString();
         return;
     }
 }

 public SQLAdaJ()
 {
     PortNumber = 3001;
     sbHex = new StringBuffer(5);
     TabComp = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
     strMsgErro = " ";
     strArea = " ";
     strMetodoErro = " ";
     strException = " ";
 }

 private static int MaxSocket;
 private static int InitMaxResp = 2001;
 private static int MaxResp[];
 private static Socket SocketNum[];
 private static int QtdeReg[];
 private static int RegTela[];
 private static int NextReg[];
 private static int TamanhoReg[];
 private static String strRegistros[];
 private static String strSVInfo[];
 private int PortNumber;
 private StringBuffer sbHex;
 private String TabComp;
 public String strMsgErro;
 public String strArea;
 public String strMetodoErro;
 public String strException;

 static 
 {
     MaxSocket = 50;
     MaxResp = new int[MaxSocket];
     SocketNum = new Socket[MaxSocket];
     QtdeReg = new int[MaxSocket];
     RegTela = new int[MaxSocket];
     NextReg = new int[MaxSocket];
     TamanhoReg = new int[MaxSocket];
     strRegistros = new String[MaxSocket];
     strSVInfo = new String[MaxSocket];
 }
}
