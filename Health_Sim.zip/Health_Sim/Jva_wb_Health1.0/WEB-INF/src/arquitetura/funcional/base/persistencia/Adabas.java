/**
 * Encapsular a execu��o de comandos no servidor Adabas
 * Franz� 09/02/2007
 */
package arquitetura.funcional.base.persistencia;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Adabas {
	SQLAdaJ objAda = null;

	private Map ERROS = new HashMap(); 
	
	//Par�metros de conex�o
	private String host;
	private String usuario;
	private String senha;
	private String perfil;
	
	//Array para armazenar a quantidade de caracteres contida em cada uma das colunas da resposta
	private List tamanhoCampos = new ArrayList();						
	
	//Array para armazenar os tipos dos campos da resposta 
	private List tipoCampos = new ArrayList();
	
	//Array para armazenar os nomes dos campos da resposta
	private List nomeCampos = new ArrayList();
	
	//Array para armazenar a resposta
	//A resposta tem um formato tabular, sendo formada por uma lista de listas
	private List resposta = new ArrayList();
	
	//N�mero de linhas e colunas no resultado
	private int numLinhas;
	private int numColunas;

	
	int iCon = 0; // Valor de retorno da rotina SAConnect
	String msgErro = ""; // Mensagem de erro	
	
	public Adabas(String host, String perfil, String senha, String usuario) {
		//super();
		
		ERROS.put(new Integer(901),"SSA901 - Comando incompleto");
		ERROS.put(new Integer(902),"SSA902 - Fim de texto inesperado");
		ERROS.put(new Integer(903),"SSA903 - Comando sem campos");
		ERROS.put(new Integer(904),"SSA904 - Comando sem DBID/File Number");
		ERROS.put(new Integer(905),"SSA905 - Cl�usula WHERE sem campos");
		ERROS.put(new Integer(906),"SSA906 - Cl�usula WHERE sem operador");
		ERROS.put(new Integer(907),"SSA907 - Cl�usula WHERE sem literal");
		ERROS.put(new Integer(908),"SSA908 - Cl�usula ORDER sem campo");
		ERROS.put(new Integer(909),"SSA909 - Delimitadores desbalanceados");
		ERROS.put(new Integer(910),"SSA910 - Mensagem SNA recebida � inv�lida");
		ERROS.put(new Integer(912),"SSA912 - Campo (ADANAME) inv�lido");
		ERROS.put(new Integer(913),"SSA913 - Mais campos que o permitido");
		ERROS.put(new Integer(914),"SSA914 - N�mero do banco ou file ADABAS inv�lido");
		ERROS.put(new Integer(915),"SSA915 - Literal informado inv�lido");
		ERROS.put(new Integer(916),"SSA916 - Ocorreu um erro no servidor ou um de seus m�dulos");
		ERROS.put(new Integer(917),"SSA917 - Tipo de campo inv�lido");
		ERROS.put(new Integer(918),"SSA918 - Erro ADABAS");
		ERROS.put(new Integer(920),"SSA920 - Operador inv�lido no na cl�usula WHERE");
		ERROS.put(new Integer(921),"SSA921 - Tentativa de leitura ap�s o �ltimo registro");
		ERROS.put(new Integer(922),"SSA922 - Nome do campo na cl�usula ORDER � inv�lido");
		ERROS.put(new Integer(923),"SSA923 - Operador da cl�usula ORDER deve ser ASC ou DESC");
		ERROS.put(new Integer(925),"SSA925 - Tamanho do registro maior que o permtido");
		ERROS.put(new Integer(926),"SSA926 - �rea insuficiente para execu��o do comando");
		ERROS.put(new Integer(927),"SSA927 - Imposs�vel validar usu�rio");
		ERROS.put(new Integer(928),"SSA928 - O perfil n�o tem acesso ao campo");
		ERROS.put(new Integer(929),"SSA929 - Usu�rio n�o autorizado");
		ERROS.put(new Integer(930),"SSA930 - Rotina inv�lida ou inexistente");
		ERROS.put(new Integer(932),"SSA932 - Comando inexistente");
		ERROS.put(new Integer(933),"SSA933 - Sequ�ncia de comandos sem commit");
		ERROS.put(new Integer(934),"SSA934 - Commit sem comandos anteriores");
		ERROS.put(new Integer(935),"SSA935 - Perfil de acesso inexistente");
		ERROS.put(new Integer(936),"SSA936 - Quantidade de comandos sem COMMIT excedida");
		ERROS.put(new Integer(937),"SSA937 - Operando inv�lido");
		ERROS.put(new Integer(938),"SSA938 - Conte�do inv�lido");
		ERROS.put(new Integer(950),"SSA950 - Arquivo inexistente no perfil");
		ERROS.put(new Integer(952),"SSA952 - Senha ou usu�rio inv�lido");
		ERROS.put(new Integer(953),"SSA953 - Senha ou usu�rio inv�lido");
		ERROS.put(new Integer(954),"SSA954 - Usu�rio bloqueado ou inativo");
		ERROS.put(new Integer(955),"SSA955 - Usu�rio n�o habilitado");
		ERROS.put(new Integer(956),"SSA956 - Erro no processo de valida��o do usu�rio");
		ERROS.put(new Integer(957),"SSA957 - Problemas na recupera��o do sistema");
		ERROS.put(new Integer(958),"SSA958 - Perfil inativo no SenhaRede");
		ERROS.put(new Integer(959),"SSA959 - Nova senha menor que seis posi��es");
		ERROS.put(new Integer(960),"SSA960 - A nova senha n�o pode come�ar com a palavra 'NOVA'");
		ERROS.put(new Integer(961),"SSA961 - A senha n�o pode ser apenas num�rica");
		ERROS.put(new Integer(962),"SSA962 - A senha n�o poder 6 caracteres ou menos");
		ERROS.put(new Integer(963),"SSA963 - A senha n�o pode conter um dos nomes do usu�rio");
		ERROS.put(new Integer(964),"SSA964 - A senha n�o pode repetir uma das seis �ltimas");
		ERROS.put(new Integer(965),"SSA965 - Senha expirada");
		ERROS.put(new Integer(966),"SSA966 - Problemas na grava��o da nova senha");
		ERROS.put(new Integer(967),"SSA967 - Problemas na grava��o do logoff");
		ERROS.put(new Integer(968),"SSA968 - Usu�rio revogado no sistema");
		ERROS.put(new Integer(969),"SSA969 - Problemas no SenhaRede (SAAR)");
		ERROS.put(new Integer(970),"SSA970 - Nova senha deve ser informada");
		ERROS.put(new Integer(980),"SSA980 - Erro TCP");
		ERROS.put(new Integer(981),"SSA981 - Tamanho de mensagem inv�lido");
		ERROS.put(new Integer(982),"SSA982 - Transa��o inv�lida");		
		ERROS.put(new Integer(985),"SSA985 - Comando inicial inv�lido");
		ERROS.put(new Integer(986),"SSA986 - Operando do ID inv�lido");
		ERROS.put(new Integer(987),"SSA987 - M�dulo de par�metros inexistente");
		ERROS.put(new Integer(988),"SSA988 - System file inv�lido");
		ERROS.put(new Integer(989),"SSA989 - ADABAS fora do ar");
		ERROS.put(new Integer(990),"SSA990 - Perfil inexistente");
		ERROS.put(new Integer(991),"SSA991 - O acesso deve ser feito com o fornecimento do subn�vel");
		ERROS.put(new Integer(999),"SSA999 - Erro no servidor SQLADA");		
		
		this.host = host;
		this.perfil = perfil;
		this.senha = senha;
		this.usuario = usuario;
		this.objAda = new SQLAdaJ();
	}

	/**
	 * Realizar a conex�o com o servidor
	 * @return valor booleano indicando se a conex�o foi bem sucedida.
	 *         Em caso de erro, a propriedade msgErro conter� a mensagem correspondente
	 */
	public boolean conectar() {		
		try {
			msgErro = "";	
			iCon = objAda.SAConnect(this.usuario, this.senha, this.perfil,this.host);

			if (iCon < 0) {
				if (ERROS.containsKey(new Integer(iCon*-1))) {
					msgErro = (String) ERROS.get(new Integer(iCon*-1));
				} else {
					msgErro = "Erro ao tentar conex�o com o servidor ADABAS: " + iCon;
				}
			}
		} catch (IOException e) {
			iCon = -1;
			e.printStackTrace();
		}

		return (iCon == 0);
	}
	
	//Executar um comando SQLAda
	public boolean comando(String comando) {
		int iQuant; // Quantidade de itens na resposta
		int iRet; // Valor de retorno da rotina SAGetNext
		List linha = null;
		boolean retorno = true;
				
		msgErro = "";
		
		resposta.clear();
		tamanhoCampos.clear();
		tipoCampos.clear();
		nomeCampos.clear();
		
		iQuant = objAda.SACommand(iCon, comando);
		
		if (iQuant >= 0) {
			//Capturar o formato da resposta
			String str = objAda.strArea;
			str = str.substring(6);		
			
			String tam = "";
			String tipo = "";
			
			for (int i = 0; i < str.length()-5; i+=6) {
				 tam = str.substring(i,i+3);
				 tipo = str.substring(i+4,i+5);
				 tamanhoCampos.add(tam);
				 tipoCampos.add(tipo);
			}			
					
			str = comando.substring(7,comando.indexOf("FROM"));
			
			for (int i = 0; i < str.length()-1; i+=3) {
				nomeCampos.add(str.substring(i,i+3));
			}
			
			for (int i = 1; i <= iQuant; i++) {				
				iRet = objAda.SAGetNext(iCon);
				if (iRet < 0) {
					this.msgErro = objAda.strMsgErro;
				} else {
					linha = new ArrayList();
					str = objAda.strArea;
					int pos = 0;
					
					for (int j = 0; j < tamanhoCampos.size(); j++ ){
						int itam = Integer.parseInt((String) tamanhoCampos.get(j));						
						if (tipoCampos.get(j).equals("U") == true) {
							linha.add(new Long(str.substring(pos+1,pos+itam)));
						} else {
							linha.add(str.substring(pos,pos+itam));
						}
						pos += itam;
					}
					resposta.add(linha);
				}				
			}					
		} else {
			if (ERROS.containsKey(new Integer(iQuant*-1))) {
				msgErro = (String) ERROS.get(new Integer(iQuant*-1));
			} else {
				this.msgErro = objAda.strMsgErro;
			}
						
			retorno = false;
		}
		
		numLinhas = resposta.size();
		numColunas = tamanhoCampos.size();
		return retorno;
	}
	
	public void desconectar() {
		try {
			objAda.SADisconnect(iCon);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Retorna a �ltima mensagem de erro do objeto SQLAda
	 * @return
	 */
	public String getMsgErro() {
		return msgErro;
	}

	/**
	 * Retorna uma lista contendo os nomes dos campos
	 * que s�o resultados da execu��o do comando
	 */
	public List getNomeCampos() {
		return nomeCampos;
	}

	/**
	 * Retorna a resposta do �ltimo comando executado
	 * O formato da resposta � uma lista contendo uma outra lista,
	 * na qual est�o armazenados cada um dos campos
	 * @return
	 */
	public List getResposta() {
		return resposta;
	}

	/**
	 * Retorna uma lisya contendo o tamanho de cada
	 * um dos campos da resposta
	 */
	public List getTamanhoCampos() {
		return tamanhoCampos;
	}

	/**
	 * Retorna uma lista contendo os tipos de cada um dos campos
	 * que vir�o na resposta: U->num�rico  A->Alfanum�rico 
	 */
	public List getTipoCampos() {
		return tipoCampos;
	}

	/**	
	 * Quantidade de colunas em cada linha do resultado
	 */
	public int getNumColunas() {
		return numColunas;
	}

	/**
	 * Quantidade de linhas contidas no resultado 
	 */
	public int getNumLinhas() {
		return numLinhas;
	}
}
