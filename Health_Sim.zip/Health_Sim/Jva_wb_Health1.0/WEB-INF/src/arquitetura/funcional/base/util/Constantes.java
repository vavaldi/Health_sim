package arquitetura.funcional.base.util;



public class Constantes {
	
	private Constantes() 
	{
	}

	//////////////// Constantes Inst�veis ////////////////	
	public static final int SISTEMA = 1; // C�digo do sistema no Controle de Acesso


	//////////////// Constantes Est�veis ////////////////	
	public static final String CONFIG = "configuracoes";

	public final static String CRYPTOGRAPHY = "_CRYPTOGRAPHY_";

	public final static String DOWNLOAD_DATA = "_DOWNLOAD_";

	public final static String USER_KEY = "_USER_KEY";

	public final static String NT_USER_KEY = "_NT_USER_KEY_";

	public static final String MODODEBUG = "MODODEBUG";

	public final static String SUBJECT_SESSION_KEY = "SUBJECT_SESSION_KEY";

	public final static String PDM_SCREEN_KEY = "PDM_SCREEN_KEY";

	public final static int EQUALS = 1;

	public final static int START_WITH = 2;

	public final static int END_WITH = 3;

	public final static int CONTAINS = 4;

	public final static String ACTION = "_ACTION";

	public final static String ENCODER = "UTF-8";

	public final static String ERROR_PAGE = "errorPage";

	public static final String VIEW_ACCESS_DENIED = "VIEW_ACCESS_DENIED";

	public static final String ACCESS_CONTROLLER = "_ACCESS_CONTROLLER_";

	public static final String DATA_FORMATO = "dd/MM/yyyy";

	public static final String DATA_FORMATO_COMPLETO = "yyyy-MM-dd HH:mm:ss.mmm";

	public static final String PERMISSAO = "permissao";

/* Inclus�o das entradas do arquivo Constants.java */
	/**
	 * Vari�vel que ser� usada no t�tulo da janela 
	 *   
	 */
//	public static final String SISTEMA = "4";  // Inserir o c�digo do sistema na tabela SIS_SISTEMA (SEGURAN�A)
	public static final String TITULO = ".:: Solu��es em Tecnologia ::.";
	public static final String NOME_SISTEMA = "Trime Health";
	public static final String LOGO_1 = "";
	public static final String LOGO_2 = "";
	public static final String USUARIO_LOGADO = "entUsuarioLogado"; 
	public static final String PESSOA_LOGADA = "entPessoaLogada"; 
	public static final String PESSOA_PERFIS = "lstPerfil"; 
	public static final String PESSOA_ORGANIZACOES = "lstOrganizacao"; 
	public static final String ORGANIZACAO_ALVO = "entOrganizacao"; 
	public static final String ORGANIZACOES_CONFIANCA = "lstOrganizacaoConfianca"; 
	public static final Long[] ORGANIZACOES_LIBERADAS = {(long) -1}; //{(long) 2}; // Colocar isso em um cadastro pr�prio
	public static final String PERFIL_ALVO = "entPerfilLogado"; 
	public static final String COMANDO_REQUISICAO = "comandoRequisicao"; 
	public static final String URL_METODO = "metodo"; 

	/** Regras de Senhas: Tamanho M�nimo. */
	public static final Integer SENHA_TAMANHO_MINIMO = 5; 
	public static final Integer SENHA_TAMANHO_MAXIMO = 12; 
	
	
	/**
	 * Indica o datasource local para acesso aos dados via pool de conex�es.
	 * 
	 * ISTO IMPLICAR� NA RETIRADA DO CLASSNAME, URL_CONNECTION, USER_KEY E KEY !!!
	 * 
	 */
	public static final String DS_LOCAL = "java:/comp/env/dsLocal";

	/**
	 * Indica o c�digo do grupo de administradores do sistema (com base no sistema de seguran�a).
	 */
	public static final String GRP_ADMIN = "???"; 

	/**
	 * Vari�vel que ser� usada no Class.forName 
	 * para conex�o com o Banco
	 * public static final String className = "oracle.jdbc.driver.OracleDriver";	  
	 */
	public static final String className = "com.mysql.jdbc.Driver"; // Alterar para a classe correta
	
	/**
	 * Vari�vel que ser� usada no DriverManager.getConnection 
	 * na cria��o da conex�o
	 * public static final String urlConnection = "jdbc:oracle:thin:@172.25.131.76:1521:cgora2"; 
	 */
	static String urlConnection; 
	public static String getUrlConnection() // Caso haja necessidade de virar pacote, deve tornar-se "default" (sem public) 
	{
		if (null == urlConnection)
			urlConnection = "jdbc:mysql://localhost/scipe?user=root&password=fabaixim"; // Alterar para a conex�o correta
		return urlConnection;
	}

	/**
	 * The session scope attribute under which the Username
	 * for the currently logged in user is stored.
	 */
//	static String USER_KEY; 
//	public static String getUSER_KEY() // Caso haja necessidade de virar pacote, deve tornar-se "default" (sem public)
//	{
//		if (null == USER_KEY)
//			USER_KEY = "root"; // Alterar para o usu�rio do banco
//		return USER_KEY;
//	}

	/**
	 * Senha do Esquema
	 */
	static String KEY; 
	public static String getKEY() // Caso haja necessidade de virar pacote, deve tornar-se "default" (sem public)
	{
		if (null == KEY)
			KEY = "fabaixim"; // Alterar para a senha do usu�rio do banco
		return KEY;
	}
	
	/**
	 * The token that represents a nominal outcome
	 * in an ActionForward.
	 */
	public static final String SUCESSO = "sucesso";

	/**
	 * The token that represents a nominal outcome
	 * in an ActionForward.
	 */ 
	public static final String FALHA = "falha";

	/**
	 * The token that represents the logon activity
	 * in an ActionForward.
	 */
	public static final String LOGON = "logon";

	/**
	 * Vari�veis que abrigam os comandos
	 * 
	 */
	public static final String EXIBIR = "exibir"; 
	public static final String INCLUIR = "incluir"; 
	public static final String CONSULTAR = "consultar"; 
	public static final String CADASTRAR = "cadastrar"; 
	public static final String EDITAR = "editar"; 
	public static final String ALTERAR = "alterar"; 
	public static final String EXCLUIR = "excluir"; 
	public static final String AUTENTICAR = "autenticar"; 
	public static final String LOGOFF = "logoff"; 
	public static final String CHECK_ON = "Sim"; 
	public static final String CHECK_OFF = "N�o"; 
	public static final String LOV = "lov";
	public static final String LISTAR = "listar";

	/**
	 * The token that represents the welcome activity
	 * in an ActionForward.
	 */
	public static final String WELCOME = "Seja Bem-Vindo...";


	/**
	 * The value to indicate debug logging.
	 */
	public static final int DEBUG = 1;


	/**
	 * The value to indicate normal logging.
	 */
	public static final int NORMAL = 0;

	/**
	 * Indica o path das imagens do sistema.
	 */
//	public static final String PATH_IMG = "\\\\intranet\\intra\\Sistemas\\tema\\imagens";
//	public static final String PATH_IMG = "http://banco/sistemas/tema/imagens";
//	public static final String PATH_IMG = "http://localhost/sistemas/tema/imagens"; // PADR�O
	public static final String PATH_IMG = "recursos/tema/imagens"; // Mudei para funcionar antes de estar no servidor. 
	public static final String PATH_IMG_APP = "/recursos/imagens";

	/**
	 * Indica os arquivos CSS (geral e da aplica��o) que ser�o utilizados pelo sistema.
	 */
//	public static final String ARQUIVO_CSS = "\\\\intranet\\intra\\Sistemas\\tema\\global.css";
//	public static final String ARQUIVO_CSS = "http://banco/sistemas/tema/global.css";
//	public static final String ARQUIVO_CSS = "http://localhost/sistemas/tema/global.css";
	public static final String ARQUIVO_CSS = "recursos/tema/global.css"; 
	public static final String ARQUIVO_CSS_APP = "/layouts/local.css";

}
