package arquitetura.funcional.base.excecao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

public class SerproException extends Exception
{
	private static final long serialVersionUID = -8661099494677889034L;

	private List listaErros, listaMensagens;

	private ActionErrors actionErrors;

	public SerproException(String msg)
	{
		super(msg);
	}

	public SerproException(List listaErros)
	{
		this.listaErros = listaErros;
	}

	public SerproException(Exception e)
	{
		String chave = e.toString();
		chave = chave.toString().substring(0, chave.toString().indexOf(":"));

		if (listaErros == null)
			listaErros = new ArrayList();
		listaErros.add(chave);

		// Armazenas as mensagens dos Exception
		if (listaMensagens == null)
			listaMensagens = new ArrayList();
		listaMensagens.add(e.getMessage());
	}

	public SerproException(ActionErrors erros)
	{
		this.actionErrors = erros;
	}

	public ActionErrors getActionErrors()
	{
		return actionErrors;
	}

	public List getListaErros()
	{
		return listaErros;
	}

	public List getListaMensagens()
	{
		return listaMensagens;
	}

	public boolean isListaVazia()
	{
		if (listaErros == null)
			return true;
		return (listaErros.isEmpty());
	}
}
