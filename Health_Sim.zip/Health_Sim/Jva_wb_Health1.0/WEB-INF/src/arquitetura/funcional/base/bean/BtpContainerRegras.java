package arquitetura.funcional.base.bean;

import java.util.List;

import arquitetura.funcional.health.entidades.EntRegraNegocio;


public class BtpContainerRegras
{ 
	public static final ThreadLocal userThreadLocal = new ThreadLocal();

	public static void set(BtpListaRegras user) 
	{
		userThreadLocal.set(user);
	}

	public static void unset() 
	{
		userThreadLocal.remove();
	}

	public static BtpListaRegras get() 
	{
		if ((BtpListaRegras)userThreadLocal.get() == null)
			return new BtpListaRegras();
		else
			return (BtpListaRegras)userThreadLocal.get();
	}
}
