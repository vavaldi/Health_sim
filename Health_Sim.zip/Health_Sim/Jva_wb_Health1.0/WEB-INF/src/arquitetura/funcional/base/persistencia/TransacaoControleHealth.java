package arquitetura.funcional.base.persistencia;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.exception.SQLGrammarException;

import arquitetura.funcional.base.excecao.SerproException;

public class TransacaoControleHealth {

	public static void commit() throws SerproException {
		IDAO oDAO = null;
		try {
			oDAO = new GenericDAOHealth(null);
			oDAO.commit();

		} catch (Exception e) {
			oDAO.rollback();
			e.printStackTrace();			
			throw tratarExcecao(e);
		}
	}
	
	
	public static void rollback() throws SerproException {
		IDAO oDAO = null;
		try {
			oDAO = new GenericDAOHealth(null);
			oDAO.rollback();

		} catch (Exception e) {
			oDAO.rollback();
			e.printStackTrace();			
			throw tratarExcecao(e);
		}
	}
	
	
	public static SerproException tratarExcecao(Exception exception){
		
		List<String> erros = new ArrayList<String>();
		SerproException se = null;
		
		if(exception instanceof ConstraintViolationException){
			erros.add("org.hibernate.exception.ConstraintViolationException");
			
		}else if(exception instanceof SQLGrammarException){			
			erros.add("org.hibernate.exception.SQLGrammarException");
			
		} else {
			erros.add("erros.hibernate.texto");
		}
		
		se = new SerproException(erros);		
		return se;
	}
	

}
