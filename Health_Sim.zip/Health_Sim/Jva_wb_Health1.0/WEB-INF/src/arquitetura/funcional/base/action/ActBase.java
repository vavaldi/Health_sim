package arquitetura.funcional.base.action;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.actions.DispatchAction;
import org.hibernate.Session;

import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.base.excecao.SerproException;
//import arquitetura.funcional.bean.BtpLogin;
//import arquitetura.funcional.entidades.EntPessoa;
//import arquitetura.funcional.negocio.NgcPessoa;

public class ActBase extends DispatchAction implements Comparator
{
	private static final ThreadLocal _criticas = new ThreadLocal();
	private String campo;
	private static ActBase instance;

	@SuppressWarnings("unchecked")
	private void addCritica(SerproException e)
	{
		_criticas.set(e);
	}

	@SuppressWarnings("unchecked")
	public void limpaCriticas()
	{
		_criticas.set(null);
	}

	private boolean isListaVazia()
	{
		SerproException e = (SerproException) _criticas.get();
		return e.isListaVazia();
	}

	public String printCriticas()
	{
		SerproException e = (SerproException) _criticas.get();
		Iterator it = e.getListaErros().iterator();
		String msg = "";
		while (it.hasNext())
		{
			msg += it.next() + "\n";
		}

		if (e.getListaMensagens() != null)
		{
			it = e.getListaMensagens().iterator();
			while (it.hasNext())
			{
				msg += it.next() + "\n";
			}
		}
		return msg;
	}

	public boolean hasCriticas()
	{
		return (_criticas.get() != null && !isListaVazia());
	}
	
	// Adiciona as mensagens positivas do Sistema
	public void addMensagensSucesso(HttpServletRequest req, String chave)
	{
		ActionMessages mens = new ActionMessages(); 
		mens.add("sucesso", new ActionMessage(chave));			
		saveMessages(req, mens);
	}
	
	public void addMensagensErro(HttpServletRequest req, String chave)
	{
		ActionMessages mens = new ActionMessages(); 
		mens.add("errors", new ActionMessage(chave));			
		this.addErrors(req, mens);
	}
	
	@SuppressWarnings("deprecation")
	public void addErrosValidacao(SerproException e, HttpServletRequest req)
	{
		addCritica(e);
		if (e.getActionErrors() != null)
			saveErrors(req, e.getActionErrors());       // Erros do Validator
		else
		{
			Iterator it = e.getListaErros().iterator(); // Erros de Neg�cio
			while (it.hasNext())
			{
				ActionMessages messages = new ActionMessages();
				messages.add("errors", new ActionMessage((String) it.next()));
				this.addErrors(req, messages);
			}
		}
	}
	
	// Coloca no Request e Retorna o usuario
//	public EntPessoa carregarUsuarioLogado(HttpServletRequest req) throws SerproException
//	{
//		HttpSession session = req.getSession(); 			
//		BtpLogin bl = (BtpLogin) session.getAttribute("usuario_logado");
//		EntPessoa entPes = new EntPessoa();
//		NgcPessoa ngc = new NgcPessoa();
//		if (bl != null)
//		{
//			entPes.setPesNumCpf(bl.getLogin()); 
//			entPes = (EntPessoa) ngc.consultaCpf(entPes);
//		}
//		req.setAttribute("entPessoa", entPes);
//		return entPes; 
//	} 
	
	public void alimentarLov(HttpServletRequest req, Object entidade, Object valorAtributo, String chaveDescricao, String baseEntidades) throws SerproException
	{
    	// Montagem a partir de "entEmpregado.entPessoa.pesDscNome"
    	String[] campoDsc = getResources(req).getMessage(chaveDescricao).split("\\.");
		String proximoCampo = "";
		Object entAux = entidade;
		int j = 0;
    	try
		{
			for (j = 0; j < campoDsc.length-1; j++)
			{
				// Ap�s os gets... Aplica o set para a nova entidade
				//entEmpregado.entPessoa.pesDscNome
				String campo = campoDsc[j].substring(0,1).toUpperCase() + campoDsc[j].substring(1);
				entAux.getClass().getMethod("set" + campo, new Class[] { Class.forName(baseEntidades + campo) } ).invoke(entAux, Class.forName(baseEntidades + campo, true, this.getClass().getClassLoader()).newInstance());
				proximoCampo = "get" + campo;
				// Aplica os gets necess�rios;
				entAux = entAux.getClass().getMethod(proximoCampo,  new Class[] { }).invoke(entAux);
			}
			//entTmpAdr.setEntEmpregado(new EntEmpregado());
			//entTmpAdr.getEntEmpregado().setEntPessoa(new EntPessoa());
			// Substituir "." por .get<MAIUSC>
			//entTmpAdr.getEntEmpregado().getEntPessoa().setPesDscNome(adrIdtChaveDsc[i]);
			String campo = campoDsc[j].substring(0,1).toUpperCase() + campoDsc[j].substring(1);
			entAux.getClass().getMethod("set" + campo, new Class[] { String.class } ).invoke(entAux, valorAtributo);
		} catch (IllegalArgumentException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//private synchronized static ActBase getInstance() 
	public synchronized static ActBase getInstance() 
	{
		if (instance == null) {
			instance = new ActBase();
		}
		return instance;
	}

	public Object extraiValorInstancia(Object objEntrada, String token) throws ClassNotFoundException
	{
		// Vari�veis de controle
		String[] vetToken = {};
		int cont = 0;

		Object objAlvo = objEntrada; 
		
		// Busca 
		if (null != objAlvo && null != token)
		{
			if (token.length() > 0)
			{
				vetToken = token.split("\\.");

				// Identifica a origem do token
				if (null != vetToken[0])
				{
					while (cont <= vetToken.length-1)
					{
						// Captura o item a ser processado
						token = vetToken[cont].trim();
						
						if (null != token && token.length() > 0)
						{
							Class<?>[] args = new Class[0];
							try 
							{
								// Captura valores dos objetos
								if (null != objAlvo)
								{
									// Conforme o token da regra, seleciona o tipo de objeto: Entidade, Lista ou Propriedade
									if (objAlvo instanceof List)
									{	
										// Prepara lista de retorno
										List<Object> tmpLst = new ArrayList<Object>();
										for (Iterator iterator = ((List<?>)objAlvo).iterator(); iterator.hasNext();)
										{
											Object obj = (Object) iterator.next();
											if (null != obj)
											{
												// Caso objValor seja um objeto at�mico, executa o m�todo "getXX" sobre o mesmo.
												Method metodo = obj.getClass().getMethod("get" + token.substring(0, 1).toUpperCase() + token.substring(1), args);
												tmpLst.add(metodo.invoke(obj));
											}
										}
										// Atribui a tmpList ao objValor
										if (tmpLst != null)
											objAlvo = tmpLst;
									} else
									{
										// Caso objValor seja um objeto at�mico, executa o m�todo "getXX" sobre o mesmo.
										Method metodo = objAlvo.getClass().getMethod("get" + token.substring(0, 1).toUpperCase() + token.substring(1), args);
										objAlvo = metodo.invoke(objAlvo);
									}
									
									// Verifica��o do Lazy Loading...
//										if (objValor instanceof List)
//										{
//											// Caso n�o tenha sido inicializado, devido ao lazy loading, associa a uma sess�o e busca o objeto
//											if (! ((PersistentBag)objValor).wasInitialized())
//											{
//												objValor = hibSession.load(objValor.getClass(), ((PersistentBag) objValor).getKey());
//												//objValor = imp.getPersistenceContext().unproxyAndReassociate(((List)objValor).size());
//											}
//										}
								}
							} catch (NoSuchMethodException e) {
								e.printStackTrace();
							} catch (SecurityException e) {
								e.printStackTrace();
							} catch (IllegalAccessException e) {
								e.printStackTrace();
							} catch (IllegalArgumentException e) {
								e.printStackTrace();
							} catch (InvocationTargetException e) {
								e.printStackTrace();
							} 
						}
	
						// Incrementa contador
						cont++;
					}
				}
			}
		}
		// Retorno
		return objAlvo;
	}
		
	public int compare_original(Object primeiro, Object segundo) 
	{
		Object o1 = null, o2 = null;
		Method getMethod = null;
		try {
			if (!(primeiro == null || segundo == null)) {
				if (primeiro instanceof String) {
					return ((String) primeiro).compareToIgnoreCase((String) segundo);
				}						
				Class<?>[] args = new Class[0];
				getMethod = primeiro.getClass().getMethod("get".concat(campo.substring(0, 1).toUpperCase()).concat(campo.substring(1)), args);
				
				o1 = getMethod.invoke(primeiro, null);
				o2 = getMethod.invoke(segundo, null);

				if (o1 != null && o2 != null && o1 instanceof Integer || o1 instanceof Float || o1 instanceof Double
						|| o1 instanceof Byte || o1 instanceof Long) 
				{
					Double numero = new Double(String.valueOf(o1));
					return numero.compareTo(new Double(String.valueOf(o2)));
				}
				if (o1 != null && o2 != null) {
					return String.valueOf(o1).compareToIgnoreCase(String.valueOf(o2));
				}
			}
		} catch (NoSuchMethodException metodo) {
			throw new RuntimeException(metodo);
		} catch (InvocationTargetException invoke) {
			throw new RuntimeException(invoke);
		} catch (IllegalAccessException access) {
			throw new RuntimeException(access);
		}
		return -1;
	}
	
	public int compare(Object primeiro, Object segundo) 
	{
		Object o1 = null, o2 = null;
		Method getMethod = null;
		try {
			if (!(primeiro == null || segundo == null)) {
				if (primeiro instanceof String) {
					return ((String) primeiro).compareToIgnoreCase((String) segundo);
				}						
				Class<?>[] args = new Class[0];
				//getMethod = primeiro.getClass().getMethod("get".concat(campo.substring(0, 1).toUpperCase()).concat(campo.substring(1)), args);
//				o1 = getMethod.invoke(primeiro, null);
//				o2 = getMethod.invoke(segundo, null);
				o1 = extraiValorInstancia(primeiro, campo);
				o2 = extraiValorInstancia(segundo, campo);
				
				if (o1 != null && o2 != null && o1 instanceof Integer || o1 instanceof Float || o1 instanceof Double
						|| o1 instanceof Byte || o1 instanceof Long) 
				{
					Double numero = new Double(String.valueOf(o1));
					return numero.compareTo(new Double(String.valueOf(o2)));
				}
				if (o1 != null && o2 != null) {
					return String.valueOf(o1).compareToIgnoreCase(String.valueOf(o2));
				}
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}

	/**
	 * M�todo respons�vel por retorna uma lista de Object ordenada pelo nome do campo informado
	 * 
	 * @param lista
	 * @param campo
	 * @return
	 */
	public static List ordenarLista(List lista, String campo) 
	{
		if (lista != null && !lista.isEmpty() && campo != null && !(campo.trim().length() == 0)) 
		{
			getInstance().setCampo(campo);
			Collections.sort(lista, getInstance());
		}
		return lista;
	}

	public String getCampo() {
		return campo;
	}

	public void setCampo(String campo) {
		this.campo = campo;
	}
}
