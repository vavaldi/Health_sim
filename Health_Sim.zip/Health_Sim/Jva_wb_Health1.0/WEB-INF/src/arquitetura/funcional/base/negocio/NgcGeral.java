package arquitetura.funcional.base.negocio;

import java.util.ArrayList;
import java.util.List;

import arquitetura.funcional.base.excecao.SerproException;

public class NgcGeral
{
	public List validaListaVazia(List lista) throws SerproException
	{
		if (lista == null || lista.size() == 0) 
		{
			List erros = new ArrayList();
			erros.add("msg.sistema.retorno.listavazia");
			throw new SerproException(erros); 				  
		}
		return lista;
		
	}

}
