package arquitetura.funcional.base.bean;

import java.util.List;

import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntPerfil;
import arquitetura.funcional.health.entidades.EntPessoa;
import arquitetura.funcional.health.entidades.EntRegraNegocio;
import arquitetura.funcional.health.entidades.EntUsuario;


public class BtpListaRegras
{ 
	private List<EntRegraNegocio> lstRegraNegocio;
	private EntUsuario entUsuarioLogado;
	private EntPessoa entPessoaLogada;
	private EntOrganizacao entOrganizacao;
	private List<EntOrganizacao> lstOrganizacaoConfianca;
	private Object entBase;
	private List<EntPerfil> lstPerfis;
	
	public List<EntRegraNegocio> getLstRegraNegocio() {
		return lstRegraNegocio;
	}

	public void setLstRegraNegocio(List<EntRegraNegocio> lstRegraNegocio) {
		this.lstRegraNegocio = lstRegraNegocio;
	}

	public EntUsuario getEntUsuarioLogado() {
		return entUsuarioLogado;
	}

	public void setEntUsuarioLogado(EntUsuario entUsuarioLogado) {
		this.entUsuarioLogado = entUsuarioLogado;
	}

	public EntPessoa getEntPessoaLogada() {
		return entPessoaLogada;
	}

	public void setEntPessoaLogada(EntPessoa entPessoaLogada) {
		this.entPessoaLogada = entPessoaLogada;
	}

	public List<EntPerfil> getLstPerfis() {
		return lstPerfis;
	}

	public void setLstPerfis(List<EntPerfil> lstPerfis) {
		this.lstPerfis = lstPerfis;
	}

	public Object getEntBase() {
		return entBase;
	}

	public void setEntBase(Object entBase) {
		this.entBase = entBase;
	}

	public EntOrganizacao getEntOrganizacao() {
		return entOrganizacao;
	}

	public void setEntOrganizacao(EntOrganizacao entOrganizacao) {
		this.entOrganizacao = entOrganizacao;
	}

	public List<EntOrganizacao> getLstOrganizacaoConfianca() {
		return lstOrganizacaoConfianca;
	}

	public void setLstOrganizacaoConfianca(List<EntOrganizacao> lstOrganizacaoConfianca) {
		this.lstOrganizacaoConfianca = lstOrganizacaoConfianca;
	}

	
}
