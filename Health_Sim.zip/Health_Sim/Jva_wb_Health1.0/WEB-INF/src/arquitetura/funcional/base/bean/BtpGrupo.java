package arquitetura.funcional.base.bean;

import arquitetura.funcional.base.bean.BtpGrupoBase;

public class BtpGrupo extends BtpGrupoBase
{

}



