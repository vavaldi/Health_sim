package arquitetura.funcional.base.persistencia;

import java.io.Serializable;
import java.util.List;

import arquitetura.funcional.base.excecao.SerproException;

public interface IDAO
{

	public Class getVO();

	public void setVO(Class classe);

	public Object getConnection();

	public Object getTransaction();

	public void closeConnection();

	public boolean hasTransaction();

	public void commit();

	public void rollback();

	// --- M�todos de manuten��o de dados ------------
	public Object inserir(Object o) throws SerproException;

	public Object alterar(Object o) throws SerproException;

	public Object salvar(Object o) throws SerproException;

	public void excluir(Object o) throws SerproException;

	// --- M�todos de consulta ---------------------
	public Object consultarID(Serializable id) throws SerproException;

	public List consultarTodos() throws SerproException;
	
	public List consultarTodos(String[][] orderBy) throws SerproException;

	public List consultarQBE(Object o) throws SerproException;

	public List consultarQBE(Object o, Object g) throws SerproException;

	public List consultarHabilitados(String[][] orderBy, List lstObj) throws SerproException;
}
