package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcTipoAcessoBase;
//import arquitetura.funcional.health.regra.RngTipoAcesso;

public class NgcTipoAcesso extends NgcTipoAcessoBase
{

}
