package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoMaladieBase;

public class DaoMaladie extends DaoMaladieBase
{
	public DaoMaladie() throws SerproException
	{
		super();
	}
}
