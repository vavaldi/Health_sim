package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntPerfil;
import arquitetura.funcional.health.entidades.EntUsuario;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntPerfilUsuarioBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "PFU_IDT_CHAVE", unique = true, nullable = false)
    private Long pfuIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="PER_IDT_CHAVE") 
    private EntPerfil entPerfil;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="USU_IDT_CHAVE") 
    private EntUsuario entUsuario;

    public Long getPfuIdtChave() {
        return this.pfuIdtChave;
    } 

    public void setPfuIdtChave(Long valor) {
        this.pfuIdtChave = valor;
    } 

    public EntPerfil getEntPerfil() {
        return this.entPerfil;
    } 

    public void setEntPerfil(EntPerfil valor) {
        this.entPerfil = valor;
    } 

    public EntUsuario getEntUsuario() {
        return this.entUsuario;
    } 

    public void setEntUsuario(EntUsuario valor) {
        this.entUsuario = valor;
    } 


}