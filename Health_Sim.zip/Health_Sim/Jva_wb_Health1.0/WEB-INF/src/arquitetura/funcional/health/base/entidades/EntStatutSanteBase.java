package arquitetura.funcional.health.base.entidades;

import javax.persistence.Column;
import javax.persistence.Table;
import arquitetura.funcional.health.entidades.EntEtatSante;
import javax.persistence.Id;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntStatutSanteBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "SST_IDT_CHAVE", unique = true, nullable = false)
    private Long sstIdtChave;

    @Column(name = "SST_DSC_TITRE", nullable = false, length = 45)
    private String sstDscTitre;

    @OneToMany(mappedBy="entStatutSante",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntEtatSante> lstEtatSante;

    public Long getSstIdtChave() {
        return this.sstIdtChave;
    } 

    public void setSstIdtChave(Long valor) {
        this.sstIdtChave = valor;
    } 

    public String getSstDscTitre() {
        return this.sstDscTitre;
    } 

    public void setSstDscTitre(String valor) {
        this.sstDscTitre = valor;
    } 

    public List<EntEtatSante> getLstEtatSante() {
        return this.lstEtatSante;
    } 

    public void setLstEtatSante(List<EntEtatSante> valor) {
        this.lstEtatSante = valor;
    } 


}