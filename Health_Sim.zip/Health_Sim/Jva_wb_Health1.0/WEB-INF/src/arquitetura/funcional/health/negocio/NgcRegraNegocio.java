package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcRegraNegocioBase;
//import arquitetura.funcional.health.regra.RngRegraNegocio;

public class NgcRegraNegocio extends NgcRegraNegocioBase
{

}
