package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntPerfilUsuarioBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "pfu_perfil_usuario")

public class EntPerfilUsuario extends EntPerfilUsuarioBase
{

}
