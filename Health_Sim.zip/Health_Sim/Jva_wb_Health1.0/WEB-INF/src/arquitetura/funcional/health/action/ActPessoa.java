package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActPessoaBase;

public class ActPessoa extends ActPessoaBase
{

}


