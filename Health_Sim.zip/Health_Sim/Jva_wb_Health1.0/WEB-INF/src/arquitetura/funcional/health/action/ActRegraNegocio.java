package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActRegraNegocioBase;

public class ActRegraNegocio extends ActRegraNegocioBase
{

}


