package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntSistema;
import arquitetura.funcional.health.negocio.NgcSistema;
import arquitetura.funcional.health.entidades.EntComando;
import arquitetura.funcional.health.negocio.NgcOrganizacao;
import arquitetura.funcional.health.negocio.NgcUsuario;
import arquitetura.funcional.health.negocio.NgcComando;
import arquitetura.funcional.health.negocio.NgcPerfil;
import arquitetura.funcional.health.negocio.NgcSistemaUsuario;
import arquitetura.funcional.health.entidades.EntSistema;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntPerfil;
import arquitetura.funcional.health.entidades.EntSistemaUsuario;
import arquitetura.funcional.health.entidades.EntTipoAcesso;
import arquitetura.funcional.health.entidades.EntUsuario;
import arquitetura.funcional.health.negocio.NgcTipoAcesso;


public class ActSistemaBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntSistema ent = new EntSistema();
		NgcSistema ngc = new NgcSistema();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);




			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResSis", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntSistema ent = new EntSistema();
		NgcSistema ngc = new NgcSistema();

		try
		{
			ent = (EntSistema) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("sisIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			



//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas
            List<EntComando> lstCmd = ent.getLstComando();
            lstCmd = ordenarLista(lstCmd, getResources(req).getMessage("comando.ordenacao")); 
            req.setAttribute("lstResCmd", lstCmd);

            List<EntPerfil> lstPer = ent.getLstPerfil();
            lstPer = ordenarLista(lstPer, getResources(req).getMessage("perfil.ordenacao")); 
            req.setAttribute("lstResPer", lstPer);

            List<EntSistemaUsuario> lstSus = ent.getLstSistemaUsuario();
            lstSus = ordenarLista(lstSus, getResources(req).getMessage("sistemaUsuario.ordenacao")); 
            req.setAttribute("lstResSus", lstSus);


			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntSistema ent = new EntSistema();
		NgcSistema ngc = new NgcSistema();

		try
		{
			ent = (EntSistema) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("sisIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						


//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas
            List<EntComando> lstCmd = ent.getLstComando();
            lstCmd = ordenarLista(lstCmd, getResources(req).getMessage("comando.ordenacao")); 
            req.setAttribute("lstResCmd", lstCmd);

            List<EntPerfil> lstPer = ent.getLstPerfil();
            lstPer = ordenarLista(lstPer, getResources(req).getMessage("perfil.ordenacao")); 
            req.setAttribute("lstResPer", lstPer);

            List<EntSistemaUsuario> lstSus = ent.getLstSistemaUsuario();
            lstSus = ordenarLista(lstSus, getResources(req).getMessage("sistemaUsuario.ordenacao")); 
            req.setAttribute("lstResSus", lstSus);


			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntSistema ent = new EntSistema();
		NgcSistema ngc = new NgcSistema();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntSistema) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("sisIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio





            if (getResources(req).getMessage("detalhe.sistema.comando.exibir").equals("s"))
            {
                // Salva Comando
                List<EntComando> lstPrsCmd = ent.getLstComando();
                List<EntComando> lstTmpCmd = montarComando(req, form, ent, "");
                AtualizarComando(form, lstPrsCmd, lstTmpCmd);
            }
            if (getResources(req).getMessage("detalhe.sistema.perfil.exibir").equals("s"))
            {
                // Salva Perfil
                List<EntPerfil> lstPrsPer = ent.getLstPerfil();
                List<EntPerfil> lstTmpPer = montarPerfil(req, form, ent, "");
                AtualizarPerfil(form, lstPrsPer, lstTmpPer);
            }
            if (getResources(req).getMessage("detalhe.sistema.sistemaUsuario.exibir").equals("s"))
            {
                // Salva SistemaUsuario
                List<EntSistemaUsuario> lstPrsSus = ent.getLstSistemaUsuario();
                List<EntSistemaUsuario> lstTmpSus = montarSistemaUsuario(req, form, ent, "");
                AtualizarSistemaUsuario(form, lstPrsSus, lstTmpSus);
            }


			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntSistema) ngc.consultarID(ent.getSisIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResSis", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntSistema ent = new EntSistema();
		NgcSistema ngc = new NgcSistema();

		try
		{
			ent = (EntSistema) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("sisIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntSistema ent = new EntSistema();
		NgcSistema ngc = new NgcSistema();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);


            if (getResources(req).getMessage("detalhe.sistema.comando.exibir").equals("s"))
            {
                // Salva Comando
                Integer qtdeComando = Integer.parseInt(req.getParameter("qtdeComando"));
                if (qtdeComando > 0)
                {
                    List<EntComando> lstTmpCmd = montarComando(req, form, ent, "");
                    ent.setLstComando(lstTmpCmd);
                }

            }
            if (getResources(req).getMessage("detalhe.sistema.perfil.exibir").equals("s"))
            {
                // Salva Perfil
                Integer qtdePerfil = Integer.parseInt(req.getParameter("qtdePerfil"));
                if (qtdePerfil > 0)
                {
                    List<EntPerfil> lstTmpPer = montarPerfil(req, form, ent, "");
                    ent.setLstPerfil(lstTmpPer);
                }

            }
            if (getResources(req).getMessage("detalhe.sistema.sistemaUsuario.exibir").equals("s"))
            {
                // Salva SistemaUsuario
                Integer qtdeSistemaUsuario = Integer.parseInt(req.getParameter("qtdeSistemaUsuario"));
                if (qtdeSistemaUsuario > 0)
                {
                    List<EntSistemaUsuario> lstTmpSus = montarSistemaUsuario(req, form, ent, "");
                    ent.setLstSistemaUsuario(lstTmpSus);
                }

            }

			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntSistema) ngc.consultarID(ent.getSisIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResSis", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntSistema ent) throws Exception
	{

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntSistema ent) throws Exception
	{
            if (getResources(req).getMessage("detalhe.sistema.comando.exibir").equals("s"))
            {
                // Salva Comando
                List<EntComando> lstPrsCmd = ent.getLstComando();
                List<EntComando> lstTmpCmd = montarComando(req, form, ent, "");
                AtualizarComando(form, lstPrsCmd, lstTmpCmd);
            }
            if (getResources(req).getMessage("detalhe.sistema.perfil.exibir").equals("s"))
            {
                // Salva Perfil
                List<EntPerfil> lstPrsPer = ent.getLstPerfil();
                List<EntPerfil> lstTmpPer = montarPerfil(req, form, ent, "");
                AtualizarPerfil(form, lstPrsPer, lstTmpPer);
            }
            if (getResources(req).getMessage("detalhe.sistema.sistemaUsuario.exibir").equals("s"))
            {
                // Salva SistemaUsuario
                List<EntSistemaUsuario> lstPrsSus = ent.getLstSistemaUsuario();
                List<EntSistemaUsuario> lstTmpSus = montarSistemaUsuario(req, form, ent, "");
                AtualizarSistemaUsuario(form, lstPrsSus, lstTmpSus);
            }

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntSistema ent) throws Exception
	{

	}

	public void converterValores(ActionForm form)
	{




	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntSistema ent) throws Exception
	{

	
            if (getResources(req).getMessage("detalhe.sistema.comando.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.comando.cmdIdtChavePai.visual").toLowerCase().equals("l") && null == req.getAttribute("lstCmd"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstComandoPai() != null && ent.getLstComandoPai().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstComandoPai().iterator(); iterator.hasNext();)
                        //{
                            //EntComando obj = (EntComando) iterator.next();
                            //l.add(obj.getEntComando());
                        //}
                    //}
                //}
                carregarComando(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.sistema.perfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.orgIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstOrg"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfil() != null && ent.getLstPerfil().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfil().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfil obj = (EntPerfil) iterator.next();
                            //l.add(obj.getEntOrganizacao());
                        //}
                    //}
                //}
                carregarOrganizacao(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.sistema.perfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.tpaIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstTpa"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfil() != null && ent.getLstPerfil().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfil().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfil obj = (EntPerfil) iterator.next();
                            //l.add(obj.getEntTipoAcesso());
                        //}
                    //}
                //}
                carregarTipoAcesso(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.sistema.perfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.perIdtChaveSuperior.visual").toLowerCase().equals("l") && null == req.getAttribute("lstPer"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfilSuperior() != null && ent.getLstPerfilSuperior().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfilSuperior().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfil obj = (EntPerfil) iterator.next();
                            //l.add(obj.getEntPerfil());
                        //}
                    //}
                //}
                carregarPerfil(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.sistema.sistemaUsuario.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.sistemaUsuario.usuIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstUsu"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstSistemaUsuario() != null && ent.getLstSistemaUsuario().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstSistemaUsuario().iterator(); iterator.hasNext();)
                        //{
                            //EntSistemaUsuario obj = (EntSistemaUsuario) iterator.next();
                            //l.add(obj.getEntUsuario());
                        //}
                    //}
                //}
                carregarUsuario(map, form, req, res, metodo, l);
            }

	}

    public void carregarComando(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarComando(map, form, req, res, "par", null);

    }
    public void carregarComando(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcComando ngc = new NgcComando();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstCmd", ngc.consultarHabilitados(new String[][]{{"cmdDscLabel", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstCmd", ngc.consultarTodos(new String[][]{{"cmdDscLabel", "ASC"}}));
        }
    }

    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarOrganizacao(map, form, req, res, "par", null);

    }
    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcOrganizacao ngc = new NgcOrganizacao();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstOrg", ngc.consultarHabilitados(new String[][]{{"orgDscFantasia", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstOrg", ngc.consultarTodos(new String[][]{{"orgDscFantasia", "ASC"}}));
        }
    }

    public void carregarTipoAcesso(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarTipoAcesso(map, form, req, res, "par", null);

    }
    public void carregarTipoAcesso(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcTipoAcesso ngc = new NgcTipoAcesso();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstTpa", ngc.consultarHabilitados(new String[][]{{"tpaDscTipo", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstTpa", ngc.consultarTodos(new String[][]{{"tpaDscTipo", "ASC"}}));
        }
    }

    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarPerfil(map, form, req, res, "par", null);

    }
    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcPerfil ngc = new NgcPerfil();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstPer", ngc.consultarHabilitados(new String[][]{{"perDscPerfil", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstPer", ngc.consultarTodos(new String[][]{{"perDscPerfil", "ASC"}}));
        }
    }

    public void carregarUsuario(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarUsuario(map, form, req, res, "par", null);

    }
    public void carregarUsuario(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcUsuario ngc = new NgcUsuario();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstUsu", ngc.consultarHabilitados(new String[][]{{"usuDscLogin", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstUsu", ngc.consultarTodos(new String[][]{{"usuDscLogin", "ASC"}}));
        }
    }









            public List<EntComando> montarComando(HttpServletRequest req, ActionForm form, EntSistema ent, String sufixo) throws Exception
            {
                List<EntComando> lst = new ArrayList<EntComando>(); 

                // Campos do detalhe
                String[] cmdIdtChave = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdIdtChave"); 
                String[] sisIdtChave = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "sisIdtChave"); 
                String[] cmdIdtChavePai = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdIdtChavePai"); 
                String[] cmdIdtChavePaiDsc = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdIdtChavePaiDsc"); 
                String[] cmdDscLabel = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdDscLabel"); 
                String[] cmdDscAcao = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdDscAcao"); 
                String[] cmdDatAtivacao = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdDatAtivacao"); 
                String[] cmdDatDesativacao = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdDatDesativacao"); 
                String[] cmdFlgMenu = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdFlgMenu"); 
                String[] cmdDscOrdem = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdDscOrdem"); 

                // Percorre cada linha 
                for (int i = 0; i < cmdIdtChave.length; i++) 
                {
                    EntComando entTmp = new EntComando();  // Percorre o detalhe
                    // Copia campos - Comando
                if (cmdIdtChave[i] != null && !cmdIdtChave[i].equals(""))
                    entTmp.setCmdIdtChave(Long.parseLong(cmdIdtChave[i]));

            if (sisIdtChave != null && sisIdtChave.length > 0 && sisIdtChave[i] != null && !sisIdtChave[i].equals(""))
            {
                EntSistema obj = new EntSistema();
                obj.setSisIdtChave(Long.parseLong(sisIdtChave[i]));
                entTmp.setEntSistema(obj);
            }
            else if(("sisIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("sisIdtChave"))
            {
                entTmp.setEntSistema(ent);
            }
                if (cmdIdtChavePai != null && cmdIdtChavePai.length > 0 && cmdIdtChavePai[i] != null && !cmdIdtChavePai[i].equals(""))
                {
                    EntComando entTmpCmd = new EntComando();
                    entTmpCmd.setCmdIdtChave(Long.parseLong(cmdIdtChavePai[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.comandoPai.cmdIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpCmd, cmdIdtChavePaiDsc[i], "campo.comandoPai.cmdIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntComandoPai(entTmpCmd);
                }

            if (cmdIdtChavePai != null && cmdIdtChavePai.length > 0 && cmdIdtChavePai[i] != null && !cmdIdtChavePai[i].equals(""))
            {
                EntComando obj = new EntComando();
                obj.setCmdIdtChave(Long.parseLong(cmdIdtChavePai[i]));
                entTmp.setEntComandoPai(obj);
            }
            if (cmdDscLabel != null && cmdDscLabel.length > 0 && cmdDscLabel[i] != null && !cmdDscLabel[i].equals(""))
                entTmp.setCmdDscLabel((cmdDscLabel[i]));

            if (cmdDscAcao != null && cmdDscAcao.length > 0 && cmdDscAcao[i] != null && !cmdDscAcao[i].equals(""))
                entTmp.setCmdDscAcao((cmdDscAcao[i]));

            if (cmdDatAtivacao != null && cmdDatAtivacao.length > 0 && cmdDatAtivacao[i] != null && !cmdDatAtivacao[i].equals(""))
                entTmp.setCmdDatAtivacao(FormatDate.parse(cmdDatAtivacao[i]));

            if (cmdDatDesativacao != null && cmdDatDesativacao.length > 0 && cmdDatDesativacao[i] != null && !cmdDatDesativacao[i].equals(""))
                entTmp.setCmdDatDesativacao(FormatDate.parse(cmdDatDesativacao[i]));

            if (cmdFlgMenu != null && cmdFlgMenu.length > 0 && cmdFlgMenu[i] != null && !cmdFlgMenu[i].equals(""))
                entTmp.setCmdFlgMenu(Integer.parseInt(cmdFlgMenu[i]));

            if (cmdDscOrdem != null && cmdDscOrdem.length > 0 && cmdDscOrdem[i] != null && !cmdDscOrdem[i].equals(""))
                entTmp.setCmdDscOrdem((cmdDscOrdem[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntPerfil> montarPerfil(HttpServletRequest req, ActionForm form, EntSistema ent, String sufixo) throws Exception
            {
                List<EntPerfil> lst = new ArrayList<EntPerfil>(); 

                // Campos do detalhe
                String[] perIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perIdtChave"); 
                String[] orgIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "orgIdtChave"); 
                String[] orgIdtChaveDsc = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "orgIdtChaveDsc"); 
                String[] sisIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "sisIdtChave"); 
                String[] perDscPerfil = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perDscPerfil"); 
                String[] perFlgPublico = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perFlgPublico"); 
                String[] tpaIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "tpaIdtChave"); 
                String[] tpaIdtChaveDsc = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "tpaIdtChaveDsc"); 
                String[] perIdtChaveSuperior = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perIdtChaveSuperior"); 
                String[] perIdtChaveSuperiorDsc = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perIdtChaveSuperiorDsc"); 

                // Percorre cada linha 
                for (int i = 0; i < perIdtChave.length; i++) 
                {
                    EntPerfil entTmp = new EntPerfil();  // Percorre o detalhe
                    // Copia campos - Perfil
                if (perIdtChave[i] != null && !perIdtChave[i].equals(""))
                    entTmp.setPerIdtChave(Long.parseLong(perIdtChave[i]));

                if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
                {
                    EntOrganizacao entTmpOrg = new EntOrganizacao();
                    entTmpOrg.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.perfil.orgIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpOrg, orgIdtChaveDsc[i], "campo.perfil.orgIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntOrganizacao(entTmpOrg);
                }

            if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
            {
                EntOrganizacao obj = new EntOrganizacao();
                obj.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                entTmp.setEntOrganizacao(obj);
            }
            if (sisIdtChave != null && sisIdtChave.length > 0 && sisIdtChave[i] != null && !sisIdtChave[i].equals(""))
            {
                EntSistema obj = new EntSistema();
                obj.setSisIdtChave(Long.parseLong(sisIdtChave[i]));
                entTmp.setEntSistema(obj);
            }
            else if(("sisIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("sisIdtChave"))
            {
                entTmp.setEntSistema(ent);
            }
            if (perDscPerfil != null && perDscPerfil.length > 0 && perDscPerfil[i] != null && !perDscPerfil[i].equals(""))
                entTmp.setPerDscPerfil((perDscPerfil[i]));

            if (perFlgPublico != null && perFlgPublico.length > 0 && perFlgPublico[i] != null && !perFlgPublico[i].equals(""))
                entTmp.setPerFlgPublico(Integer.parseInt(perFlgPublico[i]));

                if (tpaIdtChave != null && tpaIdtChave.length > 0 && tpaIdtChave[i] != null && !tpaIdtChave[i].equals(""))
                {
                    EntTipoAcesso entTmpTpa = new EntTipoAcesso();
                    entTmpTpa.setTpaIdtChave(Long.parseLong(tpaIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.perfil.tpaIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpTpa, tpaIdtChaveDsc[i], "campo.perfil.tpaIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntTipoAcesso(entTmpTpa);
                }

            if (tpaIdtChave != null && tpaIdtChave.length > 0 && tpaIdtChave[i] != null && !tpaIdtChave[i].equals(""))
            {
                EntTipoAcesso obj = new EntTipoAcesso();
                obj.setTpaIdtChave(Long.parseLong(tpaIdtChave[i]));
                entTmp.setEntTipoAcesso(obj);
            }
                if (perIdtChaveSuperior != null && perIdtChaveSuperior.length > 0 && perIdtChaveSuperior[i] != null && !perIdtChaveSuperior[i].equals(""))
                {
                    EntPerfil entTmpPer = new EntPerfil();
                    entTmpPer.setPerIdtChave(Long.parseLong(perIdtChaveSuperior[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.perfilSuperior.perIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpPer, perIdtChaveSuperiorDsc[i], "campo.perfilSuperior.perIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntPerfilSuperior(entTmpPer);
                }

            if (perIdtChaveSuperior != null && perIdtChaveSuperior.length > 0 && perIdtChaveSuperior[i] != null && !perIdtChaveSuperior[i].equals(""))
            {
                EntPerfil obj = new EntPerfil();
                obj.setPerIdtChave(Long.parseLong(perIdtChaveSuperior[i]));
                entTmp.setEntPerfilSuperior(obj);
            }

                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntSistemaUsuario> montarSistemaUsuario(HttpServletRequest req, ActionForm form, EntSistema ent, String sufixo) throws Exception
            {
                List<EntSistemaUsuario> lst = new ArrayList<EntSistemaUsuario>(); 

                // Campos do detalhe
                String[] susIdtChave = (String[])((DynaValidatorForm)form).get("sus_" + sufixo.toUpperCase() + "susIdtChave"); 
                String[] sisIdtChave = (String[])((DynaValidatorForm)form).get("sus_" + sufixo.toUpperCase() + "sisIdtChave"); 
                String[] usuIdtChave = (String[])((DynaValidatorForm)form).get("sus_" + sufixo.toUpperCase() + "usuIdtChave"); 
                String[] usuIdtChaveDsc = (String[])((DynaValidatorForm)form).get("sus_" + sufixo.toUpperCase() + "usuIdtChaveDsc"); 
                String[] susNumTentativas = (String[])((DynaValidatorForm)form).get("sus_" + sufixo.toUpperCase() + "susNumTentativas"); 

                // Percorre cada linha 
                for (int i = 0; i < susIdtChave.length; i++) 
                {
                    EntSistemaUsuario entTmp = new EntSistemaUsuario();  // Percorre o detalhe
                    // Copia campos - SistemaUsuario
                if (susIdtChave[i] != null && !susIdtChave[i].equals(""))
                    entTmp.setSusIdtChave(Long.parseLong(susIdtChave[i]));

            if (sisIdtChave != null && sisIdtChave.length > 0 && sisIdtChave[i] != null && !sisIdtChave[i].equals(""))
            {
                EntSistema obj = new EntSistema();
                obj.setSisIdtChave(Long.parseLong(sisIdtChave[i]));
                entTmp.setEntSistema(obj);
            }
            else if(("sisIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("sisIdtChave"))
            {
                entTmp.setEntSistema(ent);
            }
                if (usuIdtChave != null && usuIdtChave.length > 0 && usuIdtChave[i] != null && !usuIdtChave[i].equals(""))
                {
                    EntUsuario entTmpUsu = new EntUsuario();
                    entTmpUsu.setUsuIdtChave(Long.parseLong(usuIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.sistemaUsuario.usuIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpUsu, usuIdtChaveDsc[i], "campo.sistemaUsuario.usuIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntUsuario(entTmpUsu);
                }

            if (usuIdtChave != null && usuIdtChave.length > 0 && usuIdtChave[i] != null && !usuIdtChave[i].equals(""))
            {
                EntUsuario obj = new EntUsuario();
                obj.setUsuIdtChave(Long.parseLong(usuIdtChave[i]));
                entTmp.setEntUsuario(obj);
            }
            if (susNumTentativas != null && susNumTentativas.length > 0 && susNumTentativas[i] != null && !susNumTentativas[i].equals(""))
                entTmp.setSusNumTentativas(Integer.parseInt(susNumTentativas[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }



            public void AtualizarComando(ActionForm form, List<EntComando> lstPrs, List<EntComando> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntComando entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntComando entTmp = lstTmp.get(j);
                    if (entPrs.getCmdIdtChave().equals(entTmp.getCmdIdtChave())) // Altera��o
                    {
                    entPrs.setEntSistema(entTmp.getEntSistema());
                    entPrs.setEntComandoPai(entTmp.getEntComandoPai());
                    entPrs.setCmdDscLabel(entTmp.getCmdDscLabel());
                    entPrs.setCmdDscAcao(entTmp.getCmdDscAcao());
                    entPrs.setCmdDatAtivacao(entTmp.getCmdDatAtivacao());
                    entPrs.setCmdDatDesativacao(entTmp.getCmdDatDesativacao());
                    entPrs.setCmdFlgMenu(entTmp.getCmdFlgMenu());
                    entPrs.setCmdDscOrdem(entTmp.getCmdDscOrdem());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarPerfil(ActionForm form, List<EntPerfil> lstPrs, List<EntPerfil> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntPerfil entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntPerfil entTmp = lstTmp.get(j);
                    if (entPrs.getPerIdtChave().equals(entTmp.getPerIdtChave())) // Altera��o
                    {
                    entPrs.setEntOrganizacao(entTmp.getEntOrganizacao());
                    entPrs.setEntSistema(entTmp.getEntSistema());
                    entPrs.setPerDscPerfil(entTmp.getPerDscPerfil());
                    entPrs.setPerFlgPublico(entTmp.getPerFlgPublico());
                    entPrs.setEntTipoAcesso(entTmp.getEntTipoAcesso());
                    entPrs.setEntPerfilSuperior(entTmp.getEntPerfilSuperior());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarSistemaUsuario(ActionForm form, List<EntSistemaUsuario> lstPrs, List<EntSistemaUsuario> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntSistemaUsuario entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntSistemaUsuario entTmp = lstTmp.get(j);
                    if (entPrs.getSusIdtChave().equals(entTmp.getSusIdtChave())) // Altera��o
                    {
                    entPrs.setEntSistema(entTmp.getEntSistema());
                    entPrs.setEntUsuario(entTmp.getEntUsuario());
                    entPrs.setSusNumTentativas(entTmp.getSusNumTentativas());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }


    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.sistema." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.sistema." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
