package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntComandoperfilRegra;
import arquitetura.funcional.health.negocio.NgcComandoperfilRegra;
import arquitetura.funcional.health.negocio.NgcComandoPerfil;
import arquitetura.funcional.health.negocio.NgcRegraNegocio;
import arquitetura.funcional.health.entidades.EntRegraNegocio;
import arquitetura.funcional.health.entidades.EntComandoPerfil;


public class ActComandoperfilRegraBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoperfilRegra ent = new EntComandoperfilRegra();
		NgcComandoperfilRegra ngc = new NgcComandoperfilRegra();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);



            if (!((DynaValidatorForm) form).get("cmpIdtChave").equals(""))
            {
                EntComandoPerfil entCmp = new EntComandoPerfil();
                entCmp.setCmpIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("cmpIdtChave"))); 
                ent.setEntComandoPerfil(entCmp);
            }
            if (!((DynaValidatorForm) form).get("rngIdtChave").equals(""))
            {
                EntRegraNegocio entRng = new EntRegraNegocio();
                entRng.setRngIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("rngIdtChave"))); 
                ent.setEntRegraNegocio(entRng);
            }

			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResCmr", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoperfilRegra ent = new EntComandoperfilRegra();
		NgcComandoperfilRegra ngc = new NgcComandoperfilRegra();

		try
		{
			ent = (EntComandoperfilRegra) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cmrIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			


            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntComandoPerfil(), form, req);
            if (null != ent && null != ent.getEntComandoPerfil())
                BeanUtils.copyProperties(form, ent.getEntComandoPerfil());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntRegraNegocio(), form, req);
            if (null != ent && null != ent.getEntRegraNegocio())
                BeanUtils.copyProperties(form, ent.getEntRegraNegocio());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas

			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoperfilRegra ent = new EntComandoperfilRegra();
		NgcComandoperfilRegra ngc = new NgcComandoperfilRegra();

		try
		{
			ent = (EntComandoperfilRegra) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cmrIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						

            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntComandoPerfil(), form, req);
            if (null != ent && null != ent.getEntComandoPerfil())
                BeanUtils.copyProperties(form, ent.getEntComandoPerfil());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntRegraNegocio(), form, req);
            if (null != ent && null != ent.getEntRegraNegocio())
                BeanUtils.copyProperties(form, ent.getEntRegraNegocio());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas

			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoperfilRegra ent = new EntComandoperfilRegra();
		NgcComandoperfilRegra ngc = new NgcComandoperfilRegra();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntComandoperfilRegra) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cmrIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio




            if (getResources(req).getMessage("campo.comandoperfilRegra.cmpIdtChave.exibir.cad").equals("s"))
                this.setaComandoPerfil(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.comandoperfilRegra.rngIdtChave.exibir.cad").equals("s"))
                this.setaRegraNegocio(map, form, req, res, ent);



			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntComandoperfilRegra) ngc.consultarID(ent.getCmrIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResCmr", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoperfilRegra ent = new EntComandoperfilRegra();
		NgcComandoperfilRegra ngc = new NgcComandoperfilRegra();

		try
		{
			ent = (EntComandoperfilRegra) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cmrIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoperfilRegra ent = new EntComandoperfilRegra();
		NgcComandoperfilRegra ngc = new NgcComandoperfilRegra();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);

            if (getResources(req).getMessage("campo.comandoperfilRegra.cmpIdtChave.exibir.cad").equals("s"))
                this.setaComandoPerfil(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.comandoperfilRegra.rngIdtChave.exibir.cad").equals("s"))
                this.setaRegraNegocio(map, form, req, res, ent);


			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntComandoperfilRegra) ngc.consultarID(ent.getCmrIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResCmr", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntComandoperfilRegra ent) throws Exception
	{
            if (getResources(req).getMessage("campo.comandoperfilRegra.cmpIdtChave.exibir.cad").equals("s"))
                this.setaComandoPerfil(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.comandoperfilRegra.rngIdtChave.exibir.cad").equals("s"))
                this.setaRegraNegocio(map, form, req, res, ent);

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntComandoperfilRegra ent) throws Exception
	{

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntComandoperfilRegra ent) throws Exception
	{
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntComandoPerfil(), form, req);
            if (null != ent && null != ent.getEntComandoPerfil())
                BeanUtils.copyProperties(form, ent.getEntComandoPerfil());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntRegraNegocio(), form, req);
            if (null != ent && null != ent.getEntRegraNegocio())
                BeanUtils.copyProperties(form, ent.getEntRegraNegocio());

	}

	public void converterValores(ActionForm form)
	{

        // CmrFlgAtivo
        if ((((DynaValidatorForm) form).get("cmrFlgAtivo")) != null && !(((DynaValidatorForm) form).get("cmrFlgAtivo")).equals(""))
        {
            Integer cmrFlgAtivo = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("cmrFlgAtivo"));
            ((DynaValidatorForm) form).set("cmrFlgAtivo", cmrFlgAtivo.toString());
        }



	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntComandoperfilRegra ent) throws Exception
	{

	
        if (getResources(req).getMessage("campo.comandoperfilRegra.cmpIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.comandoperfilRegra.cmpIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstComandoPerfil"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntComandoPerfil());
            carregarComandoPerfil(map, form, req, res, metodo, l); 
            
        }
        if (getResources(req).getMessage("campo.comandoperfilRegra.rngIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.comandoperfilRegra.rngIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstRegraNegocio"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntRegraNegocio());
            carregarRegraNegocio(map, form, req, res, metodo, l); 
            
        }

	}

    public void carregarComandoPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarComandoPerfil(map, form, req, res, "par", null);

    }
    public void carregarComandoPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcComandoPerfil ngc = new NgcComandoPerfil();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstCmp", ngc.consultarHabilitados(new String[][]{{"cmpIdtChave", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstCmp", ngc.consultarTodos(new String[][]{{"cmpIdtChave", "ASC"}}));
        }
    }

    public void carregarRegraNegocio(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarRegraNegocio(map, form, req, res, "par", null);

    }
    public void carregarRegraNegocio(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcRegraNegocio ngc = new NgcRegraNegocio();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstRng", ngc.consultarHabilitados(new String[][]{{"rngDscIdentificacao", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstRng", ngc.consultarTodos(new String[][]{{"rngDscIdentificacao", "ASC"}}));
        }
    }





            public void setaComandoPerfil(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntComandoperfilRegra ent) throws Exception
            {
                EntComandoPerfil entCmp;
                if (ent.getEntComandoPerfil() != null && !((String)((DynaValidatorForm)form).get("cmpIdtChave")).equals("") && ent.getEntComandoPerfil().getCmpIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("cmpIdtChave"))) 
                    entCmp = ent.getEntComandoPerfil();
                else
                {
                    entCmp = new EntComandoPerfil();
                    try {
                        entCmp.setCmpIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("cmpIdtChave")));
                    } catch (Exception e) {
                        entCmp.setCmpIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entCmp, req);
                if (entCmp.getCmpIdtChave() != null)
                    ent.setEntComandoPerfil(entCmp);
                else
                    ent.setEntComandoPerfil(null);
            }
            public void setaRegraNegocio(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntComandoperfilRegra ent) throws Exception
            {
                EntRegraNegocio entRng;
                if (ent.getEntRegraNegocio() != null && !((String)((DynaValidatorForm)form).get("rngIdtChave")).equals("") && ent.getEntRegraNegocio().getRngIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("rngIdtChave"))) 
                    entRng = ent.getEntRegraNegocio();
                else
                {
                    entRng = new EntRegraNegocio();
                    try {
                        entRng.setRngIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("rngIdtChave")));
                    } catch (Exception e) {
                        entRng.setRngIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entRng, req);
                if (entRng.getRngIdtChave() != null)
                    ent.setEntRegraNegocio(entRng);
                else
                    ent.setEntRegraNegocio(null);
            }








    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.comandoperfilRegra." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.comandoperfilRegra." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
