package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcOrganizacaoBase;
//import arquitetura.funcional.health.regra.RngOrganizacao;

public class NgcOrganizacao extends NgcOrganizacaoBase
{

}
