package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoPerfilUsuarioBase;

public class DaoPerfilUsuario extends DaoPerfilUsuarioBase
{
	public DaoPerfilUsuario() throws SerproException
	{
		super();
	}
}
