package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntStatutSante;
import arquitetura.funcional.health.negocio.NgcStatutSante;
import arquitetura.funcional.health.entidades.EntEtatSante;
import arquitetura.funcional.health.entidades.EntStatutSante;
import arquitetura.funcional.health.negocio.NgcEtatSante;
import arquitetura.funcional.health.entidades.EntNoeud;
import arquitetura.funcional.health.negocio.NgcNoeud;


public class ActStatutSanteBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntStatutSante ent = new EntStatutSante();
		NgcStatutSante ngc = new NgcStatutSante();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);




			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResSst", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntStatutSante ent = new EntStatutSante();
		NgcStatutSante ngc = new NgcStatutSante();

		try
		{
			ent = (EntStatutSante) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("sstIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			



//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas
            List<EntEtatSante> lstEst = ent.getLstEtatSante();
            lstEst = ordenarLista(lstEst, getResources(req).getMessage("etatSante.ordenacao")); 
            req.setAttribute("lstResEst", lstEst);


			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntStatutSante ent = new EntStatutSante();
		NgcStatutSante ngc = new NgcStatutSante();

		try
		{
			ent = (EntStatutSante) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("sstIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						


//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas
            List<EntEtatSante> lstEst = ent.getLstEtatSante();
            lstEst = ordenarLista(lstEst, getResources(req).getMessage("etatSante.ordenacao")); 
            req.setAttribute("lstResEst", lstEst);


			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntStatutSante ent = new EntStatutSante();
		NgcStatutSante ngc = new NgcStatutSante();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntStatutSante) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("sstIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio





            if (getResources(req).getMessage("detalhe.statutSante.etatSante.exibir").equals("s"))
            {
                // Salva EtatSante
                List<EntEtatSante> lstPrsEst = ent.getLstEtatSante();
                List<EntEtatSante> lstTmpEst = montarEtatSante(req, form, ent, "");
                AtualizarEtatSante(form, lstPrsEst, lstTmpEst);
            }


			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntStatutSante) ngc.consultarID(ent.getSstIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResSst", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntStatutSante ent = new EntStatutSante();
		NgcStatutSante ngc = new NgcStatutSante();

		try
		{
			ent = (EntStatutSante) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("sstIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntStatutSante ent = new EntStatutSante();
		NgcStatutSante ngc = new NgcStatutSante();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);


            if (getResources(req).getMessage("detalhe.statutSante.etatSante.exibir").equals("s"))
            {
                // Salva EtatSante
                Integer qtdeEtatSante = Integer.parseInt(req.getParameter("qtdeEtatSante"));
                if (qtdeEtatSante > 0)
                {
                    List<EntEtatSante> lstTmpEst = montarEtatSante(req, form, ent, "");
                    ent.setLstEtatSante(lstTmpEst);
                }

            }

			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntStatutSante) ngc.consultarID(ent.getSstIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResSst", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntStatutSante ent) throws Exception
	{

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntStatutSante ent) throws Exception
	{
            if (getResources(req).getMessage("detalhe.statutSante.etatSante.exibir").equals("s"))
            {
                // Salva EtatSante
                List<EntEtatSante> lstPrsEst = ent.getLstEtatSante();
                List<EntEtatSante> lstTmpEst = montarEtatSante(req, form, ent, "");
                AtualizarEtatSante(form, lstPrsEst, lstTmpEst);
            }

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntStatutSante ent) throws Exception
	{

	}

	public void converterValores(ActionForm form)
	{




	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntStatutSante ent) throws Exception
	{

	
            if (getResources(req).getMessage("detalhe.statutSante.etatSante.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.etatSante.nodIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstNod"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstEtatSante() != null && ent.getLstEtatSante().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstEtatSante().iterator(); iterator.hasNext();)
                        //{
                            //EntEtatSante obj = (EntEtatSante) iterator.next();
                            //l.add(obj.getEntNoeud());
                        //}
                    //}
                //}
                carregarNoeud(map, form, req, res, metodo, l);
            }

	}

    public void carregarNoeud(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarNoeud(map, form, req, res, "par", null);

    }
    public void carregarNoeud(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcNoeud ngc = new NgcNoeud();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstNod", ngc.consultarHabilitados(new String[][]{{"nodDscTitre", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstNod", ngc.consultarTodos(new String[][]{{"nodDscTitre", "ASC"}}));
        }
    }









            public List<EntEtatSante> montarEtatSante(HttpServletRequest req, ActionForm form, EntStatutSante ent, String sufixo) throws Exception
            {
                List<EntEtatSante> lst = new ArrayList<EntEtatSante>(); 

                // Campos do detalhe
                String[] estIdtChave = (String[])((DynaValidatorForm)form).get("est_" + sufixo.toUpperCase() + "estIdtChave"); 
                String[] estNumTemps = (String[])((DynaValidatorForm)form).get("est_" + sufixo.toUpperCase() + "estNumTemps"); 
                String[] nodIdtChave = (String[])((DynaValidatorForm)form).get("est_" + sufixo.toUpperCase() + "nodIdtChave"); 
                String[] nodIdtChaveDsc = (String[])((DynaValidatorForm)form).get("est_" + sufixo.toUpperCase() + "nodIdtChaveDsc"); 
                String[] sstIdtChave = (String[])((DynaValidatorForm)form).get("est_" + sufixo.toUpperCase() + "sstIdtChave"); 

                // Percorre cada linha 
                for (int i = 0; i < estIdtChave.length; i++) 
                {
                    EntEtatSante entTmp = new EntEtatSante();  // Percorre o detalhe
                    // Copia campos - EtatSante
                if (estIdtChave[i] != null && !estIdtChave[i].equals(""))
                    entTmp.setEstIdtChave(Long.parseLong(estIdtChave[i]));

            if (estNumTemps != null && estNumTemps.length > 0 && estNumTemps[i] != null && !estNumTemps[i].equals(""))
                entTmp.setEstNumTemps(Integer.parseInt(estNumTemps[i]));

                if (nodIdtChave != null && nodIdtChave.length > 0 && nodIdtChave[i] != null && !nodIdtChave[i].equals(""))
                {
                    EntNoeud entTmpNod = new EntNoeud();
                    entTmpNod.setNodIdtChave(Long.parseLong(nodIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.etatSante.nodIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpNod, nodIdtChaveDsc[i], "campo.etatSante.nodIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntNoeud(entTmpNod);
                }

            if (nodIdtChave != null && nodIdtChave.length > 0 && nodIdtChave[i] != null && !nodIdtChave[i].equals(""))
            {
                EntNoeud obj = new EntNoeud();
                obj.setNodIdtChave(Long.parseLong(nodIdtChave[i]));
                entTmp.setEntNoeud(obj);
            }
            if (sstIdtChave != null && sstIdtChave.length > 0 && sstIdtChave[i] != null && !sstIdtChave[i].equals(""))
            {
                EntStatutSante obj = new EntStatutSante();
                obj.setSstIdtChave(Long.parseLong(sstIdtChave[i]));
                entTmp.setEntStatutSante(obj);
            }
            else if(("sstIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("sstIdtChave"))
            {
                entTmp.setEntStatutSante(ent);
            }

                    lst.add(entTmp);
                }
                return lst; 
            }



            public void AtualizarEtatSante(ActionForm form, List<EntEtatSante> lstPrs, List<EntEtatSante> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntEtatSante entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntEtatSante entTmp = lstTmp.get(j);
                    if (entPrs.getEstIdtChave().equals(entTmp.getEstIdtChave())) // Altera��o
                    {
                    entPrs.setEstNumTemps(entTmp.getEstNumTemps());
                    entPrs.setEntNoeud(entTmp.getEntNoeud());
                    entPrs.setEntStatutSante(entTmp.getEntStatutSante());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }


    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.statutSante." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.statutSante." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
