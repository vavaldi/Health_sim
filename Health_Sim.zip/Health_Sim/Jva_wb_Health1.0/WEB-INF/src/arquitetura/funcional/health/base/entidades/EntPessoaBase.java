package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import java.util.List;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import arquitetura.funcional.health.entidades.EntPapel;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntTipoPessoa;
import arquitetura.funcional.health.entidades.EntUsuario;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import java.math.BigDecimal;
import arquitetura.funcional.health.entidades.EntTipoSexo;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntPessoaBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "PES_IDT_CHAVE", unique = true, nullable = false)
    private Long pesIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="TPP_IDT_CHAVE") 
    private EntTipoPessoa entTipoPessoa;

    @Column(name = "PES_DSC_NOME", nullable = false, length = 255)
    private String pesDscNome;

    @Column(name = "PES_DOC_CPF", nullable = true, length = 11)
    private String pesDocCpf;

    @Column(name = "PES_DOC_CNPJ", nullable = true, length = 14)
    private String pesDocCnpj;

    @Column(name = "PES_DSC_FANTASIA", nullable = true, length = 255)
    private String pesDscFantasia;

    @Column(name = "PES_DAT_NASCIMENTO", nullable = true)
    private Date pesDatNascimento;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="TSX_IDT_CHAVE") 
    private EntTipoSexo entTipoSexo;

    @Column(name = "PES_FLG_EDITAVEL", nullable = true)
    private Integer pesFlgEditavel;

    @Column(name = "PES_DSC_EMAIL", nullable = true, length = 200)
    private String pesDscEmail;

    @OneToMany(mappedBy="entPessoa",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntPapel> lstPapel;

    @OneToOne (fetch = FetchType.EAGER, mappedBy = "entPessoa")
    private EntUsuario entUsuario;

    public Long getPesIdtChave() {
        return this.pesIdtChave;
    } 

    public void setPesIdtChave(Long valor) {
        this.pesIdtChave = valor;
    } 

    public EntTipoPessoa getEntTipoPessoa() {
        return this.entTipoPessoa;
    } 

    public void setEntTipoPessoa(EntTipoPessoa valor) {
        this.entTipoPessoa = valor;
    } 

    public String getPesDscNome() {
        return this.pesDscNome;
    } 

    public void setPesDscNome(String valor) {
        this.pesDscNome = valor;
    } 

    public String getPesDocCpf() {
        return this.pesDocCpf;
    } 

    public void setPesDocCpf(String valor) {
        this.pesDocCpf = valor;
    } 

    public String getPesDocCnpj() {
        return this.pesDocCnpj;
    } 

    public void setPesDocCnpj(String valor) {
        this.pesDocCnpj = valor;
    } 

    public String getPesDscFantasia() {
        return this.pesDscFantasia;
    } 

    public void setPesDscFantasia(String valor) {
        this.pesDscFantasia = valor;
    } 

    public Date getPesDatNascimento() {
        return this.pesDatNascimento;
    } 

    public void setPesDatNascimento(Date valor) {
        this.pesDatNascimento = valor;
    } 

    public EntTipoSexo getEntTipoSexo() {
        return this.entTipoSexo;
    } 

    public void setEntTipoSexo(EntTipoSexo valor) {
        this.entTipoSexo = valor;
    } 

    public Integer getPesFlgEditavel() {
        return this.pesFlgEditavel;
    } 

    public void setPesFlgEditavel(Integer valor) {
        this.pesFlgEditavel = valor;
    } 

    public String getPesDscEmail() {
        return this.pesDscEmail;
    } 

    public void setPesDscEmail(String valor) {
        this.pesDscEmail = valor;
    } 

    public List<EntPapel> getLstPapel() {
        return this.lstPapel;
    } 

    public void setLstPapel(List<EntPapel> valor) {
        this.lstPapel = valor;
    } 

    public EntUsuario getEntUsuario() {
        return this.entUsuario;
    } 

    public void setEntUsuario(EntUsuario valor) {
        this.entUsuario = valor;
    } 


}