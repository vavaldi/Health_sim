package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcMaladieBase;
//import arquitetura.funcional.health.regra.RngMaladie;

public class NgcMaladie extends NgcMaladieBase
{

}
