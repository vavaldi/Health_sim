package arquitetura.funcional.health.base.entidades;

import arquitetura.funcional.health.entidades.EntComando;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntPerfil;
import arquitetura.funcional.health.entidades.EntSistemaUsuario;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntSistemaBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "SIS_IDT_CHAVE", unique = true, nullable = false)
    private Long sisIdtChave;

    @Column(name = "SIS_DSC_TITULO", nullable = false, length = 150)
    private String sisDscTitulo;

    @Column(name = "SIS_DSC_DESCRICAO", nullable = true, length = 500)
    private String sisDscDescricao;

    @OneToMany(mappedBy="entSistema",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntComando> lstComando;

    @OneToMany(mappedBy="entSistema",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntPerfil> lstPerfil;

    @OneToMany(mappedBy="entSistema",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntSistemaUsuario> lstSistemaUsuario;

    public Long getSisIdtChave() {
        return this.sisIdtChave;
    } 

    public void setSisIdtChave(Long valor) {
        this.sisIdtChave = valor;
    } 

    public String getSisDscTitulo() {
        return this.sisDscTitulo;
    } 

    public void setSisDscTitulo(String valor) {
        this.sisDscTitulo = valor;
    } 

    public String getSisDscDescricao() {
        return this.sisDscDescricao;
    } 

    public void setSisDscDescricao(String valor) {
        this.sisDscDescricao = valor;
    } 

    public List<EntComando> getLstComando() {
        return this.lstComando;
    } 

    public void setLstComando(List<EntComando> valor) {
        this.lstComando = valor;
    } 

    public List<EntPerfil> getLstPerfil() {
        return this.lstPerfil;
    } 

    public void setLstPerfil(List<EntPerfil> valor) {
        this.lstPerfil = valor;
    } 

    public List<EntSistemaUsuario> getLstSistemaUsuario() {
        return this.lstSistemaUsuario;
    } 

    public void setLstSistemaUsuario(List<EntSistemaUsuario> valor) {
        this.lstSistemaUsuario = valor;
    } 


}