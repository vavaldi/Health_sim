package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntComando;
import arquitetura.funcional.health.negocio.NgcComando;
import arquitetura.funcional.health.negocio.NgcComandoPerfil;
import arquitetura.funcional.health.entidades.EntComando;
import arquitetura.funcional.health.negocio.NgcSistema;
import arquitetura.funcional.health.entidades.EntComandoRegra;
import arquitetura.funcional.health.negocio.NgcPerfil;
import arquitetura.funcional.health.negocio.NgcComando;
import arquitetura.funcional.health.negocio.NgcRegraNegocio;
import arquitetura.funcional.health.entidades.EntRegraNegocio;
import arquitetura.funcional.health.entidades.EntSistema;
import arquitetura.funcional.health.entidades.EntPerfil;
import arquitetura.funcional.health.entidades.EntComandoPerfil;
import arquitetura.funcional.health.negocio.NgcComandoRegra;


public class ActComandoBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComando ent = new EntComando();
		NgcComando ngc = new NgcComando();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);



            if (!((DynaValidatorForm) form).get("sisIdtChave").equals(""))
            {
                EntSistema entSis = new EntSistema();
                entSis.setSisIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("sisIdtChave"))); 
                ent.setEntSistema(entSis);
            }
            if (!((DynaValidatorForm) form).get("cmdIdtChavePai").equals(""))
            {
                EntComando entCmdPai = new EntComando();
                entCmdPai.setCmdIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("cmdIdtChavePai"))); 
                ent.setEntComandoPai(entCmdPai);
            }

			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResCmd", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComando ent = new EntComando();
		NgcComando ngc = new NgcComando();

		try
		{
			ent = (EntComando) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cmdIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
            if (null != ent.getEntComandoPai())
                ((DynaValidatorForm)form).set("cmdIdtChavePai", ent.getEntComandoPai().getCmdIdtChave().toString());


            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntSistema(), form, req);
            if (null != ent && null != ent.getEntSistema())
                BeanUtils.copyProperties(form, ent.getEntSistema());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntComandoPai(), form, req);
            if (null != ent && null != ent.getEntComandoPai())
                BeanUtils.copyProperties(form, ent.getEntComandoPai());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas
            List<EntComandoRegra> lstCdr = ent.getLstComandoRegra();
            lstCdr = ordenarLista(lstCdr, getResources(req).getMessage("comandoRegra.ordenacao")); 
            req.setAttribute("lstResCdr", lstCdr);

            List<EntComando> lstCmdPai = ent.getLstComandoPai();
            lstCmdPai = ordenarLista(lstCmdPai, getResources(req).getMessage("comando.ordenacao")); 
            req.setAttribute("lstResCmdPai", lstCmdPai);

            List<EntComandoPerfil> lstCmp = ent.getLstComandoPerfil();
            lstCmp = ordenarLista(lstCmp, getResources(req).getMessage("comandoPerfil.ordenacao")); 
            req.setAttribute("lstResCmp", lstCmp);


			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComando ent = new EntComando();
		NgcComando ngc = new NgcComando();

		try
		{
			ent = (EntComando) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cmdIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						
            if (null != ent.getEntComandoPai())
                ((DynaValidatorForm)form).set("cmdIdtChavePai", ent.getEntComandoPai().getCmdIdtChave().toString());

            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntSistema(), form, req);
            if (null != ent && null != ent.getEntSistema())
                BeanUtils.copyProperties(form, ent.getEntSistema());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntComandoPai(), form, req);
            if (null != ent && null != ent.getEntComandoPai())
                BeanUtils.copyProperties(form, ent.getEntComandoPai());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas
            List<EntComandoRegra> lstCdr = ent.getLstComandoRegra();
            lstCdr = ordenarLista(lstCdr, getResources(req).getMessage("comandoRegra.ordenacao")); 
            req.setAttribute("lstResCdr", lstCdr);

            List<EntComando> lstCmdPai = ent.getLstComandoPai();
            lstCmdPai = ordenarLista(lstCmdPai, getResources(req).getMessage("comando.ordenacao")); 
            req.setAttribute("lstResCmdPai", lstCmdPai);

            List<EntComandoPerfil> lstCmp = ent.getLstComandoPerfil();
            lstCmp = ordenarLista(lstCmp, getResources(req).getMessage("comandoPerfil.ordenacao")); 
            req.setAttribute("lstResCmp", lstCmp);


			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComando ent = new EntComando();
		NgcComando ngc = new NgcComando();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntComando) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cmdIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio




            if (getResources(req).getMessage("campo.comando.sisIdtChave.exibir.cad").equals("s"))
                this.setaSistema(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.comando.cmdIdtChavePai.exibir.cad").equals("s"))
                this.setaComandoPai(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.comando.comandoRegra.exibir").equals("s"))
            {
                // Salva ComandoRegra
                List<EntComandoRegra> lstPrsCdr = ent.getLstComandoRegra();
                List<EntComandoRegra> lstTmpCdr = montarComandoRegra(req, form, ent, "");
                AtualizarComandoRegra(form, lstPrsCdr, lstTmpCdr);
            }
            if (getResources(req).getMessage("detalhe.comando.comandoPai.exibir").equals("s"))
            {
                // Salva ComandoPai
                List<EntComando> lstPrsCmd = ent.getLstComandoPai();
                List<EntComando> lstTmpCmd = montarComando(req, form, ent, "PAI_");
                AtualizarComando(form, lstPrsCmd, lstTmpCmd);
            }
            if (getResources(req).getMessage("detalhe.comando.comandoPerfil.exibir").equals("s"))
            {
                // Salva ComandoPerfil
                List<EntComandoPerfil> lstPrsCmp = ent.getLstComandoPerfil();
                List<EntComandoPerfil> lstTmpCmp = montarComandoPerfil(req, form, ent, "");
                AtualizarComandoPerfil(form, lstPrsCmp, lstTmpCmp);
            }


			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntComando) ngc.consultarID(ent.getCmdIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResCmd", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComando ent = new EntComando();
		NgcComando ngc = new NgcComando();

		try
		{
			ent = (EntComando) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cmdIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComando ent = new EntComando();
		NgcComando ngc = new NgcComando();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);

            if (getResources(req).getMessage("campo.comando.sisIdtChave.exibir.cad").equals("s"))
                this.setaSistema(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.comando.cmdIdtChavePai.exibir.cad").equals("s"))
                this.setaComandoPai(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.comando.comandoRegra.exibir").equals("s"))
            {
                // Salva ComandoRegra
                Integer qtdeComandoRegra = Integer.parseInt(req.getParameter("qtdeComandoRegra"));
                if (qtdeComandoRegra > 0)
                {
                    List<EntComandoRegra> lstTmpCdr = montarComandoRegra(req, form, ent, "");
                    ent.setLstComandoRegra(lstTmpCdr);
                }

            }
            if (getResources(req).getMessage("detalhe.comando.comandoPai.exibir").equals("s"))
            {
                // Salva ComandoPai
                Integer qtdeComandoPai = Integer.parseInt(req.getParameter("qtdeComandoPai"));
                if (qtdeComandoPai > 0)
                {
                    List<EntComando> lstTmpCmd = montarComando(req, form, ent, "PAI_");
                    ent.setLstComandoPai(lstTmpCmd);
                }

            }
            if (getResources(req).getMessage("detalhe.comando.comandoPerfil.exibir").equals("s"))
            {
                // Salva ComandoPerfil
                Integer qtdeComandoPerfil = Integer.parseInt(req.getParameter("qtdeComandoPerfil"));
                if (qtdeComandoPerfil > 0)
                {
                    List<EntComandoPerfil> lstTmpCmp = montarComandoPerfil(req, form, ent, "");
                    ent.setLstComandoPerfil(lstTmpCmp);
                }

            }

			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntComando) ngc.consultarID(ent.getCmdIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResCmd", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntComando ent) throws Exception
	{
            if (getResources(req).getMessage("campo.comando.sisIdtChave.exibir.cad").equals("s"))
                this.setaSistema(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.comando.cmdIdtChavePai.exibir.cad").equals("s"))
                this.setaComandoPai(map, form, req, res, ent);

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntComando ent) throws Exception
	{
            if (getResources(req).getMessage("detalhe.comando.comandoRegra.exibir").equals("s"))
            {
                // Salva ComandoRegra
                List<EntComandoRegra> lstPrsCdr = ent.getLstComandoRegra();
                List<EntComandoRegra> lstTmpCdr = montarComandoRegra(req, form, ent, "");
                AtualizarComandoRegra(form, lstPrsCdr, lstTmpCdr);
            }
            if (getResources(req).getMessage("detalhe.comando.comandoPai.exibir").equals("s"))
            {
                // Salva ComandoPai
                List<EntComando> lstPrsCmd = ent.getLstComandoPai();
                List<EntComando> lstTmpCmd = montarComando(req, form, ent, "PAI_");
                AtualizarComando(form, lstPrsCmd, lstTmpCmd);
            }
            if (getResources(req).getMessage("detalhe.comando.comandoPerfil.exibir").equals("s"))
            {
                // Salva ComandoPerfil
                List<EntComandoPerfil> lstPrsCmp = ent.getLstComandoPerfil();
                List<EntComandoPerfil> lstTmpCmp = montarComandoPerfil(req, form, ent, "");
                AtualizarComandoPerfil(form, lstPrsCmp, lstTmpCmp);
            }

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntComando ent) throws Exception
	{
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntSistema(), form, req);
            if (null != ent && null != ent.getEntSistema())
                BeanUtils.copyProperties(form, ent.getEntSistema());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntComandoPai(), form, req);
            if (null != ent && null != ent.getEntComandoPai())
                BeanUtils.copyProperties(form, ent.getEntComandoPai());

	}

	public void converterValores(ActionForm form)
	{

        // CmdFlgMenu
        if ((((DynaValidatorForm) form).get("cmdFlgMenu")) != null && !(((DynaValidatorForm) form).get("cmdFlgMenu")).equals(""))
        {
            Integer cmdFlgMenu = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("cmdFlgMenu"));
            ((DynaValidatorForm) form).set("cmdFlgMenu", cmdFlgMenu.toString());
        }



	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntComando ent) throws Exception
	{

	
        if (getResources(req).getMessage("campo.comando.sisIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.comando.sisIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstSistema"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntSistema());
            carregarSistema(map, form, req, res, metodo, l); 
            
        }
        if (getResources(req).getMessage("campo.comando.cmdIdtChavePai.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.comando.cmdIdtChavePai.visual").toLowerCase().equals("l") && null == req.getAttribute("lstComando"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntComandoPai());
            carregarComando(map, form, req, res, metodo, l); 
            
        }
            if (getResources(req).getMessage("detalhe.comando.comandoRegra.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.comandoRegra.rngIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstRng"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstComandoRegra() != null && ent.getLstComandoRegra().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstComandoRegra().iterator(); iterator.hasNext();)
                        //{
                            //EntComandoRegra obj = (EntComandoRegra) iterator.next();
                            //l.add(obj.getEntRegraNegocio());
                        //}
                    //}
                //}
                carregarRegraNegocio(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.comando.comando.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.comando.sisIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstSis"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstComando() != null && ent.getLstComando().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstComando().iterator(); iterator.hasNext();)
                        //{
                            //EntComando obj = (EntComando) iterator.next();
                            //l.add(obj.getEntSistema());
                        //}
                    //}
                //}
                carregarSistema(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.comando.comandoPai.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.comando.cmdIdtChavePai.visual").toLowerCase().equals("l") && null == req.getAttribute("lstCmd"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstComandoPai() != null && ent.getLstComandoPai().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstComandoPai().iterator(); iterator.hasNext();)
                        //{
                            //EntComando obj = (EntComando) iterator.next();
                            //l.add(obj.getEntComando());
                        //}
                    //}
                //}
                carregarSistema(map, form, req, res, metodo, l);
                carregarComando(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.comando.comandoPerfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.comandoPerfil.perIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstPer"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstComandoPerfil() != null && ent.getLstComandoPerfil().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstComandoPerfil().iterator(); iterator.hasNext();)
                        //{
                            //EntComandoPerfil obj = (EntComandoPerfil) iterator.next();
                            //l.add(obj.getEntPerfil());
                        //}
                    //}
                //}
                carregarPerfil(map, form, req, res, metodo, l);
            }

	}

    public void carregarSistema(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarSistema(map, form, req, res, "par", null);

    }
    public void carregarSistema(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcSistema ngc = new NgcSistema();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstSis", ngc.consultarHabilitados(new String[][]{{"sisDscTitulo", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstSis", ngc.consultarTodos(new String[][]{{"sisDscTitulo", "ASC"}}));
        }
    }

    public void carregarComando(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarComando(map, form, req, res, "par", null);

    }
    public void carregarComando(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcComando ngc = new NgcComando();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstCmd", ngc.consultarHabilitados(new String[][]{{"cmdDscLabel", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstCmd", ngc.consultarTodos(new String[][]{{"cmdDscLabel", "ASC"}}));
        }
    }

    public void carregarRegraNegocio(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarRegraNegocio(map, form, req, res, "par", null);

    }
    public void carregarRegraNegocio(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcRegraNegocio ngc = new NgcRegraNegocio();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstRng", ngc.consultarHabilitados(new String[][]{{"rngDscIdentificacao", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstRng", ngc.consultarTodos(new String[][]{{"rngDscIdentificacao", "ASC"}}));
        }
    }

    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarPerfil(map, form, req, res, "par", null);

    }
    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcPerfil ngc = new NgcPerfil();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstPer", ngc.consultarHabilitados(new String[][]{{"perDscPerfil", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstPer", ngc.consultarTodos(new String[][]{{"perDscPerfil", "ASC"}}));
        }
    }





            public void setaSistema(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntComando ent) throws Exception
            {
                EntSistema entSis;
                if (ent.getEntSistema() != null && !((String)((DynaValidatorForm)form).get("sisIdtChave")).equals("") && ent.getEntSistema().getSisIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("sisIdtChave"))) 
                    entSis = ent.getEntSistema();
                else
                {
                    entSis = new EntSistema();
                    try {
                        entSis.setSisIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("sisIdtChave")));
                    } catch (Exception e) {
                        entSis.setSisIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entSis, req);
                if (entSis.getSisIdtChave() != null)
                    ent.setEntSistema(entSis);
                else
                    ent.setEntSistema(null);
            }
            public void setaComandoPai(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntComando ent) throws Exception
            {
                EntComando entCmd;
                if (ent.getEntComandoPai() != null && !((String)((DynaValidatorForm)form).get("cmdIdtChavePai")).equals("") && ent.getEntComandoPai().getCmdIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("cmdIdtChavePai"))) 
                    entCmd = ent.getEntComandoPai();
                else
                {
                    entCmd = new EntComando();
                    try {
                        entCmd.setCmdIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("cmdIdtChavePai")));
                    } catch (Exception e) {
                        entCmd.setCmdIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entCmd, req);
                // Ajusta o campo chave (no caso de sufixo)
                if (null != ((DynaValidatorForm)form).get("cmdIdtChavePai") && !((DynaValidatorForm)form).get("cmdIdtChavePai").equals(""))
                    entCmd.setCmdIdtChave(new Long(((String) ((DynaValidatorForm)form).get("cmdIdtChavePai"))));
                if (entCmd.getCmdIdtChave() != null)
                    ent.setEntComandoPai(entCmd);
                else
                    ent.setEntComandoPai(null);
            }




            public List<EntComandoRegra> montarComandoRegra(HttpServletRequest req, ActionForm form, EntComando ent, String sufixo) throws Exception
            {
                List<EntComandoRegra> lst = new ArrayList<EntComandoRegra>(); 

                // Campos do detalhe
                String[] cdrIdtChave = (String[])((DynaValidatorForm)form).get("cdr_" + sufixo.toUpperCase() + "cdrIdtChave"); 
                String[] cmdIdtChave = (String[])((DynaValidatorForm)form).get("cdr_" + sufixo.toUpperCase() + "cmdIdtChave"); 
                String[] rngIdtChave = (String[])((DynaValidatorForm)form).get("cdr_" + sufixo.toUpperCase() + "rngIdtChave"); 
                String[] rngIdtChaveDsc = (String[])((DynaValidatorForm)form).get("cdr_" + sufixo.toUpperCase() + "rngIdtChaveDsc"); 
                String[] cdrFlgAtivo = (String[])((DynaValidatorForm)form).get("cdr_" + sufixo.toUpperCase() + "cdrFlgAtivo"); 

                // Percorre cada linha 
                for (int i = 0; i < cdrIdtChave.length; i++) 
                {
                    EntComandoRegra entTmp = new EntComandoRegra();  // Percorre o detalhe
                    // Copia campos - ComandoRegra
                if (cdrIdtChave[i] != null && !cdrIdtChave[i].equals(""))
                    entTmp.setCdrIdtChave(Long.parseLong(cdrIdtChave[i]));

            if (cmdIdtChave != null && cmdIdtChave.length > 0 && cmdIdtChave[i] != null && !cmdIdtChave[i].equals(""))
            {
                EntComando obj = new EntComando();
                obj.setCmdIdtChave(Long.parseLong(cmdIdtChave[i]));
                entTmp.setEntComando(obj);
            }
            else if(("cmdIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("cmdIdtChave"))
            {
                entTmp.setEntComando(ent);
            }
                if (rngIdtChave != null && rngIdtChave.length > 0 && rngIdtChave[i] != null && !rngIdtChave[i].equals(""))
                {
                    EntRegraNegocio entTmpRng = new EntRegraNegocio();
                    entTmpRng.setRngIdtChave(Long.parseLong(rngIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.comandoRegra.rngIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpRng, rngIdtChaveDsc[i], "campo.comandoRegra.rngIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntRegraNegocio(entTmpRng);
                }

            if (rngIdtChave != null && rngIdtChave.length > 0 && rngIdtChave[i] != null && !rngIdtChave[i].equals(""))
            {
                EntRegraNegocio obj = new EntRegraNegocio();
                obj.setRngIdtChave(Long.parseLong(rngIdtChave[i]));
                entTmp.setEntRegraNegocio(obj);
            }
            if (cdrFlgAtivo != null && cdrFlgAtivo.length > 0 && cdrFlgAtivo[i] != null && !cdrFlgAtivo[i].equals(""))
                entTmp.setCdrFlgAtivo(Integer.parseInt(cdrFlgAtivo[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntComando> montarComando(HttpServletRequest req, ActionForm form, EntComando ent, String sufixo) throws Exception
            {
                List<EntComando> lst = new ArrayList<EntComando>(); 

                // Campos do detalhe
                String[] cmdIdtChave = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdIdtChave"); 
                String[] sisIdtChave = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "sisIdtChave"); 
                String[] sisIdtChaveDsc = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "sisIdtChaveDsc"); 
                String[] cmdIdtChavePai = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdIdtChavePai"); 
                String[] cmdDscLabel = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdDscLabel"); 
                String[] cmdDscAcao = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdDscAcao"); 
                String[] cmdDatAtivacao = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdDatAtivacao"); 
                String[] cmdDatDesativacao = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdDatDesativacao"); 
                String[] cmdFlgMenu = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdFlgMenu"); 
                String[] cmdDscOrdem = (String[])((DynaValidatorForm)form).get("cmd_" + sufixo.toUpperCase() + "cmdDscOrdem"); 

                // Percorre cada linha 
                for (int i = 0; i < cmdIdtChave.length; i++) 
                {
                    EntComando entTmp = new EntComando();  // Percorre o detalhe
                    // Copia campos - Comando
                if (cmdIdtChave[i] != null && !cmdIdtChave[i].equals(""))
                    entTmp.setCmdIdtChave(Long.parseLong(cmdIdtChave[i]));

                if (sisIdtChave != null && sisIdtChave.length > 0 && sisIdtChave[i] != null && !sisIdtChave[i].equals(""))
                {
                    EntSistema entTmpSis = new EntSistema();
                    entTmpSis.setSisIdtChave(Long.parseLong(sisIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.comando.sisIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpSis, sisIdtChaveDsc[i], "campo.comando.sisIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntSistema(entTmpSis);
                }

            if (sisIdtChave != null && sisIdtChave.length > 0 && sisIdtChave[i] != null && !sisIdtChave[i].equals(""))
            {
                EntSistema obj = new EntSistema();
                obj.setSisIdtChave(Long.parseLong(sisIdtChave[i]));
                entTmp.setEntSistema(obj);
            }
            if (cmdIdtChavePai != null && cmdIdtChavePai.length > 0 && cmdIdtChavePai[i] != null && !cmdIdtChavePai[i].equals(""))
            {
                EntComando obj = new EntComando();
                obj.setCmdIdtChave(Long.parseLong(cmdIdtChavePai[i]));
                entTmp.setEntComandoPai(obj);
            }
            else if(("cmdIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("cmdIdtChavePai"))
            {
                entTmp.setEntComandoPai(ent);
            }
            if (cmdDscLabel != null && cmdDscLabel.length > 0 && cmdDscLabel[i] != null && !cmdDscLabel[i].equals(""))
                entTmp.setCmdDscLabel((cmdDscLabel[i]));

            if (cmdDscAcao != null && cmdDscAcao.length > 0 && cmdDscAcao[i] != null && !cmdDscAcao[i].equals(""))
                entTmp.setCmdDscAcao((cmdDscAcao[i]));

            if (cmdDatAtivacao != null && cmdDatAtivacao.length > 0 && cmdDatAtivacao[i] != null && !cmdDatAtivacao[i].equals(""))
                entTmp.setCmdDatAtivacao(FormatDate.parse(cmdDatAtivacao[i]));

            if (cmdDatDesativacao != null && cmdDatDesativacao.length > 0 && cmdDatDesativacao[i] != null && !cmdDatDesativacao[i].equals(""))
                entTmp.setCmdDatDesativacao(FormatDate.parse(cmdDatDesativacao[i]));

            if (cmdFlgMenu != null && cmdFlgMenu.length > 0 && cmdFlgMenu[i] != null && !cmdFlgMenu[i].equals(""))
                entTmp.setCmdFlgMenu(Integer.parseInt(cmdFlgMenu[i]));

            if (cmdDscOrdem != null && cmdDscOrdem.length > 0 && cmdDscOrdem[i] != null && !cmdDscOrdem[i].equals(""))
                entTmp.setCmdDscOrdem((cmdDscOrdem[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntComandoPerfil> montarComandoPerfil(HttpServletRequest req, ActionForm form, EntComando ent, String sufixo) throws Exception
            {
                List<EntComandoPerfil> lst = new ArrayList<EntComandoPerfil>(); 

                // Campos do detalhe
                String[] cmpIdtChave = (String[])((DynaValidatorForm)form).get("cmp_" + sufixo.toUpperCase() + "cmpIdtChave"); 
                String[] cmdIdtChave = (String[])((DynaValidatorForm)form).get("cmp_" + sufixo.toUpperCase() + "cmdIdtChave"); 
                String[] perIdtChave = (String[])((DynaValidatorForm)form).get("cmp_" + sufixo.toUpperCase() + "perIdtChave"); 
                String[] perIdtChaveDsc = (String[])((DynaValidatorForm)form).get("cmp_" + sufixo.toUpperCase() + "perIdtChaveDsc"); 

                // Percorre cada linha 
                for (int i = 0; i < cmpIdtChave.length; i++) 
                {
                    EntComandoPerfil entTmp = new EntComandoPerfil();  // Percorre o detalhe
                    // Copia campos - ComandoPerfil
                if (cmpIdtChave[i] != null && !cmpIdtChave[i].equals(""))
                    entTmp.setCmpIdtChave(Long.parseLong(cmpIdtChave[i]));

            if (cmdIdtChave != null && cmdIdtChave.length > 0 && cmdIdtChave[i] != null && !cmdIdtChave[i].equals(""))
            {
                EntComando obj = new EntComando();
                obj.setCmdIdtChave(Long.parseLong(cmdIdtChave[i]));
                entTmp.setEntComando(obj);
            }
            else if(("cmdIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("cmdIdtChave"))
            {
                entTmp.setEntComando(ent);
            }
                if (perIdtChave != null && perIdtChave.length > 0 && perIdtChave[i] != null && !perIdtChave[i].equals(""))
                {
                    EntPerfil entTmpPer = new EntPerfil();
                    entTmpPer.setPerIdtChave(Long.parseLong(perIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.comandoPerfil.perIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpPer, perIdtChaveDsc[i], "campo.comandoPerfil.perIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntPerfil(entTmpPer);
                }

            if (perIdtChave != null && perIdtChave.length > 0 && perIdtChave[i] != null && !perIdtChave[i].equals(""))
            {
                EntPerfil obj = new EntPerfil();
                obj.setPerIdtChave(Long.parseLong(perIdtChave[i]));
                entTmp.setEntPerfil(obj);
            }

                    lst.add(entTmp);
                }
                return lst; 
            }



            public void AtualizarComandoRegra(ActionForm form, List<EntComandoRegra> lstPrs, List<EntComandoRegra> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntComandoRegra entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntComandoRegra entTmp = lstTmp.get(j);
                    if (entPrs.getCdrIdtChave().equals(entTmp.getCdrIdtChave())) // Altera��o
                    {
                    entPrs.setEntComando(entTmp.getEntComando());
                    entPrs.setEntRegraNegocio(entTmp.getEntRegraNegocio());
                    entPrs.setCdrFlgAtivo(entTmp.getCdrFlgAtivo());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarComando(ActionForm form, List<EntComando> lstPrs, List<EntComando> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntComando entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntComando entTmp = lstTmp.get(j);
                    if (entPrs.getCmdIdtChave().equals(entTmp.getCmdIdtChave())) // Altera��o
                    {
                    entPrs.setEntSistema(entTmp.getEntSistema());
                    entPrs.setEntComandoPai(entTmp.getEntComandoPai());
                    entPrs.setCmdDscLabel(entTmp.getCmdDscLabel());
                    entPrs.setCmdDscAcao(entTmp.getCmdDscAcao());
                    entPrs.setCmdDatAtivacao(entTmp.getCmdDatAtivacao());
                    entPrs.setCmdDatDesativacao(entTmp.getCmdDatDesativacao());
                    entPrs.setCmdFlgMenu(entTmp.getCmdFlgMenu());
                    entPrs.setCmdDscOrdem(entTmp.getCmdDscOrdem());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarComandoPerfil(ActionForm form, List<EntComandoPerfil> lstPrs, List<EntComandoPerfil> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntComandoPerfil entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntComandoPerfil entTmp = lstTmp.get(j);
                    if (entPrs.getCmpIdtChave().equals(entTmp.getCmpIdtChave())) // Altera��o
                    {
                    entPrs.setEntComando(entTmp.getEntComando());
                    entPrs.setEntPerfil(entTmp.getEntPerfil());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }


    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.comando." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.comando." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
