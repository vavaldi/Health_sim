package arquitetura.funcional.health.base.entidades;

import arquitetura.funcional.health.entidades.EntComando;
import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import javax.persistence.Entity;
import java.math.BigDecimal;
import arquitetura.funcional.health.entidades.EntRegraNegocio;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntComandoRegraBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "CDR_IDT_CHAVE", unique = true, nullable = false)
    private Long cdrIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="CMD_IDT_CHAVE") 
    private EntComando entComando;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="RNG_IDT_CHAVE") 
    private EntRegraNegocio entRegraNegocio;

    @Column(name = "CDR_FLG_ATIVO", nullable = false)
    private Integer cdrFlgAtivo;

    public Long getCdrIdtChave() {
        return this.cdrIdtChave;
    } 

    public void setCdrIdtChave(Long valor) {
        this.cdrIdtChave = valor;
    } 

    public EntComando getEntComando() {
        return this.entComando;
    } 

    public void setEntComando(EntComando valor) {
        this.entComando = valor;
    } 

    public EntRegraNegocio getEntRegraNegocio() {
        return this.entRegraNegocio;
    } 

    public void setEntRegraNegocio(EntRegraNegocio valor) {
        this.entRegraNegocio = valor;
    } 

    public Integer getCdrFlgAtivo() {
        return this.cdrFlgAtivo;
    } 

    public void setCdrFlgAtivo(Integer valor) {
        this.cdrFlgAtivo = valor;
    } 


}