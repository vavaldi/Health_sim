package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoPapelBase;

public class DaoPapel extends DaoPapelBase
{
	public DaoPapel() throws SerproException
	{
		super();
	}
}
