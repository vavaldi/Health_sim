package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntTipoRegraBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "trn_tipo_regra")

public class EntTipoRegra extends EntTipoRegraBase
{

}
