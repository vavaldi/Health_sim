package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntComandoperfilRegraBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "cmr_comandoperfil_regra")

public class EntComandoperfilRegra extends EntComandoperfilRegraBase
{

}
