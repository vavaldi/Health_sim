package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActNoeudBase;

public class ActNoeud extends ActNoeudBase
{

}


