package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoStatutSanteBase;

public class DaoStatutSante extends DaoStatutSanteBase
{
	public DaoStatutSante() throws SerproException
	{
		super();
	}
}
