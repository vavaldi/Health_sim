package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoScenarioBase;

public class DaoScenario extends DaoScenarioBase
{
	public DaoScenario() throws SerproException
	{
		super();
	}
}
