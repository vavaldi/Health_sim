package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import java.util.List;
import javax.persistence.Id;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntComandoRegra;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import arquitetura.funcional.health.entidades.EntTipoRegra;
import arquitetura.funcional.health.entidades.EntComandoperfilRegra;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntRegraNegocioBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "RNG_IDT_CHAVE", unique = true, nullable = false)
    private Long rngIdtChave;

    @Column(name = "RNG_DSC_IDENTIFICACAO", nullable = false, length = 100)
    private String rngDscIdentificacao;

    @Column(name = "RNG_DSC_ALVO", nullable = false, length = 255)
    private String rngDscAlvo;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="TRN_IDT_CHAVE") 
    private EntTipoRegra entTipoRegra;

    @Column(name = "RNG_DSC_VALOR", nullable = true, length = 250)
    private String rngDscValor;

    @OneToMany(mappedBy="entRegraNegocio",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntComandoRegra> lstComandoRegra;

    @OneToMany(mappedBy="entRegraNegocio",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntComandoperfilRegra> lstComandoperfilRegra;

    public Long getRngIdtChave() {
        return this.rngIdtChave;
    } 

    public void setRngIdtChave(Long valor) {
        this.rngIdtChave = valor;
    } 

    public String getRngDscIdentificacao() {
        return this.rngDscIdentificacao;
    } 

    public void setRngDscIdentificacao(String valor) {
        this.rngDscIdentificacao = valor;
    } 

    public String getRngDscAlvo() {
        return this.rngDscAlvo;
    } 

    public void setRngDscAlvo(String valor) {
        this.rngDscAlvo = valor;
    } 

    public EntTipoRegra getEntTipoRegra() {
        return this.entTipoRegra;
    } 

    public void setEntTipoRegra(EntTipoRegra valor) {
        this.entTipoRegra = valor;
    } 

    public String getRngDscValor() {
        return this.rngDscValor;
    } 

    public void setRngDscValor(String valor) {
        this.rngDscValor = valor;
    } 

    public List<EntComandoRegra> getLstComandoRegra() {
        return this.lstComandoRegra;
    } 

    public void setLstComandoRegra(List<EntComandoRegra> valor) {
        this.lstComandoRegra = valor;
    } 

    public List<EntComandoperfilRegra> getLstComandoperfilRegra() {
        return this.lstComandoperfilRegra;
    } 

    public void setLstComandoperfilRegra(List<EntComandoperfilRegra> valor) {
        this.lstComandoperfilRegra = valor;
    } 


}