package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoComandoPerfilBase;

public class DaoComandoPerfil extends DaoComandoPerfilBase
{
	public DaoComandoPerfil() throws SerproException
	{
		super();
	}
}
