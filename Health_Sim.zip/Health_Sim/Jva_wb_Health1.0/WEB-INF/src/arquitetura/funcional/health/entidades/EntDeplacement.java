package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntDeplacementBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "dpc_deplacement")

public class EntDeplacement extends EntDeplacementBase
{

}
