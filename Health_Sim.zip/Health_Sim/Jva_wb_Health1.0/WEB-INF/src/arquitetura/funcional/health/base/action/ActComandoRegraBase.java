package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntComandoRegra;
import arquitetura.funcional.health.negocio.NgcComandoRegra;
import arquitetura.funcional.health.entidades.EntComando;
import arquitetura.funcional.health.negocio.NgcComando;
import arquitetura.funcional.health.negocio.NgcRegraNegocio;
import arquitetura.funcional.health.entidades.EntRegraNegocio;


public class ActComandoRegraBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoRegra ent = new EntComandoRegra();
		NgcComandoRegra ngc = new NgcComandoRegra();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);



            if (!((DynaValidatorForm) form).get("cmdIdtChave").equals(""))
            {
                EntComando entCmd = new EntComando();
                entCmd.setCmdIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("cmdIdtChave"))); 
                ent.setEntComando(entCmd);
            }
            if (!((DynaValidatorForm) form).get("rngIdtChave").equals(""))
            {
                EntRegraNegocio entRng = new EntRegraNegocio();
                entRng.setRngIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("rngIdtChave"))); 
                ent.setEntRegraNegocio(entRng);
            }

			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResCdr", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoRegra ent = new EntComandoRegra();
		NgcComandoRegra ngc = new NgcComandoRegra();

		try
		{
			ent = (EntComandoRegra) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cdrIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			


            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntComando(), form, req);
            if (null != ent && null != ent.getEntComando())
                BeanUtils.copyProperties(form, ent.getEntComando());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntRegraNegocio(), form, req);
            if (null != ent && null != ent.getEntRegraNegocio())
                BeanUtils.copyProperties(form, ent.getEntRegraNegocio());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas

			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoRegra ent = new EntComandoRegra();
		NgcComandoRegra ngc = new NgcComandoRegra();

		try
		{
			ent = (EntComandoRegra) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cdrIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						

            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntComando(), form, req);
            if (null != ent && null != ent.getEntComando())
                BeanUtils.copyProperties(form, ent.getEntComando());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntRegraNegocio(), form, req);
            if (null != ent && null != ent.getEntRegraNegocio())
                BeanUtils.copyProperties(form, ent.getEntRegraNegocio());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas

			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoRegra ent = new EntComandoRegra();
		NgcComandoRegra ngc = new NgcComandoRegra();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntComandoRegra) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cdrIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio




            if (getResources(req).getMessage("campo.comandoRegra.cmdIdtChave.exibir.cad").equals("s"))
                this.setaComando(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.comandoRegra.rngIdtChave.exibir.cad").equals("s"))
                this.setaRegraNegocio(map, form, req, res, ent);



			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntComandoRegra) ngc.consultarID(ent.getCdrIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResCdr", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoRegra ent = new EntComandoRegra();
		NgcComandoRegra ngc = new NgcComandoRegra();

		try
		{
			ent = (EntComandoRegra) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cdrIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoRegra ent = new EntComandoRegra();
		NgcComandoRegra ngc = new NgcComandoRegra();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);

            if (getResources(req).getMessage("campo.comandoRegra.cmdIdtChave.exibir.cad").equals("s"))
                this.setaComando(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.comandoRegra.rngIdtChave.exibir.cad").equals("s"))
                this.setaRegraNegocio(map, form, req, res, ent);


			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntComandoRegra) ngc.consultarID(ent.getCdrIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResCdr", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntComandoRegra ent) throws Exception
	{
            if (getResources(req).getMessage("campo.comandoRegra.cmdIdtChave.exibir.cad").equals("s"))
                this.setaComando(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.comandoRegra.rngIdtChave.exibir.cad").equals("s"))
                this.setaRegraNegocio(map, form, req, res, ent);

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntComandoRegra ent) throws Exception
	{

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntComandoRegra ent) throws Exception
	{
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntComando(), form, req);
            if (null != ent && null != ent.getEntComando())
                BeanUtils.copyProperties(form, ent.getEntComando());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntRegraNegocio(), form, req);
            if (null != ent && null != ent.getEntRegraNegocio())
                BeanUtils.copyProperties(form, ent.getEntRegraNegocio());

	}

	public void converterValores(ActionForm form)
	{

        // CdrFlgAtivo
        if ((((DynaValidatorForm) form).get("cdrFlgAtivo")) != null && !(((DynaValidatorForm) form).get("cdrFlgAtivo")).equals(""))
        {
            Integer cdrFlgAtivo = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("cdrFlgAtivo"));
            ((DynaValidatorForm) form).set("cdrFlgAtivo", cdrFlgAtivo.toString());
        }



	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntComandoRegra ent) throws Exception
	{

	
        if (getResources(req).getMessage("campo.comandoRegra.cmdIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.comandoRegra.cmdIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstComando"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntComando());
            carregarComando(map, form, req, res, metodo, l); 
            
        }
        if (getResources(req).getMessage("campo.comandoRegra.rngIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.comandoRegra.rngIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstRegraNegocio"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntRegraNegocio());
            carregarRegraNegocio(map, form, req, res, metodo, l); 
            
        }

	}

    public void carregarComando(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarComando(map, form, req, res, "par", null);

    }
    public void carregarComando(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcComando ngc = new NgcComando();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstCmd", ngc.consultarHabilitados(new String[][]{{"cmdDscLabel", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstCmd", ngc.consultarTodos(new String[][]{{"cmdDscLabel", "ASC"}}));
        }
    }

    public void carregarRegraNegocio(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarRegraNegocio(map, form, req, res, "par", null);

    }
    public void carregarRegraNegocio(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcRegraNegocio ngc = new NgcRegraNegocio();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstRng", ngc.consultarHabilitados(new String[][]{{"rngDscIdentificacao", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstRng", ngc.consultarTodos(new String[][]{{"rngDscIdentificacao", "ASC"}}));
        }
    }





            public void setaComando(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntComandoRegra ent) throws Exception
            {
                EntComando entCmd;
                if (ent.getEntComando() != null && !((String)((DynaValidatorForm)form).get("cmdIdtChave")).equals("") && ent.getEntComando().getCmdIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("cmdIdtChave"))) 
                    entCmd = ent.getEntComando();
                else
                {
                    entCmd = new EntComando();
                    try {
                        entCmd.setCmdIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("cmdIdtChave")));
                    } catch (Exception e) {
                        entCmd.setCmdIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entCmd, req);
                if (entCmd.getCmdIdtChave() != null)
                    ent.setEntComando(entCmd);
                else
                    ent.setEntComando(null);
            }
            public void setaRegraNegocio(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntComandoRegra ent) throws Exception
            {
                EntRegraNegocio entRng;
                if (ent.getEntRegraNegocio() != null && !((String)((DynaValidatorForm)form).get("rngIdtChave")).equals("") && ent.getEntRegraNegocio().getRngIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("rngIdtChave"))) 
                    entRng = ent.getEntRegraNegocio();
                else
                {
                    entRng = new EntRegraNegocio();
                    try {
                        entRng.setRngIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("rngIdtChave")));
                    } catch (Exception e) {
                        entRng.setRngIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entRng, req);
                if (entRng.getRngIdtChave() != null)
                    ent.setEntRegraNegocio(entRng);
                else
                    ent.setEntRegraNegocio(null);
            }








    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.comandoRegra." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.comandoRegra." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
