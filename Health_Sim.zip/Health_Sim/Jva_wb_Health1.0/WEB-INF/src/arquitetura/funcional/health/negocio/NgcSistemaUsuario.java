package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcSistemaUsuarioBase;
//import arquitetura.funcional.health.regra.RngSistemaUsuario;

public class NgcSistemaUsuario extends NgcSistemaUsuarioBase
{

}
