package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import java.util.List;
import javax.persistence.Id;
import arquitetura.funcional.health.entidades.EntPapel;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntTipoOrganizacao;
import arquitetura.funcional.health.entidades.EntPerfil;
import arquitetura.funcional.health.entidades.EntTipoPessoa;
import arquitetura.funcional.health.entidades.EntConfiguracao;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import arquitetura.funcional.health.entidades.EntTipoSexo;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntOrganizacaoBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ORG_IDT_CHAVE", unique = true, nullable = false)
    private Long orgIdtChave;

    @Column(name = "ORG_DSC_FANTASIA", nullable = false, length = 150)
    private String orgDscFantasia;

    @Column(name = "ORG_DSC_RAZAO_SOCIAL", nullable = true, length = 150)
    private String orgDscRazaoSocial;

    @Column(name = "ORG_DSC_CNPJ", nullable = true, length = 14)
    private String orgDscCnpj;

    @Column(name = "ORG_DSC_SITE", nullable = true, length = 100)
    private String orgDscSite;

    @Column(name = "ORG_DSC_EMAIL", nullable = true, length = 100)
    private String orgDscEmail;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="TOR_IDT_CHAVE") 
    private EntTipoOrganizacao entTipoOrganizacao;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="ORG_IDT_CHAVE_PAI") 
    private EntOrganizacao entOrganizacaoPai;

    @Column(name = "ORG_FLG_ATIVO", nullable = false)
    private Integer orgFlgAtivo;

    @OneToMany(mappedBy="entOrganizacao",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntConfiguracao> lstConfiguracao;

    @OneToMany(mappedBy="entOrganizacaoPai",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntOrganizacao> lstOrganizacaoPai;

    @OneToMany(mappedBy="entOrganizacao",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntPapel> lstPapel;

    @OneToMany(mappedBy="entOrganizacao",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntPerfil> lstPerfil;

    @OneToMany(mappedBy="entOrganizacao",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntTipoPessoa> lstTipoPessoa;

    @OneToMany(mappedBy="entOrganizacao",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntTipoSexo> lstTipoSexo;

    public Long getOrgIdtChave() {
        return this.orgIdtChave;
    } 

    public void setOrgIdtChave(Long valor) {
        this.orgIdtChave = valor;
    } 

    public String getOrgDscFantasia() {
        return this.orgDscFantasia;
    } 

    public void setOrgDscFantasia(String valor) {
        this.orgDscFantasia = valor;
    } 

    public String getOrgDscRazaoSocial() {
        return this.orgDscRazaoSocial;
    } 

    public void setOrgDscRazaoSocial(String valor) {
        this.orgDscRazaoSocial = valor;
    } 

    public String getOrgDscCnpj() {
        return this.orgDscCnpj;
    } 

    public void setOrgDscCnpj(String valor) {
        this.orgDscCnpj = valor;
    } 

    public String getOrgDscSite() {
        return this.orgDscSite;
    } 

    public void setOrgDscSite(String valor) {
        this.orgDscSite = valor;
    } 

    public String getOrgDscEmail() {
        return this.orgDscEmail;
    } 

    public void setOrgDscEmail(String valor) {
        this.orgDscEmail = valor;
    } 

    public EntTipoOrganizacao getEntTipoOrganizacao() {
        return this.entTipoOrganizacao;
    } 

    public void setEntTipoOrganizacao(EntTipoOrganizacao valor) {
        this.entTipoOrganizacao = valor;
    } 

    public EntOrganizacao getEntOrganizacaoPai() {
        return this.entOrganizacaoPai;
    } 

    public void setEntOrganizacaoPai(EntOrganizacao valor) {
        this.entOrganizacaoPai = valor;
    } 

    public Integer getOrgFlgAtivo() {
        return this.orgFlgAtivo;
    } 

    public void setOrgFlgAtivo(Integer valor) {
        this.orgFlgAtivo = valor;
    } 

    public List<EntConfiguracao> getLstConfiguracao() {
        return this.lstConfiguracao;
    } 

    public void setLstConfiguracao(List<EntConfiguracao> valor) {
        this.lstConfiguracao = valor;
    } 

    public List<EntOrganizacao> getLstOrganizacaoPai() {
        return this.lstOrganizacaoPai;
    } 

    public void setLstOrganizacaoPai(List<EntOrganizacao> valor) {
        this.lstOrganizacaoPai = valor;
    } 

    public List<EntPapel> getLstPapel() {
        return this.lstPapel;
    } 

    public void setLstPapel(List<EntPapel> valor) {
        this.lstPapel = valor;
    } 

    public List<EntPerfil> getLstPerfil() {
        return this.lstPerfil;
    } 

    public void setLstPerfil(List<EntPerfil> valor) {
        this.lstPerfil = valor;
    } 

    public List<EntTipoPessoa> getLstTipoPessoa() {
        return this.lstTipoPessoa;
    } 

    public void setLstTipoPessoa(List<EntTipoPessoa> valor) {
        this.lstTipoPessoa = valor;
    } 

    public List<EntTipoSexo> getLstTipoSexo() {
        return this.lstTipoSexo;
    } 

    public void setLstTipoSexo(List<EntTipoSexo> valor) {
        this.lstTipoSexo = valor;
    } 


}