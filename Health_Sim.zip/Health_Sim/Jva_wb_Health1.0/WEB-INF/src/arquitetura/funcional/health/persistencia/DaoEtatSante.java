package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoEtatSanteBase;

public class DaoEtatSante extends DaoEtatSanteBase
{
	public DaoEtatSante() throws SerproException
	{
		super();
	}
}
