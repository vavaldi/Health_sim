package arquitetura.funcional.health.persistencia;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoComandoBase;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntPessoa;

public class DaoComando extends DaoComandoBase
{
		public DaoComando() throws SerproException
		{
			super();
		}

//		public Object consultarPermissao(Object login)
//		{ 
//			Session sessao = (Session) getConnection();
//			//sessionFactory = new Configuration().configure("/resources/hibernate.cfg.xml").buildSessionFactory();
////			SessionFactory sessionFactory = new AnnotationConfiguration().configure("hibernateAcesso.cfg.xml").buildSessionFactory();
////			Session sessaoAcesso = sessionFactory.openSession();
//			
//			BtpLogin l = (BtpLogin) login;
//			Query q = sessao.createQuery(" select distinct cp.entComando "
//					+ " from arquitetura.funcional.health.entidades.EntUsuario u, "
//					+ "      arquitetura.funcional.health.entidades.EntSistema s,"
//					+ "      arquitetura.funcional.health.entidades.EntPerfilUsuario pu, "
//					+ "      arquitetura.funcional.health.entidades.EntPerfil p, "
//					//+ "      arquitetura.funcional.health.entidades.EntComandoPerfil cp "
//					+ " 	 IN (p.lstComandoPerfil) AS cp "
//					+ " where  (u.usuDscLogin like :login or p.perFlgPublico = '1' ) " 
//					+ "   and s.sisIdtChave = :sistema "
//					+ "   and u.usuIdtChave = pu.entUsuario.usuIdtChave "
//					+ "   and pu.entPerfil.perIdtChave = p.perIdtChave "
//					+ "   and cp.entComando.entSistema.sisIdtChave = :sistema " 
//					//+ "   and p.lstComandoPerfil.cmpIdtChave = cp.cmpIdtChave " 
//					+ " order by cp.entComando.cmdDscOrdem ");
//		    //q.setProperties(l); // fooBean has getName() and getSize()
//		    //q.set("login", u); 
//		    q.setString("login", l.getLogin()); 
//		    q.setInteger("sistema", Integer.valueOf(l.getSistema())); 
//			List comandos = q.list();
//			
//			// Verifica se o usu�rio n�o possui perfil cadastrado. 
//			//Retorna os comandos dos perfis p�blicos
//			if (comandos == null || comandos.size() == 0 || comandos.get(0) == null) 
//			{
//				q = sessao.createQuery(" select distinct cp.entComando "      
//								  +  " from arquitetura.funcional.health.entidades.EntPerfil p, "
//								  +  " 	    arquitetura.funcional.health.entidades.EntComandoPerfil cp "
//								  //+  " inner join p.entComandoPerfil cp " 
//								  //+  " inner join p.entSistema s "
//								  +  "	where p.perFlgPublico = '1' " 
//								  + "     and cp.entComando.entSistema.sisIdtChave = :sistema " 
//								  +  "	  and p.lstComandoPerfil.cmpIdtChave = cp.cmpIdtChave " 
//								  +  "    and p.entSistema.sisIdtChave = :sistema " 
//								  +  " order by cp.entComando.cmdDscOrdem "
//								);
//			    q.setInteger("sistema", Integer.valueOf(l.getSistema())); 
//			    comandos = q.list();  
//			}
//			
//			return comandos;
//		}

		public Object consultarPermissao(Object pessoa)
		{ 
			Session sessao = (Session) getConnection();
			
			// Verifica se a pessoa possui perfis cadastrados. 
			Query q = sessao.createQuery(" select distinct cp.entComando "
					+ " from arquitetura.funcional.health.entidades.EntPessoa ps, "
					+ "      arquitetura.funcional.health.entidades.EntPapel pp, "
					+ "      arquitetura.funcional.health.entidades.EntPerfil p, "
					+ " 	 IN (p.lstComandoPerfil) AS cp "
					+ " where  (ps.pesIdtChave = :idPessoa or p.perFlgPublico = '1' ) " 
					+ "   and ps.pesIdtChave = pp.entPessoa.pesIdtChave "
					+ "   and pp.entPerfil.perIdtChave = p.perIdtChave "
					+ " order by cp.entComando.cmdDscOrdem ");

		    q.setLong("idPessoa", ((EntPessoa)pessoa).getPesIdtChave()); 
			List comandos = q.list();
			
			//Retorna os comandos dos perfis p�blicos
//			if (comandos == null || comandos.size() == 0 || comandos.get(0) == null) 
//			{
//				q = sessao.createQuery(" select distinct cp.entComando "      
//								  +  " from arquitetura.funcional.health.entidades.EntPerfil p, "
//								  +  " 	    arquitetura.funcional.health.entidades.EntComandoPerfil cp "
//								  //+  " inner join p.entComandoPerfil cp " 
//								  //+  " inner join p.entSistema s "
//								  +  "	where p.perFlgPublico = '1' " 
//								  + "     and cp.entComando.entSistema.sisIdtChave = :sistema " 
//								  +  "	  and p.lstComandoPerfil.cmpIdtChave = cp.cmpIdtChave " 
//								  +  "    and p.entSistema.sisIdtChave = :sistema " 
//								  +  " order by cp.entComando.cmdDscOrdem "
//								);
//			    q.setInteger("sistema", Integer.valueOf(l.getSistema())); 
//			    comandos = q.list();  
//			}
			
			return comandos;
		}

		public Object consultarPermissao(EntPessoa pes, EntOrganizacao org)
		{ 
			Session sessao = (Session) getConnection();
			
//			// Verifica se a pessoa possui perfis cadastrados. 
//			Query q = sessao.createQuery(" select distinct cp.entComando "
//					+ " from arquitetura.funcional.health.entidades.EntPessoa ps, "
//					+ "      arquitetura.funcional.health.entidades.EntPapel pp, "
//					+ "      arquitetura.funcional.health.entidades.EntPerfil p, "
//					+ " 	 IN (p.lstComandoPerfil) AS cp "
//					+ " where  (ps.pesIdtChave = :idPessoa or p.perFlgPublico = '1' ) " 
//					+ "   and pp.entOrganizacao.orgIdtChave = :idOrg "
//					+ "   and ps.pesIdtChave = pp.entPessoa.pesIdtChave "
//					+ "   and pp.entPerfil.perIdtChave = p.perIdtChave "
//					+ " order by cp.entComando.cmdDscOrdem ");
			
			// Verifica se a pessoa possui perfis cadastrados. 
			Query q = sessao.createQuery(" select distinct cp.entComando "
					+ " from arquitetura.funcional.health.entidades.EntPessoa ps, "
					+ "      arquitetura.funcional.health.entidades.EntPapel pp, "
					+ "      arquitetura.funcional.health.entidades.EntOrganizacao o, "
					+ "      arquitetura.funcional.health.entidades.EntPerfil p, "
					+ " 	 IN (p.lstComandoPerfil) AS cp "
					+ " where  (ps.pesIdtChave = :idPessoa or p.perFlgPublico = '1' ) " 
					+ "   and pp.entOrganizacao.orgIdtChave = o.orgIdtChave "
					+ "   and o.orgIdtChave = :idOrg "
					+ "   and ps.pesIdtChave = pp.entPessoa.pesIdtChave "
					+ "   and pp.entPerfil.perIdtChave = p.perIdtChave "
					+ " order by cp.entComando.cmdDscOrdem ");
			
			if (null != pes && null != pes.getPesIdtChave() && pes.getPesIdtChave() > 0)
				q.setLong("idPessoa", pes.getPesIdtChave());
			else 
				q.setLong("idPessoa", 0);

			if (null != org && null != org.getOrgIdtChave() && org.getOrgIdtChave() > 0)
				q.setLong("idOrg", org.getOrgIdtChave());
			else 
				q.setLong("idOrg", 0);
			
			List comandos = q.list();
			
			//Retorna os comandos dos perfis p�blicos
//			if (comandos == null || comandos.size() == 0 || comandos.get(0) == null) 
//			{
//				q = sessao.createQuery(" select distinct cp.entComando "      
//								  +  " from arquitetura.funcional.health.entidades.EntPerfil p, "
//								  +  " 	    arquitetura.funcional.health.entidades.EntComandoPerfil cp "
//								  //+  " inner join p.entComandoPerfil cp " 
//								  //+  " inner join p.entSistema s "
//								  +  "	where p.perFlgPublico = '1' " 
//								  + "     and cp.entComando.entSistema.sisIdtChave = :sistema " 
//								  +  "	  and p.lstComandoPerfil.cmpIdtChave = cp.cmpIdtChave " 
//								  +  "    and p.entSistema.sisIdtChave = :sistema " 
//								  +  " order by cp.entComando.cmdDscOrdem "
//								);
//			    q.setInteger("sistema", Integer.valueOf(l.getSistema())); 
//			    comandos = q.list();  
//			}
			
			return comandos;
		}

		public Object consultarPermissao_BKP(EntPessoa pes, EntOrganizacao org)
		{ 
			Session sessao = (Session) getConnection();
			
			// Verifica se a pessoa possui perfis cadastrados. 
			Query q = sessao.createQuery(" select distinct cp.entComando "
					+ " from arquitetura.funcional.health.entidades.EntPessoa ps, "
					+ "      arquitetura.funcional.health.entidades.EntPapel pp, "
					+ "      arquitetura.funcional.health.entidades.EntPerfil p, "
					+ " 	 IN (p.lstComandoPerfil) AS cp "
					+ " where  (ps.pesIdtChave = :idPessoa or p.perFlgPublico = '1' ) " 
					+ "   and pp.entOrganizacao.orgIdtChave = :idOrg "
					+ "   and ps.pesIdtChave = pp.entPessoa.pesIdtChave "
					+ "   and pp.entPerfil.perIdtChave = p.perIdtChave "
					+ " order by cp.entComando.cmdDscOrdem ");
			
			if (null != pes && null != pes.getPesIdtChave())
				q.setLong("idPessoa", pes.getPesIdtChave());
			else 
				q.setLong("idPessoa", 0);

			if (null != org && null != org.getOrgIdtChave())
				q.setLong("idOrg", org.getOrgIdtChave());
			else 
				q.setLong("idOrg", 0);

			List comandos = q.list();
			
			//Retorna os comandos dos perfis p�blicos
//			if (comandos == null || comandos.size() == 0 || comandos.get(0) == null) 
//			{
//				q = sessao.createQuery(" select distinct cp.entComando "      
//								  +  " from arquitetura.funcional.health.entidades.EntPerfil p, "
//								  +  " 	    arquitetura.funcional.health.entidades.EntComandoPerfil cp "
//								  //+  " inner join p.entComandoPerfil cp " 
//								  //+  " inner join p.entSistema s "
//								  +  "	where p.perFlgPublico = '1' " 
//								  + "     and cp.entComando.entSistema.sisIdtChave = :sistema " 
//								  +  "	  and p.lstComandoPerfil.cmpIdtChave = cp.cmpIdtChave " 
//								  +  "    and p.entSistema.sisIdtChave = :sistema " 
//								  +  " order by cp.entComando.cmdDscOrdem "
//								);
//			    q.setInteger("sistema", Integer.valueOf(l.getSistema())); 
//			    comandos = q.list();  
//			}
			
			return comandos;
		}
}
