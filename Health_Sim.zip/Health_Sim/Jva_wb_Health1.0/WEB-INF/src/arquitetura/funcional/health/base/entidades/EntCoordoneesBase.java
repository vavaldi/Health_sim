package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import arquitetura.funcional.health.entidades.EntNoeud;
import java.util.Date;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntCoordoneesBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "COO_IDT_CHAVE", unique = true, nullable = false)
    private Long cooIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="NOD_IDT_CHAVE") 
    private EntNoeud entNoeud;

    @Column(name = "COO_NUM_TEMPS", nullable = false)
    private Integer cooNumTemps;

    @Column(name = "COD_VLR_COORDX", nullable = false)
    private BigDecimal codVlrCoordx;

    @Column(name = "COD_VLR_COORDY", nullable = false)
    private BigDecimal codVlrCoordy;

    public Long getCooIdtChave() {
        return this.cooIdtChave;
    } 

    public void setCooIdtChave(Long valor) {
        this.cooIdtChave = valor;
    } 

    public EntNoeud getEntNoeud() {
        return this.entNoeud;
    } 

    public void setEntNoeud(EntNoeud valor) {
        this.entNoeud = valor;
    } 

    public Integer getCooNumTemps() {
        return this.cooNumTemps;
    } 

    public void setCooNumTemps(Integer valor) {
        this.cooNumTemps = valor;
    } 

    public BigDecimal getCodVlrCoordx() {
        return this.codVlrCoordx;
    } 

    public void setCodVlrCoordx(BigDecimal valor) {
        this.codVlrCoordx = valor;
    } 

    public BigDecimal getCodVlrCoordy() {
        return this.codVlrCoordy;
    } 

    public void setCodVlrCoordy(BigDecimal valor) {
        this.codVlrCoordy = valor;
    } 


}