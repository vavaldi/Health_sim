package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActEtatSanteBase;

public class ActEtatSante extends ActEtatSanteBase
{

}


