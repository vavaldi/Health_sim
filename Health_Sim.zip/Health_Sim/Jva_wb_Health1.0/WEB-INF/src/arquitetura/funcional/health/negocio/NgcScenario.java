package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcScenarioBase;
//import arquitetura.funcional.health.regra.RngScenario;

public class NgcScenario extends NgcScenarioBase
{

}
