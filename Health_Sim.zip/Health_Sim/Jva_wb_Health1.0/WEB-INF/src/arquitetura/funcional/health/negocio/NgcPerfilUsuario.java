package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcPerfilUsuarioBase;
//import arquitetura.funcional.health.regra.RngPerfilUsuario;

public class NgcPerfilUsuario extends NgcPerfilUsuarioBase
{

}
