package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntComandoRegraBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "cdr_comando_regra")

public class EntComandoRegra extends EntComandoRegraBase
{

}
