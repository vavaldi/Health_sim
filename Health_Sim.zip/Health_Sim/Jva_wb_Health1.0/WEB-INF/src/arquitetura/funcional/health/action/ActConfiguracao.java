package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActConfiguracaoBase;

public class ActConfiguracao extends ActConfiguracaoBase
{

}


