package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcComandoRegraBase;
//import arquitetura.funcional.health.regra.RngComandoRegra;

public class NgcComandoRegra extends NgcComandoRegraBase
{

}
