package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcTipoOrganizacaoBase;
//import arquitetura.funcional.health.regra.RngTipoOrganizacao;

public class NgcTipoOrganizacao extends NgcTipoOrganizacaoBase
{

}
