package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoTipoRegraBase;

public class DaoTipoRegra extends DaoTipoRegraBase
{
	public DaoTipoRegra() throws SerproException
	{
		super();
	}
}
