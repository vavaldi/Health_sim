package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcContaminationBase;
//import arquitetura.funcional.health.regra.RngContamination;

public class NgcContamination extends NgcContaminationBase
{

}
