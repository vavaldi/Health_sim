package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntPerfilBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "per_perfil")

public class EntPerfil extends EntPerfilBase
{

}
