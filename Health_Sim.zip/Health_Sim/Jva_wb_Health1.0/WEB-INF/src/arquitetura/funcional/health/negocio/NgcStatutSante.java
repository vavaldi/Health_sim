package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcStatutSanteBase;
//import arquitetura.funcional.health.regra.RngStatutSante;

public class NgcStatutSante extends NgcStatutSanteBase
{

}
