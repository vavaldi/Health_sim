package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntEtatSante;
import arquitetura.funcional.health.negocio.NgcEtatSante;
import arquitetura.funcional.health.entidades.EntStatutSante;
import arquitetura.funcional.health.entidades.EntNoeud;
import arquitetura.funcional.health.negocio.NgcNoeud;
import arquitetura.funcional.health.negocio.NgcStatutSante;


public class ActEtatSanteBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntEtatSante ent = new EntEtatSante();
		NgcEtatSante ngc = new NgcEtatSante();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);



            if (!((DynaValidatorForm) form).get("nodIdtChave").equals(""))
            {
                EntNoeud entNod = new EntNoeud();
                entNod.setNodIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("nodIdtChave"))); 
                ent.setEntNoeud(entNod);
            }
            if (!((DynaValidatorForm) form).get("sstIdtChave").equals(""))
            {
                EntStatutSante entSst = new EntStatutSante();
                entSst.setSstIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("sstIdtChave"))); 
                ent.setEntStatutSante(entSst);
            }

			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResEst", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntEtatSante ent = new EntEtatSante();
		NgcEtatSante ngc = new NgcEtatSante();

		try
		{
			ent = (EntEtatSante) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("estIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			


            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntNoeud(), form, req);
            if (null != ent && null != ent.getEntNoeud())
                BeanUtils.copyProperties(form, ent.getEntNoeud());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntStatutSante(), form, req);
            if (null != ent && null != ent.getEntStatutSante())
                BeanUtils.copyProperties(form, ent.getEntStatutSante());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas

			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntEtatSante ent = new EntEtatSante();
		NgcEtatSante ngc = new NgcEtatSante();

		try
		{
			ent = (EntEtatSante) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("estIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						

            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntNoeud(), form, req);
            if (null != ent && null != ent.getEntNoeud())
                BeanUtils.copyProperties(form, ent.getEntNoeud());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntStatutSante(), form, req);
            if (null != ent && null != ent.getEntStatutSante())
                BeanUtils.copyProperties(form, ent.getEntStatutSante());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas

			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntEtatSante ent = new EntEtatSante();
		NgcEtatSante ngc = new NgcEtatSante();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntEtatSante) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("estIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio




            if (getResources(req).getMessage("campo.etatSante.nodIdtChave.exibir.cad").equals("s"))
                this.setaNoeud(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.etatSante.sstIdtChave.exibir.cad").equals("s"))
                this.setaStatutSante(map, form, req, res, ent);



			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntEtatSante) ngc.consultarID(ent.getEstIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResEst", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntEtatSante ent = new EntEtatSante();
		NgcEtatSante ngc = new NgcEtatSante();

		try
		{
			ent = (EntEtatSante) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("estIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntEtatSante ent = new EntEtatSante();
		NgcEtatSante ngc = new NgcEtatSante();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);

            if (getResources(req).getMessage("campo.etatSante.nodIdtChave.exibir.cad").equals("s"))
                this.setaNoeud(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.etatSante.sstIdtChave.exibir.cad").equals("s"))
                this.setaStatutSante(map, form, req, res, ent);


			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntEtatSante) ngc.consultarID(ent.getEstIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResEst", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntEtatSante ent) throws Exception
	{
            if (getResources(req).getMessage("campo.etatSante.nodIdtChave.exibir.cad").equals("s"))
                this.setaNoeud(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.etatSante.sstIdtChave.exibir.cad").equals("s"))
                this.setaStatutSante(map, form, req, res, ent);

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntEtatSante ent) throws Exception
	{

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntEtatSante ent) throws Exception
	{
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntNoeud(), form, req);
            if (null != ent && null != ent.getEntNoeud())
                BeanUtils.copyProperties(form, ent.getEntNoeud());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntStatutSante(), form, req);
            if (null != ent && null != ent.getEntStatutSante())
                BeanUtils.copyProperties(form, ent.getEntStatutSante());

	}

	public void converterValores(ActionForm form)
	{

        // EstNumTemps
        if ((((DynaValidatorForm) form).get("estNumTemps")) != null && !(((DynaValidatorForm) form).get("estNumTemps")).equals(""))
        {
            Integer estNumTemps = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("estNumTemps"));
            ((DynaValidatorForm) form).set("estNumTemps", estNumTemps.toString());
        }



	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntEtatSante ent) throws Exception
	{

	
        if (getResources(req).getMessage("campo.etatSante.nodIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.etatSante.nodIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstNoeud"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntNoeud());
            carregarNoeud(map, form, req, res, metodo, l); 
            
        }
        if (getResources(req).getMessage("campo.etatSante.sstIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.etatSante.sstIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstStatutSante"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntStatutSante());
            carregarStatutSante(map, form, req, res, metodo, l); 
            
        }

	}

    public void carregarNoeud(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarNoeud(map, form, req, res, "par", null);

    }
    public void carregarNoeud(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcNoeud ngc = new NgcNoeud();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstNod", ngc.consultarHabilitados(new String[][]{{"nodDscTitre", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstNod", ngc.consultarTodos(new String[][]{{"nodDscTitre", "ASC"}}));
        }
    }

    public void carregarStatutSante(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarStatutSante(map, form, req, res, "par", null);

    }
    public void carregarStatutSante(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcStatutSante ngc = new NgcStatutSante();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstSst", ngc.consultarHabilitados(new String[][]{{"sstDscTitre", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstSst", ngc.consultarTodos(new String[][]{{"sstDscTitre", "ASC"}}));
        }
    }





            public void setaNoeud(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntEtatSante ent) throws Exception
            {
                EntNoeud entNod;
                if (ent.getEntNoeud() != null && !((String)((DynaValidatorForm)form).get("nodIdtChave")).equals("") && ent.getEntNoeud().getNodIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("nodIdtChave"))) 
                    entNod = ent.getEntNoeud();
                else
                {
                    entNod = new EntNoeud();
                    try {
                        entNod.setNodIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("nodIdtChave")));
                    } catch (Exception e) {
                        entNod.setNodIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entNod, req);
                if (entNod.getNodIdtChave() != null)
                    ent.setEntNoeud(entNod);
                else
                    ent.setEntNoeud(null);
            }
            public void setaStatutSante(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntEtatSante ent) throws Exception
            {
                EntStatutSante entSst;
                if (ent.getEntStatutSante() != null && !((String)((DynaValidatorForm)form).get("sstIdtChave")).equals("") && ent.getEntStatutSante().getSstIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("sstIdtChave"))) 
                    entSst = ent.getEntStatutSante();
                else
                {
                    entSst = new EntStatutSante();
                    try {
                        entSst.setSstIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("sstIdtChave")));
                    } catch (Exception e) {
                        entSst.setSstIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entSst, req);
                if (entSst.getSstIdtChave() != null)
                    ent.setEntStatutSante(entSst);
                else
                    ent.setEntStatutSante(null);
            }








    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.etatSante." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.etatSante." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
