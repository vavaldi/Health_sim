package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActTipoSexoBase;

public class ActTipoSexo extends ActTipoSexoBase
{

}


