package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcPapelBase;
//import arquitetura.funcional.health.regra.RngPapel;

public class NgcPapel extends NgcPapelBase
{

}
