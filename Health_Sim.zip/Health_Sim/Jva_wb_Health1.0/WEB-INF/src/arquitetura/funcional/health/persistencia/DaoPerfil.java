package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoPerfilBase;

public class DaoPerfil extends DaoPerfilBase
{
	public DaoPerfil() throws SerproException
	{
		super();
	}
}
