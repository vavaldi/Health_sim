package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntEtatSanteBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "est_etat_sante")

public class EntEtatSante extends EntEtatSanteBase
{

}
