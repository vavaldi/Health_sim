package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntNoeud;
import arquitetura.funcional.health.negocio.NgcNoeud;
import arquitetura.funcional.health.negocio.NgcDeplacement;
import arquitetura.funcional.health.negocio.NgcContamination;
import arquitetura.funcional.health.entidades.EntEtatSante;
import arquitetura.funcional.health.entidades.EntStatutSante;
import arquitetura.funcional.health.entidades.EntDeplacement;
import arquitetura.funcional.health.negocio.NgcMaladie;
import arquitetura.funcional.health.entidades.EntNoeud;
import arquitetura.funcional.health.entidades.EntCoordonees;
import arquitetura.funcional.health.entidades.EntMaladie;
import arquitetura.funcional.health.entidades.EntScenario;
import arquitetura.funcional.health.negocio.NgcScenario;
import arquitetura.funcional.health.negocio.NgcCoordonees;
import arquitetura.funcional.health.negocio.NgcEtatSante;
import arquitetura.funcional.health.entidades.EntContamination;
import arquitetura.funcional.health.negocio.NgcStatutSante;


public class ActNoeudBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntNoeud ent = new EntNoeud();
		NgcNoeud ngc = new NgcNoeud();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);



            if (!((DynaValidatorForm) form).get("sceIdtChave").equals(""))
            {
                EntScenario entSce = new EntScenario();
                entSce.setSceIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("sceIdtChave"))); 
                ent.setEntScenario(entSce);
            }

			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResNod", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntNoeud ent = new EntNoeud();
		NgcNoeud ngc = new NgcNoeud();

		try
		{
			ent = (EntNoeud) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("nodIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			


            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntScenario(), form, req);
            if (null != ent && null != ent.getEntScenario())
                BeanUtils.copyProperties(form, ent.getEntScenario());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas
            List<EntContamination> lstCon1 = ent.getLstContamination1();
            lstCon1 = ordenarLista(lstCon1, getResources(req).getMessage("contamination.ordenacao")); 
            req.setAttribute("lstResCon1", lstCon1);

            List<EntContamination> lstCon2 = ent.getLstContamination2();
            lstCon2 = ordenarLista(lstCon2, getResources(req).getMessage("contamination.ordenacao")); 
            req.setAttribute("lstResCon2", lstCon2);

            List<EntCoordonees> lstCoo = ent.getLstCoordonees();
            lstCoo = ordenarLista(lstCoo, getResources(req).getMessage("coordonees.ordenacao")); 
            req.setAttribute("lstResCoo", lstCoo);

            List<EntDeplacement> lstDpc1 = ent.getLstDeplacement1();
            lstDpc1 = ordenarLista(lstDpc1, getResources(req).getMessage("deplacement.ordenacao")); 
            req.setAttribute("lstResDpc1", lstDpc1);

            List<EntDeplacement> lstDpc2 = ent.getLstDeplacement2();
            lstDpc2 = ordenarLista(lstDpc2, getResources(req).getMessage("deplacement.ordenacao")); 
            req.setAttribute("lstResDpc2", lstDpc2);

            List<EntEtatSante> lstEst = ent.getLstEtatSante();
            lstEst = ordenarLista(lstEst, getResources(req).getMessage("etatSante.ordenacao")); 
            req.setAttribute("lstResEst", lstEst);


			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntNoeud ent = new EntNoeud();
		NgcNoeud ngc = new NgcNoeud();

		try
		{
			ent = (EntNoeud) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("nodIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						

            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntScenario(), form, req);
            if (null != ent && null != ent.getEntScenario())
                BeanUtils.copyProperties(form, ent.getEntScenario());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas
            List<EntContamination> lstCon1 = ent.getLstContamination1();
            lstCon1 = ordenarLista(lstCon1, getResources(req).getMessage("contamination.ordenacao")); 
            req.setAttribute("lstResCon1", lstCon1);

            List<EntContamination> lstCon2 = ent.getLstContamination2();
            lstCon2 = ordenarLista(lstCon2, getResources(req).getMessage("contamination.ordenacao")); 
            req.setAttribute("lstResCon2", lstCon2);

            List<EntCoordonees> lstCoo = ent.getLstCoordonees();
            lstCoo = ordenarLista(lstCoo, getResources(req).getMessage("coordonees.ordenacao")); 
            req.setAttribute("lstResCoo", lstCoo);

            List<EntDeplacement> lstDpc1 = ent.getLstDeplacement1();
            lstDpc1 = ordenarLista(lstDpc1, getResources(req).getMessage("deplacement.ordenacao")); 
            req.setAttribute("lstResDpc1", lstDpc1);

            List<EntDeplacement> lstDpc2 = ent.getLstDeplacement2();
            lstDpc2 = ordenarLista(lstDpc2, getResources(req).getMessage("deplacement.ordenacao")); 
            req.setAttribute("lstResDpc2", lstDpc2);

            List<EntEtatSante> lstEst = ent.getLstEtatSante();
            lstEst = ordenarLista(lstEst, getResources(req).getMessage("etatSante.ordenacao")); 
            req.setAttribute("lstResEst", lstEst);


			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntNoeud ent = new EntNoeud();
		NgcNoeud ngc = new NgcNoeud();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntNoeud) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("nodIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio




            if (getResources(req).getMessage("campo.noeud.sceIdtChave.exibir.cad").equals("s"))
                this.setaScenario(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.noeud.contamination1.exibir").equals("s"))
            {
                // Salva Contamination1
                List<EntContamination> lstPrsCon = ent.getLstContamination1();
                List<EntContamination> lstTmpCon = montarContamination(req, form, ent, "1_");
                AtualizarContamination(form, lstPrsCon, lstTmpCon);
            }
            if (getResources(req).getMessage("detalhe.noeud.contamination2.exibir").equals("s"))
            {
                // Salva Contamination2
                List<EntContamination> lstPrsCon = ent.getLstContamination2();
                List<EntContamination> lstTmpCon = montarContamination(req, form, ent, "2_");
                AtualizarContamination(form, lstPrsCon, lstTmpCon);
            }
            if (getResources(req).getMessage("detalhe.noeud.coordonees.exibir").equals("s"))
            {
                // Salva Coordonees
                List<EntCoordonees> lstPrsCoo = ent.getLstCoordonees();
                List<EntCoordonees> lstTmpCoo = montarCoordonees(req, form, ent, "");
                AtualizarCoordonees(form, lstPrsCoo, lstTmpCoo);
            }
            if (getResources(req).getMessage("detalhe.noeud.deplacement1.exibir").equals("s"))
            {
                // Salva Deplacement1
                List<EntDeplacement> lstPrsDpc = ent.getLstDeplacement1();
                List<EntDeplacement> lstTmpDpc = montarDeplacement(req, form, ent, "1_");
                AtualizarDeplacement(form, lstPrsDpc, lstTmpDpc);
            }
            if (getResources(req).getMessage("detalhe.noeud.deplacement2.exibir").equals("s"))
            {
                // Salva Deplacement2
                List<EntDeplacement> lstPrsDpc = ent.getLstDeplacement2();
                List<EntDeplacement> lstTmpDpc = montarDeplacement(req, form, ent, "2_");
                AtualizarDeplacement(form, lstPrsDpc, lstTmpDpc);
            }
            if (getResources(req).getMessage("detalhe.noeud.etatSante.exibir").equals("s"))
            {
                // Salva EtatSante
                List<EntEtatSante> lstPrsEst = ent.getLstEtatSante();
                List<EntEtatSante> lstTmpEst = montarEtatSante(req, form, ent, "");
                AtualizarEtatSante(form, lstPrsEst, lstTmpEst);
            }


			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntNoeud) ngc.consultarID(ent.getNodIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResNod", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntNoeud ent = new EntNoeud();
		NgcNoeud ngc = new NgcNoeud();

		try
		{
			ent = (EntNoeud) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("nodIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntNoeud ent = new EntNoeud();
		NgcNoeud ngc = new NgcNoeud();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);

            if (getResources(req).getMessage("campo.noeud.sceIdtChave.exibir.cad").equals("s"))
                this.setaScenario(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.noeud.contamination1.exibir").equals("s"))
            {
                // Salva Contamination1
                Integer qtdeContamination1 = Integer.parseInt(req.getParameter("qtdeContamination1"));
                if (qtdeContamination1 > 0)
                {
                    List<EntContamination> lstTmpCon = montarContamination(req, form, ent, "1_");
                    ent.setLstContamination1(lstTmpCon);
                }

            }
            if (getResources(req).getMessage("detalhe.noeud.contamination2.exibir").equals("s"))
            {
                // Salva Contamination2
                Integer qtdeContamination2 = Integer.parseInt(req.getParameter("qtdeContamination2"));
                if (qtdeContamination2 > 0)
                {
                    List<EntContamination> lstTmpCon = montarContamination(req, form, ent, "2_");
                    ent.setLstContamination2(lstTmpCon);
                }

            }
            if (getResources(req).getMessage("detalhe.noeud.coordonees.exibir").equals("s"))
            {
                // Salva Coordonees
                Integer qtdeCoordonees = Integer.parseInt(req.getParameter("qtdeCoordonees"));
                if (qtdeCoordonees > 0)
                {
                    List<EntCoordonees> lstTmpCoo = montarCoordonees(req, form, ent, "");
                    ent.setLstCoordonees(lstTmpCoo);
                }

            }
            if (getResources(req).getMessage("detalhe.noeud.deplacement1.exibir").equals("s"))
            {
                // Salva Deplacement1
                Integer qtdeDeplacement1 = Integer.parseInt(req.getParameter("qtdeDeplacement1"));
                if (qtdeDeplacement1 > 0)
                {
                    List<EntDeplacement> lstTmpDpc = montarDeplacement(req, form, ent, "1_");
                    ent.setLstDeplacement1(lstTmpDpc);
                }

            }
            if (getResources(req).getMessage("detalhe.noeud.deplacement2.exibir").equals("s"))
            {
                // Salva Deplacement2
                Integer qtdeDeplacement2 = Integer.parseInt(req.getParameter("qtdeDeplacement2"));
                if (qtdeDeplacement2 > 0)
                {
                    List<EntDeplacement> lstTmpDpc = montarDeplacement(req, form, ent, "2_");
                    ent.setLstDeplacement2(lstTmpDpc);
                }

            }
            if (getResources(req).getMessage("detalhe.noeud.etatSante.exibir").equals("s"))
            {
                // Salva EtatSante
                Integer qtdeEtatSante = Integer.parseInt(req.getParameter("qtdeEtatSante"));
                if (qtdeEtatSante > 0)
                {
                    List<EntEtatSante> lstTmpEst = montarEtatSante(req, form, ent, "");
                    ent.setLstEtatSante(lstTmpEst);
                }

            }

			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntNoeud) ngc.consultarID(ent.getNodIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResNod", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntNoeud ent) throws Exception
	{
            if (getResources(req).getMessage("campo.noeud.sceIdtChave.exibir.cad").equals("s"))
                this.setaScenario(map, form, req, res, ent);

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntNoeud ent) throws Exception
	{
            if (getResources(req).getMessage("detalhe.noeud.contamination1.exibir").equals("s"))
            {
                // Salva Contamination1
                List<EntContamination> lstPrsCon = ent.getLstContamination1();
                List<EntContamination> lstTmpCon = montarContamination(req, form, ent, "1_");
                AtualizarContamination(form, lstPrsCon, lstTmpCon);
            }
            if (getResources(req).getMessage("detalhe.noeud.contamination2.exibir").equals("s"))
            {
                // Salva Contamination2
                List<EntContamination> lstPrsCon = ent.getLstContamination2();
                List<EntContamination> lstTmpCon = montarContamination(req, form, ent, "2_");
                AtualizarContamination(form, lstPrsCon, lstTmpCon);
            }
            if (getResources(req).getMessage("detalhe.noeud.coordonees.exibir").equals("s"))
            {
                // Salva Coordonees
                List<EntCoordonees> lstPrsCoo = ent.getLstCoordonees();
                List<EntCoordonees> lstTmpCoo = montarCoordonees(req, form, ent, "");
                AtualizarCoordonees(form, lstPrsCoo, lstTmpCoo);
            }
            if (getResources(req).getMessage("detalhe.noeud.deplacement1.exibir").equals("s"))
            {
                // Salva Deplacement1
                List<EntDeplacement> lstPrsDpc = ent.getLstDeplacement1();
                List<EntDeplacement> lstTmpDpc = montarDeplacement(req, form, ent, "1_");
                AtualizarDeplacement(form, lstPrsDpc, lstTmpDpc);
            }
            if (getResources(req).getMessage("detalhe.noeud.deplacement2.exibir").equals("s"))
            {
                // Salva Deplacement2
                List<EntDeplacement> lstPrsDpc = ent.getLstDeplacement2();
                List<EntDeplacement> lstTmpDpc = montarDeplacement(req, form, ent, "2_");
                AtualizarDeplacement(form, lstPrsDpc, lstTmpDpc);
            }
            if (getResources(req).getMessage("detalhe.noeud.etatSante.exibir").equals("s"))
            {
                // Salva EtatSante
                List<EntEtatSante> lstPrsEst = ent.getLstEtatSante();
                List<EntEtatSante> lstTmpEst = montarEtatSante(req, form, ent, "");
                AtualizarEtatSante(form, lstPrsEst, lstTmpEst);
            }

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntNoeud ent) throws Exception
	{
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntScenario(), form, req);
            if (null != ent && null != ent.getEntScenario())
                BeanUtils.copyProperties(form, ent.getEntScenario());

	}

	public void converterValores(ActionForm form)
	{




	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntNoeud ent) throws Exception
	{

	
        if (getResources(req).getMessage("campo.noeud.sceIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.noeud.sceIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstScenario"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntScenario());
            carregarScenario(map, form, req, res, metodo, l); 
            
        }
            if (getResources(req).getMessage("detalhe.noeud.contamination1.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.contamination.nodIdtChave1.visual").toLowerCase().equals("l") && null == req.getAttribute("lstNod"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstContamination1() != null && ent.getLstContamination1().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstContamination1().iterator(); iterator.hasNext();)
                        //{
                            //EntContamination obj = (EntContamination) iterator.next();
                            //l.add(obj.getEntNoeud());
                        //}
                    //}
                //}
                carregarNoeud(map, form, req, res, metodo, l);
                carregarMaladie(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.noeud.contamination2.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.contamination.nodIdtChave2.visual").toLowerCase().equals("l") && null == req.getAttribute("lstNod"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstContamination2() != null && ent.getLstContamination2().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstContamination2().iterator(); iterator.hasNext();)
                        //{
                            //EntContamination obj = (EntContamination) iterator.next();
                            //l.add(obj.getEntNoeud());
                        //}
                    //}
                //}
                carregarNoeud(map, form, req, res, metodo, l);
                carregarMaladie(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.noeud.contamination.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.contamination.mldIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstMld"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstContamination() != null && ent.getLstContamination().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstContamination().iterator(); iterator.hasNext();)
                        //{
                            //EntContamination obj = (EntContamination) iterator.next();
                            //l.add(obj.getEntMaladie());
                        //}
                    //}
                //}
                carregarMaladie(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.noeud.deplacement1.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.deplacement.nodIdtChave1.visual").toLowerCase().equals("l") && null == req.getAttribute("lstNod"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstDeplacement1() != null && ent.getLstDeplacement1().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstDeplacement1().iterator(); iterator.hasNext();)
                        //{
                            //EntDeplacement obj = (EntDeplacement) iterator.next();
                            //l.add(obj.getEntNoeud());
                        //}
                    //}
                //}
                carregarNoeud(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.noeud.deplacement2.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.deplacement.nodIdtChave2.visual").toLowerCase().equals("l") && null == req.getAttribute("lstNod"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstDeplacement2() != null && ent.getLstDeplacement2().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstDeplacement2().iterator(); iterator.hasNext();)
                        //{
                            //EntDeplacement obj = (EntDeplacement) iterator.next();
                            //l.add(obj.getEntNoeud());
                        //}
                    //}
                //}
                carregarNoeud(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.noeud.etatSante.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.etatSante.sstIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstSst"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstEtatSante() != null && ent.getLstEtatSante().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstEtatSante().iterator(); iterator.hasNext();)
                        //{
                            //EntEtatSante obj = (EntEtatSante) iterator.next();
                            //l.add(obj.getEntStatutSante());
                        //}
                    //}
                //}
                carregarStatutSante(map, form, req, res, metodo, l);
            }

	}

    public void carregarScenario(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarScenario(map, form, req, res, "par", null);

    }
    public void carregarScenario(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcScenario ngc = new NgcScenario();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstSce", ngc.consultarHabilitados(new String[][]{{"sceDscTitre", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstSce", ngc.consultarTodos(new String[][]{{"sceDscTitre", "ASC"}}));
        }
    }

    public void carregarNoeud(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarNoeud(map, form, req, res, "par", null);

    }
    public void carregarNoeud(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcNoeud ngc = new NgcNoeud();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstNod", ngc.consultarHabilitados(new String[][]{{"nodDscTitre", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstNod", ngc.consultarTodos(new String[][]{{"nodDscTitre", "ASC"}}));
        }
    }

    public void carregarMaladie(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarMaladie(map, form, req, res, "par", null);

    }
    public void carregarMaladie(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcMaladie ngc = new NgcMaladie();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstMld", ngc.consultarHabilitados(new String[][]{{"mldDscNom", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstMld", ngc.consultarTodos(new String[][]{{"mldDscNom", "ASC"}}));
        }
    }

    public void carregarStatutSante(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarStatutSante(map, form, req, res, "par", null);

    }
    public void carregarStatutSante(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcStatutSante ngc = new NgcStatutSante();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstSst", ngc.consultarHabilitados(new String[][]{{"sstDscTitre", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstSst", ngc.consultarTodos(new String[][]{{"sstDscTitre", "ASC"}}));
        }
    }





            public void setaScenario(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntNoeud ent) throws Exception
            {
                EntScenario entSce;
                if (ent.getEntScenario() != null && !((String)((DynaValidatorForm)form).get("sceIdtChave")).equals("") && ent.getEntScenario().getSceIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("sceIdtChave"))) 
                    entSce = ent.getEntScenario();
                else
                {
                    entSce = new EntScenario();
                    try {
                        entSce.setSceIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("sceIdtChave")));
                    } catch (Exception e) {
                        entSce.setSceIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entSce, req);
                if (entSce.getSceIdtChave() != null)
                    ent.setEntScenario(entSce);
                else
                    ent.setEntScenario(null);
            }




            public List<EntContamination> montarContamination(HttpServletRequest req, ActionForm form, EntNoeud ent, String sufixo) throws Exception
            {
                List<EntContamination> lst = new ArrayList<EntContamination>(); 

                // Campos do detalhe
                String[] conIdtChave = (String[])((DynaValidatorForm)form).get("con_" + sufixo.toUpperCase() + "conIdtChave"); 
                String[] conNumTemps = (String[])((DynaValidatorForm)form).get("con_" + sufixo.toUpperCase() + "conNumTemps"); 
                String[] nodIdtChave1 = (String[])((DynaValidatorForm)form).get("con_" + sufixo.toUpperCase() + "nodIdtChave1"); 
                String[] nodIdtChave2 = (String[])((DynaValidatorForm)form).get("con_" + sufixo.toUpperCase() + "nodIdtChave2"); 
                String[] conVlrDistance = (String[])((DynaValidatorForm)form).get("con_" + sufixo.toUpperCase() + "conVlrDistance"); 
                String[] mldIdtChave = (String[])((DynaValidatorForm)form).get("con_" + sufixo.toUpperCase() + "mldIdtChave"); 
                String[] mldIdtChaveDsc = (String[])((DynaValidatorForm)form).get("con_" + sufixo.toUpperCase() + "mldIdtChaveDsc"); 

                // Percorre cada linha 
                for (int i = 0; i < conIdtChave.length; i++) 
                {
                    EntContamination entTmp = new EntContamination();  // Percorre o detalhe
                    // Copia campos - Contamination
                if (conIdtChave[i] != null && !conIdtChave[i].equals(""))
                    entTmp.setConIdtChave(Long.parseLong(conIdtChave[i]));

            if (conNumTemps != null && conNumTemps.length > 0 && conNumTemps[i] != null && !conNumTemps[i].equals(""))
                entTmp.setConNumTemps(Integer.parseInt(conNumTemps[i]));

            if (nodIdtChave1 != null && nodIdtChave1.length > 0 && nodIdtChave1[i] != null && !nodIdtChave1[i].equals(""))
            {
                EntNoeud obj = new EntNoeud();
                obj.setNodIdtChave(Long.parseLong(nodIdtChave1[i]));
                entTmp.setEntNoeud1(obj);
            }
            else if(("nodIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("nodIdtChave1"))
            {
                entTmp.setEntNoeud1(ent);
            }
            if (nodIdtChave2 != null && nodIdtChave2.length > 0 && nodIdtChave2[i] != null && !nodIdtChave2[i].equals(""))
            {
                EntNoeud obj = new EntNoeud();
                obj.setNodIdtChave(Long.parseLong(nodIdtChave2[i]));
                entTmp.setEntNoeud2(obj);
            }
            else if(("nodIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("nodIdtChave2"))
            {
                entTmp.setEntNoeud2(ent);
            }
            if (conVlrDistance != null && conVlrDistance.length > 0 && conVlrDistance[i] != null && !conVlrDistance[i].equals(""))
                entTmp.setConVlrDistance(FormatNumber.parseBigDecimal(conVlrDistance[i]));

                if (mldIdtChave != null && mldIdtChave.length > 0 && mldIdtChave[i] != null && !mldIdtChave[i].equals(""))
                {
                    EntMaladie entTmpMld = new EntMaladie();
                    entTmpMld.setMldIdtChave(Long.parseLong(mldIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.contamination.mldIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpMld, mldIdtChaveDsc[i], "campo.contamination.mldIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntMaladie(entTmpMld);
                }

            if (mldIdtChave != null && mldIdtChave.length > 0 && mldIdtChave[i] != null && !mldIdtChave[i].equals(""))
            {
                EntMaladie obj = new EntMaladie();
                obj.setMldIdtChave(Long.parseLong(mldIdtChave[i]));
                entTmp.setEntMaladie(obj);
            }

                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntCoordonees> montarCoordonees(HttpServletRequest req, ActionForm form, EntNoeud ent, String sufixo) throws Exception
            {
                List<EntCoordonees> lst = new ArrayList<EntCoordonees>(); 

                // Campos do detalhe
                String[] cooIdtChave = (String[])((DynaValidatorForm)form).get("coo_" + sufixo.toUpperCase() + "cooIdtChave"); 
                String[] nodIdtChave = (String[])((DynaValidatorForm)form).get("coo_" + sufixo.toUpperCase() + "nodIdtChave"); 
                String[] cooNumTemps = (String[])((DynaValidatorForm)form).get("coo_" + sufixo.toUpperCase() + "cooNumTemps"); 
                String[] codVlrCoordx = (String[])((DynaValidatorForm)form).get("coo_" + sufixo.toUpperCase() + "codVlrCoordx"); 
                String[] codVlrCoordy = (String[])((DynaValidatorForm)form).get("coo_" + sufixo.toUpperCase() + "codVlrCoordy"); 

                // Percorre cada linha 
                for (int i = 0; i < cooIdtChave.length; i++) 
                {
                    EntCoordonees entTmp = new EntCoordonees();  // Percorre o detalhe
                    // Copia campos - Coordonees
                if (cooIdtChave[i] != null && !cooIdtChave[i].equals(""))
                    entTmp.setCooIdtChave(Long.parseLong(cooIdtChave[i]));

            if (nodIdtChave != null && nodIdtChave.length > 0 && nodIdtChave[i] != null && !nodIdtChave[i].equals(""))
            {
                EntNoeud obj = new EntNoeud();
                obj.setNodIdtChave(Long.parseLong(nodIdtChave[i]));
                entTmp.setEntNoeud(obj);
            }
            else if(("nodIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("nodIdtChave"))
            {
                entTmp.setEntNoeud(ent);
            }
            if (cooNumTemps != null && cooNumTemps.length > 0 && cooNumTemps[i] != null && !cooNumTemps[i].equals(""))
                entTmp.setCooNumTemps(Integer.parseInt(cooNumTemps[i]));

            if (codVlrCoordx != null && codVlrCoordx.length > 0 && codVlrCoordx[i] != null && !codVlrCoordx[i].equals(""))
                entTmp.setCodVlrCoordx(FormatNumber.parseBigDecimal(codVlrCoordx[i]));

            if (codVlrCoordy != null && codVlrCoordy.length > 0 && codVlrCoordy[i] != null && !codVlrCoordy[i].equals(""))
                entTmp.setCodVlrCoordy(FormatNumber.parseBigDecimal(codVlrCoordy[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntDeplacement> montarDeplacement(HttpServletRequest req, ActionForm form, EntNoeud ent, String sufixo) throws Exception
            {
                List<EntDeplacement> lst = new ArrayList<EntDeplacement>(); 

                // Campos do detalhe
                String[] dpcIdtChave = (String[])((DynaValidatorForm)form).get("dpc_" + sufixo.toUpperCase() + "dpcIdtChave"); 
                String[] dpcNumTemps = (String[])((DynaValidatorForm)form).get("dpc_" + sufixo.toUpperCase() + "dpcNumTemps"); 
                String[] nodIdtChave1 = (String[])((DynaValidatorForm)form).get("dpc_" + sufixo.toUpperCase() + "nodIdtChave1"); 
                String[] nodIdtChave2 = (String[])((DynaValidatorForm)form).get("dpc_" + sufixo.toUpperCase() + "nodIdtChave2"); 
                String[] dpcVlrDistance = (String[])((DynaValidatorForm)form).get("dpc_" + sufixo.toUpperCase() + "dpcVlrDistance"); 

                // Percorre cada linha 
                for (int i = 0; i < dpcIdtChave.length; i++) 
                {
                    EntDeplacement entTmp = new EntDeplacement();  // Percorre o detalhe
                    // Copia campos - Deplacement
                if (dpcIdtChave[i] != null && !dpcIdtChave[i].equals(""))
                    entTmp.setDpcIdtChave(Long.parseLong(dpcIdtChave[i]));

            if (dpcNumTemps != null && dpcNumTemps.length > 0 && dpcNumTemps[i] != null && !dpcNumTemps[i].equals(""))
                entTmp.setDpcNumTemps(Integer.parseInt(dpcNumTemps[i]));

            if (nodIdtChave1 != null && nodIdtChave1.length > 0 && nodIdtChave1[i] != null && !nodIdtChave1[i].equals(""))
            {
                EntNoeud obj = new EntNoeud();
                obj.setNodIdtChave(Long.parseLong(nodIdtChave1[i]));
                entTmp.setEntNoeud1(obj);
            }
            else if(("nodIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("nodIdtChave1"))
            {
                entTmp.setEntNoeud1(ent);
            }
            if (nodIdtChave2 != null && nodIdtChave2.length > 0 && nodIdtChave2[i] != null && !nodIdtChave2[i].equals(""))
            {
                EntNoeud obj = new EntNoeud();
                obj.setNodIdtChave(Long.parseLong(nodIdtChave2[i]));
                entTmp.setEntNoeud2(obj);
            }
            else if(("nodIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("nodIdtChave2"))
            {
                entTmp.setEntNoeud2(ent);
            }
            if (dpcVlrDistance != null && dpcVlrDistance.length > 0 && dpcVlrDistance[i] != null && !dpcVlrDistance[i].equals(""))
                entTmp.setDpcVlrDistance(FormatNumber.parseBigDecimal(dpcVlrDistance[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntEtatSante> montarEtatSante(HttpServletRequest req, ActionForm form, EntNoeud ent, String sufixo) throws Exception
            {
                List<EntEtatSante> lst = new ArrayList<EntEtatSante>(); 

                // Campos do detalhe
                String[] estIdtChave = (String[])((DynaValidatorForm)form).get("est_" + sufixo.toUpperCase() + "estIdtChave"); 
                String[] estNumTemps = (String[])((DynaValidatorForm)form).get("est_" + sufixo.toUpperCase() + "estNumTemps"); 
                String[] nodIdtChave = (String[])((DynaValidatorForm)form).get("est_" + sufixo.toUpperCase() + "nodIdtChave"); 
                String[] sstIdtChave = (String[])((DynaValidatorForm)form).get("est_" + sufixo.toUpperCase() + "sstIdtChave"); 
                String[] sstIdtChaveDsc = (String[])((DynaValidatorForm)form).get("est_" + sufixo.toUpperCase() + "sstIdtChaveDsc"); 

                // Percorre cada linha 
                for (int i = 0; i < estIdtChave.length; i++) 
                {
                    EntEtatSante entTmp = new EntEtatSante();  // Percorre o detalhe
                    // Copia campos - EtatSante
                if (estIdtChave[i] != null && !estIdtChave[i].equals(""))
                    entTmp.setEstIdtChave(Long.parseLong(estIdtChave[i]));

            if (estNumTemps != null && estNumTemps.length > 0 && estNumTemps[i] != null && !estNumTemps[i].equals(""))
                entTmp.setEstNumTemps(Integer.parseInt(estNumTemps[i]));

            if (nodIdtChave != null && nodIdtChave.length > 0 && nodIdtChave[i] != null && !nodIdtChave[i].equals(""))
            {
                EntNoeud obj = new EntNoeud();
                obj.setNodIdtChave(Long.parseLong(nodIdtChave[i]));
                entTmp.setEntNoeud(obj);
            }
            else if(("nodIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("nodIdtChave"))
            {
                entTmp.setEntNoeud(ent);
            }
                if (sstIdtChave != null && sstIdtChave.length > 0 && sstIdtChave[i] != null && !sstIdtChave[i].equals(""))
                {
                    EntStatutSante entTmpSst = new EntStatutSante();
                    entTmpSst.setSstIdtChave(Long.parseLong(sstIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.etatSante.sstIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpSst, sstIdtChaveDsc[i], "campo.etatSante.sstIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntStatutSante(entTmpSst);
                }

            if (sstIdtChave != null && sstIdtChave.length > 0 && sstIdtChave[i] != null && !sstIdtChave[i].equals(""))
            {
                EntStatutSante obj = new EntStatutSante();
                obj.setSstIdtChave(Long.parseLong(sstIdtChave[i]));
                entTmp.setEntStatutSante(obj);
            }

                    lst.add(entTmp);
                }
                return lst; 
            }



            public void AtualizarContamination(ActionForm form, List<EntContamination> lstPrs, List<EntContamination> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntContamination entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntContamination entTmp = lstTmp.get(j);
                    if (entPrs.getConIdtChave().equals(entTmp.getConIdtChave())) // Altera��o
                    {
                    entPrs.setConNumTemps(entTmp.getConNumTemps());
                    entPrs.setEntNoeud1(entTmp.getEntNoeud1());
                    entPrs.setEntNoeud2(entTmp.getEntNoeud2());
                    entPrs.setConVlrDistance(entTmp.getConVlrDistance());
                    entPrs.setEntMaladie(entTmp.getEntMaladie());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarCoordonees(ActionForm form, List<EntCoordonees> lstPrs, List<EntCoordonees> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntCoordonees entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntCoordonees entTmp = lstTmp.get(j);
                    if (entPrs.getCooIdtChave().equals(entTmp.getCooIdtChave())) // Altera��o
                    {
                    entPrs.setEntNoeud(entTmp.getEntNoeud());
                    entPrs.setCooNumTemps(entTmp.getCooNumTemps());
                    entPrs.setCodVlrCoordx(entTmp.getCodVlrCoordx());
                    entPrs.setCodVlrCoordy(entTmp.getCodVlrCoordy());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarDeplacement(ActionForm form, List<EntDeplacement> lstPrs, List<EntDeplacement> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntDeplacement entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntDeplacement entTmp = lstTmp.get(j);
                    if (entPrs.getDpcIdtChave().equals(entTmp.getDpcIdtChave())) // Altera��o
                    {
                    entPrs.setDpcNumTemps(entTmp.getDpcNumTemps());
                    entPrs.setEntNoeud1(entTmp.getEntNoeud1());
                    entPrs.setEntNoeud2(entTmp.getEntNoeud2());
                    entPrs.setDpcVlrDistance(entTmp.getDpcVlrDistance());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarEtatSante(ActionForm form, List<EntEtatSante> lstPrs, List<EntEtatSante> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntEtatSante entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntEtatSante entTmp = lstTmp.get(j);
                    if (entPrs.getEstIdtChave().equals(entTmp.getEstIdtChave())) // Altera��o
                    {
                    entPrs.setEstNumTemps(entTmp.getEstNumTemps());
                    entPrs.setEntNoeud(entTmp.getEntNoeud());
                    entPrs.setEntStatutSante(entTmp.getEntStatutSante());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }


    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.noeud." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.noeud." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
