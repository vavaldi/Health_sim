package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntTipoPessoa;
import arquitetura.funcional.health.negocio.NgcTipoPessoa;
import arquitetura.funcional.health.entidades.EntTipoPessoa;
import arquitetura.funcional.health.entidades.EntPessoa;
import arquitetura.funcional.health.negocio.NgcOrganizacao;
import arquitetura.funcional.health.entidades.EntTipoSexo;
import arquitetura.funcional.health.negocio.NgcPessoa;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.negocio.NgcTipoSexo;


public class ActTipoPessoaBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoPessoa ent = new EntTipoPessoa();
		NgcTipoPessoa ngc = new NgcTipoPessoa();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);



            if (!((DynaValidatorForm) form).get("orgIdtChave").equals(""))
            {
                EntOrganizacao entOrg = new EntOrganizacao();
                entOrg.setOrgIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("orgIdtChave"))); 
                ent.setEntOrganizacao(entOrg);
            }

			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResTpp", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoPessoa ent = new EntTipoPessoa();
		NgcTipoPessoa ngc = new NgcTipoPessoa();

		try
		{
			ent = (EntTipoPessoa) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("tppIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			


            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntOrganizacao(), form, req);
            if (null != ent && null != ent.getEntOrganizacao())
                BeanUtils.copyProperties(form, ent.getEntOrganizacao());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas
            List<EntPessoa> lstPes = ent.getLstPessoa();
            lstPes = ordenarLista(lstPes, getResources(req).getMessage("pessoa.ordenacao")); 
            req.setAttribute("lstResPes", lstPes);


			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoPessoa ent = new EntTipoPessoa();
		NgcTipoPessoa ngc = new NgcTipoPessoa();

		try
		{
			ent = (EntTipoPessoa) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("tppIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						

            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntOrganizacao(), form, req);
            if (null != ent && null != ent.getEntOrganizacao())
                BeanUtils.copyProperties(form, ent.getEntOrganizacao());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas
            List<EntPessoa> lstPes = ent.getLstPessoa();
            lstPes = ordenarLista(lstPes, getResources(req).getMessage("pessoa.ordenacao")); 
            req.setAttribute("lstResPes", lstPes);


			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoPessoa ent = new EntTipoPessoa();
		NgcTipoPessoa ngc = new NgcTipoPessoa();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntTipoPessoa) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("tppIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio




            if (getResources(req).getMessage("campo.tipoPessoa.orgIdtChave.exibir.cad").equals("s"))
                this.setaOrganizacao(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.tipoPessoa.pessoa.exibir").equals("s"))
            {
                // Salva Pessoa
                List<EntPessoa> lstPrsPes = ent.getLstPessoa();
                List<EntPessoa> lstTmpPes = montarPessoa(req, form, ent, "");
                AtualizarPessoa(form, lstPrsPes, lstTmpPes);
            }


			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntTipoPessoa) ngc.consultarID(ent.getTppIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResTpp", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoPessoa ent = new EntTipoPessoa();
		NgcTipoPessoa ngc = new NgcTipoPessoa();

		try
		{
			ent = (EntTipoPessoa) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("tppIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoPessoa ent = new EntTipoPessoa();
		NgcTipoPessoa ngc = new NgcTipoPessoa();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);

            if (getResources(req).getMessage("campo.tipoPessoa.orgIdtChave.exibir.cad").equals("s"))
                this.setaOrganizacao(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.tipoPessoa.pessoa.exibir").equals("s"))
            {
                // Salva Pessoa
                Integer qtdePessoa = Integer.parseInt(req.getParameter("qtdePessoa"));
                if (qtdePessoa > 0)
                {
                    List<EntPessoa> lstTmpPes = montarPessoa(req, form, ent, "");
                    ent.setLstPessoa(lstTmpPes);
                }

            }

			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntTipoPessoa) ngc.consultarID(ent.getTppIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResTpp", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntTipoPessoa ent) throws Exception
	{
            if (getResources(req).getMessage("campo.tipoPessoa.orgIdtChave.exibir.cad").equals("s"))
                this.setaOrganizacao(map, form, req, res, ent);

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntTipoPessoa ent) throws Exception
	{
            if (getResources(req).getMessage("detalhe.tipoPessoa.pessoa.exibir").equals("s"))
            {
                // Salva Pessoa
                List<EntPessoa> lstPrsPes = ent.getLstPessoa();
                List<EntPessoa> lstTmpPes = montarPessoa(req, form, ent, "");
                AtualizarPessoa(form, lstPrsPes, lstTmpPes);
            }

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntTipoPessoa ent) throws Exception
	{
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntOrganizacao(), form, req);
            if (null != ent && null != ent.getEntOrganizacao())
                BeanUtils.copyProperties(form, ent.getEntOrganizacao());

	}

	public void converterValores(ActionForm form)
	{

        // TppFlgAtivo
        if ((((DynaValidatorForm) form).get("tppFlgAtivo")) != null && !(((DynaValidatorForm) form).get("tppFlgAtivo")).equals(""))
        {
            Integer tppFlgAtivo = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("tppFlgAtivo"));
            ((DynaValidatorForm) form).set("tppFlgAtivo", tppFlgAtivo.toString());
        }



	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntTipoPessoa ent) throws Exception
	{

	
        if (getResources(req).getMessage("campo.tipoPessoa.orgIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.tipoPessoa.orgIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstOrganizacao"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntOrganizacao());
            carregarOrganizacao(map, form, req, res, metodo, l); 
            
        }
            if (getResources(req).getMessage("detalhe.tipoPessoa.pessoa.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.pessoa.tsxIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstTsx"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPessoa() != null && ent.getLstPessoa().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPessoa().iterator(); iterator.hasNext();)
                        //{
                            //EntPessoa obj = (EntPessoa) iterator.next();
                            //l.add(obj.getEntTipoSexo());
                        //}
                    //}
                //}
                carregarTipoSexo(map, form, req, res, metodo, l);
            }

	}

    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarOrganizacao(map, form, req, res, "par", null);

    }
    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcOrganizacao ngc = new NgcOrganizacao();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstOrg", ngc.consultarHabilitados(new String[][]{{"orgDscFantasia", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstOrg", ngc.consultarTodos(new String[][]{{"orgDscFantasia", "ASC"}}));
        }
    }

    public void carregarTipoSexo(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarTipoSexo(map, form, req, res, "par", null);

    }
    public void carregarTipoSexo(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcTipoSexo ngc = new NgcTipoSexo();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstTsx", ngc.consultarHabilitados(new String[][]{{"tsxDscNome", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstTsx", ngc.consultarTodos(new String[][]{{"tsxDscNome", "ASC"}}));
        }
    }





            public void setaOrganizacao(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntTipoPessoa ent) throws Exception
            {
                EntOrganizacao entOrg;
                if (ent.getEntOrganizacao() != null && !((String)((DynaValidatorForm)form).get("orgIdtChave")).equals("") && ent.getEntOrganizacao().getOrgIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("orgIdtChave"))) 
                    entOrg = ent.getEntOrganizacao();
                else
                {
                    entOrg = new EntOrganizacao();
                    try {
                        entOrg.setOrgIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("orgIdtChave")));
                    } catch (Exception e) {
                        entOrg.setOrgIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entOrg, req);
                if (entOrg.getOrgIdtChave() != null)
                    ent.setEntOrganizacao(entOrg);
                else
                    ent.setEntOrganizacao(null);
            }




            public List<EntPessoa> montarPessoa(HttpServletRequest req, ActionForm form, EntTipoPessoa ent, String sufixo) throws Exception
            {
                List<EntPessoa> lst = new ArrayList<EntPessoa>(); 

                // Campos do detalhe
                String[] pesIdtChave = (String[])((DynaValidatorForm)form).get("pes_" + sufixo.toUpperCase() + "pesIdtChave"); 
                String[] tppIdtChave = (String[])((DynaValidatorForm)form).get("pes_" + sufixo.toUpperCase() + "tppIdtChave"); 
                String[] pesDscNome = (String[])((DynaValidatorForm)form).get("pes_" + sufixo.toUpperCase() + "pesDscNome"); 
                String[] pesDocCpf = (String[])((DynaValidatorForm)form).get("pes_" + sufixo.toUpperCase() + "pesDocCpf"); 
                String[] pesDocCnpj = (String[])((DynaValidatorForm)form).get("pes_" + sufixo.toUpperCase() + "pesDocCnpj"); 
                String[] pesDscFantasia = (String[])((DynaValidatorForm)form).get("pes_" + sufixo.toUpperCase() + "pesDscFantasia"); 
                String[] pesDatNascimento = (String[])((DynaValidatorForm)form).get("pes_" + sufixo.toUpperCase() + "pesDatNascimento"); 
                String[] tsxIdtChave = (String[])((DynaValidatorForm)form).get("pes_" + sufixo.toUpperCase() + "tsxIdtChave"); 
                String[] tsxIdtChaveDsc = (String[])((DynaValidatorForm)form).get("pes_" + sufixo.toUpperCase() + "tsxIdtChaveDsc"); 
                String[] pesFlgEditavel = (String[])((DynaValidatorForm)form).get("pes_" + sufixo.toUpperCase() + "pesFlgEditavel"); 
                String[] pesDscEmail = (String[])((DynaValidatorForm)form).get("pes_" + sufixo.toUpperCase() + "pesDscEmail"); 

                // Percorre cada linha 
                for (int i = 0; i < pesIdtChave.length; i++) 
                {
                    EntPessoa entTmp = new EntPessoa();  // Percorre o detalhe
                    // Copia campos - Pessoa
                if (pesIdtChave[i] != null && !pesIdtChave[i].equals(""))
                    entTmp.setPesIdtChave(Long.parseLong(pesIdtChave[i]));

            if (tppIdtChave != null && tppIdtChave.length > 0 && tppIdtChave[i] != null && !tppIdtChave[i].equals(""))
            {
                EntTipoPessoa obj = new EntTipoPessoa();
                obj.setTppIdtChave(Long.parseLong(tppIdtChave[i]));
                entTmp.setEntTipoPessoa(obj);
            }
            else if(("tppIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("tppIdtChave"))
            {
                entTmp.setEntTipoPessoa(ent);
            }
            if (pesDscNome != null && pesDscNome.length > 0 && pesDscNome[i] != null && !pesDscNome[i].equals(""))
                entTmp.setPesDscNome((pesDscNome[i]));

            if (pesDocCpf != null && pesDocCpf.length > 0 && pesDocCpf[i] != null && !pesDocCpf[i].equals(""))
                entTmp.setPesDocCpf((pesDocCpf[i]));

            if (pesDocCnpj != null && pesDocCnpj.length > 0 && pesDocCnpj[i] != null && !pesDocCnpj[i].equals(""))
                entTmp.setPesDocCnpj((pesDocCnpj[i]));

            if (pesDscFantasia != null && pesDscFantasia.length > 0 && pesDscFantasia[i] != null && !pesDscFantasia[i].equals(""))
                entTmp.setPesDscFantasia((pesDscFantasia[i]));

            if (pesDatNascimento != null && pesDatNascimento.length > 0 && pesDatNascimento[i] != null && !pesDatNascimento[i].equals(""))
                entTmp.setPesDatNascimento(FormatDate.parse(pesDatNascimento[i]));

                if (tsxIdtChave != null && tsxIdtChave.length > 0 && tsxIdtChave[i] != null && !tsxIdtChave[i].equals(""))
                {
                    EntTipoSexo entTmpTsx = new EntTipoSexo();
                    entTmpTsx.setTsxIdtChave(Long.parseLong(tsxIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.pessoa.tsxIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpTsx, tsxIdtChaveDsc[i], "campo.pessoa.tsxIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntTipoSexo(entTmpTsx);
                }

            if (tsxIdtChave != null && tsxIdtChave.length > 0 && tsxIdtChave[i] != null && !tsxIdtChave[i].equals(""))
            {
                EntTipoSexo obj = new EntTipoSexo();
                obj.setTsxIdtChave(Long.parseLong(tsxIdtChave[i]));
                entTmp.setEntTipoSexo(obj);
            }
            if (pesFlgEditavel != null && pesFlgEditavel.length > 0 && pesFlgEditavel[i] != null && !pesFlgEditavel[i].equals(""))
                entTmp.setPesFlgEditavel(Integer.parseInt(pesFlgEditavel[i]));

            if (pesDscEmail != null && pesDscEmail.length > 0 && pesDscEmail[i] != null && !pesDscEmail[i].equals(""))
                entTmp.setPesDscEmail((pesDscEmail[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }



            public void AtualizarPessoa(ActionForm form, List<EntPessoa> lstPrs, List<EntPessoa> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntPessoa entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntPessoa entTmp = lstTmp.get(j);
                    if (entPrs.getPesIdtChave().equals(entTmp.getPesIdtChave())) // Altera��o
                    {
                    entPrs.setEntTipoPessoa(entTmp.getEntTipoPessoa());
                    entPrs.setPesDscNome(entTmp.getPesDscNome());
                    entPrs.setPesDocCpf(entTmp.getPesDocCpf());
                    entPrs.setPesDocCnpj(entTmp.getPesDocCnpj());
                    entPrs.setPesDscFantasia(entTmp.getPesDscFantasia());
                    entPrs.setPesDatNascimento(entTmp.getPesDatNascimento());
                    entPrs.setEntTipoSexo(entTmp.getEntTipoSexo());
                    entPrs.setPesFlgEditavel(entTmp.getPesFlgEditavel());
                    entPrs.setPesDscEmail(entTmp.getPesDscEmail());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }


    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.tipoPessoa." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.tipoPessoa." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
