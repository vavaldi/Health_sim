package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntStatutSanteBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "sst_statut_sante")

public class EntStatutSante extends EntStatutSanteBase
{

}
