package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoModeleBase;

public class DaoModele extends DaoModeleBase
{
	public DaoModele() throws SerproException
	{
		super();
	}
}
