package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActContaminationBase;

public class ActContamination extends ActContaminationBase
{

}


