package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import arquitetura.funcional.health.entidades.EntPessoa;
import javax.persistence.Column;
import javax.persistence.Table;
import java.util.List;
import javax.persistence.Id;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntTipoSexoBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "TSX_IDT_CHAVE", unique = true, nullable = false)
    private Long tsxIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="ORG_IDT_CHAVE") 
    private EntOrganizacao entOrganizacao;

    @Column(name = "TSX_DSC_NOME", nullable = false, length = 100)
    private String tsxDscNome;

    @Column(name = "TSX_DSC_SIGLA", nullable = false, length = 5)
    private String tsxDscSigla;

    @OneToMany(mappedBy="entTipoSexo",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntPessoa> lstPessoa;

    public Long getTsxIdtChave() {
        return this.tsxIdtChave;
    } 

    public void setTsxIdtChave(Long valor) {
        this.tsxIdtChave = valor;
    } 

    public EntOrganizacao getEntOrganizacao() {
        return this.entOrganizacao;
    } 

    public void setEntOrganizacao(EntOrganizacao valor) {
        this.entOrganizacao = valor;
    } 

    public String getTsxDscNome() {
        return this.tsxDscNome;
    } 

    public void setTsxDscNome(String valor) {
        this.tsxDscNome = valor;
    } 

    public String getTsxDscSigla() {
        return this.tsxDscSigla;
    } 

    public void setTsxDscSigla(String valor) {
        this.tsxDscSigla = valor;
    } 

    public List<EntPessoa> getLstPessoa() {
        return this.lstPessoa;
    } 

    public void setLstPessoa(List<EntPessoa> valor) {
        this.lstPessoa = valor;
    } 


}