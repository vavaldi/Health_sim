package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import java.util.List;
import javax.persistence.Id;
import arquitetura.funcional.health.entidades.EntPapel;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntSistema;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntComandoPerfil;
import arquitetura.funcional.health.entidades.EntPerfil;
import arquitetura.funcional.health.entidades.EntPerfilUsuario;
import javax.persistence.OneToMany;
import arquitetura.funcional.health.entidades.EntTipoAcesso;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntPerfilBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "PER_IDT_CHAVE", unique = true, nullable = false)
    private Long perIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="ORG_IDT_CHAVE") 
    private EntOrganizacao entOrganizacao;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="SIS_IDT_CHAVE") 
    private EntSistema entSistema;

    @Column(name = "PER_DSC_PERFIL", nullable = false, length = 50)
    private String perDscPerfil;

    @Column(name = "PER_FLG_PUBLICO", nullable = false)
    private Integer perFlgPublico;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="TPA_IDT_CHAVE") 
    private EntTipoAcesso entTipoAcesso;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="PER_IDT_CHAVE_SUPERIOR") 
    private EntPerfil entPerfilSuperior;

    @OneToMany(mappedBy="entPerfil",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntComandoPerfil> lstComandoPerfil;

    @OneToMany(mappedBy="entPerfil",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntPapel> lstPapel;

    @OneToMany(mappedBy="entPerfilSuperior",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntPerfil> lstPerfilSuperior;

    @OneToMany(mappedBy="entPerfil",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntPerfilUsuario> lstPerfilUsuario;

    public Long getPerIdtChave() {
        return this.perIdtChave;
    } 

    public void setPerIdtChave(Long valor) {
        this.perIdtChave = valor;
    } 

    public EntOrganizacao getEntOrganizacao() {
        return this.entOrganizacao;
    } 

    public void setEntOrganizacao(EntOrganizacao valor) {
        this.entOrganizacao = valor;
    } 

    public EntSistema getEntSistema() {
        return this.entSistema;
    } 

    public void setEntSistema(EntSistema valor) {
        this.entSistema = valor;
    } 

    public String getPerDscPerfil() {
        return this.perDscPerfil;
    } 

    public void setPerDscPerfil(String valor) {
        this.perDscPerfil = valor;
    } 

    public Integer getPerFlgPublico() {
        return this.perFlgPublico;
    } 

    public void setPerFlgPublico(Integer valor) {
        this.perFlgPublico = valor;
    } 

    public EntTipoAcesso getEntTipoAcesso() {
        return this.entTipoAcesso;
    } 

    public void setEntTipoAcesso(EntTipoAcesso valor) {
        this.entTipoAcesso = valor;
    } 

    public EntPerfil getEntPerfilSuperior() {
        return this.entPerfilSuperior;
    } 

    public void setEntPerfilSuperior(EntPerfil valor) {
        this.entPerfilSuperior = valor;
    } 

    public List<EntComandoPerfil> getLstComandoPerfil() {
        return this.lstComandoPerfil;
    } 

    public void setLstComandoPerfil(List<EntComandoPerfil> valor) {
        this.lstComandoPerfil = valor;
    } 

    public List<EntPapel> getLstPapel() {
        return this.lstPapel;
    } 

    public void setLstPapel(List<EntPapel> valor) {
        this.lstPapel = valor;
    } 

    public List<EntPerfil> getLstPerfilSuperior() {
        return this.lstPerfilSuperior;
    } 

    public void setLstPerfilSuperior(List<EntPerfil> valor) {
        this.lstPerfilSuperior = valor;
    } 

    public List<EntPerfilUsuario> getLstPerfilUsuario() {
        return this.lstPerfilUsuario;
    } 

    public void setLstPerfilUsuario(List<EntPerfilUsuario> valor) {
        this.lstPerfilUsuario = valor;
    } 


}