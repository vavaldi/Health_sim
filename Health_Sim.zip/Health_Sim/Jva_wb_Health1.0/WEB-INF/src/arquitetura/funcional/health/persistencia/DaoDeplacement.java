package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoDeplacementBase;

public class DaoDeplacement extends DaoDeplacementBase
{
	public DaoDeplacement() throws SerproException
	{
		super();
	}
}
