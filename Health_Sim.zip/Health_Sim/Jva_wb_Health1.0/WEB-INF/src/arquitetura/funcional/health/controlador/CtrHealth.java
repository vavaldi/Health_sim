package arquitetura.funcional.health.controlador;

import arquitetura.funcional.health.base.controlador.CtrHealthBase;

public class CtrHealth extends CtrHealthBase
{

}
