package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntTipoRegra;
import arquitetura.funcional.health.negocio.NgcTipoRegra;
import arquitetura.funcional.health.entidades.EntTipoRegra;
import arquitetura.funcional.health.negocio.NgcRegraNegocio;
import arquitetura.funcional.health.entidades.EntRegraNegocio;


public class ActTipoRegraBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoRegra ent = new EntTipoRegra();
		NgcTipoRegra ngc = new NgcTipoRegra();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);




			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResTrn", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoRegra ent = new EntTipoRegra();
		NgcTipoRegra ngc = new NgcTipoRegra();

		try
		{
			ent = (EntTipoRegra) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("trnIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			



//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas
            List<EntRegraNegocio> lstRng = ent.getLstRegraNegocio();
            lstRng = ordenarLista(lstRng, getResources(req).getMessage("regraNegocio.ordenacao")); 
            req.setAttribute("lstResRng", lstRng);


			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoRegra ent = new EntTipoRegra();
		NgcTipoRegra ngc = new NgcTipoRegra();

		try
		{
			ent = (EntTipoRegra) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("trnIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						


//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas
            List<EntRegraNegocio> lstRng = ent.getLstRegraNegocio();
            lstRng = ordenarLista(lstRng, getResources(req).getMessage("regraNegocio.ordenacao")); 
            req.setAttribute("lstResRng", lstRng);


			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoRegra ent = new EntTipoRegra();
		NgcTipoRegra ngc = new NgcTipoRegra();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntTipoRegra) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("trnIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio





            if (getResources(req).getMessage("detalhe.tipoRegra.regraNegocio.exibir").equals("s"))
            {
                // Salva RegraNegocio
                List<EntRegraNegocio> lstPrsRng = ent.getLstRegraNegocio();
                List<EntRegraNegocio> lstTmpRng = montarRegraNegocio(req, form, ent, "");
                AtualizarRegraNegocio(form, lstPrsRng, lstTmpRng);
            }


			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntTipoRegra) ngc.consultarID(ent.getTrnIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResTrn", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoRegra ent = new EntTipoRegra();
		NgcTipoRegra ngc = new NgcTipoRegra();

		try
		{
			ent = (EntTipoRegra) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("trnIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoRegra ent = new EntTipoRegra();
		NgcTipoRegra ngc = new NgcTipoRegra();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);


            if (getResources(req).getMessage("detalhe.tipoRegra.regraNegocio.exibir").equals("s"))
            {
                // Salva RegraNegocio
                Integer qtdeRegraNegocio = Integer.parseInt(req.getParameter("qtdeRegraNegocio"));
                if (qtdeRegraNegocio > 0)
                {
                    List<EntRegraNegocio> lstTmpRng = montarRegraNegocio(req, form, ent, "");
                    ent.setLstRegraNegocio(lstTmpRng);
                }

            }

			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntTipoRegra) ngc.consultarID(ent.getTrnIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResTrn", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntTipoRegra ent) throws Exception
	{

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntTipoRegra ent) throws Exception
	{
            if (getResources(req).getMessage("detalhe.tipoRegra.regraNegocio.exibir").equals("s"))
            {
                // Salva RegraNegocio
                List<EntRegraNegocio> lstPrsRng = ent.getLstRegraNegocio();
                List<EntRegraNegocio> lstTmpRng = montarRegraNegocio(req, form, ent, "");
                AtualizarRegraNegocio(form, lstPrsRng, lstTmpRng);
            }

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntTipoRegra ent) throws Exception
	{

	}

	public void converterValores(ActionForm form)
	{

        // TrnFlgIgual
        if ((((DynaValidatorForm) form).get("trnFlgIgual")) != null && !(((DynaValidatorForm) form).get("trnFlgIgual")).equals(""))
        {
            Integer trnFlgIgual = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("trnFlgIgual"));
            ((DynaValidatorForm) form).set("trnFlgIgual", trnFlgIgual.toString());
        }
        // TrnFlgDiferente
        if ((((DynaValidatorForm) form).get("trnFlgDiferente")) != null && !(((DynaValidatorForm) form).get("trnFlgDiferente")).equals(""))
        {
            Integer trnFlgDiferente = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("trnFlgDiferente"));
            ((DynaValidatorForm) form).set("trnFlgDiferente", trnFlgDiferente.toString());
        }
        // TrnFlgMaiorque
        if ((((DynaValidatorForm) form).get("trnFlgMaiorque")) != null && !(((DynaValidatorForm) form).get("trnFlgMaiorque")).equals(""))
        {
            Integer trnFlgMaiorque = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("trnFlgMaiorque"));
            ((DynaValidatorForm) form).set("trnFlgMaiorque", trnFlgMaiorque.toString());
        }
        // TrnFlgMenorque
        if ((((DynaValidatorForm) form).get("trnFlgMenorque")) != null && !(((DynaValidatorForm) form).get("trnFlgMenorque")).equals(""))
        {
            Integer trnFlgMenorque = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("trnFlgMenorque"));
            ((DynaValidatorForm) form).set("trnFlgMenorque", trnFlgMenorque.toString());
        }
        // TrnFlgContido
        if ((((DynaValidatorForm) form).get("trnFlgContido")) != null && !(((DynaValidatorForm) form).get("trnFlgContido")).equals(""))
        {
            Integer trnFlgContido = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("trnFlgContido"));
            ((DynaValidatorForm) form).set("trnFlgContido", trnFlgContido.toString());
        }
        // TrnFlgContem
        if ((((DynaValidatorForm) form).get("trnFlgContem")) != null && !(((DynaValidatorForm) form).get("trnFlgContem")).equals(""))
        {
            Integer trnFlgContem = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("trnFlgContem"));
            ((DynaValidatorForm) form).set("trnFlgContem", trnFlgContem.toString());
        }
        // TrnFlgAtivo
        if ((((DynaValidatorForm) form).get("trnFlgAtivo")) != null && !(((DynaValidatorForm) form).get("trnFlgAtivo")).equals(""))
        {
            Integer trnFlgAtivo = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("trnFlgAtivo"));
            ((DynaValidatorForm) form).set("trnFlgAtivo", trnFlgAtivo.toString());
        }



	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntTipoRegra ent) throws Exception
	{

	

	}









            public List<EntRegraNegocio> montarRegraNegocio(HttpServletRequest req, ActionForm form, EntTipoRegra ent, String sufixo) throws Exception
            {
                List<EntRegraNegocio> lst = new ArrayList<EntRegraNegocio>(); 

                // Campos do detalhe
                String[] rngIdtChave = (String[])((DynaValidatorForm)form).get("rng_" + sufixo.toUpperCase() + "rngIdtChave"); 
                String[] rngDscIdentificacao = (String[])((DynaValidatorForm)form).get("rng_" + sufixo.toUpperCase() + "rngDscIdentificacao"); 
                String[] rngDscAlvo = (String[])((DynaValidatorForm)form).get("rng_" + sufixo.toUpperCase() + "rngDscAlvo"); 
                String[] trnIdtChave = (String[])((DynaValidatorForm)form).get("rng_" + sufixo.toUpperCase() + "trnIdtChave"); 
                String[] rngDscValor = (String[])((DynaValidatorForm)form).get("rng_" + sufixo.toUpperCase() + "rngDscValor"); 

                // Percorre cada linha 
                for (int i = 0; i < rngIdtChave.length; i++) 
                {
                    EntRegraNegocio entTmp = new EntRegraNegocio();  // Percorre o detalhe
                    // Copia campos - RegraNegocio
                if (rngIdtChave[i] != null && !rngIdtChave[i].equals(""))
                    entTmp.setRngIdtChave(Long.parseLong(rngIdtChave[i]));

            if (rngDscIdentificacao != null && rngDscIdentificacao.length > 0 && rngDscIdentificacao[i] != null && !rngDscIdentificacao[i].equals(""))
                entTmp.setRngDscIdentificacao((rngDscIdentificacao[i]));

            if (rngDscAlvo != null && rngDscAlvo.length > 0 && rngDscAlvo[i] != null && !rngDscAlvo[i].equals(""))
                entTmp.setRngDscAlvo((rngDscAlvo[i]));

            if (trnIdtChave != null && trnIdtChave.length > 0 && trnIdtChave[i] != null && !trnIdtChave[i].equals(""))
            {
                EntTipoRegra obj = new EntTipoRegra();
                obj.setTrnIdtChave(Long.parseLong(trnIdtChave[i]));
                entTmp.setEntTipoRegra(obj);
            }
            else if(("trnIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("trnIdtChave"))
            {
                entTmp.setEntTipoRegra(ent);
            }
            if (rngDscValor != null && rngDscValor.length > 0 && rngDscValor[i] != null && !rngDscValor[i].equals(""))
                entTmp.setRngDscValor((rngDscValor[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }



            public void AtualizarRegraNegocio(ActionForm form, List<EntRegraNegocio> lstPrs, List<EntRegraNegocio> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntRegraNegocio entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntRegraNegocio entTmp = lstTmp.get(j);
                    if (entPrs.getRngIdtChave().equals(entTmp.getRngIdtChave())) // Altera��o
                    {
                    entPrs.setRngDscIdentificacao(entTmp.getRngDscIdentificacao());
                    entPrs.setRngDscAlvo(entTmp.getRngDscAlvo());
                    entPrs.setEntTipoRegra(entTmp.getEntTipoRegra());
                    entPrs.setRngDscValor(entTmp.getRngDscValor());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }


    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.tipoRegra." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.tipoRegra." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
