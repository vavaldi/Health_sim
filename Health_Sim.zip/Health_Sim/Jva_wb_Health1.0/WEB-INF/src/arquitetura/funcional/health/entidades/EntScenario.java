package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntScenarioBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "sce_scenario")

public class EntScenario extends EntScenarioBase
{

}
