package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntPapelBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "pap_papel")

public class EntPapel extends EntPapelBase
{

}
