package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoContaminationBase;

public class DaoContamination extends DaoContaminationBase
{
	public DaoContamination() throws SerproException
	{
		super();
	}
}
