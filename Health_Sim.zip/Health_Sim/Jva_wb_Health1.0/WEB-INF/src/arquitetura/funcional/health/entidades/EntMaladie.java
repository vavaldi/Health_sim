package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntMaladieBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "mld_maladie")

public class EntMaladie extends EntMaladieBase
{

}
