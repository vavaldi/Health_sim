package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcSistemaBase;
//import arquitetura.funcional.health.regra.RngSistema;

public class NgcSistema extends NgcSistemaBase
{

}
