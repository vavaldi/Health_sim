package arquitetura.funcional.health.base.entidades;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import arquitetura.funcional.health.entidades.EntRegraNegocio;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntTipoRegraBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "TRN_IDT_CHAVE", unique = true, nullable = false)
    private Long trnIdtChave;

    @Column(name = "TRN_DSC_NOME", nullable = false, length = 100)
    private String trnDscNome;

    @Column(name = "TRN_DSC_DESCRICAO", nullable = true, length = 255)
    private String trnDscDescricao;

    @Column(name = "TRN_FLG_IGUAL", nullable = true)
    private Integer trnFlgIgual;

    @Column(name = "TRN_FLG_DIFERENTE", nullable = true)
    private Integer trnFlgDiferente;

    @Column(name = "TRN_FLG_MAIORQUE", nullable = true)
    private Integer trnFlgMaiorque;

    @Column(name = "TRN_FLG_MENORQUE", nullable = true)
    private Integer trnFlgMenorque;

    @Column(name = "TRN_FLG_CONTIDO", nullable = true)
    private Integer trnFlgContido;

    @Column(name = "TRN_FLG_CONTEM", nullable = true)
    private Integer trnFlgContem;

    @Column(name = "TRN_FLG_ATIVO", nullable = false)
    private Integer trnFlgAtivo;

    @OneToMany(mappedBy="entTipoRegra",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntRegraNegocio> lstRegraNegocio;

    public Long getTrnIdtChave() {
        return this.trnIdtChave;
    } 

    public void setTrnIdtChave(Long valor) {
        this.trnIdtChave = valor;
    } 

    public String getTrnDscNome() {
        return this.trnDscNome;
    } 

    public void setTrnDscNome(String valor) {
        this.trnDscNome = valor;
    } 

    public String getTrnDscDescricao() {
        return this.trnDscDescricao;
    } 

    public void setTrnDscDescricao(String valor) {
        this.trnDscDescricao = valor;
    } 

    public Integer getTrnFlgIgual() {
        return this.trnFlgIgual;
    } 

    public void setTrnFlgIgual(Integer valor) {
        this.trnFlgIgual = valor;
    } 

    public Integer getTrnFlgDiferente() {
        return this.trnFlgDiferente;
    } 

    public void setTrnFlgDiferente(Integer valor) {
        this.trnFlgDiferente = valor;
    } 

    public Integer getTrnFlgMaiorque() {
        return this.trnFlgMaiorque;
    } 

    public void setTrnFlgMaiorque(Integer valor) {
        this.trnFlgMaiorque = valor;
    } 

    public Integer getTrnFlgMenorque() {
        return this.trnFlgMenorque;
    } 

    public void setTrnFlgMenorque(Integer valor) {
        this.trnFlgMenorque = valor;
    } 

    public Integer getTrnFlgContido() {
        return this.trnFlgContido;
    } 

    public void setTrnFlgContido(Integer valor) {
        this.trnFlgContido = valor;
    } 

    public Integer getTrnFlgContem() {
        return this.trnFlgContem;
    } 

    public void setTrnFlgContem(Integer valor) {
        this.trnFlgContem = valor;
    } 

    public Integer getTrnFlgAtivo() {
        return this.trnFlgAtivo;
    } 

    public void setTrnFlgAtivo(Integer valor) {
        this.trnFlgAtivo = valor;
    } 

    public List<EntRegraNegocio> getLstRegraNegocio() {
        return this.lstRegraNegocio;
    } 

    public void setLstRegraNegocio(List<EntRegraNegocio> valor) {
        this.lstRegraNegocio = valor;
    } 


}