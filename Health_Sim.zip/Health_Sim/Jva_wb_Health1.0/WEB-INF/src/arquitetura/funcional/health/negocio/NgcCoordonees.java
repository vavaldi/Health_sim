package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcCoordoneesBase;
//import arquitetura.funcional.health.regra.RngCoordonees;

public class NgcCoordonees extends NgcCoordoneesBase
{

}
