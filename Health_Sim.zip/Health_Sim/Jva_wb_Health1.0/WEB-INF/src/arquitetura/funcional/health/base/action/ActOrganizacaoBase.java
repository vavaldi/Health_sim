package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.negocio.NgcOrganizacao;
import arquitetura.funcional.health.entidades.EntPessoa;
import arquitetura.funcional.health.negocio.NgcPapel;
import arquitetura.funcional.health.negocio.NgcOrganizacao;
import arquitetura.funcional.health.negocio.NgcConfiguracao;
import arquitetura.funcional.health.entidades.EntPapel;
import arquitetura.funcional.health.negocio.NgcPerfil;
import arquitetura.funcional.health.negocio.NgcPessoa;
import arquitetura.funcional.health.negocio.NgcTipoPessoa;
import arquitetura.funcional.health.entidades.EntSistema;
import arquitetura.funcional.health.entidades.EntTipoOrganizacao;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.negocio.NgcTipoSexo;
import arquitetura.funcional.health.entidades.EntPerfil;
import arquitetura.funcional.health.entidades.EntTipoPessoa;
import arquitetura.funcional.health.negocio.NgcSistema;
import arquitetura.funcional.health.entidades.EntConfiguracao;
import arquitetura.funcional.health.entidades.EntTipoAcesso;
import arquitetura.funcional.health.negocio.NgcTipoOrganizacao;
import arquitetura.funcional.health.entidades.EntTipoSexo;
import arquitetura.funcional.health.negocio.NgcTipoAcesso;


public class ActOrganizacaoBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntOrganizacao ent = new EntOrganizacao();
		NgcOrganizacao ngc = new NgcOrganizacao();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);



            if (!((DynaValidatorForm) form).get("torIdtChave").equals(""))
            {
                EntTipoOrganizacao entTor = new EntTipoOrganizacao();
                entTor.setTorIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("torIdtChave"))); 
                ent.setEntTipoOrganizacao(entTor);
            }
            if (!((DynaValidatorForm) form).get("orgIdtChavePai").equals(""))
            {
                EntOrganizacao entOrgPai = new EntOrganizacao();
                entOrgPai.setOrgIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("orgIdtChavePai"))); 
                ent.setEntOrganizacaoPai(entOrgPai);
            }

			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResOrg", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntOrganizacao ent = new EntOrganizacao();
		NgcOrganizacao ngc = new NgcOrganizacao();

		try
		{
			ent = (EntOrganizacao) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("orgIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
            if (null != ent.getEntOrganizacaoPai())
                ((DynaValidatorForm)form).set("orgIdtChavePai", ent.getEntOrganizacaoPai().getOrgIdtChave().toString());


            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoOrganizacao(), form, req);
            if (null != ent && null != ent.getEntTipoOrganizacao())
                BeanUtils.copyProperties(form, ent.getEntTipoOrganizacao());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntOrganizacaoPai(), form, req);
            if (null != ent && null != ent.getEntOrganizacaoPai())
                BeanUtils.copyProperties(form, ent.getEntOrganizacaoPai());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas
            List<EntConfiguracao> lstCon = ent.getLstConfiguracao();
            lstCon = ordenarLista(lstCon, getResources(req).getMessage("configuracao.ordenacao")); 
            req.setAttribute("lstResCon", lstCon);

            List<EntOrganizacao> lstOrgPai = ent.getLstOrganizacaoPai();
            lstOrgPai = ordenarLista(lstOrgPai, getResources(req).getMessage("organizacao.ordenacao")); 
            req.setAttribute("lstResOrgPai", lstOrgPai);

            List<EntPapel> lstPap = ent.getLstPapel();
            lstPap = ordenarLista(lstPap, getResources(req).getMessage("papel.ordenacao")); 
            req.setAttribute("lstResPap", lstPap);

            List<EntPerfil> lstPer = ent.getLstPerfil();
            lstPer = ordenarLista(lstPer, getResources(req).getMessage("perfil.ordenacao")); 
            req.setAttribute("lstResPer", lstPer);

            List<EntTipoPessoa> lstTpp = ent.getLstTipoPessoa();
            lstTpp = ordenarLista(lstTpp, getResources(req).getMessage("tipoPessoa.ordenacao")); 
            req.setAttribute("lstResTpp", lstTpp);

            List<EntTipoSexo> lstTsx = ent.getLstTipoSexo();
            lstTsx = ordenarLista(lstTsx, getResources(req).getMessage("tipoSexo.ordenacao")); 
            req.setAttribute("lstResTsx", lstTsx);


			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntOrganizacao ent = new EntOrganizacao();
		NgcOrganizacao ngc = new NgcOrganizacao();

		try
		{
			ent = (EntOrganizacao) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("orgIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						
            if (null != ent.getEntOrganizacaoPai())
                ((DynaValidatorForm)form).set("orgIdtChavePai", ent.getEntOrganizacaoPai().getOrgIdtChave().toString());

            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoOrganizacao(), form, req);
            if (null != ent && null != ent.getEntTipoOrganizacao())
                BeanUtils.copyProperties(form, ent.getEntTipoOrganizacao());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntOrganizacaoPai(), form, req);
            if (null != ent && null != ent.getEntOrganizacaoPai())
                BeanUtils.copyProperties(form, ent.getEntOrganizacaoPai());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas
            List<EntConfiguracao> lstCon = ent.getLstConfiguracao();
            lstCon = ordenarLista(lstCon, getResources(req).getMessage("configuracao.ordenacao")); 
            req.setAttribute("lstResCon", lstCon);

            List<EntOrganizacao> lstOrgPai = ent.getLstOrganizacaoPai();
            lstOrgPai = ordenarLista(lstOrgPai, getResources(req).getMessage("organizacao.ordenacao")); 
            req.setAttribute("lstResOrgPai", lstOrgPai);

            List<EntPapel> lstPap = ent.getLstPapel();
            lstPap = ordenarLista(lstPap, getResources(req).getMessage("papel.ordenacao")); 
            req.setAttribute("lstResPap", lstPap);

            List<EntPerfil> lstPer = ent.getLstPerfil();
            lstPer = ordenarLista(lstPer, getResources(req).getMessage("perfil.ordenacao")); 
            req.setAttribute("lstResPer", lstPer);

            List<EntTipoPessoa> lstTpp = ent.getLstTipoPessoa();
            lstTpp = ordenarLista(lstTpp, getResources(req).getMessage("tipoPessoa.ordenacao")); 
            req.setAttribute("lstResTpp", lstTpp);

            List<EntTipoSexo> lstTsx = ent.getLstTipoSexo();
            lstTsx = ordenarLista(lstTsx, getResources(req).getMessage("tipoSexo.ordenacao")); 
            req.setAttribute("lstResTsx", lstTsx);


			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntOrganizacao ent = new EntOrganizacao();
		NgcOrganizacao ngc = new NgcOrganizacao();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntOrganizacao) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("orgIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio




            if (getResources(req).getMessage("campo.organizacao.torIdtChave.exibir.cad").equals("s"))
                this.setaTipoOrganizacao(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.organizacao.orgIdtChavePai.exibir.cad").equals("s"))
                this.setaOrganizacaoPai(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.organizacao.configuracao.exibir").equals("s"))
            {
                // Salva Configuracao
                List<EntConfiguracao> lstPrsCon = ent.getLstConfiguracao();
                List<EntConfiguracao> lstTmpCon = montarConfiguracao(req, form, ent, "");
                AtualizarConfiguracao(form, lstPrsCon, lstTmpCon);
            }
            if (getResources(req).getMessage("detalhe.organizacao.organizacaoPai.exibir").equals("s"))
            {
                // Salva OrganizacaoPai
                List<EntOrganizacao> lstPrsOrg = ent.getLstOrganizacaoPai();
                List<EntOrganizacao> lstTmpOrg = montarOrganizacao(req, form, ent, "PAI_");
                AtualizarOrganizacao(form, lstPrsOrg, lstTmpOrg);
            }
            if (getResources(req).getMessage("detalhe.organizacao.papel.exibir").equals("s"))
            {
                // Salva Papel
                List<EntPapel> lstPrsPap = ent.getLstPapel();
                List<EntPapel> lstTmpPap = montarPapel(req, form, ent, "");
                AtualizarPapel(form, lstPrsPap, lstTmpPap);
            }
            if (getResources(req).getMessage("detalhe.organizacao.perfil.exibir").equals("s"))
            {
                // Salva Perfil
                List<EntPerfil> lstPrsPer = ent.getLstPerfil();
                List<EntPerfil> lstTmpPer = montarPerfil(req, form, ent, "");
                AtualizarPerfil(form, lstPrsPer, lstTmpPer);
            }
            if (getResources(req).getMessage("detalhe.organizacao.tipoPessoa.exibir").equals("s"))
            {
                // Salva TipoPessoa
                List<EntTipoPessoa> lstPrsTpp = ent.getLstTipoPessoa();
                List<EntTipoPessoa> lstTmpTpp = montarTipoPessoa(req, form, ent, "");
                AtualizarTipoPessoa(form, lstPrsTpp, lstTmpTpp);
            }
            if (getResources(req).getMessage("detalhe.organizacao.tipoSexo.exibir").equals("s"))
            {
                // Salva TipoSexo
                List<EntTipoSexo> lstPrsTsx = ent.getLstTipoSexo();
                List<EntTipoSexo> lstTmpTsx = montarTipoSexo(req, form, ent, "");
                AtualizarTipoSexo(form, lstPrsTsx, lstTmpTsx);
            }


			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntOrganizacao) ngc.consultarID(ent.getOrgIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResOrg", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntOrganizacao ent = new EntOrganizacao();
		NgcOrganizacao ngc = new NgcOrganizacao();

		try
		{
			ent = (EntOrganizacao) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("orgIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntOrganizacao ent = new EntOrganizacao();
		NgcOrganizacao ngc = new NgcOrganizacao();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);

            if (getResources(req).getMessage("campo.organizacao.torIdtChave.exibir.cad").equals("s"))
                this.setaTipoOrganizacao(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.organizacao.orgIdtChavePai.exibir.cad").equals("s"))
                this.setaOrganizacaoPai(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.organizacao.configuracao.exibir").equals("s"))
            {
                // Salva Configuracao
                Integer qtdeConfiguracao = Integer.parseInt(req.getParameter("qtdeConfiguracao"));
                if (qtdeConfiguracao > 0)
                {
                    List<EntConfiguracao> lstTmpCon = montarConfiguracao(req, form, ent, "");
                    ent.setLstConfiguracao(lstTmpCon);
                }

            }
            if (getResources(req).getMessage("detalhe.organizacao.organizacaoPai.exibir").equals("s"))
            {
                // Salva OrganizacaoPai
                Integer qtdeOrganizacaoPai = Integer.parseInt(req.getParameter("qtdeOrganizacaoPai"));
                if (qtdeOrganizacaoPai > 0)
                {
                    List<EntOrganizacao> lstTmpOrg = montarOrganizacao(req, form, ent, "PAI_");
                    ent.setLstOrganizacaoPai(lstTmpOrg);
                }

            }
            if (getResources(req).getMessage("detalhe.organizacao.papel.exibir").equals("s"))
            {
                // Salva Papel
                Integer qtdePapel = Integer.parseInt(req.getParameter("qtdePapel"));
                if (qtdePapel > 0)
                {
                    List<EntPapel> lstTmpPap = montarPapel(req, form, ent, "");
                    ent.setLstPapel(lstTmpPap);
                }

            }
            if (getResources(req).getMessage("detalhe.organizacao.perfil.exibir").equals("s"))
            {
                // Salva Perfil
                Integer qtdePerfil = Integer.parseInt(req.getParameter("qtdePerfil"));
                if (qtdePerfil > 0)
                {
                    List<EntPerfil> lstTmpPer = montarPerfil(req, form, ent, "");
                    ent.setLstPerfil(lstTmpPer);
                }

            }
            if (getResources(req).getMessage("detalhe.organizacao.tipoPessoa.exibir").equals("s"))
            {
                // Salva TipoPessoa
                Integer qtdeTipoPessoa = Integer.parseInt(req.getParameter("qtdeTipoPessoa"));
                if (qtdeTipoPessoa > 0)
                {
                    List<EntTipoPessoa> lstTmpTpp = montarTipoPessoa(req, form, ent, "");
                    ent.setLstTipoPessoa(lstTmpTpp);
                }

            }
            if (getResources(req).getMessage("detalhe.organizacao.tipoSexo.exibir").equals("s"))
            {
                // Salva TipoSexo
                Integer qtdeTipoSexo = Integer.parseInt(req.getParameter("qtdeTipoSexo"));
                if (qtdeTipoSexo > 0)
                {
                    List<EntTipoSexo> lstTmpTsx = montarTipoSexo(req, form, ent, "");
                    ent.setLstTipoSexo(lstTmpTsx);
                }

            }

			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntOrganizacao) ngc.consultarID(ent.getOrgIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResOrg", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntOrganizacao ent) throws Exception
	{
            if (getResources(req).getMessage("campo.organizacao.torIdtChave.exibir.cad").equals("s"))
                this.setaTipoOrganizacao(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.organizacao.orgIdtChavePai.exibir.cad").equals("s"))
                this.setaOrganizacaoPai(map, form, req, res, ent);

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntOrganizacao ent) throws Exception
	{
            if (getResources(req).getMessage("detalhe.organizacao.configuracao.exibir").equals("s"))
            {
                // Salva Configuracao
                List<EntConfiguracao> lstPrsCon = ent.getLstConfiguracao();
                List<EntConfiguracao> lstTmpCon = montarConfiguracao(req, form, ent, "");
                AtualizarConfiguracao(form, lstPrsCon, lstTmpCon);
            }
            if (getResources(req).getMessage("detalhe.organizacao.organizacaoPai.exibir").equals("s"))
            {
                // Salva OrganizacaoPai
                List<EntOrganizacao> lstPrsOrg = ent.getLstOrganizacaoPai();
                List<EntOrganizacao> lstTmpOrg = montarOrganizacao(req, form, ent, "PAI_");
                AtualizarOrganizacao(form, lstPrsOrg, lstTmpOrg);
            }
            if (getResources(req).getMessage("detalhe.organizacao.papel.exibir").equals("s"))
            {
                // Salva Papel
                List<EntPapel> lstPrsPap = ent.getLstPapel();
                List<EntPapel> lstTmpPap = montarPapel(req, form, ent, "");
                AtualizarPapel(form, lstPrsPap, lstTmpPap);
            }
            if (getResources(req).getMessage("detalhe.organizacao.perfil.exibir").equals("s"))
            {
                // Salva Perfil
                List<EntPerfil> lstPrsPer = ent.getLstPerfil();
                List<EntPerfil> lstTmpPer = montarPerfil(req, form, ent, "");
                AtualizarPerfil(form, lstPrsPer, lstTmpPer);
            }
            if (getResources(req).getMessage("detalhe.organizacao.tipoPessoa.exibir").equals("s"))
            {
                // Salva TipoPessoa
                List<EntTipoPessoa> lstPrsTpp = ent.getLstTipoPessoa();
                List<EntTipoPessoa> lstTmpTpp = montarTipoPessoa(req, form, ent, "");
                AtualizarTipoPessoa(form, lstPrsTpp, lstTmpTpp);
            }
            if (getResources(req).getMessage("detalhe.organizacao.tipoSexo.exibir").equals("s"))
            {
                // Salva TipoSexo
                List<EntTipoSexo> lstPrsTsx = ent.getLstTipoSexo();
                List<EntTipoSexo> lstTmpTsx = montarTipoSexo(req, form, ent, "");
                AtualizarTipoSexo(form, lstPrsTsx, lstTmpTsx);
            }

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntOrganizacao ent) throws Exception
	{
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoOrganizacao(), form, req);
            if (null != ent && null != ent.getEntTipoOrganizacao())
                BeanUtils.copyProperties(form, ent.getEntTipoOrganizacao());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntOrganizacaoPai(), form, req);
            if (null != ent && null != ent.getEntOrganizacaoPai())
                BeanUtils.copyProperties(form, ent.getEntOrganizacaoPai());

	}

	public void converterValores(ActionForm form)
	{

        // OrgFlgAtivo
        if ((((DynaValidatorForm) form).get("orgFlgAtivo")) != null && !(((DynaValidatorForm) form).get("orgFlgAtivo")).equals(""))
        {
            Integer orgFlgAtivo = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("orgFlgAtivo"));
            ((DynaValidatorForm) form).set("orgFlgAtivo", orgFlgAtivo.toString());
        }



	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntOrganizacao ent) throws Exception
	{

	
        if (getResources(req).getMessage("campo.organizacao.torIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.organizacao.torIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstTipoOrganizacao"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntTipoOrganizacao());
            carregarTipoOrganizacao(map, form, req, res, metodo, l); 
            
        }
        if (getResources(req).getMessage("campo.organizacao.orgIdtChavePai.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.organizacao.orgIdtChavePai.visual").toLowerCase().equals("l") && null == req.getAttribute("lstOrganizacao"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntOrganizacaoPai());
            carregarOrganizacao(map, form, req, res, metodo, l); 
            
        }
            if (getResources(req).getMessage("detalhe.organizacao.organizacao.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.organizacao.torIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstTor"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstOrganizacao() != null && ent.getLstOrganizacao().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstOrganizacao().iterator(); iterator.hasNext();)
                        //{
                            //EntOrganizacao obj = (EntOrganizacao) iterator.next();
                            //l.add(obj.getEntTipoOrganizacao());
                        //}
                    //}
                //}
                carregarTipoOrganizacao(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.organizacao.organizacaoPai.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.organizacao.orgIdtChavePai.visual").toLowerCase().equals("l") && null == req.getAttribute("lstOrg"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstOrganizacaoPai() != null && ent.getLstOrganizacaoPai().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstOrganizacaoPai().iterator(); iterator.hasNext();)
                        //{
                            //EntOrganizacao obj = (EntOrganizacao) iterator.next();
                            //l.add(obj.getEntOrganizacao());
                        //}
                    //}
                //}
                carregarTipoOrganizacao(map, form, req, res, metodo, l);
                carregarOrganizacao(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.organizacao.papel.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.papel.pesIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstPes"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPapel() != null && ent.getLstPapel().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPapel().iterator(); iterator.hasNext();)
                        //{
                            //EntPapel obj = (EntPapel) iterator.next();
                            //l.add(obj.getEntPessoa());
                        //}
                    //}
                //}
                carregarPessoa(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.organizacao.papel.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.papel.perIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstPer"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPapel() != null && ent.getLstPapel().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPapel().iterator(); iterator.hasNext();)
                        //{
                            //EntPapel obj = (EntPapel) iterator.next();
                            //l.add(obj.getEntPerfil());
                        //}
                    //}
                //}
                carregarPerfil(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.organizacao.perfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.sisIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstSis"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfil() != null && ent.getLstPerfil().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfil().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfil obj = (EntPerfil) iterator.next();
                            //l.add(obj.getEntSistema());
                        //}
                    //}
                //}
                carregarSistema(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.organizacao.perfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.tpaIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstTpa"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfil() != null && ent.getLstPerfil().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfil().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfil obj = (EntPerfil) iterator.next();
                            //l.add(obj.getEntTipoAcesso());
                        //}
                    //}
                //}
                carregarTipoAcesso(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.organizacao.perfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.perIdtChaveSuperior.visual").toLowerCase().equals("l") && null == req.getAttribute("lstPer"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfilSuperior() != null && ent.getLstPerfilSuperior().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfilSuperior().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfil obj = (EntPerfil) iterator.next();
                            //l.add(obj.getEntPerfil());
                        //}
                    //}
                //}
                carregarPerfil(map, form, req, res, metodo, l);
            }

	}

    public void carregarTipoOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarTipoOrganizacao(map, form, req, res, "par", null);

    }
    public void carregarTipoOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcTipoOrganizacao ngc = new NgcTipoOrganizacao();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstTor", ngc.consultarHabilitados(new String[][]{{"torDscNome", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstTor", ngc.consultarTodos(new String[][]{{"torDscNome", "ASC"}}));
        }
    }

    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarOrganizacao(map, form, req, res, "par", null);

    }
    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcOrganizacao ngc = new NgcOrganizacao();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstOrg", ngc.consultarHabilitados(new String[][]{{"orgDscFantasia", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstOrg", ngc.consultarTodos(new String[][]{{"orgDscFantasia", "ASC"}}));
        }
    }

    public void carregarPessoa(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarPessoa(map, form, req, res, "par", null);

    }
    public void carregarPessoa(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcPessoa ngc = new NgcPessoa();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstPes", ngc.consultarHabilitados(new String[][]{{"pesDscNome", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstPes", ngc.consultarTodos(new String[][]{{"pesDscNome", "ASC"}}));
        }
    }

    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarPerfil(map, form, req, res, "par", null);

    }
    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcPerfil ngc = new NgcPerfil();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstPer", ngc.consultarHabilitados(new String[][]{{"perDscPerfil", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstPer", ngc.consultarTodos(new String[][]{{"perDscPerfil", "ASC"}}));
        }
    }

    public void carregarSistema(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarSistema(map, form, req, res, "par", null);

    }
    public void carregarSistema(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcSistema ngc = new NgcSistema();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstSis", ngc.consultarHabilitados(new String[][]{{"sisDscTitulo", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstSis", ngc.consultarTodos(new String[][]{{"sisDscTitulo", "ASC"}}));
        }
    }

    public void carregarTipoAcesso(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarTipoAcesso(map, form, req, res, "par", null);

    }
    public void carregarTipoAcesso(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcTipoAcesso ngc = new NgcTipoAcesso();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstTpa", ngc.consultarHabilitados(new String[][]{{"tpaDscTipo", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstTpa", ngc.consultarTodos(new String[][]{{"tpaDscTipo", "ASC"}}));
        }
    }





            public void setaTipoOrganizacao(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntOrganizacao ent) throws Exception
            {
                EntTipoOrganizacao entTor;
                if (ent.getEntTipoOrganizacao() != null && !((String)((DynaValidatorForm)form).get("torIdtChave")).equals("") && ent.getEntTipoOrganizacao().getTorIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("torIdtChave"))) 
                    entTor = ent.getEntTipoOrganizacao();
                else
                {
                    entTor = new EntTipoOrganizacao();
                    try {
                        entTor.setTorIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("torIdtChave")));
                    } catch (Exception e) {
                        entTor.setTorIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entTor, req);
                if (entTor.getTorIdtChave() != null)
                    ent.setEntTipoOrganizacao(entTor);
                else
                    ent.setEntTipoOrganizacao(null);
            }
            public void setaOrganizacaoPai(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntOrganizacao ent) throws Exception
            {
                EntOrganizacao entOrg;
                if (ent.getEntOrganizacaoPai() != null && !((String)((DynaValidatorForm)form).get("orgIdtChavePai")).equals("") && ent.getEntOrganizacaoPai().getOrgIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("orgIdtChavePai"))) 
                    entOrg = ent.getEntOrganizacaoPai();
                else
                {
                    entOrg = new EntOrganizacao();
                    try {
                        entOrg.setOrgIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("orgIdtChavePai")));
                    } catch (Exception e) {
                        entOrg.setOrgIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entOrg, req);
                // Ajusta o campo chave (no caso de sufixo)
                if (null != ((DynaValidatorForm)form).get("orgIdtChavePai") && !((DynaValidatorForm)form).get("orgIdtChavePai").equals(""))
                    entOrg.setOrgIdtChave(new Long(((String) ((DynaValidatorForm)form).get("orgIdtChavePai"))));
                if (entOrg.getOrgIdtChave() != null)
                    ent.setEntOrganizacaoPai(entOrg);
                else
                    ent.setEntOrganizacaoPai(null);
            }




            public List<EntConfiguracao> montarConfiguracao(HttpServletRequest req, ActionForm form, EntOrganizacao ent, String sufixo) throws Exception
            {
                List<EntConfiguracao> lst = new ArrayList<EntConfiguracao>(); 

                // Campos do detalhe
                String[] conIdtChave = (String[])((DynaValidatorForm)form).get("con_" + sufixo.toUpperCase() + "conIdtChave"); 
                String[] orgIdtChave = (String[])((DynaValidatorForm)form).get("con_" + sufixo.toUpperCase() + "orgIdtChave"); 
                String[] conDscCampo = (String[])((DynaValidatorForm)form).get("con_" + sufixo.toUpperCase() + "conDscCampo"); 
                String[] conDscValor = (String[])((DynaValidatorForm)form).get("con_" + sufixo.toUpperCase() + "conDscValor"); 

                // Percorre cada linha 
                for (int i = 0; i < conIdtChave.length; i++) 
                {
                    EntConfiguracao entTmp = new EntConfiguracao();  // Percorre o detalhe
                    // Copia campos - Configuracao
                if (conIdtChave[i] != null && !conIdtChave[i].equals(""))
                    entTmp.setConIdtChave(Long.parseLong(conIdtChave[i]));

            if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
            {
                EntOrganizacao obj = new EntOrganizacao();
                obj.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                entTmp.setEntOrganizacao(obj);
            }
            else if(("orgIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("orgIdtChave"))
            {
                entTmp.setEntOrganizacao(ent);
            }
            if (conDscCampo != null && conDscCampo.length > 0 && conDscCampo[i] != null && !conDscCampo[i].equals(""))
                entTmp.setConDscCampo((conDscCampo[i]));

            if (conDscValor != null && conDscValor.length > 0 && conDscValor[i] != null && !conDscValor[i].equals(""))
                entTmp.setConDscValor((conDscValor[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntOrganizacao> montarOrganizacao(HttpServletRequest req, ActionForm form, EntOrganizacao ent, String sufixo) throws Exception
            {
                List<EntOrganizacao> lst = new ArrayList<EntOrganizacao>(); 

                // Campos do detalhe
                String[] orgIdtChave = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgIdtChave"); 
                String[] orgDscFantasia = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgDscFantasia"); 
                String[] orgDscRazaoSocial = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgDscRazaoSocial"); 
                String[] orgDscCnpj = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgDscCnpj"); 
                String[] orgDscSite = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgDscSite"); 
                String[] orgDscEmail = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgDscEmail"); 
                String[] torIdtChave = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "torIdtChave"); 
                String[] torIdtChaveDsc = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "torIdtChaveDsc"); 
                String[] orgIdtChavePai = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgIdtChavePai"); 
                String[] orgFlgAtivo = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgFlgAtivo"); 

                // Percorre cada linha 
                for (int i = 0; i < orgIdtChave.length; i++) 
                {
                    EntOrganizacao entTmp = new EntOrganizacao();  // Percorre o detalhe
                    // Copia campos - Organizacao
                if (orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
                    entTmp.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));

            if (orgDscFantasia != null && orgDscFantasia.length > 0 && orgDscFantasia[i] != null && !orgDscFantasia[i].equals(""))
                entTmp.setOrgDscFantasia((orgDscFantasia[i]));

            if (orgDscRazaoSocial != null && orgDscRazaoSocial.length > 0 && orgDscRazaoSocial[i] != null && !orgDscRazaoSocial[i].equals(""))
                entTmp.setOrgDscRazaoSocial((orgDscRazaoSocial[i]));

            if (orgDscCnpj != null && orgDscCnpj.length > 0 && orgDscCnpj[i] != null && !orgDscCnpj[i].equals(""))
                entTmp.setOrgDscCnpj((orgDscCnpj[i]));

            if (orgDscSite != null && orgDscSite.length > 0 && orgDscSite[i] != null && !orgDscSite[i].equals(""))
                entTmp.setOrgDscSite((orgDscSite[i]));

            if (orgDscEmail != null && orgDscEmail.length > 0 && orgDscEmail[i] != null && !orgDscEmail[i].equals(""))
                entTmp.setOrgDscEmail((orgDscEmail[i]));

                if (torIdtChave != null && torIdtChave.length > 0 && torIdtChave[i] != null && !torIdtChave[i].equals(""))
                {
                    EntTipoOrganizacao entTmpTor = new EntTipoOrganizacao();
                    entTmpTor.setTorIdtChave(Long.parseLong(torIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.organizacao.torIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpTor, torIdtChaveDsc[i], "campo.organizacao.torIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntTipoOrganizacao(entTmpTor);
                }

            if (torIdtChave != null && torIdtChave.length > 0 && torIdtChave[i] != null && !torIdtChave[i].equals(""))
            {
                EntTipoOrganizacao obj = new EntTipoOrganizacao();
                obj.setTorIdtChave(Long.parseLong(torIdtChave[i]));
                entTmp.setEntTipoOrganizacao(obj);
            }
            if (orgIdtChavePai != null && orgIdtChavePai.length > 0 && orgIdtChavePai[i] != null && !orgIdtChavePai[i].equals(""))
            {
                EntOrganizacao obj = new EntOrganizacao();
                obj.setOrgIdtChave(Long.parseLong(orgIdtChavePai[i]));
                entTmp.setEntOrganizacaoPai(obj);
            }
            else if(("orgIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("orgIdtChavePai"))
            {
                entTmp.setEntOrganizacaoPai(ent);
            }
            if (orgFlgAtivo != null && orgFlgAtivo.length > 0 && orgFlgAtivo[i] != null && !orgFlgAtivo[i].equals(""))
                entTmp.setOrgFlgAtivo(Integer.parseInt(orgFlgAtivo[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntPapel> montarPapel(HttpServletRequest req, ActionForm form, EntOrganizacao ent, String sufixo) throws Exception
            {
                List<EntPapel> lst = new ArrayList<EntPapel>(); 

                // Campos do detalhe
                String[] papIdtChave = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "papIdtChave"); 
                String[] orgIdtChave = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "orgIdtChave"); 
                String[] pesIdtChave = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "pesIdtChave"); 
                String[] pesIdtChaveDsc = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "pesIdtChaveDsc"); 
                String[] perIdtChave = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "perIdtChave"); 
                String[] perIdtChaveDsc = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "perIdtChaveDsc"); 
                String[] papDatInicio = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "papDatInicio"); 
                String[] papDatFim = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "papDatFim"); 
                String[] papFlgAtivo = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "papFlgAtivo"); 

                // Percorre cada linha 
                for (int i = 0; i < papIdtChave.length; i++) 
                {
                    EntPapel entTmp = new EntPapel();  // Percorre o detalhe
                    // Copia campos - Papel
                if (papIdtChave[i] != null && !papIdtChave[i].equals(""))
                    entTmp.setPapIdtChave(Long.parseLong(papIdtChave[i]));

            if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
            {
                EntOrganizacao obj = new EntOrganizacao();
                obj.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                entTmp.setEntOrganizacao(obj);
            }
            else if(("orgIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("orgIdtChave"))
            {
                entTmp.setEntOrganizacao(ent);
            }
                if (pesIdtChave != null && pesIdtChave.length > 0 && pesIdtChave[i] != null && !pesIdtChave[i].equals(""))
                {
                    EntPessoa entTmpPes = new EntPessoa();
                    entTmpPes.setPesIdtChave(Long.parseLong(pesIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.papel.pesIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpPes, pesIdtChaveDsc[i], "campo.papel.pesIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntPessoa(entTmpPes);
                }

            if (pesIdtChave != null && pesIdtChave.length > 0 && pesIdtChave[i] != null && !pesIdtChave[i].equals(""))
            {
                EntPessoa obj = new EntPessoa();
                obj.setPesIdtChave(Long.parseLong(pesIdtChave[i]));
                entTmp.setEntPessoa(obj);
            }
                if (perIdtChave != null && perIdtChave.length > 0 && perIdtChave[i] != null && !perIdtChave[i].equals(""))
                {
                    EntPerfil entTmpPer = new EntPerfil();
                    entTmpPer.setPerIdtChave(Long.parseLong(perIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.papel.perIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpPer, perIdtChaveDsc[i], "campo.papel.perIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntPerfil(entTmpPer);
                }

            if (perIdtChave != null && perIdtChave.length > 0 && perIdtChave[i] != null && !perIdtChave[i].equals(""))
            {
                EntPerfil obj = new EntPerfil();
                obj.setPerIdtChave(Long.parseLong(perIdtChave[i]));
                entTmp.setEntPerfil(obj);
            }
            if (papDatInicio != null && papDatInicio.length > 0 && papDatInicio[i] != null && !papDatInicio[i].equals(""))
                entTmp.setPapDatInicio(FormatDate.parse(papDatInicio[i]));

            if (papDatFim != null && papDatFim.length > 0 && papDatFim[i] != null && !papDatFim[i].equals(""))
                entTmp.setPapDatFim(FormatDate.parse(papDatFim[i]));

            if (papFlgAtivo != null && papFlgAtivo.length > 0 && papFlgAtivo[i] != null && !papFlgAtivo[i].equals(""))
                entTmp.setPapFlgAtivo(Integer.parseInt(papFlgAtivo[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntPerfil> montarPerfil(HttpServletRequest req, ActionForm form, EntOrganizacao ent, String sufixo) throws Exception
            {
                List<EntPerfil> lst = new ArrayList<EntPerfil>(); 

                // Campos do detalhe
                String[] perIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perIdtChave"); 
                String[] orgIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "orgIdtChave"); 
                String[] sisIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "sisIdtChave"); 
                String[] sisIdtChaveDsc = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "sisIdtChaveDsc"); 
                String[] perDscPerfil = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perDscPerfil"); 
                String[] perFlgPublico = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perFlgPublico"); 
                String[] tpaIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "tpaIdtChave"); 
                String[] tpaIdtChaveDsc = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "tpaIdtChaveDsc"); 
                String[] perIdtChaveSuperior = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perIdtChaveSuperior"); 
                String[] perIdtChaveSuperiorDsc = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perIdtChaveSuperiorDsc"); 

                // Percorre cada linha 
                for (int i = 0; i < perIdtChave.length; i++) 
                {
                    EntPerfil entTmp = new EntPerfil();  // Percorre o detalhe
                    // Copia campos - Perfil
                if (perIdtChave[i] != null && !perIdtChave[i].equals(""))
                    entTmp.setPerIdtChave(Long.parseLong(perIdtChave[i]));

            if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
            {
                EntOrganizacao obj = new EntOrganizacao();
                obj.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                entTmp.setEntOrganizacao(obj);
            }
            else if(("orgIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("orgIdtChave"))
            {
                entTmp.setEntOrganizacao(ent);
            }
                if (sisIdtChave != null && sisIdtChave.length > 0 && sisIdtChave[i] != null && !sisIdtChave[i].equals(""))
                {
                    EntSistema entTmpSis = new EntSistema();
                    entTmpSis.setSisIdtChave(Long.parseLong(sisIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.perfil.sisIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpSis, sisIdtChaveDsc[i], "campo.perfil.sisIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntSistema(entTmpSis);
                }

            if (sisIdtChave != null && sisIdtChave.length > 0 && sisIdtChave[i] != null && !sisIdtChave[i].equals(""))
            {
                EntSistema obj = new EntSistema();
                obj.setSisIdtChave(Long.parseLong(sisIdtChave[i]));
                entTmp.setEntSistema(obj);
            }
            if (perDscPerfil != null && perDscPerfil.length > 0 && perDscPerfil[i] != null && !perDscPerfil[i].equals(""))
                entTmp.setPerDscPerfil((perDscPerfil[i]));

            if (perFlgPublico != null && perFlgPublico.length > 0 && perFlgPublico[i] != null && !perFlgPublico[i].equals(""))
                entTmp.setPerFlgPublico(Integer.parseInt(perFlgPublico[i]));

                if (tpaIdtChave != null && tpaIdtChave.length > 0 && tpaIdtChave[i] != null && !tpaIdtChave[i].equals(""))
                {
                    EntTipoAcesso entTmpTpa = new EntTipoAcesso();
                    entTmpTpa.setTpaIdtChave(Long.parseLong(tpaIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.perfil.tpaIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpTpa, tpaIdtChaveDsc[i], "campo.perfil.tpaIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntTipoAcesso(entTmpTpa);
                }

            if (tpaIdtChave != null && tpaIdtChave.length > 0 && tpaIdtChave[i] != null && !tpaIdtChave[i].equals(""))
            {
                EntTipoAcesso obj = new EntTipoAcesso();
                obj.setTpaIdtChave(Long.parseLong(tpaIdtChave[i]));
                entTmp.setEntTipoAcesso(obj);
            }
                if (perIdtChaveSuperior != null && perIdtChaveSuperior.length > 0 && perIdtChaveSuperior[i] != null && !perIdtChaveSuperior[i].equals(""))
                {
                    EntPerfil entTmpPer = new EntPerfil();
                    entTmpPer.setPerIdtChave(Long.parseLong(perIdtChaveSuperior[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.perfilSuperior.perIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpPer, perIdtChaveSuperiorDsc[i], "campo.perfilSuperior.perIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntPerfilSuperior(entTmpPer);
                }

            if (perIdtChaveSuperior != null && perIdtChaveSuperior.length > 0 && perIdtChaveSuperior[i] != null && !perIdtChaveSuperior[i].equals(""))
            {
                EntPerfil obj = new EntPerfil();
                obj.setPerIdtChave(Long.parseLong(perIdtChaveSuperior[i]));
                entTmp.setEntPerfilSuperior(obj);
            }

                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntTipoPessoa> montarTipoPessoa(HttpServletRequest req, ActionForm form, EntOrganizacao ent, String sufixo) throws Exception
            {
                List<EntTipoPessoa> lst = new ArrayList<EntTipoPessoa>(); 

                // Campos do detalhe
                String[] tppIdtChave = (String[])((DynaValidatorForm)form).get("tpp_" + sufixo.toUpperCase() + "tppIdtChave"); 
                String[] orgIdtChave = (String[])((DynaValidatorForm)form).get("tpp_" + sufixo.toUpperCase() + "orgIdtChave"); 
                String[] tppDscNome = (String[])((DynaValidatorForm)form).get("tpp_" + sufixo.toUpperCase() + "tppDscNome"); 
                String[] tppDscDescricao = (String[])((DynaValidatorForm)form).get("tpp_" + sufixo.toUpperCase() + "tppDscDescricao"); 
                String[] tppFlgAtivo = (String[])((DynaValidatorForm)form).get("tpp_" + sufixo.toUpperCase() + "tppFlgAtivo"); 

                // Percorre cada linha 
                for (int i = 0; i < tppIdtChave.length; i++) 
                {
                    EntTipoPessoa entTmp = new EntTipoPessoa();  // Percorre o detalhe
                    // Copia campos - TipoPessoa
                if (tppIdtChave[i] != null && !tppIdtChave[i].equals(""))
                    entTmp.setTppIdtChave(Long.parseLong(tppIdtChave[i]));

            if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
            {
                EntOrganizacao obj = new EntOrganizacao();
                obj.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                entTmp.setEntOrganizacao(obj);
            }
            else if(("orgIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("orgIdtChave"))
            {
                entTmp.setEntOrganizacao(ent);
            }
            if (tppDscNome != null && tppDscNome.length > 0 && tppDscNome[i] != null && !tppDscNome[i].equals(""))
                entTmp.setTppDscNome((tppDscNome[i]));

            if (tppDscDescricao != null && tppDscDescricao.length > 0 && tppDscDescricao[i] != null && !tppDscDescricao[i].equals(""))
                entTmp.setTppDscDescricao((tppDscDescricao[i]));

            if (tppFlgAtivo != null && tppFlgAtivo.length > 0 && tppFlgAtivo[i] != null && !tppFlgAtivo[i].equals(""))
                entTmp.setTppFlgAtivo(Integer.parseInt(tppFlgAtivo[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntTipoSexo> montarTipoSexo(HttpServletRequest req, ActionForm form, EntOrganizacao ent, String sufixo) throws Exception
            {
                List<EntTipoSexo> lst = new ArrayList<EntTipoSexo>(); 

                // Campos do detalhe
                String[] tsxIdtChave = (String[])((DynaValidatorForm)form).get("tsx_" + sufixo.toUpperCase() + "tsxIdtChave"); 
                String[] orgIdtChave = (String[])((DynaValidatorForm)form).get("tsx_" + sufixo.toUpperCase() + "orgIdtChave"); 
                String[] tsxDscNome = (String[])((DynaValidatorForm)form).get("tsx_" + sufixo.toUpperCase() + "tsxDscNome"); 
                String[] tsxDscSigla = (String[])((DynaValidatorForm)form).get("tsx_" + sufixo.toUpperCase() + "tsxDscSigla"); 

                // Percorre cada linha 
                for (int i = 0; i < tsxIdtChave.length; i++) 
                {
                    EntTipoSexo entTmp = new EntTipoSexo();  // Percorre o detalhe
                    // Copia campos - TipoSexo
                if (tsxIdtChave[i] != null && !tsxIdtChave[i].equals(""))
                    entTmp.setTsxIdtChave(Long.parseLong(tsxIdtChave[i]));

            if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
            {
                EntOrganizacao obj = new EntOrganizacao();
                obj.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                entTmp.setEntOrganizacao(obj);
            }
            else if(("orgIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("orgIdtChave"))
            {
                entTmp.setEntOrganizacao(ent);
            }
            if (tsxDscNome != null && tsxDscNome.length > 0 && tsxDscNome[i] != null && !tsxDscNome[i].equals(""))
                entTmp.setTsxDscNome((tsxDscNome[i]));

            if (tsxDscSigla != null && tsxDscSigla.length > 0 && tsxDscSigla[i] != null && !tsxDscSigla[i].equals(""))
                entTmp.setTsxDscSigla((tsxDscSigla[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }



            public void AtualizarConfiguracao(ActionForm form, List<EntConfiguracao> lstPrs, List<EntConfiguracao> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntConfiguracao entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntConfiguracao entTmp = lstTmp.get(j);
                    if (entPrs.getConIdtChave().equals(entTmp.getConIdtChave())) // Altera��o
                    {
                    entPrs.setEntOrganizacao(entTmp.getEntOrganizacao());
                    entPrs.setConDscCampo(entTmp.getConDscCampo());
                    entPrs.setConDscValor(entTmp.getConDscValor());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarOrganizacao(ActionForm form, List<EntOrganizacao> lstPrs, List<EntOrganizacao> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntOrganizacao entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntOrganizacao entTmp = lstTmp.get(j);
                    if (entPrs.getOrgIdtChave().equals(entTmp.getOrgIdtChave())) // Altera��o
                    {
                    entPrs.setOrgDscFantasia(entTmp.getOrgDscFantasia());
                    entPrs.setOrgDscRazaoSocial(entTmp.getOrgDscRazaoSocial());
                    entPrs.setOrgDscCnpj(entTmp.getOrgDscCnpj());
                    entPrs.setOrgDscSite(entTmp.getOrgDscSite());
                    entPrs.setOrgDscEmail(entTmp.getOrgDscEmail());
                    entPrs.setEntTipoOrganizacao(entTmp.getEntTipoOrganizacao());
                    entPrs.setEntOrganizacaoPai(entTmp.getEntOrganizacaoPai());
                    entPrs.setOrgFlgAtivo(entTmp.getOrgFlgAtivo());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarPapel(ActionForm form, List<EntPapel> lstPrs, List<EntPapel> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntPapel entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntPapel entTmp = lstTmp.get(j);
                    if (entPrs.getPapIdtChave().equals(entTmp.getPapIdtChave())) // Altera��o
                    {
                    entPrs.setEntOrganizacao(entTmp.getEntOrganizacao());
                    entPrs.setEntPessoa(entTmp.getEntPessoa());
                    entPrs.setEntPerfil(entTmp.getEntPerfil());
                    entPrs.setPapDatInicio(entTmp.getPapDatInicio());
                    entPrs.setPapDatFim(entTmp.getPapDatFim());
                    entPrs.setPapFlgAtivo(entTmp.getPapFlgAtivo());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarPerfil(ActionForm form, List<EntPerfil> lstPrs, List<EntPerfil> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntPerfil entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntPerfil entTmp = lstTmp.get(j);
                    if (entPrs.getPerIdtChave().equals(entTmp.getPerIdtChave())) // Altera��o
                    {
                    entPrs.setEntOrganizacao(entTmp.getEntOrganizacao());
                    entPrs.setEntSistema(entTmp.getEntSistema());
                    entPrs.setPerDscPerfil(entTmp.getPerDscPerfil());
                    entPrs.setPerFlgPublico(entTmp.getPerFlgPublico());
                    entPrs.setEntTipoAcesso(entTmp.getEntTipoAcesso());
                    entPrs.setEntPerfilSuperior(entTmp.getEntPerfilSuperior());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarTipoPessoa(ActionForm form, List<EntTipoPessoa> lstPrs, List<EntTipoPessoa> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntTipoPessoa entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntTipoPessoa entTmp = lstTmp.get(j);
                    if (entPrs.getTppIdtChave().equals(entTmp.getTppIdtChave())) // Altera��o
                    {
                    entPrs.setEntOrganizacao(entTmp.getEntOrganizacao());
                    entPrs.setTppDscNome(entTmp.getTppDscNome());
                    entPrs.setTppDscDescricao(entTmp.getTppDscDescricao());
                    entPrs.setTppFlgAtivo(entTmp.getTppFlgAtivo());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarTipoSexo(ActionForm form, List<EntTipoSexo> lstPrs, List<EntTipoSexo> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntTipoSexo entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntTipoSexo entTmp = lstTmp.get(j);
                    if (entPrs.getTsxIdtChave().equals(entTmp.getTsxIdtChave())) // Altera��o
                    {
                    entPrs.setEntOrganizacao(entTmp.getEntOrganizacao());
                    entPrs.setTsxDscNome(entTmp.getTsxDscNome());
                    entPrs.setTsxDscSigla(entTmp.getTsxDscSigla());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }


    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.organizacao." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.organizacao." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
