package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntPerfil;
import arquitetura.funcional.health.negocio.NgcPerfil;
import arquitetura.funcional.health.entidades.EntComando;
import arquitetura.funcional.health.entidades.EntPessoa;
import arquitetura.funcional.health.negocio.NgcPapel;
import arquitetura.funcional.health.negocio.NgcUsuario;
import arquitetura.funcional.health.negocio.NgcOrganizacao;
import arquitetura.funcional.health.entidades.EntPapel;
import arquitetura.funcional.health.negocio.NgcPerfil;
import arquitetura.funcional.health.negocio.NgcComando;
import arquitetura.funcional.health.negocio.NgcPessoa;
import arquitetura.funcional.health.entidades.EntSistema;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntPerfil;
import arquitetura.funcional.health.entidades.EntComandoPerfil;
import arquitetura.funcional.health.entidades.EntPerfilUsuario;
import arquitetura.funcional.health.negocio.NgcComandoPerfil;
import arquitetura.funcional.health.negocio.NgcSistema;
import arquitetura.funcional.health.entidades.EntUsuario;
import arquitetura.funcional.health.entidades.EntTipoAcesso;
import arquitetura.funcional.health.negocio.NgcPerfilUsuario;
import arquitetura.funcional.health.negocio.NgcTipoAcesso;


public class ActPerfilBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntPerfil ent = new EntPerfil();
		NgcPerfil ngc = new NgcPerfil();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);



            if (!((DynaValidatorForm) form).get("orgIdtChave").equals(""))
            {
                EntOrganizacao entOrg = new EntOrganizacao();
                entOrg.setOrgIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("orgIdtChave"))); 
                ent.setEntOrganizacao(entOrg);
            }
            if (!((DynaValidatorForm) form).get("sisIdtChave").equals(""))
            {
                EntSistema entSis = new EntSistema();
                entSis.setSisIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("sisIdtChave"))); 
                ent.setEntSistema(entSis);
            }
            if (!((DynaValidatorForm) form).get("tpaIdtChave").equals(""))
            {
                EntTipoAcesso entTpa = new EntTipoAcesso();
                entTpa.setTpaIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("tpaIdtChave"))); 
                ent.setEntTipoAcesso(entTpa);
            }
            if (!((DynaValidatorForm) form).get("perIdtChaveSuperior").equals(""))
            {
                EntPerfil entPerSuperior = new EntPerfil();
                entPerSuperior.setPerIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("perIdtChaveSuperior"))); 
                ent.setEntPerfilSuperior(entPerSuperior);
            }

			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResPer", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntPerfil ent = new EntPerfil();
		NgcPerfil ngc = new NgcPerfil();

		try
		{
			ent = (EntPerfil) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("perIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
            if (null != ent.getEntPerfilSuperior())
                ((DynaValidatorForm)form).set("perIdtChaveSuperior", ent.getEntPerfilSuperior().getPerIdtChave().toString());


            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntOrganizacao(), form, req);
            if (null != ent && null != ent.getEntOrganizacao())
                BeanUtils.copyProperties(form, ent.getEntOrganizacao());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntSistema(), form, req);
            if (null != ent && null != ent.getEntSistema())
                BeanUtils.copyProperties(form, ent.getEntSistema());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoAcesso(), form, req);
            if (null != ent && null != ent.getEntTipoAcesso())
                BeanUtils.copyProperties(form, ent.getEntTipoAcesso());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntPerfilSuperior(), form, req);
            if (null != ent && null != ent.getEntPerfilSuperior())
                BeanUtils.copyProperties(form, ent.getEntPerfilSuperior());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas
            List<EntComandoPerfil> lstCmp = ent.getLstComandoPerfil();
            lstCmp = ordenarLista(lstCmp, getResources(req).getMessage("comandoPerfil.ordenacao")); 
            req.setAttribute("lstResCmp", lstCmp);

            List<EntPapel> lstPap = ent.getLstPapel();
            lstPap = ordenarLista(lstPap, getResources(req).getMessage("papel.ordenacao")); 
            req.setAttribute("lstResPap", lstPap);

            List<EntPerfil> lstPerSuperior = ent.getLstPerfilSuperior();
            lstPerSuperior = ordenarLista(lstPerSuperior, getResources(req).getMessage("perfil.ordenacao")); 
            req.setAttribute("lstResPerSuperior", lstPerSuperior);

            List<EntPerfilUsuario> lstPfu = ent.getLstPerfilUsuario();
            lstPfu = ordenarLista(lstPfu, getResources(req).getMessage("perfilUsuario.ordenacao")); 
            req.setAttribute("lstResPfu", lstPfu);


			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntPerfil ent = new EntPerfil();
		NgcPerfil ngc = new NgcPerfil();

		try
		{
			ent = (EntPerfil) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("perIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						
            if (null != ent.getEntPerfilSuperior())
                ((DynaValidatorForm)form).set("perIdtChaveSuperior", ent.getEntPerfilSuperior().getPerIdtChave().toString());

            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntOrganizacao(), form, req);
            if (null != ent && null != ent.getEntOrganizacao())
                BeanUtils.copyProperties(form, ent.getEntOrganizacao());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntSistema(), form, req);
            if (null != ent && null != ent.getEntSistema())
                BeanUtils.copyProperties(form, ent.getEntSistema());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoAcesso(), form, req);
            if (null != ent && null != ent.getEntTipoAcesso())
                BeanUtils.copyProperties(form, ent.getEntTipoAcesso());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntPerfilSuperior(), form, req);
            if (null != ent && null != ent.getEntPerfilSuperior())
                BeanUtils.copyProperties(form, ent.getEntPerfilSuperior());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas
            List<EntComandoPerfil> lstCmp = ent.getLstComandoPerfil();
            lstCmp = ordenarLista(lstCmp, getResources(req).getMessage("comandoPerfil.ordenacao")); 
            req.setAttribute("lstResCmp", lstCmp);

            List<EntPapel> lstPap = ent.getLstPapel();
            lstPap = ordenarLista(lstPap, getResources(req).getMessage("papel.ordenacao")); 
            req.setAttribute("lstResPap", lstPap);

            List<EntPerfil> lstPerSuperior = ent.getLstPerfilSuperior();
            lstPerSuperior = ordenarLista(lstPerSuperior, getResources(req).getMessage("perfil.ordenacao")); 
            req.setAttribute("lstResPerSuperior", lstPerSuperior);

            List<EntPerfilUsuario> lstPfu = ent.getLstPerfilUsuario();
            lstPfu = ordenarLista(lstPfu, getResources(req).getMessage("perfilUsuario.ordenacao")); 
            req.setAttribute("lstResPfu", lstPfu);


			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntPerfil ent = new EntPerfil();
		NgcPerfil ngc = new NgcPerfil();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntPerfil) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("perIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio




            if (getResources(req).getMessage("campo.perfil.orgIdtChave.exibir.cad").equals("s"))
                this.setaOrganizacao(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.perfil.sisIdtChave.exibir.cad").equals("s"))
                this.setaSistema(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.perfil.tpaIdtChave.exibir.cad").equals("s"))
                this.setaTipoAcesso(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.perfil.perIdtChaveSuperior.exibir.cad").equals("s"))
                this.setaPerfilSuperior(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.perfil.comandoPerfil.exibir").equals("s"))
            {
                // Salva ComandoPerfil
                List<EntComandoPerfil> lstPrsCmp = ent.getLstComandoPerfil();
                List<EntComandoPerfil> lstTmpCmp = montarComandoPerfil(req, form, ent, "");
                AtualizarComandoPerfil(form, lstPrsCmp, lstTmpCmp);
            }
            if (getResources(req).getMessage("detalhe.perfil.papel.exibir").equals("s"))
            {
                // Salva Papel
                List<EntPapel> lstPrsPap = ent.getLstPapel();
                List<EntPapel> lstTmpPap = montarPapel(req, form, ent, "");
                AtualizarPapel(form, lstPrsPap, lstTmpPap);
            }
            if (getResources(req).getMessage("detalhe.perfil.perfilSuperior.exibir").equals("s"))
            {
                // Salva PerfilSuperior
                List<EntPerfil> lstPrsPer = ent.getLstPerfilSuperior();
                List<EntPerfil> lstTmpPer = montarPerfil(req, form, ent, "SUPERIOR_");
                AtualizarPerfil(form, lstPrsPer, lstTmpPer);
            }
            if (getResources(req).getMessage("detalhe.perfil.perfilUsuario.exibir").equals("s"))
            {
                // Salva PerfilUsuario
                List<EntPerfilUsuario> lstPrsPfu = ent.getLstPerfilUsuario();
                List<EntPerfilUsuario> lstTmpPfu = montarPerfilUsuario(req, form, ent, "");
                AtualizarPerfilUsuario(form, lstPrsPfu, lstTmpPfu);
            }


			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntPerfil) ngc.consultarID(ent.getPerIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResPer", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntPerfil ent = new EntPerfil();
		NgcPerfil ngc = new NgcPerfil();

		try
		{
			ent = (EntPerfil) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("perIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntPerfil ent = new EntPerfil();
		NgcPerfil ngc = new NgcPerfil();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);

            if (getResources(req).getMessage("campo.perfil.orgIdtChave.exibir.cad").equals("s"))
                this.setaOrganizacao(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.perfil.sisIdtChave.exibir.cad").equals("s"))
                this.setaSistema(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.perfil.tpaIdtChave.exibir.cad").equals("s"))
                this.setaTipoAcesso(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.perfil.perIdtChaveSuperior.exibir.cad").equals("s"))
                this.setaPerfilSuperior(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.perfil.comandoPerfil.exibir").equals("s"))
            {
                // Salva ComandoPerfil
                Integer qtdeComandoPerfil = Integer.parseInt(req.getParameter("qtdeComandoPerfil"));
                if (qtdeComandoPerfil > 0)
                {
                    List<EntComandoPerfil> lstTmpCmp = montarComandoPerfil(req, form, ent, "");
                    ent.setLstComandoPerfil(lstTmpCmp);
                }

            }
            if (getResources(req).getMessage("detalhe.perfil.papel.exibir").equals("s"))
            {
                // Salva Papel
                Integer qtdePapel = Integer.parseInt(req.getParameter("qtdePapel"));
                if (qtdePapel > 0)
                {
                    List<EntPapel> lstTmpPap = montarPapel(req, form, ent, "");
                    ent.setLstPapel(lstTmpPap);
                }

            }
            if (getResources(req).getMessage("detalhe.perfil.perfilSuperior.exibir").equals("s"))
            {
                // Salva PerfilSuperior
                Integer qtdePerfilSuperior = Integer.parseInt(req.getParameter("qtdePerfilSuperior"));
                if (qtdePerfilSuperior > 0)
                {
                    List<EntPerfil> lstTmpPer = montarPerfil(req, form, ent, "SUPERIOR_");
                    ent.setLstPerfilSuperior(lstTmpPer);
                }

            }
            if (getResources(req).getMessage("detalhe.perfil.perfilUsuario.exibir").equals("s"))
            {
                // Salva PerfilUsuario
                Integer qtdePerfilUsuario = Integer.parseInt(req.getParameter("qtdePerfilUsuario"));
                if (qtdePerfilUsuario > 0)
                {
                    List<EntPerfilUsuario> lstTmpPfu = montarPerfilUsuario(req, form, ent, "");
                    ent.setLstPerfilUsuario(lstTmpPfu);
                }

            }

			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntPerfil) ngc.consultarID(ent.getPerIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResPer", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntPerfil ent) throws Exception
	{
            if (getResources(req).getMessage("campo.perfil.orgIdtChave.exibir.cad").equals("s"))
                this.setaOrganizacao(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.perfil.sisIdtChave.exibir.cad").equals("s"))
                this.setaSistema(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.perfil.tpaIdtChave.exibir.cad").equals("s"))
                this.setaTipoAcesso(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.perfil.perIdtChaveSuperior.exibir.cad").equals("s"))
                this.setaPerfilSuperior(map, form, req, res, ent);

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntPerfil ent) throws Exception
	{
            if (getResources(req).getMessage("detalhe.perfil.comandoPerfil.exibir").equals("s"))
            {
                // Salva ComandoPerfil
                List<EntComandoPerfil> lstPrsCmp = ent.getLstComandoPerfil();
                List<EntComandoPerfil> lstTmpCmp = montarComandoPerfil(req, form, ent, "");
                AtualizarComandoPerfil(form, lstPrsCmp, lstTmpCmp);
            }
            if (getResources(req).getMessage("detalhe.perfil.papel.exibir").equals("s"))
            {
                // Salva Papel
                List<EntPapel> lstPrsPap = ent.getLstPapel();
                List<EntPapel> lstTmpPap = montarPapel(req, form, ent, "");
                AtualizarPapel(form, lstPrsPap, lstTmpPap);
            }
            if (getResources(req).getMessage("detalhe.perfil.perfilSuperior.exibir").equals("s"))
            {
                // Salva PerfilSuperior
                List<EntPerfil> lstPrsPer = ent.getLstPerfilSuperior();
                List<EntPerfil> lstTmpPer = montarPerfil(req, form, ent, "SUPERIOR_");
                AtualizarPerfil(form, lstPrsPer, lstTmpPer);
            }
            if (getResources(req).getMessage("detalhe.perfil.perfilUsuario.exibir").equals("s"))
            {
                // Salva PerfilUsuario
                List<EntPerfilUsuario> lstPrsPfu = ent.getLstPerfilUsuario();
                List<EntPerfilUsuario> lstTmpPfu = montarPerfilUsuario(req, form, ent, "");
                AtualizarPerfilUsuario(form, lstPrsPfu, lstTmpPfu);
            }

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntPerfil ent) throws Exception
	{
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntOrganizacao(), form, req);
            if (null != ent && null != ent.getEntOrganizacao())
                BeanUtils.copyProperties(form, ent.getEntOrganizacao());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntSistema(), form, req);
            if (null != ent && null != ent.getEntSistema())
                BeanUtils.copyProperties(form, ent.getEntSistema());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoAcesso(), form, req);
            if (null != ent && null != ent.getEntTipoAcesso())
                BeanUtils.copyProperties(form, ent.getEntTipoAcesso());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntPerfilSuperior(), form, req);
            if (null != ent && null != ent.getEntPerfilSuperior())
                BeanUtils.copyProperties(form, ent.getEntPerfilSuperior());

	}

	public void converterValores(ActionForm form)
	{

        // PerFlgPublico
        if ((((DynaValidatorForm) form).get("perFlgPublico")) != null && !(((DynaValidatorForm) form).get("perFlgPublico")).equals(""))
        {
            Integer perFlgPublico = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("perFlgPublico"));
            ((DynaValidatorForm) form).set("perFlgPublico", perFlgPublico.toString());
        }



	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntPerfil ent) throws Exception
	{

	
        if (getResources(req).getMessage("campo.perfil.orgIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.orgIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstOrganizacao"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntOrganizacao());
            carregarOrganizacao(map, form, req, res, metodo, l); 
            
        }
        if (getResources(req).getMessage("campo.perfil.sisIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.sisIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstSistema"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntSistema());
            carregarSistema(map, form, req, res, metodo, l); 
            
        }
        if (getResources(req).getMessage("campo.perfil.tpaIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.tpaIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstTipoAcesso"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntTipoAcesso());
            carregarTipoAcesso(map, form, req, res, metodo, l); 
            
        }
        if (getResources(req).getMessage("campo.perfil.perIdtChaveSuperior.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.perIdtChaveSuperior.visual").toLowerCase().equals("l") && null == req.getAttribute("lstPerfil"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntPerfilSuperior());
            carregarPerfil(map, form, req, res, metodo, l); 
            
        }
            if (getResources(req).getMessage("detalhe.perfil.comandoPerfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.comandoPerfil.cmdIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstCmd"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstComandoPerfil() != null && ent.getLstComandoPerfil().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstComandoPerfil().iterator(); iterator.hasNext();)
                        //{
                            //EntComandoPerfil obj = (EntComandoPerfil) iterator.next();
                            //l.add(obj.getEntComando());
                        //}
                    //}
                //}
                carregarComando(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.perfil.papel.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.papel.orgIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstOrg"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPapel() != null && ent.getLstPapel().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPapel().iterator(); iterator.hasNext();)
                        //{
                            //EntPapel obj = (EntPapel) iterator.next();
                            //l.add(obj.getEntOrganizacao());
                        //}
                    //}
                //}
                carregarOrganizacao(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.perfil.papel.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.papel.pesIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstPes"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPapel() != null && ent.getLstPapel().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPapel().iterator(); iterator.hasNext();)
                        //{
                            //EntPapel obj = (EntPapel) iterator.next();
                            //l.add(obj.getEntPessoa());
                        //}
                    //}
                //}
                carregarPessoa(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.perfil.perfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.orgIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstOrg"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfil() != null && ent.getLstPerfil().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfil().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfil obj = (EntPerfil) iterator.next();
                            //l.add(obj.getEntOrganizacao());
                        //}
                    //}
                //}
                carregarOrganizacao(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.perfil.perfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.sisIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstSis"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfil() != null && ent.getLstPerfil().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfil().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfil obj = (EntPerfil) iterator.next();
                            //l.add(obj.getEntSistema());
                        //}
                    //}
                //}
                carregarSistema(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.perfil.perfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.tpaIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstTpa"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfil() != null && ent.getLstPerfil().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfil().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfil obj = (EntPerfil) iterator.next();
                            //l.add(obj.getEntTipoAcesso());
                        //}
                    //}
                //}
                carregarTipoAcesso(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.perfil.perfilSuperior.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.perIdtChaveSuperior.visual").toLowerCase().equals("l") && null == req.getAttribute("lstPer"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfilSuperior() != null && ent.getLstPerfilSuperior().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfilSuperior().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfil obj = (EntPerfil) iterator.next();
                            //l.add(obj.getEntPerfil());
                        //}
                    //}
                //}
                carregarOrganizacao(map, form, req, res, metodo, l);
                carregarSistema(map, form, req, res, metodo, l);
                carregarTipoAcesso(map, form, req, res, metodo, l);
                carregarPerfil(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.perfil.perfilUsuario.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfilUsuario.usuIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstUsu"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfilUsuario() != null && ent.getLstPerfilUsuario().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfilUsuario().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfilUsuario obj = (EntPerfilUsuario) iterator.next();
                            //l.add(obj.getEntUsuario());
                        //}
                    //}
                //}
                carregarUsuario(map, form, req, res, metodo, l);
            }

	}

    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarOrganizacao(map, form, req, res, "par", null);

    }
    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcOrganizacao ngc = new NgcOrganizacao();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstOrg", ngc.consultarHabilitados(new String[][]{{"orgDscFantasia", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstOrg", ngc.consultarTodos(new String[][]{{"orgDscFantasia", "ASC"}}));
        }
    }

    public void carregarSistema(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarSistema(map, form, req, res, "par", null);

    }
    public void carregarSistema(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcSistema ngc = new NgcSistema();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstSis", ngc.consultarHabilitados(new String[][]{{"sisDscTitulo", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstSis", ngc.consultarTodos(new String[][]{{"sisDscTitulo", "ASC"}}));
        }
    }

    public void carregarTipoAcesso(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarTipoAcesso(map, form, req, res, "par", null);

    }
    public void carregarTipoAcesso(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcTipoAcesso ngc = new NgcTipoAcesso();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstTpa", ngc.consultarHabilitados(new String[][]{{"tpaDscTipo", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstTpa", ngc.consultarTodos(new String[][]{{"tpaDscTipo", "ASC"}}));
        }
    }

    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarPerfil(map, form, req, res, "par", null);

    }
    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcPerfil ngc = new NgcPerfil();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstPer", ngc.consultarHabilitados(new String[][]{{"perDscPerfil", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstPer", ngc.consultarTodos(new String[][]{{"perDscPerfil", "ASC"}}));
        }
    }

    public void carregarComando(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarComando(map, form, req, res, "par", null);

    }
    public void carregarComando(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcComando ngc = new NgcComando();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstCmd", ngc.consultarHabilitados(new String[][]{{"cmdDscLabel", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstCmd", ngc.consultarTodos(new String[][]{{"cmdDscLabel", "ASC"}}));
        }
    }

    public void carregarPessoa(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarPessoa(map, form, req, res, "par", null);

    }
    public void carregarPessoa(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcPessoa ngc = new NgcPessoa();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstPes", ngc.consultarHabilitados(new String[][]{{"pesDscNome", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstPes", ngc.consultarTodos(new String[][]{{"pesDscNome", "ASC"}}));
        }
    }

    public void carregarUsuario(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarUsuario(map, form, req, res, "par", null);

    }
    public void carregarUsuario(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcUsuario ngc = new NgcUsuario();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstUsu", ngc.consultarHabilitados(new String[][]{{"usuDscLogin", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstUsu", ngc.consultarTodos(new String[][]{{"usuDscLogin", "ASC"}}));
        }
    }





            public void setaOrganizacao(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntPerfil ent) throws Exception
            {
                EntOrganizacao entOrg;
                if (ent.getEntOrganizacao() != null && !((String)((DynaValidatorForm)form).get("orgIdtChave")).equals("") && ent.getEntOrganizacao().getOrgIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("orgIdtChave"))) 
                    entOrg = ent.getEntOrganizacao();
                else
                {
                    entOrg = new EntOrganizacao();
                    try {
                        entOrg.setOrgIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("orgIdtChave")));
                    } catch (Exception e) {
                        entOrg.setOrgIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entOrg, req);
                if (entOrg.getOrgIdtChave() != null)
                    ent.setEntOrganizacao(entOrg);
                else
                    ent.setEntOrganizacao(null);
            }
            public void setaSistema(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntPerfil ent) throws Exception
            {
                EntSistema entSis;
                if (ent.getEntSistema() != null && !((String)((DynaValidatorForm)form).get("sisIdtChave")).equals("") && ent.getEntSistema().getSisIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("sisIdtChave"))) 
                    entSis = ent.getEntSistema();
                else
                {
                    entSis = new EntSistema();
                    try {
                        entSis.setSisIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("sisIdtChave")));
                    } catch (Exception e) {
                        entSis.setSisIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entSis, req);
                if (entSis.getSisIdtChave() != null)
                    ent.setEntSistema(entSis);
                else
                    ent.setEntSistema(null);
            }
            public void setaTipoAcesso(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntPerfil ent) throws Exception
            {
                EntTipoAcesso entTpa;
                if (ent.getEntTipoAcesso() != null && !((String)((DynaValidatorForm)form).get("tpaIdtChave")).equals("") && ent.getEntTipoAcesso().getTpaIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("tpaIdtChave"))) 
                    entTpa = ent.getEntTipoAcesso();
                else
                {
                    entTpa = new EntTipoAcesso();
                    try {
                        entTpa.setTpaIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("tpaIdtChave")));
                    } catch (Exception e) {
                        entTpa.setTpaIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entTpa, req);
                if (entTpa.getTpaIdtChave() != null)
                    ent.setEntTipoAcesso(entTpa);
                else
                    ent.setEntTipoAcesso(null);
            }
            public void setaPerfilSuperior(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntPerfil ent) throws Exception
            {
                EntPerfil entPer;
                if (ent.getEntPerfilSuperior() != null && !((String)((DynaValidatorForm)form).get("perIdtChaveSuperior")).equals("") && ent.getEntPerfilSuperior().getPerIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("perIdtChaveSuperior"))) 
                    entPer = ent.getEntPerfilSuperior();
                else
                {
                    entPer = new EntPerfil();
                    try {
                        entPer.setPerIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("perIdtChaveSuperior")));
                    } catch (Exception e) {
                        entPer.setPerIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entPer, req);
                // Ajusta o campo chave (no caso de sufixo)
                if (null != ((DynaValidatorForm)form).get("perIdtChaveSuperior") && !((DynaValidatorForm)form).get("perIdtChaveSuperior").equals(""))
                    entPer.setPerIdtChave(new Long(((String) ((DynaValidatorForm)form).get("perIdtChaveSuperior"))));
                if (entPer.getPerIdtChave() != null)
                    ent.setEntPerfilSuperior(entPer);
                else
                    ent.setEntPerfilSuperior(null);
            }




            public List<EntComandoPerfil> montarComandoPerfil(HttpServletRequest req, ActionForm form, EntPerfil ent, String sufixo) throws Exception
            {
                List<EntComandoPerfil> lst = new ArrayList<EntComandoPerfil>(); 

                // Campos do detalhe
                String[] cmpIdtChave = (String[])((DynaValidatorForm)form).get("cmp_" + sufixo.toUpperCase() + "cmpIdtChave"); 
                String[] cmdIdtChave = (String[])((DynaValidatorForm)form).get("cmp_" + sufixo.toUpperCase() + "cmdIdtChave"); 
                String[] cmdIdtChaveDsc = (String[])((DynaValidatorForm)form).get("cmp_" + sufixo.toUpperCase() + "cmdIdtChaveDsc"); 
                String[] perIdtChave = (String[])((DynaValidatorForm)form).get("cmp_" + sufixo.toUpperCase() + "perIdtChave"); 

                // Percorre cada linha 
                for (int i = 0; i < cmpIdtChave.length; i++) 
                {
                    EntComandoPerfil entTmp = new EntComandoPerfil();  // Percorre o detalhe
                    // Copia campos - ComandoPerfil
                if (cmpIdtChave[i] != null && !cmpIdtChave[i].equals(""))
                    entTmp.setCmpIdtChave(Long.parseLong(cmpIdtChave[i]));

                if (cmdIdtChave != null && cmdIdtChave.length > 0 && cmdIdtChave[i] != null && !cmdIdtChave[i].equals(""))
                {
                    EntComando entTmpCmd = new EntComando();
                    entTmpCmd.setCmdIdtChave(Long.parseLong(cmdIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.comandoPerfil.cmdIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpCmd, cmdIdtChaveDsc[i], "campo.comandoPerfil.cmdIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntComando(entTmpCmd);
                }

            if (cmdIdtChave != null && cmdIdtChave.length > 0 && cmdIdtChave[i] != null && !cmdIdtChave[i].equals(""))
            {
                EntComando obj = new EntComando();
                obj.setCmdIdtChave(Long.parseLong(cmdIdtChave[i]));
                entTmp.setEntComando(obj);
            }
            if (perIdtChave != null && perIdtChave.length > 0 && perIdtChave[i] != null && !perIdtChave[i].equals(""))
            {
                EntPerfil obj = new EntPerfil();
                obj.setPerIdtChave(Long.parseLong(perIdtChave[i]));
                entTmp.setEntPerfil(obj);
            }
            else if(("perIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("perIdtChave"))
            {
                entTmp.setEntPerfil(ent);
            }

                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntPapel> montarPapel(HttpServletRequest req, ActionForm form, EntPerfil ent, String sufixo) throws Exception
            {
                List<EntPapel> lst = new ArrayList<EntPapel>(); 

                // Campos do detalhe
                String[] papIdtChave = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "papIdtChave"); 
                String[] orgIdtChave = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "orgIdtChave"); 
                String[] orgIdtChaveDsc = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "orgIdtChaveDsc"); 
                String[] pesIdtChave = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "pesIdtChave"); 
                String[] pesIdtChaveDsc = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "pesIdtChaveDsc"); 
                String[] perIdtChave = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "perIdtChave"); 
                String[] papDatInicio = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "papDatInicio"); 
                String[] papDatFim = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "papDatFim"); 
                String[] papFlgAtivo = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "papFlgAtivo"); 

                // Percorre cada linha 
                for (int i = 0; i < papIdtChave.length; i++) 
                {
                    EntPapel entTmp = new EntPapel();  // Percorre o detalhe
                    // Copia campos - Papel
                if (papIdtChave[i] != null && !papIdtChave[i].equals(""))
                    entTmp.setPapIdtChave(Long.parseLong(papIdtChave[i]));

                if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
                {
                    EntOrganizacao entTmpOrg = new EntOrganizacao();
                    entTmpOrg.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.papel.orgIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpOrg, orgIdtChaveDsc[i], "campo.papel.orgIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntOrganizacao(entTmpOrg);
                }

            if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
            {
                EntOrganizacao obj = new EntOrganizacao();
                obj.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                entTmp.setEntOrganizacao(obj);
            }
                if (pesIdtChave != null && pesIdtChave.length > 0 && pesIdtChave[i] != null && !pesIdtChave[i].equals(""))
                {
                    EntPessoa entTmpPes = new EntPessoa();
                    entTmpPes.setPesIdtChave(Long.parseLong(pesIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.papel.pesIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpPes, pesIdtChaveDsc[i], "campo.papel.pesIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntPessoa(entTmpPes);
                }

            if (pesIdtChave != null && pesIdtChave.length > 0 && pesIdtChave[i] != null && !pesIdtChave[i].equals(""))
            {
                EntPessoa obj = new EntPessoa();
                obj.setPesIdtChave(Long.parseLong(pesIdtChave[i]));
                entTmp.setEntPessoa(obj);
            }
            if (perIdtChave != null && perIdtChave.length > 0 && perIdtChave[i] != null && !perIdtChave[i].equals(""))
            {
                EntPerfil obj = new EntPerfil();
                obj.setPerIdtChave(Long.parseLong(perIdtChave[i]));
                entTmp.setEntPerfil(obj);
            }
            else if(("perIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("perIdtChave"))
            {
                entTmp.setEntPerfil(ent);
            }
            if (papDatInicio != null && papDatInicio.length > 0 && papDatInicio[i] != null && !papDatInicio[i].equals(""))
                entTmp.setPapDatInicio(FormatDate.parse(papDatInicio[i]));

            if (papDatFim != null && papDatFim.length > 0 && papDatFim[i] != null && !papDatFim[i].equals(""))
                entTmp.setPapDatFim(FormatDate.parse(papDatFim[i]));

            if (papFlgAtivo != null && papFlgAtivo.length > 0 && papFlgAtivo[i] != null && !papFlgAtivo[i].equals(""))
                entTmp.setPapFlgAtivo(Integer.parseInt(papFlgAtivo[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntPerfil> montarPerfil(HttpServletRequest req, ActionForm form, EntPerfil ent, String sufixo) throws Exception
            {
                List<EntPerfil> lst = new ArrayList<EntPerfil>(); 

                // Campos do detalhe
                String[] perIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perIdtChave"); 
                String[] orgIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "orgIdtChave"); 
                String[] orgIdtChaveDsc = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "orgIdtChaveDsc"); 
                String[] sisIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "sisIdtChave"); 
                String[] sisIdtChaveDsc = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "sisIdtChaveDsc"); 
                String[] perDscPerfil = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perDscPerfil"); 
                String[] perFlgPublico = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perFlgPublico"); 
                String[] tpaIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "tpaIdtChave"); 
                String[] tpaIdtChaveDsc = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "tpaIdtChaveDsc"); 
                String[] perIdtChaveSuperior = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perIdtChaveSuperior"); 

                // Percorre cada linha 
                for (int i = 0; i < perIdtChave.length; i++) 
                {
                    EntPerfil entTmp = new EntPerfil();  // Percorre o detalhe
                    // Copia campos - Perfil
                if (perIdtChave[i] != null && !perIdtChave[i].equals(""))
                    entTmp.setPerIdtChave(Long.parseLong(perIdtChave[i]));

                if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
                {
                    EntOrganizacao entTmpOrg = new EntOrganizacao();
                    entTmpOrg.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.perfil.orgIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpOrg, orgIdtChaveDsc[i], "campo.perfil.orgIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntOrganizacao(entTmpOrg);
                }

            if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
            {
                EntOrganizacao obj = new EntOrganizacao();
                obj.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                entTmp.setEntOrganizacao(obj);
            }
                if (sisIdtChave != null && sisIdtChave.length > 0 && sisIdtChave[i] != null && !sisIdtChave[i].equals(""))
                {
                    EntSistema entTmpSis = new EntSistema();
                    entTmpSis.setSisIdtChave(Long.parseLong(sisIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.perfil.sisIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpSis, sisIdtChaveDsc[i], "campo.perfil.sisIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntSistema(entTmpSis);
                }

            if (sisIdtChave != null && sisIdtChave.length > 0 && sisIdtChave[i] != null && !sisIdtChave[i].equals(""))
            {
                EntSistema obj = new EntSistema();
                obj.setSisIdtChave(Long.parseLong(sisIdtChave[i]));
                entTmp.setEntSistema(obj);
            }
            if (perDscPerfil != null && perDscPerfil.length > 0 && perDscPerfil[i] != null && !perDscPerfil[i].equals(""))
                entTmp.setPerDscPerfil((perDscPerfil[i]));

            if (perFlgPublico != null && perFlgPublico.length > 0 && perFlgPublico[i] != null && !perFlgPublico[i].equals(""))
                entTmp.setPerFlgPublico(Integer.parseInt(perFlgPublico[i]));

                if (tpaIdtChave != null && tpaIdtChave.length > 0 && tpaIdtChave[i] != null && !tpaIdtChave[i].equals(""))
                {
                    EntTipoAcesso entTmpTpa = new EntTipoAcesso();
                    entTmpTpa.setTpaIdtChave(Long.parseLong(tpaIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.perfil.tpaIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpTpa, tpaIdtChaveDsc[i], "campo.perfil.tpaIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntTipoAcesso(entTmpTpa);
                }

            if (tpaIdtChave != null && tpaIdtChave.length > 0 && tpaIdtChave[i] != null && !tpaIdtChave[i].equals(""))
            {
                EntTipoAcesso obj = new EntTipoAcesso();
                obj.setTpaIdtChave(Long.parseLong(tpaIdtChave[i]));
                entTmp.setEntTipoAcesso(obj);
            }
            if (perIdtChaveSuperior != null && perIdtChaveSuperior.length > 0 && perIdtChaveSuperior[i] != null && !perIdtChaveSuperior[i].equals(""))
            {
                EntPerfil obj = new EntPerfil();
                obj.setPerIdtChave(Long.parseLong(perIdtChaveSuperior[i]));
                entTmp.setEntPerfilSuperior(obj);
            }
            else if(("perIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("perIdtChaveSuperior"))
            {
                entTmp.setEntPerfilSuperior(ent);
            }

                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntPerfilUsuario> montarPerfilUsuario(HttpServletRequest req, ActionForm form, EntPerfil ent, String sufixo) throws Exception
            {
                List<EntPerfilUsuario> lst = new ArrayList<EntPerfilUsuario>(); 

                // Campos do detalhe
                String[] pfuIdtChave = (String[])((DynaValidatorForm)form).get("pfu_" + sufixo.toUpperCase() + "pfuIdtChave"); 
                String[] perIdtChave = (String[])((DynaValidatorForm)form).get("pfu_" + sufixo.toUpperCase() + "perIdtChave"); 
                String[] usuIdtChave = (String[])((DynaValidatorForm)form).get("pfu_" + sufixo.toUpperCase() + "usuIdtChave"); 
                String[] usuIdtChaveDsc = (String[])((DynaValidatorForm)form).get("pfu_" + sufixo.toUpperCase() + "usuIdtChaveDsc"); 

                // Percorre cada linha 
                for (int i = 0; i < pfuIdtChave.length; i++) 
                {
                    EntPerfilUsuario entTmp = new EntPerfilUsuario();  // Percorre o detalhe
                    // Copia campos - PerfilUsuario
                if (pfuIdtChave[i] != null && !pfuIdtChave[i].equals(""))
                    entTmp.setPfuIdtChave(Long.parseLong(pfuIdtChave[i]));

            if (perIdtChave != null && perIdtChave.length > 0 && perIdtChave[i] != null && !perIdtChave[i].equals(""))
            {
                EntPerfil obj = new EntPerfil();
                obj.setPerIdtChave(Long.parseLong(perIdtChave[i]));
                entTmp.setEntPerfil(obj);
            }
            else if(("perIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("perIdtChave"))
            {
                entTmp.setEntPerfil(ent);
            }
                if (usuIdtChave != null && usuIdtChave.length > 0 && usuIdtChave[i] != null && !usuIdtChave[i].equals(""))
                {
                    EntUsuario entTmpUsu = new EntUsuario();
                    entTmpUsu.setUsuIdtChave(Long.parseLong(usuIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.perfilUsuario.usuIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpUsu, usuIdtChaveDsc[i], "campo.perfilUsuario.usuIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntUsuario(entTmpUsu);
                }

            if (usuIdtChave != null && usuIdtChave.length > 0 && usuIdtChave[i] != null && !usuIdtChave[i].equals(""))
            {
                EntUsuario obj = new EntUsuario();
                obj.setUsuIdtChave(Long.parseLong(usuIdtChave[i]));
                entTmp.setEntUsuario(obj);
            }

                    lst.add(entTmp);
                }
                return lst; 
            }



            public void AtualizarComandoPerfil(ActionForm form, List<EntComandoPerfil> lstPrs, List<EntComandoPerfil> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntComandoPerfil entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntComandoPerfil entTmp = lstTmp.get(j);
                    if (entPrs.getCmpIdtChave().equals(entTmp.getCmpIdtChave())) // Altera��o
                    {
                    entPrs.setEntComando(entTmp.getEntComando());
                    entPrs.setEntPerfil(entTmp.getEntPerfil());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarPapel(ActionForm form, List<EntPapel> lstPrs, List<EntPapel> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntPapel entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntPapel entTmp = lstTmp.get(j);
                    if (entPrs.getPapIdtChave().equals(entTmp.getPapIdtChave())) // Altera��o
                    {
                    entPrs.setEntOrganizacao(entTmp.getEntOrganizacao());
                    entPrs.setEntPessoa(entTmp.getEntPessoa());
                    entPrs.setEntPerfil(entTmp.getEntPerfil());
                    entPrs.setPapDatInicio(entTmp.getPapDatInicio());
                    entPrs.setPapDatFim(entTmp.getPapDatFim());
                    entPrs.setPapFlgAtivo(entTmp.getPapFlgAtivo());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarPerfil(ActionForm form, List<EntPerfil> lstPrs, List<EntPerfil> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntPerfil entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntPerfil entTmp = lstTmp.get(j);
                    if (entPrs.getPerIdtChave().equals(entTmp.getPerIdtChave())) // Altera��o
                    {
                    entPrs.setEntOrganizacao(entTmp.getEntOrganizacao());
                    entPrs.setEntSistema(entTmp.getEntSistema());
                    entPrs.setPerDscPerfil(entTmp.getPerDscPerfil());
                    entPrs.setPerFlgPublico(entTmp.getPerFlgPublico());
                    entPrs.setEntTipoAcesso(entTmp.getEntTipoAcesso());
                    entPrs.setEntPerfilSuperior(entTmp.getEntPerfilSuperior());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarPerfilUsuario(ActionForm form, List<EntPerfilUsuario> lstPrs, List<EntPerfilUsuario> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntPerfilUsuario entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntPerfilUsuario entTmp = lstTmp.get(j);
                    if (entPrs.getPfuIdtChave().equals(entTmp.getPfuIdtChave())) // Altera��o
                    {
                    entPrs.setEntPerfil(entTmp.getEntPerfil());
                    entPrs.setEntUsuario(entTmp.getEntUsuario());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }


    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.perfil." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.perfil." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
