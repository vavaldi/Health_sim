package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoTipoAcessoBase;

public class DaoTipoAcesso extends DaoTipoAcessoBase
{
	public DaoTipoAcesso() throws SerproException
	{
		super();
	}
}
