package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcEtatSanteBase;
//import arquitetura.funcional.health.regra.RngEtatSante;

public class NgcEtatSante extends NgcEtatSanteBase
{

}
