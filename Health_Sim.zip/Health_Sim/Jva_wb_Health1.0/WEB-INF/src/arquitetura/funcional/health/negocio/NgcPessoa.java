package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcPessoaBase;
//import arquitetura.funcional.health.regra.RngPessoa;

public class NgcPessoa extends NgcPessoaBase
{

}
