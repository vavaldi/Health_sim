package arquitetura.funcional.health.negocio;

import java.util.List;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.negocio.NgcComandoBase;
//import arquitetura.funcional.health.regra.RngComando;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntPessoa;
import arquitetura.funcional.health.persistencia.DaoComando;

public class NgcComando extends NgcComandoBase
{
	public List consultarPermissao(Object o) throws SerproException
	{ 
		DaoComando dao = new DaoComando();
		return (List)dao.consultarPermissao(o); 
	}

	// Consulta as permiss�es de uma pessoa para uma determinada organiza��o
	public List consultarPermissao(EntPessoa p, EntOrganizacao o) throws SerproException
	{ 
		DaoComando dao = new DaoComando();
		return (List)dao.consultarPermissao(p, o); 
	}

}
