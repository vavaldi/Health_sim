package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoSistemaUsuarioBase;

public class DaoSistemaUsuario extends DaoSistemaUsuarioBase
{
	public DaoSistemaUsuario() throws SerproException
	{
		super();
	}
}
