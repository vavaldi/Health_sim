package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActOrganizacaoBase;

public class ActOrganizacao extends ActOrganizacaoBase
{

}


