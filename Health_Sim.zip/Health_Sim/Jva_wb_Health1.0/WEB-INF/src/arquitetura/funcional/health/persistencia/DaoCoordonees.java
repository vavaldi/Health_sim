package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoCoordoneesBase;

public class DaoCoordonees extends DaoCoordoneesBase
{
	public DaoCoordonees() throws SerproException
	{
		super();
	}
}
