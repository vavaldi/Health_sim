package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntRegraNegocio;
import arquitetura.funcional.health.negocio.NgcRegraNegocio;
import arquitetura.funcional.health.negocio.NgcComandoPerfil;
import arquitetura.funcional.health.entidades.EntComando;
import arquitetura.funcional.health.negocio.NgcTipoRegra;
import arquitetura.funcional.health.entidades.EntComandoRegra;
import arquitetura.funcional.health.negocio.NgcComandoperfilRegra;
import arquitetura.funcional.health.entidades.EntTipoRegra;
import arquitetura.funcional.health.negocio.NgcComando;
import arquitetura.funcional.health.entidades.EntComandoperfilRegra;
import arquitetura.funcional.health.entidades.EntRegraNegocio;
import arquitetura.funcional.health.entidades.EntComandoPerfil;
import arquitetura.funcional.health.negocio.NgcComandoRegra;


public class ActRegraNegocioBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntRegraNegocio ent = new EntRegraNegocio();
		NgcRegraNegocio ngc = new NgcRegraNegocio();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);



            if (!((DynaValidatorForm) form).get("trnIdtChave").equals(""))
            {
                EntTipoRegra entTrn = new EntTipoRegra();
                entTrn.setTrnIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("trnIdtChave"))); 
                ent.setEntTipoRegra(entTrn);
            }

			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResRng", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntRegraNegocio ent = new EntRegraNegocio();
		NgcRegraNegocio ngc = new NgcRegraNegocio();

		try
		{
			ent = (EntRegraNegocio) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("rngIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			


            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoRegra(), form, req);
            if (null != ent && null != ent.getEntTipoRegra())
                BeanUtils.copyProperties(form, ent.getEntTipoRegra());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas
            List<EntComandoRegra> lstCdr = ent.getLstComandoRegra();
            lstCdr = ordenarLista(lstCdr, getResources(req).getMessage("comandoRegra.ordenacao")); 
            req.setAttribute("lstResCdr", lstCdr);

            List<EntComandoperfilRegra> lstCmr = ent.getLstComandoperfilRegra();
            lstCmr = ordenarLista(lstCmr, getResources(req).getMessage("comandoperfilRegra.ordenacao")); 
            req.setAttribute("lstResCmr", lstCmr);


			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntRegraNegocio ent = new EntRegraNegocio();
		NgcRegraNegocio ngc = new NgcRegraNegocio();

		try
		{
			ent = (EntRegraNegocio) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("rngIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						

            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoRegra(), form, req);
            if (null != ent && null != ent.getEntTipoRegra())
                BeanUtils.copyProperties(form, ent.getEntTipoRegra());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas
            List<EntComandoRegra> lstCdr = ent.getLstComandoRegra();
            lstCdr = ordenarLista(lstCdr, getResources(req).getMessage("comandoRegra.ordenacao")); 
            req.setAttribute("lstResCdr", lstCdr);

            List<EntComandoperfilRegra> lstCmr = ent.getLstComandoperfilRegra();
            lstCmr = ordenarLista(lstCmr, getResources(req).getMessage("comandoperfilRegra.ordenacao")); 
            req.setAttribute("lstResCmr", lstCmr);


			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntRegraNegocio ent = new EntRegraNegocio();
		NgcRegraNegocio ngc = new NgcRegraNegocio();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntRegraNegocio) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("rngIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio




            if (getResources(req).getMessage("campo.regraNegocio.trnIdtChave.exibir.cad").equals("s"))
                this.setaTipoRegra(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.regraNegocio.comandoRegra.exibir").equals("s"))
            {
                // Salva ComandoRegra
                List<EntComandoRegra> lstPrsCdr = ent.getLstComandoRegra();
                List<EntComandoRegra> lstTmpCdr = montarComandoRegra(req, form, ent, "");
                AtualizarComandoRegra(form, lstPrsCdr, lstTmpCdr);
            }
            if (getResources(req).getMessage("detalhe.regraNegocio.comandoperfilRegra.exibir").equals("s"))
            {
                // Salva ComandoperfilRegra
                List<EntComandoperfilRegra> lstPrsCmr = ent.getLstComandoperfilRegra();
                List<EntComandoperfilRegra> lstTmpCmr = montarComandoperfilRegra(req, form, ent, "");
                AtualizarComandoperfilRegra(form, lstPrsCmr, lstTmpCmr);
            }


			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntRegraNegocio) ngc.consultarID(ent.getRngIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResRng", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntRegraNegocio ent = new EntRegraNegocio();
		NgcRegraNegocio ngc = new NgcRegraNegocio();

		try
		{
			ent = (EntRegraNegocio) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("rngIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntRegraNegocio ent = new EntRegraNegocio();
		NgcRegraNegocio ngc = new NgcRegraNegocio();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);

            if (getResources(req).getMessage("campo.regraNegocio.trnIdtChave.exibir.cad").equals("s"))
                this.setaTipoRegra(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.regraNegocio.comandoRegra.exibir").equals("s"))
            {
                // Salva ComandoRegra
                Integer qtdeComandoRegra = Integer.parseInt(req.getParameter("qtdeComandoRegra"));
                if (qtdeComandoRegra > 0)
                {
                    List<EntComandoRegra> lstTmpCdr = montarComandoRegra(req, form, ent, "");
                    ent.setLstComandoRegra(lstTmpCdr);
                }

            }
            if (getResources(req).getMessage("detalhe.regraNegocio.comandoperfilRegra.exibir").equals("s"))
            {
                // Salva ComandoperfilRegra
                Integer qtdeComandoperfilRegra = Integer.parseInt(req.getParameter("qtdeComandoperfilRegra"));
                if (qtdeComandoperfilRegra > 0)
                {
                    List<EntComandoperfilRegra> lstTmpCmr = montarComandoperfilRegra(req, form, ent, "");
                    ent.setLstComandoperfilRegra(lstTmpCmr);
                }

            }

			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntRegraNegocio) ngc.consultarID(ent.getRngIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResRng", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntRegraNegocio ent) throws Exception
	{
            if (getResources(req).getMessage("campo.regraNegocio.trnIdtChave.exibir.cad").equals("s"))
                this.setaTipoRegra(map, form, req, res, ent);

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntRegraNegocio ent) throws Exception
	{
            if (getResources(req).getMessage("detalhe.regraNegocio.comandoRegra.exibir").equals("s"))
            {
                // Salva ComandoRegra
                List<EntComandoRegra> lstPrsCdr = ent.getLstComandoRegra();
                List<EntComandoRegra> lstTmpCdr = montarComandoRegra(req, form, ent, "");
                AtualizarComandoRegra(form, lstPrsCdr, lstTmpCdr);
            }
            if (getResources(req).getMessage("detalhe.regraNegocio.comandoperfilRegra.exibir").equals("s"))
            {
                // Salva ComandoperfilRegra
                List<EntComandoperfilRegra> lstPrsCmr = ent.getLstComandoperfilRegra();
                List<EntComandoperfilRegra> lstTmpCmr = montarComandoperfilRegra(req, form, ent, "");
                AtualizarComandoperfilRegra(form, lstPrsCmr, lstTmpCmr);
            }

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntRegraNegocio ent) throws Exception
	{
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoRegra(), form, req);
            if (null != ent && null != ent.getEntTipoRegra())
                BeanUtils.copyProperties(form, ent.getEntTipoRegra());

	}

	public void converterValores(ActionForm form)
	{




	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntRegraNegocio ent) throws Exception
	{

	
        if (getResources(req).getMessage("campo.regraNegocio.trnIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.regraNegocio.trnIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstTipoRegra"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntTipoRegra());
            carregarTipoRegra(map, form, req, res, metodo, l); 
            
        }
            if (getResources(req).getMessage("detalhe.regraNegocio.comandoRegra.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.comandoRegra.cmdIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstCmd"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstComandoRegra() != null && ent.getLstComandoRegra().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstComandoRegra().iterator(); iterator.hasNext();)
                        //{
                            //EntComandoRegra obj = (EntComandoRegra) iterator.next();
                            //l.add(obj.getEntComando());
                        //}
                    //}
                //}
                carregarComando(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.regraNegocio.comandoperfilRegra.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.comandoperfilRegra.cmpIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstCmp"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstComandoperfilRegra() != null && ent.getLstComandoperfilRegra().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstComandoperfilRegra().iterator(); iterator.hasNext();)
                        //{
                            //EntComandoperfilRegra obj = (EntComandoperfilRegra) iterator.next();
                            //l.add(obj.getEntComandoPerfil());
                        //}
                    //}
                //}
                carregarComandoPerfil(map, form, req, res, metodo, l);
            }

	}

    public void carregarTipoRegra(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarTipoRegra(map, form, req, res, "par", null);

    }
    public void carregarTipoRegra(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcTipoRegra ngc = new NgcTipoRegra();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstTrn", ngc.consultarHabilitados(new String[][]{{"trnDscNome", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstTrn", ngc.consultarTodos(new String[][]{{"trnDscNome", "ASC"}}));
        }
    }

    public void carregarComando(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarComando(map, form, req, res, "par", null);

    }
    public void carregarComando(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcComando ngc = new NgcComando();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstCmd", ngc.consultarHabilitados(new String[][]{{"cmdDscLabel", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstCmd", ngc.consultarTodos(new String[][]{{"cmdDscLabel", "ASC"}}));
        }
    }

    public void carregarComandoPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarComandoPerfil(map, form, req, res, "par", null);

    }
    public void carregarComandoPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcComandoPerfil ngc = new NgcComandoPerfil();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstCmp", ngc.consultarHabilitados(new String[][]{{"cmpIdtChave", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstCmp", ngc.consultarTodos(new String[][]{{"cmpIdtChave", "ASC"}}));
        }
    }





            public void setaTipoRegra(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntRegraNegocio ent) throws Exception
            {
                EntTipoRegra entTrn;
                if (ent.getEntTipoRegra() != null && !((String)((DynaValidatorForm)form).get("trnIdtChave")).equals("") && ent.getEntTipoRegra().getTrnIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("trnIdtChave"))) 
                    entTrn = ent.getEntTipoRegra();
                else
                {
                    entTrn = new EntTipoRegra();
                    try {
                        entTrn.setTrnIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("trnIdtChave")));
                    } catch (Exception e) {
                        entTrn.setTrnIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entTrn, req);
                if (entTrn.getTrnIdtChave() != null)
                    ent.setEntTipoRegra(entTrn);
                else
                    ent.setEntTipoRegra(null);
            }




            public List<EntComandoRegra> montarComandoRegra(HttpServletRequest req, ActionForm form, EntRegraNegocio ent, String sufixo) throws Exception
            {
                List<EntComandoRegra> lst = new ArrayList<EntComandoRegra>(); 

                // Campos do detalhe
                String[] cdrIdtChave = (String[])((DynaValidatorForm)form).get("cdr_" + sufixo.toUpperCase() + "cdrIdtChave"); 
                String[] cmdIdtChave = (String[])((DynaValidatorForm)form).get("cdr_" + sufixo.toUpperCase() + "cmdIdtChave"); 
                String[] cmdIdtChaveDsc = (String[])((DynaValidatorForm)form).get("cdr_" + sufixo.toUpperCase() + "cmdIdtChaveDsc"); 
                String[] rngIdtChave = (String[])((DynaValidatorForm)form).get("cdr_" + sufixo.toUpperCase() + "rngIdtChave"); 
                String[] cdrFlgAtivo = (String[])((DynaValidatorForm)form).get("cdr_" + sufixo.toUpperCase() + "cdrFlgAtivo"); 

                // Percorre cada linha 
                for (int i = 0; i < cdrIdtChave.length; i++) 
                {
                    EntComandoRegra entTmp = new EntComandoRegra();  // Percorre o detalhe
                    // Copia campos - ComandoRegra
                if (cdrIdtChave[i] != null && !cdrIdtChave[i].equals(""))
                    entTmp.setCdrIdtChave(Long.parseLong(cdrIdtChave[i]));

                if (cmdIdtChave != null && cmdIdtChave.length > 0 && cmdIdtChave[i] != null && !cmdIdtChave[i].equals(""))
                {
                    EntComando entTmpCmd = new EntComando();
                    entTmpCmd.setCmdIdtChave(Long.parseLong(cmdIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.comandoRegra.cmdIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpCmd, cmdIdtChaveDsc[i], "campo.comandoRegra.cmdIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntComando(entTmpCmd);
                }

            if (cmdIdtChave != null && cmdIdtChave.length > 0 && cmdIdtChave[i] != null && !cmdIdtChave[i].equals(""))
            {
                EntComando obj = new EntComando();
                obj.setCmdIdtChave(Long.parseLong(cmdIdtChave[i]));
                entTmp.setEntComando(obj);
            }
            if (rngIdtChave != null && rngIdtChave.length > 0 && rngIdtChave[i] != null && !rngIdtChave[i].equals(""))
            {
                EntRegraNegocio obj = new EntRegraNegocio();
                obj.setRngIdtChave(Long.parseLong(rngIdtChave[i]));
                entTmp.setEntRegraNegocio(obj);
            }
            else if(("rngIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("rngIdtChave"))
            {
                entTmp.setEntRegraNegocio(ent);
            }
            if (cdrFlgAtivo != null && cdrFlgAtivo.length > 0 && cdrFlgAtivo[i] != null && !cdrFlgAtivo[i].equals(""))
                entTmp.setCdrFlgAtivo(Integer.parseInt(cdrFlgAtivo[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntComandoperfilRegra> montarComandoperfilRegra(HttpServletRequest req, ActionForm form, EntRegraNegocio ent, String sufixo) throws Exception
            {
                List<EntComandoperfilRegra> lst = new ArrayList<EntComandoperfilRegra>(); 

                // Campos do detalhe
                String[] cmrIdtChave = (String[])((DynaValidatorForm)form).get("cmr_" + sufixo.toUpperCase() + "cmrIdtChave"); 
                String[] cmpIdtChave = (String[])((DynaValidatorForm)form).get("cmr_" + sufixo.toUpperCase() + "cmpIdtChave"); 
                String[] cmpIdtChaveDsc = (String[])((DynaValidatorForm)form).get("cmr_" + sufixo.toUpperCase() + "cmpIdtChaveDsc"); 
                String[] rngIdtChave = (String[])((DynaValidatorForm)form).get("cmr_" + sufixo.toUpperCase() + "rngIdtChave"); 
                String[] cmrFlgAtivo = (String[])((DynaValidatorForm)form).get("cmr_" + sufixo.toUpperCase() + "cmrFlgAtivo"); 

                // Percorre cada linha 
                for (int i = 0; i < cmrIdtChave.length; i++) 
                {
                    EntComandoperfilRegra entTmp = new EntComandoperfilRegra();  // Percorre o detalhe
                    // Copia campos - ComandoperfilRegra
                if (cmrIdtChave[i] != null && !cmrIdtChave[i].equals(""))
                    entTmp.setCmrIdtChave(Long.parseLong(cmrIdtChave[i]));

                if (cmpIdtChave != null && cmpIdtChave.length > 0 && cmpIdtChave[i] != null && !cmpIdtChave[i].equals(""))
                {
                    EntComandoPerfil entTmpCmp = new EntComandoPerfil();
                    entTmpCmp.setCmpIdtChave(Long.parseLong(cmpIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.comandoperfilRegra.cmpIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpCmp, cmpIdtChaveDsc[i], "campo.comandoperfilRegra.cmpIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntComandoPerfil(entTmpCmp);
                }

            if (cmpIdtChave != null && cmpIdtChave.length > 0 && cmpIdtChave[i] != null && !cmpIdtChave[i].equals(""))
            {
                EntComandoPerfil obj = new EntComandoPerfil();
                obj.setCmpIdtChave(Long.parseLong(cmpIdtChave[i]));
                entTmp.setEntComandoPerfil(obj);
            }
            if (rngIdtChave != null && rngIdtChave.length > 0 && rngIdtChave[i] != null && !rngIdtChave[i].equals(""))
            {
                EntRegraNegocio obj = new EntRegraNegocio();
                obj.setRngIdtChave(Long.parseLong(rngIdtChave[i]));
                entTmp.setEntRegraNegocio(obj);
            }
            else if(("rngIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("rngIdtChave"))
            {
                entTmp.setEntRegraNegocio(ent);
            }
            if (cmrFlgAtivo != null && cmrFlgAtivo.length > 0 && cmrFlgAtivo[i] != null && !cmrFlgAtivo[i].equals(""))
                entTmp.setCmrFlgAtivo(Integer.parseInt(cmrFlgAtivo[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }



            public void AtualizarComandoRegra(ActionForm form, List<EntComandoRegra> lstPrs, List<EntComandoRegra> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntComandoRegra entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntComandoRegra entTmp = lstTmp.get(j);
                    if (entPrs.getCdrIdtChave().equals(entTmp.getCdrIdtChave())) // Altera��o
                    {
                    entPrs.setEntComando(entTmp.getEntComando());
                    entPrs.setEntRegraNegocio(entTmp.getEntRegraNegocio());
                    entPrs.setCdrFlgAtivo(entTmp.getCdrFlgAtivo());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarComandoperfilRegra(ActionForm form, List<EntComandoperfilRegra> lstPrs, List<EntComandoperfilRegra> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntComandoperfilRegra entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntComandoperfilRegra entTmp = lstTmp.get(j);
                    if (entPrs.getCmrIdtChave().equals(entTmp.getCmrIdtChave())) // Altera��o
                    {
                    entPrs.setEntComandoPerfil(entTmp.getEntComandoPerfil());
                    entPrs.setEntRegraNegocio(entTmp.getEntRegraNegocio());
                    entPrs.setCmrFlgAtivo(entTmp.getCmrFlgAtivo());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }


    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.regraNegocio." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.regraNegocio." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
