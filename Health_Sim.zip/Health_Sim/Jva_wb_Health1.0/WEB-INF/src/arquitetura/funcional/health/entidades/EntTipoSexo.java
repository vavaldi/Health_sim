package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntTipoSexoBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "tsx_tipo_sexo")

public class EntTipoSexo extends EntTipoSexoBase
{

}
