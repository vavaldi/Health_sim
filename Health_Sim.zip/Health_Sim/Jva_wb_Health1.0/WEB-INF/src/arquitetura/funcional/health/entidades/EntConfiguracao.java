package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntConfiguracaoBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "con_configuracao")

public class EntConfiguracao extends EntConfiguracaoBase
{

}
