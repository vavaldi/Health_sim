package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActSistemaBase;

public class ActSistema extends ActSistemaBase
{

}


