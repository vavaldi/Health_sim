package arquitetura.funcional.health.base.persistencia;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Order;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.persistencia.GenericDAOHealth;
import arquitetura.funcional.health.entidades.EntScenario;

public class DaoScenarioBase extends GenericDAOHealth
{
	public DaoScenarioBase() throws SerproException
	{
		super(EntScenario.class);
	}
}
