package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActStatutSanteBase;

public class ActStatutSante extends ActStatutSanteBase
{

}


