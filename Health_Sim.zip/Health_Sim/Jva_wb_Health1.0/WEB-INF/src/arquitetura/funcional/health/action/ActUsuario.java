package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActUsuarioBase;

public class ActUsuario extends ActUsuarioBase
{

}


