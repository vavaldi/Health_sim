package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntPessoaBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "pes_pessoa")

public class EntPessoa extends EntPessoaBase
{

}
