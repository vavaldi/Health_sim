package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoComandoperfilRegraBase;

public class DaoComandoperfilRegra extends DaoComandoperfilRegraBase
{
	public DaoComandoperfilRegra() throws SerproException
	{
		super();
	}
}
