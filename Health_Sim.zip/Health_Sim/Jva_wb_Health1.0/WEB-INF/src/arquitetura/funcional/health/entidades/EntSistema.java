package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntSistemaBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "sis_sistema")

public class EntSistema extends EntSistemaBase
{

}
