package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntTipoOrganizacaoBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "tor_tipo_organizacao")

public class EntTipoOrganizacao extends EntTipoOrganizacaoBase
{

}
