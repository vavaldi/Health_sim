package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntComandoPerfilBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "cmp_comando_perfil")

public class EntComandoPerfil extends EntComandoPerfilBase
{

}
