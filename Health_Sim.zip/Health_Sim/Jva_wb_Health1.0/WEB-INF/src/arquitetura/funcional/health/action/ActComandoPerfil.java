package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActComandoPerfilBase;

public class ActComandoPerfil extends ActComandoPerfilBase
{

}


