package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntNoeudBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "nod_noeud")

public class EntNoeud extends EntNoeudBase
{

}
