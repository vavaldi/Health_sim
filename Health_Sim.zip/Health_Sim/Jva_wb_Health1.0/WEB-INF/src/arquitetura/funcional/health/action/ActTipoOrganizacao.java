package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActTipoOrganizacaoBase;

public class ActTipoOrganizacao extends ActTipoOrganizacaoBase
{

}


