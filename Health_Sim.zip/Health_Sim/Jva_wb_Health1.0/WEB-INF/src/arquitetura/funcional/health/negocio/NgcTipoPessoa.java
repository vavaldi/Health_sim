package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcTipoPessoaBase;
//import arquitetura.funcional.health.regra.RngTipoPessoa;

public class NgcTipoPessoa extends NgcTipoPessoaBase
{

}
