package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntConfiguracao;
import arquitetura.funcional.health.negocio.NgcConfiguracao;
import arquitetura.funcional.health.negocio.NgcOrganizacao;
import arquitetura.funcional.health.entidades.EntOrganizacao;


public class ActConfiguracaoBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntConfiguracao ent = new EntConfiguracao();
		NgcConfiguracao ngc = new NgcConfiguracao();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);



            if (!((DynaValidatorForm) form).get("orgIdtChave").equals(""))
            {
                EntOrganizacao entOrg = new EntOrganizacao();
                entOrg.setOrgIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("orgIdtChave"))); 
                ent.setEntOrganizacao(entOrg);
            }

			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResCon", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntConfiguracao ent = new EntConfiguracao();
		NgcConfiguracao ngc = new NgcConfiguracao();

		try
		{
			ent = (EntConfiguracao) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("conIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			


            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntOrganizacao(), form, req);
            if (null != ent && null != ent.getEntOrganizacao())
                BeanUtils.copyProperties(form, ent.getEntOrganizacao());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas

			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntConfiguracao ent = new EntConfiguracao();
		NgcConfiguracao ngc = new NgcConfiguracao();

		try
		{
			ent = (EntConfiguracao) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("conIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						

            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntOrganizacao(), form, req);
            if (null != ent && null != ent.getEntOrganizacao())
                BeanUtils.copyProperties(form, ent.getEntOrganizacao());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas

			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntConfiguracao ent = new EntConfiguracao();
		NgcConfiguracao ngc = new NgcConfiguracao();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntConfiguracao) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("conIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio




            if (getResources(req).getMessage("campo.configuracao.orgIdtChave.exibir.cad").equals("s"))
                this.setaOrganizacao(map, form, req, res, ent);



			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntConfiguracao) ngc.consultarID(ent.getConIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResCon", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntConfiguracao ent = new EntConfiguracao();
		NgcConfiguracao ngc = new NgcConfiguracao();

		try
		{
			ent = (EntConfiguracao) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("conIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntConfiguracao ent = new EntConfiguracao();
		NgcConfiguracao ngc = new NgcConfiguracao();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);

            if (getResources(req).getMessage("campo.configuracao.orgIdtChave.exibir.cad").equals("s"))
                this.setaOrganizacao(map, form, req, res, ent);


			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntConfiguracao) ngc.consultarID(ent.getConIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResCon", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntConfiguracao ent) throws Exception
	{
            if (getResources(req).getMessage("campo.configuracao.orgIdtChave.exibir.cad").equals("s"))
                this.setaOrganizacao(map, form, req, res, ent);

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntConfiguracao ent) throws Exception
	{

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntConfiguracao ent) throws Exception
	{
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntOrganizacao(), form, req);
            if (null != ent && null != ent.getEntOrganizacao())
                BeanUtils.copyProperties(form, ent.getEntOrganizacao());

	}

	public void converterValores(ActionForm form)
	{




	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntConfiguracao ent) throws Exception
	{

	
        if (getResources(req).getMessage("campo.configuracao.orgIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.configuracao.orgIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstOrganizacao"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntOrganizacao());
            carregarOrganizacao(map, form, req, res, metodo, l); 
            
        }

	}

    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarOrganizacao(map, form, req, res, "par", null);

    }
    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcOrganizacao ngc = new NgcOrganizacao();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstOrg", ngc.consultarHabilitados(new String[][]{{"orgDscFantasia", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstOrg", ngc.consultarTodos(new String[][]{{"orgDscFantasia", "ASC"}}));
        }
    }





            public void setaOrganizacao(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntConfiguracao ent) throws Exception
            {
                EntOrganizacao entOrg;
                if (ent.getEntOrganizacao() != null && !((String)((DynaValidatorForm)form).get("orgIdtChave")).equals("") && ent.getEntOrganizacao().getOrgIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("orgIdtChave"))) 
                    entOrg = ent.getEntOrganizacao();
                else
                {
                    entOrg = new EntOrganizacao();
                    try {
                        entOrg.setOrgIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("orgIdtChave")));
                    } catch (Exception e) {
                        entOrg.setOrgIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entOrg, req);
                if (entOrg.getOrgIdtChave() != null)
                    ent.setEntOrganizacao(entOrg);
                else
                    ent.setEntOrganizacao(null);
            }








    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.configuracao." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.configuracao." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
