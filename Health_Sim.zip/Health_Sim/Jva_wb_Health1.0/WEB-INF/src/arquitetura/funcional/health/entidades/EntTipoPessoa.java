package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntTipoPessoaBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "tpp_tipo_pessoa")

public class EntTipoPessoa extends EntTipoPessoaBase
{

}
