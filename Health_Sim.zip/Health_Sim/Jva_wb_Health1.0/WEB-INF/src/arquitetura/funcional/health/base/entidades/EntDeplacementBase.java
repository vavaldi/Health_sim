package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import arquitetura.funcional.health.entidades.EntNoeud;
import java.util.Date;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntDeplacementBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "DPC_IDT_CHAVE", unique = true, nullable = false)
    private Long dpcIdtChave;

    @Column(name = "DPC_NUM_TEMPS", nullable = false)
    private Integer dpcNumTemps;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="NOD_IDT_CHAVE_1") 
    private EntNoeud entNoeud1;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="NOD_IDT_CHAVE_2") 
    private EntNoeud entNoeud2;

    @Column(name = "DPC_VLR_DISTANCE", nullable = false)
    private BigDecimal dpcVlrDistance;

    public Long getDpcIdtChave() {
        return this.dpcIdtChave;
    } 

    public void setDpcIdtChave(Long valor) {
        this.dpcIdtChave = valor;
    } 

    public Integer getDpcNumTemps() {
        return this.dpcNumTemps;
    } 

    public void setDpcNumTemps(Integer valor) {
        this.dpcNumTemps = valor;
    } 

    public EntNoeud getEntNoeud1() {
        return this.entNoeud1;
    } 

    public void setEntNoeud1(EntNoeud valor) {
        this.entNoeud1 = valor;
    } 

    public EntNoeud getEntNoeud2() {
        return this.entNoeud2;
    } 

    public void setEntNoeud2(EntNoeud valor) {
        this.entNoeud2 = valor;
    } 

    public BigDecimal getDpcVlrDistance() {
        return this.dpcVlrDistance;
    } 

    public void setDpcVlrDistance(BigDecimal valor) {
        this.dpcVlrDistance = valor;
    } 


}