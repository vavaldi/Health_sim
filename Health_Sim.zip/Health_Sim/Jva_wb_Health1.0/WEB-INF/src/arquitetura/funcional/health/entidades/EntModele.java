package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntModeleBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "mdl_modele")

public class EntModele extends EntModeleBase
{

}
