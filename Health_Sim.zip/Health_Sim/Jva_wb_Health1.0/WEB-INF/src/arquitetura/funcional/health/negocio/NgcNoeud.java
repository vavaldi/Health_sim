package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcNoeudBase;
//import arquitetura.funcional.health.regra.RngNoeud;

public class NgcNoeud extends NgcNoeudBase
{

}
