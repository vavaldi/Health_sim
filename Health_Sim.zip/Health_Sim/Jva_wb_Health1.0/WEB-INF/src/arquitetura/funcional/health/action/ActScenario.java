package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActScenarioBase;

public class ActScenario extends ActScenarioBase
{

}


