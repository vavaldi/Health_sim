package arquitetura.funcional.health.base.entidades;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import arquitetura.funcional.health.entidades.EntContamination;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntMaladieBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "MLD_IDT_CHAVE", unique = true, nullable = false)
    private Long mldIdtChave;

    @Column(name = "MLD_DSC_NOM", nullable = false, length = 45)
    private String mldDscNom;

    @OneToMany(mappedBy="entMaladie",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntContamination> lstContamination;

    public Long getMldIdtChave() {
        return this.mldIdtChave;
    } 

    public void setMldIdtChave(Long valor) {
        this.mldIdtChave = valor;
    } 

    public String getMldDscNom() {
        return this.mldDscNom;
    } 

    public void setMldDscNom(String valor) {
        this.mldDscNom = valor;
    } 

    public List<EntContamination> getLstContamination() {
        return this.lstContamination;
    } 

    public void setLstContamination(List<EntContamination> valor) {
        this.lstContamination = valor;
    } 


}