package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import arquitetura.funcional.health.entidades.EntNoeud;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntMaladie;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntContaminationBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "CON_IDT_CHAVE", unique = true, nullable = false)
    private Long conIdtChave;

    @Column(name = "CON_NUM_TEMPS", nullable = false)
    private Integer conNumTemps;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="NOD_IDT_CHAVE_1") 
    private EntNoeud entNoeud1;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="NOD_IDT_CHAVE_2") 
    private EntNoeud entNoeud2;

    @Column(name = "CON_VLR_DISTANCE", nullable = false)
    private BigDecimal conVlrDistance;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="MLD_IDT_CHAVE") 
    private EntMaladie entMaladie;

    public Long getConIdtChave() {
        return this.conIdtChave;
    } 

    public void setConIdtChave(Long valor) {
        this.conIdtChave = valor;
    } 

    public Integer getConNumTemps() {
        return this.conNumTemps;
    } 

    public void setConNumTemps(Integer valor) {
        this.conNumTemps = valor;
    } 

    public EntNoeud getEntNoeud1() {
        return this.entNoeud1;
    } 

    public void setEntNoeud1(EntNoeud valor) {
        this.entNoeud1 = valor;
    } 

    public EntNoeud getEntNoeud2() {
        return this.entNoeud2;
    } 

    public void setEntNoeud2(EntNoeud valor) {
        this.entNoeud2 = valor;
    } 

    public BigDecimal getConVlrDistance() {
        return this.conVlrDistance;
    } 

    public void setConVlrDistance(BigDecimal valor) {
        this.conVlrDistance = valor;
    } 

    public EntMaladie getEntMaladie() {
        return this.entMaladie;
    } 

    public void setEntMaladie(EntMaladie valor) {
        this.entMaladie = valor;
    } 


}