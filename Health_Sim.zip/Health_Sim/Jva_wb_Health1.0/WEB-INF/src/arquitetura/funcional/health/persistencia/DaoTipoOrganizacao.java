package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoTipoOrganizacaoBase;

public class DaoTipoOrganizacao extends DaoTipoOrganizacaoBase
{
	public DaoTipoOrganizacao() throws SerproException
	{
		super();
	}
}
