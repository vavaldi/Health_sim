package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import arquitetura.funcional.health.entidades.EntEtatSante;
import java.util.List;
import javax.persistence.Id;
import arquitetura.funcional.health.entidades.EntDeplacement;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import arquitetura.funcional.health.entidades.EntCoordonees;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntScenario;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import arquitetura.funcional.health.entidades.EntContamination;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntNoeudBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "NOD_IDT_CHAVE", unique = true, nullable = false)
    private Long nodIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="SCE_IDT_CHAVE") 
    private EntScenario entScenario;

    @Column(name = "NOD_DSC_TITRE", nullable = false, length = 45)
    private String nodDscTitre;

    @OneToMany(mappedBy="entNoeud1",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntContamination> lstContamination1;

    @OneToMany(mappedBy="entNoeud2",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntContamination> lstContamination2;

    @OneToMany(mappedBy="entNoeud",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntCoordonees> lstCoordonees;

    @OneToMany(mappedBy="entNoeud1",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntDeplacement> lstDeplacement1;

    @OneToMany(mappedBy="entNoeud2",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntDeplacement> lstDeplacement2;

    @OneToMany(mappedBy="entNoeud",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntEtatSante> lstEtatSante;

    public Long getNodIdtChave() {
        return this.nodIdtChave;
    } 

    public void setNodIdtChave(Long valor) {
        this.nodIdtChave = valor;
    } 

    public EntScenario getEntScenario() {
        return this.entScenario;
    } 

    public void setEntScenario(EntScenario valor) {
        this.entScenario = valor;
    } 

    public String getNodDscTitre() {
        return this.nodDscTitre;
    } 

    public void setNodDscTitre(String valor) {
        this.nodDscTitre = valor;
    } 

    public List<EntContamination> getLstContamination1() {
        return this.lstContamination1;
    } 

    public void setLstContamination1(List<EntContamination> valor) {
        this.lstContamination1 = valor;
    } 

    public List<EntContamination> getLstContamination2() {
        return this.lstContamination2;
    } 

    public void setLstContamination2(List<EntContamination> valor) {
        this.lstContamination2 = valor;
    } 

    public List<EntCoordonees> getLstCoordonees() {
        return this.lstCoordonees;
    } 

    public void setLstCoordonees(List<EntCoordonees> valor) {
        this.lstCoordonees = valor;
    } 

    public List<EntDeplacement> getLstDeplacement1() {
        return this.lstDeplacement1;
    } 

    public void setLstDeplacement1(List<EntDeplacement> valor) {
        this.lstDeplacement1 = valor;
    } 

    public List<EntDeplacement> getLstDeplacement2() {
        return this.lstDeplacement2;
    } 

    public void setLstDeplacement2(List<EntDeplacement> valor) {
        this.lstDeplacement2 = valor;
    } 

    public List<EntEtatSante> getLstEtatSante() {
        return this.lstEtatSante;
    } 

    public void setLstEtatSante(List<EntEtatSante> valor) {
        this.lstEtatSante = valor;
    } 


}