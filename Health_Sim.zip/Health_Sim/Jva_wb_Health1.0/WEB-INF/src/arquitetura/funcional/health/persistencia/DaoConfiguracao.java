package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoConfiguracaoBase;

public class DaoConfiguracao extends DaoConfiguracaoBase
{
	public DaoConfiguracao() throws SerproException
	{
		super();
	}
}
