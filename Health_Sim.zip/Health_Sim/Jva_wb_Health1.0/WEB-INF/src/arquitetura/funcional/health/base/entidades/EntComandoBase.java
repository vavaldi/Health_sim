package arquitetura.funcional.health.base.entidades;

import arquitetura.funcional.health.entidades.EntComando;
import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import java.util.List;
import javax.persistence.Id;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntSistema;
import arquitetura.funcional.health.entidades.EntComandoPerfil;
import arquitetura.funcional.health.entidades.EntComandoRegra;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntComandoBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "CMD_IDT_CHAVE", unique = true, nullable = false)
    private Long cmdIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="SIS_IDT_CHAVE") 
    private EntSistema entSistema;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="CMD_IDT_CHAVE_PAI") 
    private EntComando entComandoPai;

    @Column(name = "CMD_DSC_LABEL", nullable = false, length = 100)
    private String cmdDscLabel;

    @Column(name = "CMD_DSC_ACAO", nullable = false, length = 500)
    private String cmdDscAcao;

    @Column(name = "CMD_DAT_ATIVACAO", nullable = true)
    private Date cmdDatAtivacao;

    @Column(name = "CMD_DAT_DESATIVACAO", nullable = true)
    private Date cmdDatDesativacao;

    @Column(name = "CMD_FLG_MENU", nullable = false)
    private Integer cmdFlgMenu;

    @Column(name = "CMD_DSC_ORDEM", nullable = true, length = 8)
    private String cmdDscOrdem;

    @OneToMany(mappedBy="entComando",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntComandoRegra> lstComandoRegra;

    @OneToMany(mappedBy="entComandoPai",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntComando> lstComandoPai;

    @OneToMany(mappedBy="entComando",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntComandoPerfil> lstComandoPerfil;

    public Long getCmdIdtChave() {
        return this.cmdIdtChave;
    } 

    public void setCmdIdtChave(Long valor) {
        this.cmdIdtChave = valor;
    } 

    public EntSistema getEntSistema() {
        return this.entSistema;
    } 

    public void setEntSistema(EntSistema valor) {
        this.entSistema = valor;
    } 

    public EntComando getEntComandoPai() {
        return this.entComandoPai;
    } 

    public void setEntComandoPai(EntComando valor) {
        this.entComandoPai = valor;
    } 

    public String getCmdDscLabel() {
        return this.cmdDscLabel;
    } 

    public void setCmdDscLabel(String valor) {
        this.cmdDscLabel = valor;
    } 

    public String getCmdDscAcao() {
        return this.cmdDscAcao;
    } 

    public void setCmdDscAcao(String valor) {
        this.cmdDscAcao = valor;
    } 

    public Date getCmdDatAtivacao() {
        return this.cmdDatAtivacao;
    } 

    public void setCmdDatAtivacao(Date valor) {
        this.cmdDatAtivacao = valor;
    } 

    public Date getCmdDatDesativacao() {
        return this.cmdDatDesativacao;
    } 

    public void setCmdDatDesativacao(Date valor) {
        this.cmdDatDesativacao = valor;
    } 

    public Integer getCmdFlgMenu() {
        return this.cmdFlgMenu;
    } 

    public void setCmdFlgMenu(Integer valor) {
        this.cmdFlgMenu = valor;
    } 

    public String getCmdDscOrdem() {
        return this.cmdDscOrdem;
    } 

    public void setCmdDscOrdem(String valor) {
        this.cmdDscOrdem = valor;
    } 

    public List<EntComandoRegra> getLstComandoRegra() {
        return this.lstComandoRegra;
    } 

    public void setLstComandoRegra(List<EntComandoRegra> valor) {
        this.lstComandoRegra = valor;
    } 

    public List<EntComando> getLstComandoPai() {
        return this.lstComandoPai;
    } 

    public void setLstComandoPai(List<EntComando> valor) {
        this.lstComandoPai = valor;
    } 

    public List<EntComandoPerfil> getLstComandoPerfil() {
        return this.lstComandoPerfil;
    } 

    public void setLstComandoPerfil(List<EntComandoPerfil> valor) {
        this.lstComandoPerfil = valor;
    } 


}