package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActPerfilUsuarioBase;

public class ActPerfilUsuario extends ActPerfilUsuarioBase
{

}


