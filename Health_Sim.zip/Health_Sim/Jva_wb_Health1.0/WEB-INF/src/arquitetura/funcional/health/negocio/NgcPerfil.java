package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcPerfilBase;
//import arquitetura.funcional.health.regra.RngPerfil;

public class NgcPerfil extends NgcPerfilBase
{

}
