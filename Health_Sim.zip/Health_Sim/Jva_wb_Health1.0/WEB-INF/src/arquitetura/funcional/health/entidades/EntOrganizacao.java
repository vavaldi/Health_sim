package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntOrganizacaoBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "org_organizacao")

public class EntOrganizacao extends EntOrganizacaoBase
{

}
