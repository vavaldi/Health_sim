package arquitetura.funcional.health.base.entidades;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntTipoOrganizacaoBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "TOR_IDT_CHAVE", unique = true, nullable = false)
    private Long torIdtChave;

    @Column(name = "TOR_DSC_NOME", nullable = false, length = 100)
    private String torDscNome;

    @Column(name = "TOR_DSC_DESCRICAO", nullable = true, length = 254)
    private String torDscDescricao;

    @Column(name = "TOR_FLG_ATIVO", nullable = false)
    private Integer torFlgAtivo;

    @OneToMany(mappedBy="entTipoOrganizacao",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntOrganizacao> lstOrganizacao;

    public Long getTorIdtChave() {
        return this.torIdtChave;
    } 

    public void setTorIdtChave(Long valor) {
        this.torIdtChave = valor;
    } 

    public String getTorDscNome() {
        return this.torDscNome;
    } 

    public void setTorDscNome(String valor) {
        this.torDscNome = valor;
    } 

    public String getTorDscDescricao() {
        return this.torDscDescricao;
    } 

    public void setTorDscDescricao(String valor) {
        this.torDscDescricao = valor;
    } 

    public Integer getTorFlgAtivo() {
        return this.torFlgAtivo;
    } 

    public void setTorFlgAtivo(Integer valor) {
        this.torFlgAtivo = valor;
    } 

    public List<EntOrganizacao> getLstOrganizacao() {
        return this.lstOrganizacao;
    } 

    public void setLstOrganizacao(List<EntOrganizacao> valor) {
        this.lstOrganizacao = valor;
    } 


}