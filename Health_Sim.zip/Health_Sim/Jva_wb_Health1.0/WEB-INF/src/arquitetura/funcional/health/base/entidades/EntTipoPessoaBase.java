package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import arquitetura.funcional.health.entidades.EntPessoa;
import javax.persistence.Column;
import javax.persistence.Table;
import java.util.List;
import javax.persistence.Id;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntTipoPessoaBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "TPP_IDT_CHAVE", unique = true, nullable = false)
    private Long tppIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="ORG_IDT_CHAVE") 
    private EntOrganizacao entOrganizacao;

    @Column(name = "TPP_DSC_NOME", nullable = false, length = 100)
    private String tppDscNome;

    @Column(name = "TPP_DSC_DESCRICAO", nullable = true, length = 2147483647)
    private String tppDscDescricao;

    @Column(name = "TPP_FLG_ATIVO", nullable = false)
    private Integer tppFlgAtivo;

    @OneToMany(mappedBy="entTipoPessoa",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntPessoa> lstPessoa;

    public Long getTppIdtChave() {
        return this.tppIdtChave;
    } 

    public void setTppIdtChave(Long valor) {
        this.tppIdtChave = valor;
    } 

    public EntOrganizacao getEntOrganizacao() {
        return this.entOrganizacao;
    } 

    public void setEntOrganizacao(EntOrganizacao valor) {
        this.entOrganizacao = valor;
    } 

    public String getTppDscNome() {
        return this.tppDscNome;
    } 

    public void setTppDscNome(String valor) {
        this.tppDscNome = valor;
    } 

    public String getTppDscDescricao() {
        return this.tppDscDescricao;
    } 

    public void setTppDscDescricao(String valor) {
        this.tppDscDescricao = valor;
    } 

    public Integer getTppFlgAtivo() {
        return this.tppFlgAtivo;
    } 

    public void setTppFlgAtivo(Integer valor) {
        this.tppFlgAtivo = valor;
    } 

    public List<EntPessoa> getLstPessoa() {
        return this.lstPessoa;
    } 

    public void setLstPessoa(List<EntPessoa> valor) {
        this.lstPessoa = valor;
    } 


}