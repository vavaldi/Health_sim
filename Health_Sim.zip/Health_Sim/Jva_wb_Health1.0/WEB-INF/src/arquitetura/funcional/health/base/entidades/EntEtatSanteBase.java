package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import arquitetura.funcional.health.entidades.EntStatutSante;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import arquitetura.funcional.health.entidades.EntNoeud;
import java.util.Date;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntEtatSanteBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "EST_IDT_CHAVE", unique = true, nullable = false)
    private Long estIdtChave;

    @Column(name = "EST_NUM_TEMPS", nullable = false)
    private Integer estNumTemps;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="NOD_IDT_CHAVE") 
    private EntNoeud entNoeud;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="SST_IDT_CHAVE") 
    private EntStatutSante entStatutSante;

    public Long getEstIdtChave() {
        return this.estIdtChave;
    } 

    public void setEstIdtChave(Long valor) {
        this.estIdtChave = valor;
    } 

    public Integer getEstNumTemps() {
        return this.estNumTemps;
    } 

    public void setEstNumTemps(Integer valor) {
        this.estNumTemps = valor;
    } 

    public EntNoeud getEntNoeud() {
        return this.entNoeud;
    } 

    public void setEntNoeud(EntNoeud valor) {
        this.entNoeud = valor;
    } 

    public EntStatutSante getEntStatutSante() {
        return this.entStatutSante;
    } 

    public void setEntStatutSante(EntStatutSante valor) {
        this.entStatutSante = valor;
    } 


}