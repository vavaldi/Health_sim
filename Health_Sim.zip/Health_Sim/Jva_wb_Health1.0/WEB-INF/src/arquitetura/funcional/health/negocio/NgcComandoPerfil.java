package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcComandoPerfilBase;
//import arquitetura.funcional.health.regra.RngComandoPerfil;

public class NgcComandoPerfil extends NgcComandoPerfilBase
{

}
