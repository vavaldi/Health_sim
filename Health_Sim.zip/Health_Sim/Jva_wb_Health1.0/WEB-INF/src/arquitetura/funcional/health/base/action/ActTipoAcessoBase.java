package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntTipoAcesso;
import arquitetura.funcional.health.negocio.NgcTipoAcesso;
import arquitetura.funcional.health.negocio.NgcSistema;
import arquitetura.funcional.health.negocio.NgcOrganizacao;
import arquitetura.funcional.health.entidades.EntTipoAcesso;
import arquitetura.funcional.health.negocio.NgcPerfil;
import arquitetura.funcional.health.entidades.EntSistema;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntPerfil;


public class ActTipoAcessoBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoAcesso ent = new EntTipoAcesso();
		NgcTipoAcesso ngc = new NgcTipoAcesso();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);




			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResTpa", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoAcesso ent = new EntTipoAcesso();
		NgcTipoAcesso ngc = new NgcTipoAcesso();

		try
		{
			ent = (EntTipoAcesso) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("tpaIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			



//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas
            List<EntPerfil> lstPer = ent.getLstPerfil();
            lstPer = ordenarLista(lstPer, getResources(req).getMessage("perfil.ordenacao")); 
            req.setAttribute("lstResPer", lstPer);


			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoAcesso ent = new EntTipoAcesso();
		NgcTipoAcesso ngc = new NgcTipoAcesso();

		try
		{
			ent = (EntTipoAcesso) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("tpaIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						


//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas
            List<EntPerfil> lstPer = ent.getLstPerfil();
            lstPer = ordenarLista(lstPer, getResources(req).getMessage("perfil.ordenacao")); 
            req.setAttribute("lstResPer", lstPer);


			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoAcesso ent = new EntTipoAcesso();
		NgcTipoAcesso ngc = new NgcTipoAcesso();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntTipoAcesso) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("tpaIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio





            if (getResources(req).getMessage("detalhe.tipoAcesso.perfil.exibir").equals("s"))
            {
                // Salva Perfil
                List<EntPerfil> lstPrsPer = ent.getLstPerfil();
                List<EntPerfil> lstTmpPer = montarPerfil(req, form, ent, "");
                AtualizarPerfil(form, lstPrsPer, lstTmpPer);
            }


			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntTipoAcesso) ngc.consultarID(ent.getTpaIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResTpa", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoAcesso ent = new EntTipoAcesso();
		NgcTipoAcesso ngc = new NgcTipoAcesso();

		try
		{
			ent = (EntTipoAcesso) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("tpaIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoAcesso ent = new EntTipoAcesso();
		NgcTipoAcesso ngc = new NgcTipoAcesso();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);


            if (getResources(req).getMessage("detalhe.tipoAcesso.perfil.exibir").equals("s"))
            {
                // Salva Perfil
                Integer qtdePerfil = Integer.parseInt(req.getParameter("qtdePerfil"));
                if (qtdePerfil > 0)
                {
                    List<EntPerfil> lstTmpPer = montarPerfil(req, form, ent, "");
                    ent.setLstPerfil(lstTmpPer);
                }

            }

			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntTipoAcesso) ngc.consultarID(ent.getTpaIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResTpa", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntTipoAcesso ent) throws Exception
	{

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntTipoAcesso ent) throws Exception
	{
            if (getResources(req).getMessage("detalhe.tipoAcesso.perfil.exibir").equals("s"))
            {
                // Salva Perfil
                List<EntPerfil> lstPrsPer = ent.getLstPerfil();
                List<EntPerfil> lstTmpPer = montarPerfil(req, form, ent, "");
                AtualizarPerfil(form, lstPrsPer, lstTmpPer);
            }

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntTipoAcesso ent) throws Exception
	{

	}

	public void converterValores(ActionForm form)
	{




	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntTipoAcesso ent) throws Exception
	{

	
            if (getResources(req).getMessage("detalhe.tipoAcesso.perfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.orgIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstOrg"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfil() != null && ent.getLstPerfil().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfil().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfil obj = (EntPerfil) iterator.next();
                            //l.add(obj.getEntOrganizacao());
                        //}
                    //}
                //}
                carregarOrganizacao(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.tipoAcesso.perfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.sisIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstSis"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfil() != null && ent.getLstPerfil().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfil().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfil obj = (EntPerfil) iterator.next();
                            //l.add(obj.getEntSistema());
                        //}
                    //}
                //}
                carregarSistema(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.tipoAcesso.perfil.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.perfil.perIdtChaveSuperior.visual").toLowerCase().equals("l") && null == req.getAttribute("lstPer"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPerfilSuperior() != null && ent.getLstPerfilSuperior().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPerfilSuperior().iterator(); iterator.hasNext();)
                        //{
                            //EntPerfil obj = (EntPerfil) iterator.next();
                            //l.add(obj.getEntPerfil());
                        //}
                    //}
                //}
                carregarPerfil(map, form, req, res, metodo, l);
            }

	}

    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarOrganizacao(map, form, req, res, "par", null);

    }
    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcOrganizacao ngc = new NgcOrganizacao();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstOrg", ngc.consultarHabilitados(new String[][]{{"orgDscFantasia", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstOrg", ngc.consultarTodos(new String[][]{{"orgDscFantasia", "ASC"}}));
        }
    }

    public void carregarSistema(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarSistema(map, form, req, res, "par", null);

    }
    public void carregarSistema(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcSistema ngc = new NgcSistema();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstSis", ngc.consultarHabilitados(new String[][]{{"sisDscTitulo", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstSis", ngc.consultarTodos(new String[][]{{"sisDscTitulo", "ASC"}}));
        }
    }

    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarPerfil(map, form, req, res, "par", null);

    }
    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcPerfil ngc = new NgcPerfil();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstPer", ngc.consultarHabilitados(new String[][]{{"perDscPerfil", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstPer", ngc.consultarTodos(new String[][]{{"perDscPerfil", "ASC"}}));
        }
    }









            public List<EntPerfil> montarPerfil(HttpServletRequest req, ActionForm form, EntTipoAcesso ent, String sufixo) throws Exception
            {
                List<EntPerfil> lst = new ArrayList<EntPerfil>(); 

                // Campos do detalhe
                String[] perIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perIdtChave"); 
                String[] orgIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "orgIdtChave"); 
                String[] orgIdtChaveDsc = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "orgIdtChaveDsc"); 
                String[] sisIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "sisIdtChave"); 
                String[] sisIdtChaveDsc = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "sisIdtChaveDsc"); 
                String[] perDscPerfil = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perDscPerfil"); 
                String[] perFlgPublico = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perFlgPublico"); 
                String[] tpaIdtChave = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "tpaIdtChave"); 
                String[] perIdtChaveSuperior = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perIdtChaveSuperior"); 
                String[] perIdtChaveSuperiorDsc = (String[])((DynaValidatorForm)form).get("per_" + sufixo.toUpperCase() + "perIdtChaveSuperiorDsc"); 

                // Percorre cada linha 
                for (int i = 0; i < perIdtChave.length; i++) 
                {
                    EntPerfil entTmp = new EntPerfil();  // Percorre o detalhe
                    // Copia campos - Perfil
                if (perIdtChave[i] != null && !perIdtChave[i].equals(""))
                    entTmp.setPerIdtChave(Long.parseLong(perIdtChave[i]));

                if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
                {
                    EntOrganizacao entTmpOrg = new EntOrganizacao();
                    entTmpOrg.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.perfil.orgIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpOrg, orgIdtChaveDsc[i], "campo.perfil.orgIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntOrganizacao(entTmpOrg);
                }

            if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
            {
                EntOrganizacao obj = new EntOrganizacao();
                obj.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                entTmp.setEntOrganizacao(obj);
            }
                if (sisIdtChave != null && sisIdtChave.length > 0 && sisIdtChave[i] != null && !sisIdtChave[i].equals(""))
                {
                    EntSistema entTmpSis = new EntSistema();
                    entTmpSis.setSisIdtChave(Long.parseLong(sisIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.perfil.sisIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpSis, sisIdtChaveDsc[i], "campo.perfil.sisIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntSistema(entTmpSis);
                }

            if (sisIdtChave != null && sisIdtChave.length > 0 && sisIdtChave[i] != null && !sisIdtChave[i].equals(""))
            {
                EntSistema obj = new EntSistema();
                obj.setSisIdtChave(Long.parseLong(sisIdtChave[i]));
                entTmp.setEntSistema(obj);
            }
            if (perDscPerfil != null && perDscPerfil.length > 0 && perDscPerfil[i] != null && !perDscPerfil[i].equals(""))
                entTmp.setPerDscPerfil((perDscPerfil[i]));

            if (perFlgPublico != null && perFlgPublico.length > 0 && perFlgPublico[i] != null && !perFlgPublico[i].equals(""))
                entTmp.setPerFlgPublico(Integer.parseInt(perFlgPublico[i]));

            if (tpaIdtChave != null && tpaIdtChave.length > 0 && tpaIdtChave[i] != null && !tpaIdtChave[i].equals(""))
            {
                EntTipoAcesso obj = new EntTipoAcesso();
                obj.setTpaIdtChave(Long.parseLong(tpaIdtChave[i]));
                entTmp.setEntTipoAcesso(obj);
            }
            else if(("tpaIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("tpaIdtChave"))
            {
                entTmp.setEntTipoAcesso(ent);
            }
                if (perIdtChaveSuperior != null && perIdtChaveSuperior.length > 0 && perIdtChaveSuperior[i] != null && !perIdtChaveSuperior[i].equals(""))
                {
                    EntPerfil entTmpPer = new EntPerfil();
                    entTmpPer.setPerIdtChave(Long.parseLong(perIdtChaveSuperior[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.perfilSuperior.perIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpPer, perIdtChaveSuperiorDsc[i], "campo.perfilSuperior.perIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntPerfilSuperior(entTmpPer);
                }

            if (perIdtChaveSuperior != null && perIdtChaveSuperior.length > 0 && perIdtChaveSuperior[i] != null && !perIdtChaveSuperior[i].equals(""))
            {
                EntPerfil obj = new EntPerfil();
                obj.setPerIdtChave(Long.parseLong(perIdtChaveSuperior[i]));
                entTmp.setEntPerfilSuperior(obj);
            }

                    lst.add(entTmp);
                }
                return lst; 
            }



            public void AtualizarPerfil(ActionForm form, List<EntPerfil> lstPrs, List<EntPerfil> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntPerfil entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntPerfil entTmp = lstTmp.get(j);
                    if (entPrs.getPerIdtChave().equals(entTmp.getPerIdtChave())) // Altera��o
                    {
                    entPrs.setEntOrganizacao(entTmp.getEntOrganizacao());
                    entPrs.setEntSistema(entTmp.getEntSistema());
                    entPrs.setPerDscPerfil(entTmp.getPerDscPerfil());
                    entPrs.setPerFlgPublico(entTmp.getPerFlgPublico());
                    entPrs.setEntTipoAcesso(entTmp.getEntTipoAcesso());
                    entPrs.setEntPerfilSuperior(entTmp.getEntPerfilSuperior());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }


    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.tipoAcesso." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.tipoAcesso." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
