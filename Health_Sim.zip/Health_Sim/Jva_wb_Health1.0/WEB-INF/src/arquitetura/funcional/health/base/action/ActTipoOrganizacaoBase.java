package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntTipoOrganizacao;
import arquitetura.funcional.health.negocio.NgcTipoOrganizacao;
import arquitetura.funcional.health.negocio.NgcOrganizacao;
import arquitetura.funcional.health.entidades.EntTipoOrganizacao;
import arquitetura.funcional.health.entidades.EntOrganizacao;


public class ActTipoOrganizacaoBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoOrganizacao ent = new EntTipoOrganizacao();
		NgcTipoOrganizacao ngc = new NgcTipoOrganizacao();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);




			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResTor", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoOrganizacao ent = new EntTipoOrganizacao();
		NgcTipoOrganizacao ngc = new NgcTipoOrganizacao();

		try
		{
			ent = (EntTipoOrganizacao) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("torIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			



//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas
            List<EntOrganizacao> lstOrg = ent.getLstOrganizacao();
            lstOrg = ordenarLista(lstOrg, getResources(req).getMessage("organizacao.ordenacao")); 
            req.setAttribute("lstResOrg", lstOrg);


			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoOrganizacao ent = new EntTipoOrganizacao();
		NgcTipoOrganizacao ngc = new NgcTipoOrganizacao();

		try
		{
			ent = (EntTipoOrganizacao) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("torIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						


//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas
            List<EntOrganizacao> lstOrg = ent.getLstOrganizacao();
            lstOrg = ordenarLista(lstOrg, getResources(req).getMessage("organizacao.ordenacao")); 
            req.setAttribute("lstResOrg", lstOrg);


			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoOrganizacao ent = new EntTipoOrganizacao();
		NgcTipoOrganizacao ngc = new NgcTipoOrganizacao();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntTipoOrganizacao) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("torIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio





            if (getResources(req).getMessage("detalhe.tipoOrganizacao.organizacao.exibir").equals("s"))
            {
                // Salva Organizacao
                List<EntOrganizacao> lstPrsOrg = ent.getLstOrganizacao();
                List<EntOrganizacao> lstTmpOrg = montarOrganizacao(req, form, ent, "");
                AtualizarOrganizacao(form, lstPrsOrg, lstTmpOrg);
            }


			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntTipoOrganizacao) ngc.consultarID(ent.getTorIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResTor", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoOrganizacao ent = new EntTipoOrganizacao();
		NgcTipoOrganizacao ngc = new NgcTipoOrganizacao();

		try
		{
			ent = (EntTipoOrganizacao) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("torIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntTipoOrganizacao ent = new EntTipoOrganizacao();
		NgcTipoOrganizacao ngc = new NgcTipoOrganizacao();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);


            if (getResources(req).getMessage("detalhe.tipoOrganizacao.organizacao.exibir").equals("s"))
            {
                // Salva Organizacao
                Integer qtdeOrganizacao = Integer.parseInt(req.getParameter("qtdeOrganizacao"));
                if (qtdeOrganizacao > 0)
                {
                    List<EntOrganizacao> lstTmpOrg = montarOrganizacao(req, form, ent, "");
                    ent.setLstOrganizacao(lstTmpOrg);
                }

            }

			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntTipoOrganizacao) ngc.consultarID(ent.getTorIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResTor", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntTipoOrganizacao ent) throws Exception
	{

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntTipoOrganizacao ent) throws Exception
	{
            if (getResources(req).getMessage("detalhe.tipoOrganizacao.organizacao.exibir").equals("s"))
            {
                // Salva Organizacao
                List<EntOrganizacao> lstPrsOrg = ent.getLstOrganizacao();
                List<EntOrganizacao> lstTmpOrg = montarOrganizacao(req, form, ent, "");
                AtualizarOrganizacao(form, lstPrsOrg, lstTmpOrg);
            }

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntTipoOrganizacao ent) throws Exception
	{

	}

	public void converterValores(ActionForm form)
	{

        // TorFlgAtivo
        if ((((DynaValidatorForm) form).get("torFlgAtivo")) != null && !(((DynaValidatorForm) form).get("torFlgAtivo")).equals(""))
        {
            Integer torFlgAtivo = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("torFlgAtivo"));
            ((DynaValidatorForm) form).set("torFlgAtivo", torFlgAtivo.toString());
        }



	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntTipoOrganizacao ent) throws Exception
	{

	
            if (getResources(req).getMessage("detalhe.tipoOrganizacao.organizacao.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.organizacao.orgIdtChavePai.visual").toLowerCase().equals("l") && null == req.getAttribute("lstOrg"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstOrganizacaoPai() != null && ent.getLstOrganizacaoPai().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstOrganizacaoPai().iterator(); iterator.hasNext();)
                        //{
                            //EntOrganizacao obj = (EntOrganizacao) iterator.next();
                            //l.add(obj.getEntOrganizacao());
                        //}
                    //}
                //}
                carregarOrganizacao(map, form, req, res, metodo, l);
            }

	}

    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarOrganizacao(map, form, req, res, "par", null);

    }
    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcOrganizacao ngc = new NgcOrganizacao();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstOrg", ngc.consultarHabilitados(new String[][]{{"orgDscFantasia", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstOrg", ngc.consultarTodos(new String[][]{{"orgDscFantasia", "ASC"}}));
        }
    }









            public List<EntOrganizacao> montarOrganizacao(HttpServletRequest req, ActionForm form, EntTipoOrganizacao ent, String sufixo) throws Exception
            {
                List<EntOrganizacao> lst = new ArrayList<EntOrganizacao>(); 

                // Campos do detalhe
                String[] orgIdtChave = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgIdtChave"); 
                String[] orgDscFantasia = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgDscFantasia"); 
                String[] orgDscRazaoSocial = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgDscRazaoSocial"); 
                String[] orgDscCnpj = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgDscCnpj"); 
                String[] orgDscSite = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgDscSite"); 
                String[] orgDscEmail = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgDscEmail"); 
                String[] torIdtChave = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "torIdtChave"); 
                String[] orgIdtChavePai = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgIdtChavePai"); 
                String[] orgIdtChavePaiDsc = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgIdtChavePaiDsc"); 
                String[] orgFlgAtivo = (String[])((DynaValidatorForm)form).get("org_" + sufixo.toUpperCase() + "orgFlgAtivo"); 

                // Percorre cada linha 
                for (int i = 0; i < orgIdtChave.length; i++) 
                {
                    EntOrganizacao entTmp = new EntOrganizacao();  // Percorre o detalhe
                    // Copia campos - Organizacao
                if (orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
                    entTmp.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));

            if (orgDscFantasia != null && orgDscFantasia.length > 0 && orgDscFantasia[i] != null && !orgDscFantasia[i].equals(""))
                entTmp.setOrgDscFantasia((orgDscFantasia[i]));

            if (orgDscRazaoSocial != null && orgDscRazaoSocial.length > 0 && orgDscRazaoSocial[i] != null && !orgDscRazaoSocial[i].equals(""))
                entTmp.setOrgDscRazaoSocial((orgDscRazaoSocial[i]));

            if (orgDscCnpj != null && orgDscCnpj.length > 0 && orgDscCnpj[i] != null && !orgDscCnpj[i].equals(""))
                entTmp.setOrgDscCnpj((orgDscCnpj[i]));

            if (orgDscSite != null && orgDscSite.length > 0 && orgDscSite[i] != null && !orgDscSite[i].equals(""))
                entTmp.setOrgDscSite((orgDscSite[i]));

            if (orgDscEmail != null && orgDscEmail.length > 0 && orgDscEmail[i] != null && !orgDscEmail[i].equals(""))
                entTmp.setOrgDscEmail((orgDscEmail[i]));

            if (torIdtChave != null && torIdtChave.length > 0 && torIdtChave[i] != null && !torIdtChave[i].equals(""))
            {
                EntTipoOrganizacao obj = new EntTipoOrganizacao();
                obj.setTorIdtChave(Long.parseLong(torIdtChave[i]));
                entTmp.setEntTipoOrganizacao(obj);
            }
            else if(("torIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("torIdtChave"))
            {
                entTmp.setEntTipoOrganizacao(ent);
            }
                if (orgIdtChavePai != null && orgIdtChavePai.length > 0 && orgIdtChavePai[i] != null && !orgIdtChavePai[i].equals(""))
                {
                    EntOrganizacao entTmpOrg = new EntOrganizacao();
                    entTmpOrg.setOrgIdtChave(Long.parseLong(orgIdtChavePai[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.organizacaoPai.orgIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpOrg, orgIdtChavePaiDsc[i], "campo.organizacaoPai.orgIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntOrganizacaoPai(entTmpOrg);
                }

            if (orgIdtChavePai != null && orgIdtChavePai.length > 0 && orgIdtChavePai[i] != null && !orgIdtChavePai[i].equals(""))
            {
                EntOrganizacao obj = new EntOrganizacao();
                obj.setOrgIdtChave(Long.parseLong(orgIdtChavePai[i]));
                entTmp.setEntOrganizacaoPai(obj);
            }
            if (orgFlgAtivo != null && orgFlgAtivo.length > 0 && orgFlgAtivo[i] != null && !orgFlgAtivo[i].equals(""))
                entTmp.setOrgFlgAtivo(Integer.parseInt(orgFlgAtivo[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }



            public void AtualizarOrganizacao(ActionForm form, List<EntOrganizacao> lstPrs, List<EntOrganizacao> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntOrganizacao entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntOrganizacao entTmp = lstTmp.get(j);
                    if (entPrs.getOrgIdtChave().equals(entTmp.getOrgIdtChave())) // Altera��o
                    {
                    entPrs.setOrgDscFantasia(entTmp.getOrgDscFantasia());
                    entPrs.setOrgDscRazaoSocial(entTmp.getOrgDscRazaoSocial());
                    entPrs.setOrgDscCnpj(entTmp.getOrgDscCnpj());
                    entPrs.setOrgDscSite(entTmp.getOrgDscSite());
                    entPrs.setOrgDscEmail(entTmp.getOrgDscEmail());
                    entPrs.setEntTipoOrganizacao(entTmp.getEntTipoOrganizacao());
                    entPrs.setEntOrganizacaoPai(entTmp.getEntOrganizacaoPai());
                    entPrs.setOrgFlgAtivo(entTmp.getOrgFlgAtivo());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }


    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.tipoOrganizacao." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.tipoOrganizacao." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
