package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoRegraNegocioBase;

public class DaoRegraNegocio extends DaoRegraNegocioBase
{
	public DaoRegraNegocio() throws SerproException
	{
		super();
	}
}
