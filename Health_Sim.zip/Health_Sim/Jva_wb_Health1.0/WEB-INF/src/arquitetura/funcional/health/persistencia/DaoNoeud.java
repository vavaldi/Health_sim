package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoNoeudBase;

public class DaoNoeud extends DaoNoeudBase
{
	public DaoNoeud() throws SerproException
	{
		super();
	}
}
