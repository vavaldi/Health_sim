package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntSistema;
import arquitetura.funcional.health.entidades.EntUsuario;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntSistemaUsuarioBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "SUS_IDT_CHAVE", unique = true, nullable = false)
    private Long susIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="SIS_IDT_CHAVE") 
    private EntSistema entSistema;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="USU_IDT_CHAVE") 
    private EntUsuario entUsuario;

    @Column(name = "SUS_NUM_TENTATIVAS", nullable = true)
    private Integer susNumTentativas;

    public Long getSusIdtChave() {
        return this.susIdtChave;
    } 

    public void setSusIdtChave(Long valor) {
        this.susIdtChave = valor;
    } 

    public EntSistema getEntSistema() {
        return this.entSistema;
    } 

    public void setEntSistema(EntSistema valor) {
        this.entSistema = valor;
    } 

    public EntUsuario getEntUsuario() {
        return this.entUsuario;
    } 

    public void setEntUsuario(EntUsuario valor) {
        this.entUsuario = valor;
    } 

    public Integer getSusNumTentativas() {
        return this.susNumTentativas;
    } 

    public void setSusNumTentativas(Integer valor) {
        this.susNumTentativas = valor;
    } 


}