package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntUsuarioBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "usu_usuario")

public class EntUsuario extends EntUsuarioBase
{

}
