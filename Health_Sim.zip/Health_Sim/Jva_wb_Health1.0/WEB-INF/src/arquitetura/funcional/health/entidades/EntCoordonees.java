package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntCoordoneesBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "coo_coordonees")

public class EntCoordonees extends EntCoordoneesBase
{

}
