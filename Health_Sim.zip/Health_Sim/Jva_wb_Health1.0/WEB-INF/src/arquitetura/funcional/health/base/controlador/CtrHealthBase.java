package arquitetura.funcional.health.base.controlador;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionServlet;

import arquitetura.funcional.base.excecao.SerproException;

public class CtrHealthBase extends ActionServlet
{
	private static final long serialVersionUID = 1L;

	@Override
	protected void process(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServletException
	{


	    boolean retorno = true; 

	    // Seguran�a
//	    AcessoControlador acesso = new AcessoControlador(); // Otimizar o processo de instancia��o
//	    retorno = acesso.processar(request, response);
	    
	    // ... outros pacotes ...

		// Aciona o construtor da classe pai 
		if (retorno)
			super.process(request,response);
		else
		{			
			throw new ServletException("texto.erro.acesso");
		}
			 
						
		// Colocar o c�digo do Token Synchronizer
		// if (SynchronizerToken.doIt(request, response))
		//super.process(request, response);

	}

}
