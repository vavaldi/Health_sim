package arquitetura.funcional.health.negocio;

import java.util.ArrayList;
import java.util.List;

import arquitetura.funcional.acesso.bean.BtpLogin;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.Constantes;
import arquitetura.funcional.health.base.negocio.NgcUsuarioBase;
//import arquitetura.funcional.health.regra.RngUsuario;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntPessoa;
import arquitetura.funcional.health.entidades.EntUsuario;
import arquitetura.funcional.health.negocio.NgcComando;

public class NgcUsuario extends NgcUsuarioBase
{
	public  Object autenticar(Object o) throws SerproException
	{
		// Autentica��o
		List lUsu = new ArrayList();
		if (valida((BtpLogin) o))
		{
			lUsu = buscarUsuario((BtpLogin) o);
		}
		return lUsu;
	}

	public Object registraPermissoes(Object o) throws SerproException
	{
		// Busca as permiss�es do usu�rio autenticado
		NgcComando ngc = new NgcComando();
		try {
			List permissoes = ngc.consultarPermissao(o);
			return permissoes;
		} catch (SerproException e) {
			e.printStackTrace();
			return null;
		}

	}

	public Object registraPermissoes(EntPessoa p, EntOrganizacao o) throws SerproException
	{
		// Busca as permiss�es do usu�rio autenticado
		NgcComando ngc = new NgcComando();
		try {
			List permissoes = ngc.consultarPermissao(p, o);
			return permissoes;
		} catch (SerproException e) {
			e.printStackTrace();
			return null;
		}

	}

	@SuppressWarnings({"unchecked", "static-access"})
	public boolean valida(BtpLogin login) throws SerproException
	{	
		ArrayList erros = new ArrayList(); 	  

		// Tamanho m�nimo da senha
		if (login.getSenha().length() < Constantes.SENHA_TAMANHO_MINIMO)
			erros.add("erro.senha.tamanho"); 		  

		if (login.getSenha().length() > Constantes.SENHA_TAMANHO_MAXIMO) 
			erros.add("erro.senhamuitogrande.texto");

		// Valida��o do Usu�rio
		if (erros.isEmpty())
		{
			EntUsuario entUsu = new EntUsuario();
			entUsu.setUsuDscLogin(login.getLogin().trim());
			entUsu.setUsuDscSenha(login.getSenha().trim());
			if (this.consultarQBE(entUsu).size() <= 0)
				erros.add("texto.erro.acesso.usuario");
		}
		
		//Valida��o no SenhaRede		
//		if(DebugManager.applicacaoEmModoDeTeste()==false){
//
//			Adabas DaoAda = new Adabas(Configuracao.getInstance().getLoginServidor(),Configuracao.getInstance().getLoginPerfil(),senha,login.getLogin());
//			if (! DaoAda.conectar()) 
//			{
//				erros.add("erro.sqlada");
//				erros.add(DaoAda.getMsgErro().trim().substring(0, 6));
//			}
//			DaoAda.desconectar();		
//		}
//
//		// Verifica se este CPF existe como usu�rio
//		EntUsuario entUsu = new EntUsuario();
//		entUsu.setUsuDscLogin(login.getLogin().trim());
//		if (this.consultarQBEListaVazia(entUsu).size() <= 0)
//			erros.add("texto.erro.acesso.usuario");


		if (!erros.isEmpty())
			throw new SerproException(erros); 

		return true;
	}

	@SuppressWarnings({"unchecked", "static-access"})
	public List buscarUsuario(BtpLogin login) throws SerproException
	{	
		ArrayList erros = new ArrayList(); 	  

		EntUsuario entUsu = new EntUsuario();
		entUsu.setUsuDscLogin(login.getLogin().trim());
		entUsu.setUsuDscSenha(login.getSenha().trim());
		List usuarios = this.consultarQBE(entUsu);
		
		if (usuarios.size() <= 0)
			erros.add("texto.erro.acesso.usuario");

		if (!erros.isEmpty())
			throw new SerproException(erros);

		return usuarios;
	}

}
