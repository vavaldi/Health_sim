package arquitetura.funcional.health.base.entidades;

import arquitetura.funcional.health.entidades.EntPessoa;
import javax.persistence.Column;
import javax.persistence.Table;
import java.util.List;
import javax.persistence.Id;
import javax.persistence.CascadeType;
import javax.persistence.OneToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntPerfilUsuario;
import arquitetura.funcional.health.entidades.EntSistemaUsuario;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntUsuarioBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @OneToOne (fetch = FetchType.EAGER)
    @PrimaryKeyJoinColumn
    private EntPessoa entPessoa;

    @Id 
    @Column(name = "USU_IDT_CHAVE", unique = true, nullable = false)
    private Long usuIdtChave;

    @Column(name = "USU_DSC_LOGIN", nullable = false, length = 50)
    private String usuDscLogin;

    @Column(name = "USU_DSC_SENHA", nullable = true, length = 50)
    private String usuDscSenha;

    @Column(name = "USU_FLG_DESATIVADO", nullable = false)
    private Integer usuFlgDesativado;

    @OneToMany(mappedBy="entUsuario",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntPerfilUsuario> lstPerfilUsuario;

    @OneToMany(mappedBy="entUsuario",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntSistemaUsuario> lstSistemaUsuario;

    public EntPessoa getEntPessoa() {
        return this.entPessoa;
    } 

    public void setEntPessoa(EntPessoa valor) {
        this.entPessoa = valor;
    } 

    public Long getUsuIdtChave() {
        return this.usuIdtChave;
    } 

    public void setUsuIdtChave(Long valor) {
        this.usuIdtChave = valor;
    } 

    public String getUsuDscLogin() {
        return this.usuDscLogin;
    } 

    public void setUsuDscLogin(String valor) {
        this.usuDscLogin = valor;
    } 

    public String getUsuDscSenha() {
        return this.usuDscSenha;
    } 

    public void setUsuDscSenha(String valor) {
        this.usuDscSenha = valor;
    } 

    public Integer getUsuFlgDesativado() {
        return this.usuFlgDesativado;
    } 

    public void setUsuFlgDesativado(Integer valor) {
        this.usuFlgDesativado = valor;
    } 

    public List<EntPerfilUsuario> getLstPerfilUsuario() {
        return this.lstPerfilUsuario;
    } 

    public void setLstPerfilUsuario(List<EntPerfilUsuario> valor) {
        this.lstPerfilUsuario = valor;
    } 

    public List<EntSistemaUsuario> getLstSistemaUsuario() {
        return this.lstSistemaUsuario;
    } 

    public void setLstSistemaUsuario(List<EntSistemaUsuario> valor) {
        this.lstSistemaUsuario = valor;
    } 


}