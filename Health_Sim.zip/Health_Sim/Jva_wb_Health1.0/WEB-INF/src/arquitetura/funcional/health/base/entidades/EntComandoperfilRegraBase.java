package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntComandoPerfil;
import javax.persistence.Entity;
import java.math.BigDecimal;
import arquitetura.funcional.health.entidades.EntRegraNegocio;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntComandoperfilRegraBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "CMR_IDT_CHAVE", unique = true, nullable = false)
    private Long cmrIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="CMP_IDT_CHAVE") 
    private EntComandoPerfil entComandoPerfil;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="RNG_IDT_CHAVE") 
    private EntRegraNegocio entRegraNegocio;

    @Column(name = "CMR_FLG_ATIVO", nullable = false)
    private Integer cmrFlgAtivo;

    public Long getCmrIdtChave() {
        return this.cmrIdtChave;
    } 

    public void setCmrIdtChave(Long valor) {
        this.cmrIdtChave = valor;
    } 

    public EntComandoPerfil getEntComandoPerfil() {
        return this.entComandoPerfil;
    } 

    public void setEntComandoPerfil(EntComandoPerfil valor) {
        this.entComandoPerfil = valor;
    } 

    public EntRegraNegocio getEntRegraNegocio() {
        return this.entRegraNegocio;
    } 

    public void setEntRegraNegocio(EntRegraNegocio valor) {
        this.entRegraNegocio = valor;
    } 

    public Integer getCmrFlgAtivo() {
        return this.cmrFlgAtivo;
    } 

    public void setCmrFlgAtivo(Integer valor) {
        this.cmrFlgAtivo = valor;
    } 


}