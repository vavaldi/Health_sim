package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcComandoperfilRegraBase;
//import arquitetura.funcional.health.regra.RngComandoperfilRegra;

public class NgcComandoperfilRegra extends NgcComandoperfilRegraBase
{

}
