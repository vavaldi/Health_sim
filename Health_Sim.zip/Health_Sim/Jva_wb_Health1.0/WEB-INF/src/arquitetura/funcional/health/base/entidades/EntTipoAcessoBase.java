package arquitetura.funcional.health.base.entidades;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntPerfil;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntTipoAcessoBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "TPA_IDT_CHAVE", unique = true, nullable = false)
    private Long tpaIdtChave;

    @Column(name = "TPA_DSC_TIPO", nullable = false, length = 100)
    private String tpaDscTipo;

    @OneToMany(mappedBy="entTipoAcesso",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntPerfil> lstPerfil;

    public Long getTpaIdtChave() {
        return this.tpaIdtChave;
    } 

    public void setTpaIdtChave(Long valor) {
        this.tpaIdtChave = valor;
    } 

    public String getTpaDscTipo() {
        return this.tpaDscTipo;
    } 

    public void setTpaDscTipo(String valor) {
        this.tpaDscTipo = valor;
    } 

    public List<EntPerfil> getLstPerfil() {
        return this.lstPerfil;
    } 

    public void setLstPerfil(List<EntPerfil> valor) {
        this.lstPerfil = valor;
    } 


}