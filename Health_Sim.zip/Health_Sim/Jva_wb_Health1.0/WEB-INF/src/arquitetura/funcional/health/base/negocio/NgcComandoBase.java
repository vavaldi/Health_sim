package arquitetura.funcional.health.base.negocio;

import java.io.Serializable;
import java.util.List;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.negocio.INegocio;
import arquitetura.funcional.base.negocio.NgcGeral;
//import arquitetura.funcional.health.regra.RngComando;
import arquitetura.funcional.health.entidades.EntComando;
import arquitetura.funcional.health.persistencia.DaoComando;

public class NgcComandoBase extends NgcGeral implements INegocio
{

	public Object alterar(Object o) throws SerproException
	{
		if (validaAlterar(o))
		{
			DaoComando dao = new DaoComando(); 
			return dao.alterar(o); 
		}
		return o;
	}

	public Object consultarID(Serializable id) throws SerproException
	{
		DaoComando dao = new DaoComando();		
		return dao.consultarID(id);
	}

	public List consultarQBE(Object o) throws SerproException
	{
		EntComando ent = (EntComando) o;
		DaoComando dao = new DaoComando();
		//return validaListaVazia(dao.consultarQBE(ent));
		return dao.consultarQBE(ent);
	}

	public List consultarQBE(Object o, Object g) throws SerproException
	{
		EntComando ent = (EntComando) o;
		DaoComando dao = new DaoComando();
		//return validaListaVazia(dao.consultarQBE(ent, g));
		return dao.consultarQBE(ent, g);
	}

	public List consultarTodos() throws SerproException
	{ 
		DaoComando dao = new DaoComando(); 
		return  dao.consultarTodos(); 
	}

	public List consultarTodos(String[][] orderBy) throws SerproException
	{
		DaoComando dao = new DaoComando(); 
		return  dao.consultarTodos(orderBy); 
	}
	
	public List consultarHabilitados(String[][] orderBy, List lstObj) throws SerproException
	{
		DaoComando dao = new DaoComando(); 
		return  dao.consultarHabilitados(orderBy, lstObj); 
	}

	public void excluir(Object o) throws SerproException
	{
		if (validaExcluir(o))
		{
			DaoComando dao = new DaoComando(); 
			dao.excluir(o); 		
		}
	}

	public Object inserir(Object o) throws SerproException
	{
		if (validaInserir(o))
		{
			DaoComando dao = new DaoComando(); 		 
			return dao.inserir(o);
		}
		return o;
	}

	public Object salvar(Object o) throws SerproException
	{
		if (validaSalvar(o))
		{
			DaoComando dao = new DaoComando(); 		 
			return dao.salvar(o);
		}
		return o;
	}

	public boolean valida(Object o) throws SerproException
	{
		return true;
	}

	public boolean validaAlterar(Object o) throws SerproException
	{
		return valida(o);
	}

	public boolean validaExcluir(Object o) throws SerproException
	{
		return valida(o);
	}

	public boolean validaInserir(Object o) throws SerproException
	{
		return valida(o);
	}

	public boolean validaSalvar(Object o) throws SerproException
	{
		return valida(o);
	}
}
