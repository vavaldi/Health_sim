package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import java.util.List;
import javax.persistence.Id;
import javax.persistence.CascadeType;
import arquitetura.funcional.health.entidades.EntNoeud;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import arquitetura.funcional.health.entidades.EntModele;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntScenarioBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "SCE_IDT_CHAVE", unique = true, nullable = false)
    private Long sceIdtChave;

    @Column(name = "SCE_DSC_TITRE", nullable = false, length = 45)
    private String sceDscTitre;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="MDL_IDT_CHAVE") 
    private EntModele entModele;

    @OneToMany(mappedBy="entScenario",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntNoeud> lstNoeud;

    public Long getSceIdtChave() {
        return this.sceIdtChave;
    } 

    public void setSceIdtChave(Long valor) {
        this.sceIdtChave = valor;
    } 

    public String getSceDscTitre() {
        return this.sceDscTitre;
    } 

    public void setSceDscTitre(String valor) {
        this.sceDscTitre = valor;
    } 

    public EntModele getEntModele() {
        return this.entModele;
    } 

    public void setEntModele(EntModele valor) {
        this.entModele = valor;
    } 

    public List<EntNoeud> getLstNoeud() {
        return this.lstNoeud;
    } 

    public void setLstNoeud(List<EntNoeud> valor) {
        this.lstNoeud = valor;
    } 


}