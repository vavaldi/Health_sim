package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActCoordoneesBase;

public class ActCoordonees extends ActCoordoneesBase
{

}


