package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoUsuarioBase;

public class DaoUsuario extends DaoUsuarioBase
{
	public DaoUsuario() throws SerproException
	{
		super();
	}
}
