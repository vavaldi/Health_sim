package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntComandoBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "cmd_comando")

public class EntComando extends EntComandoBase
{

}
