package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntComandoPerfil;
import arquitetura.funcional.health.negocio.NgcComandoPerfil;
import arquitetura.funcional.health.entidades.EntComando;
import arquitetura.funcional.health.negocio.NgcComandoperfilRegra;
import arquitetura.funcional.health.negocio.NgcPerfil;
import arquitetura.funcional.health.negocio.NgcComando;
import arquitetura.funcional.health.negocio.NgcRegraNegocio;
import arquitetura.funcional.health.entidades.EntRegraNegocio;
import arquitetura.funcional.health.entidades.EntComandoperfilRegra;
import arquitetura.funcional.health.entidades.EntComandoPerfil;
import arquitetura.funcional.health.entidades.EntPerfil;


public class ActComandoPerfilBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoPerfil ent = new EntComandoPerfil();
		NgcComandoPerfil ngc = new NgcComandoPerfil();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);



            if (!((DynaValidatorForm) form).get("cmdIdtChave").equals(""))
            {
                EntComando entCmd = new EntComando();
                entCmd.setCmdIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("cmdIdtChave"))); 
                ent.setEntComando(entCmd);
            }
            if (!((DynaValidatorForm) form).get("perIdtChave").equals(""))
            {
                EntPerfil entPer = new EntPerfil();
                entPer.setPerIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("perIdtChave"))); 
                ent.setEntPerfil(entPer);
            }

			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResCmp", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoPerfil ent = new EntComandoPerfil();
		NgcComandoPerfil ngc = new NgcComandoPerfil();

		try
		{
			ent = (EntComandoPerfil) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cmpIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			


            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntComando(), form, req);
            if (null != ent && null != ent.getEntComando())
                BeanUtils.copyProperties(form, ent.getEntComando());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntPerfil(), form, req);
            if (null != ent && null != ent.getEntPerfil())
                BeanUtils.copyProperties(form, ent.getEntPerfil());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas
            List<EntComandoperfilRegra> lstCmr = ent.getLstComandoperfilRegra();
            lstCmr = ordenarLista(lstCmr, getResources(req).getMessage("comandoperfilRegra.ordenacao")); 
            req.setAttribute("lstResCmr", lstCmr);


			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoPerfil ent = new EntComandoPerfil();
		NgcComandoPerfil ngc = new NgcComandoPerfil();

		try
		{
			ent = (EntComandoPerfil) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cmpIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						

            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntComando(), form, req);
            if (null != ent && null != ent.getEntComando())
                BeanUtils.copyProperties(form, ent.getEntComando());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntPerfil(), form, req);
            if (null != ent && null != ent.getEntPerfil())
                BeanUtils.copyProperties(form, ent.getEntPerfil());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas
            List<EntComandoperfilRegra> lstCmr = ent.getLstComandoperfilRegra();
            lstCmr = ordenarLista(lstCmr, getResources(req).getMessage("comandoperfilRegra.ordenacao")); 
            req.setAttribute("lstResCmr", lstCmr);


			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoPerfil ent = new EntComandoPerfil();
		NgcComandoPerfil ngc = new NgcComandoPerfil();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntComandoPerfil) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cmpIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio




            if (getResources(req).getMessage("campo.comandoPerfil.cmdIdtChave.exibir.cad").equals("s"))
                this.setaComando(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.comandoPerfil.perIdtChave.exibir.cad").equals("s"))
                this.setaPerfil(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.comandoPerfil.comandoperfilRegra.exibir").equals("s"))
            {
                // Salva ComandoperfilRegra
                List<EntComandoperfilRegra> lstPrsCmr = ent.getLstComandoperfilRegra();
                List<EntComandoperfilRegra> lstTmpCmr = montarComandoperfilRegra(req, form, ent, "");
                AtualizarComandoperfilRegra(form, lstPrsCmr, lstTmpCmr);
            }


			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntComandoPerfil) ngc.consultarID(ent.getCmpIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResCmp", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoPerfil ent = new EntComandoPerfil();
		NgcComandoPerfil ngc = new NgcComandoPerfil();

		try
		{
			ent = (EntComandoPerfil) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("cmpIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntComandoPerfil ent = new EntComandoPerfil();
		NgcComandoPerfil ngc = new NgcComandoPerfil();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);

            if (getResources(req).getMessage("campo.comandoPerfil.cmdIdtChave.exibir.cad").equals("s"))
                this.setaComando(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.comandoPerfil.perIdtChave.exibir.cad").equals("s"))
                this.setaPerfil(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.comandoPerfil.comandoperfilRegra.exibir").equals("s"))
            {
                // Salva ComandoperfilRegra
                Integer qtdeComandoperfilRegra = Integer.parseInt(req.getParameter("qtdeComandoperfilRegra"));
                if (qtdeComandoperfilRegra > 0)
                {
                    List<EntComandoperfilRegra> lstTmpCmr = montarComandoperfilRegra(req, form, ent, "");
                    ent.setLstComandoperfilRegra(lstTmpCmr);
                }

            }

			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntComandoPerfil) ngc.consultarID(ent.getCmpIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResCmp", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntComandoPerfil ent) throws Exception
	{
            if (getResources(req).getMessage("campo.comandoPerfil.cmdIdtChave.exibir.cad").equals("s"))
                this.setaComando(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.comandoPerfil.perIdtChave.exibir.cad").equals("s"))
                this.setaPerfil(map, form, req, res, ent);

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntComandoPerfil ent) throws Exception
	{
            if (getResources(req).getMessage("detalhe.comandoPerfil.comandoperfilRegra.exibir").equals("s"))
            {
                // Salva ComandoperfilRegra
                List<EntComandoperfilRegra> lstPrsCmr = ent.getLstComandoperfilRegra();
                List<EntComandoperfilRegra> lstTmpCmr = montarComandoperfilRegra(req, form, ent, "");
                AtualizarComandoperfilRegra(form, lstPrsCmr, lstTmpCmr);
            }

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntComandoPerfil ent) throws Exception
	{
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntComando(), form, req);
            if (null != ent && null != ent.getEntComando())
                BeanUtils.copyProperties(form, ent.getEntComando());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntPerfil(), form, req);
            if (null != ent && null != ent.getEntPerfil())
                BeanUtils.copyProperties(form, ent.getEntPerfil());

	}

	public void converterValores(ActionForm form)
	{




	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntComandoPerfil ent) throws Exception
	{

	
        if (getResources(req).getMessage("campo.comandoPerfil.cmdIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.comandoPerfil.cmdIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstComando"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntComando());
            carregarComando(map, form, req, res, metodo, l); 
            
        }
        if (getResources(req).getMessage("campo.comandoPerfil.perIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.comandoPerfil.perIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstPerfil"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntPerfil());
            carregarPerfil(map, form, req, res, metodo, l); 
            
        }
            if (getResources(req).getMessage("detalhe.comandoPerfil.comandoperfilRegra.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.comandoperfilRegra.rngIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstRng"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstComandoperfilRegra() != null && ent.getLstComandoperfilRegra().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstComandoperfilRegra().iterator(); iterator.hasNext();)
                        //{
                            //EntComandoperfilRegra obj = (EntComandoperfilRegra) iterator.next();
                            //l.add(obj.getEntRegraNegocio());
                        //}
                    //}
                //}
                carregarRegraNegocio(map, form, req, res, metodo, l);
            }

	}

    public void carregarComando(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarComando(map, form, req, res, "par", null);

    }
    public void carregarComando(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcComando ngc = new NgcComando();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstCmd", ngc.consultarHabilitados(new String[][]{{"cmdDscLabel", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstCmd", ngc.consultarTodos(new String[][]{{"cmdDscLabel", "ASC"}}));
        }
    }

    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarPerfil(map, form, req, res, "par", null);

    }
    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcPerfil ngc = new NgcPerfil();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstPer", ngc.consultarHabilitados(new String[][]{{"perDscPerfil", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstPer", ngc.consultarTodos(new String[][]{{"perDscPerfil", "ASC"}}));
        }
    }

    public void carregarRegraNegocio(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarRegraNegocio(map, form, req, res, "par", null);

    }
    public void carregarRegraNegocio(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcRegraNegocio ngc = new NgcRegraNegocio();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstRng", ngc.consultarHabilitados(new String[][]{{"rngDscIdentificacao", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstRng", ngc.consultarTodos(new String[][]{{"rngDscIdentificacao", "ASC"}}));
        }
    }





            public void setaComando(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntComandoPerfil ent) throws Exception
            {
                EntComando entCmd;
                if (ent.getEntComando() != null && !((String)((DynaValidatorForm)form).get("cmdIdtChave")).equals("") && ent.getEntComando().getCmdIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("cmdIdtChave"))) 
                    entCmd = ent.getEntComando();
                else
                {
                    entCmd = new EntComando();
                    try {
                        entCmd.setCmdIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("cmdIdtChave")));
                    } catch (Exception e) {
                        entCmd.setCmdIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entCmd, req);
                if (entCmd.getCmdIdtChave() != null)
                    ent.setEntComando(entCmd);
                else
                    ent.setEntComando(null);
            }
            public void setaPerfil(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntComandoPerfil ent) throws Exception
            {
                EntPerfil entPer;
                if (ent.getEntPerfil() != null && !((String)((DynaValidatorForm)form).get("perIdtChave")).equals("") && ent.getEntPerfil().getPerIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("perIdtChave"))) 
                    entPer = ent.getEntPerfil();
                else
                {
                    entPer = new EntPerfil();
                    try {
                        entPer.setPerIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("perIdtChave")));
                    } catch (Exception e) {
                        entPer.setPerIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entPer, req);
                if (entPer.getPerIdtChave() != null)
                    ent.setEntPerfil(entPer);
                else
                    ent.setEntPerfil(null);
            }




            public List<EntComandoperfilRegra> montarComandoperfilRegra(HttpServletRequest req, ActionForm form, EntComandoPerfil ent, String sufixo) throws Exception
            {
                List<EntComandoperfilRegra> lst = new ArrayList<EntComandoperfilRegra>(); 

                // Campos do detalhe
                String[] cmrIdtChave = (String[])((DynaValidatorForm)form).get("cmr_" + sufixo.toUpperCase() + "cmrIdtChave"); 
                String[] cmpIdtChave = (String[])((DynaValidatorForm)form).get("cmr_" + sufixo.toUpperCase() + "cmpIdtChave"); 
                String[] rngIdtChave = (String[])((DynaValidatorForm)form).get("cmr_" + sufixo.toUpperCase() + "rngIdtChave"); 
                String[] rngIdtChaveDsc = (String[])((DynaValidatorForm)form).get("cmr_" + sufixo.toUpperCase() + "rngIdtChaveDsc"); 
                String[] cmrFlgAtivo = (String[])((DynaValidatorForm)form).get("cmr_" + sufixo.toUpperCase() + "cmrFlgAtivo"); 

                // Percorre cada linha 
                for (int i = 0; i < cmrIdtChave.length; i++) 
                {
                    EntComandoperfilRegra entTmp = new EntComandoperfilRegra();  // Percorre o detalhe
                    // Copia campos - ComandoperfilRegra
                if (cmrIdtChave[i] != null && !cmrIdtChave[i].equals(""))
                    entTmp.setCmrIdtChave(Long.parseLong(cmrIdtChave[i]));

            if (cmpIdtChave != null && cmpIdtChave.length > 0 && cmpIdtChave[i] != null && !cmpIdtChave[i].equals(""))
            {
                EntComandoPerfil obj = new EntComandoPerfil();
                obj.setCmpIdtChave(Long.parseLong(cmpIdtChave[i]));
                entTmp.setEntComandoPerfil(obj);
            }
            else if(("cmpIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("cmpIdtChave"))
            {
                entTmp.setEntComandoPerfil(ent);
            }
                if (rngIdtChave != null && rngIdtChave.length > 0 && rngIdtChave[i] != null && !rngIdtChave[i].equals(""))
                {
                    EntRegraNegocio entTmpRng = new EntRegraNegocio();
                    entTmpRng.setRngIdtChave(Long.parseLong(rngIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.comandoperfilRegra.rngIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpRng, rngIdtChaveDsc[i], "campo.comandoperfilRegra.rngIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntRegraNegocio(entTmpRng);
                }

            if (rngIdtChave != null && rngIdtChave.length > 0 && rngIdtChave[i] != null && !rngIdtChave[i].equals(""))
            {
                EntRegraNegocio obj = new EntRegraNegocio();
                obj.setRngIdtChave(Long.parseLong(rngIdtChave[i]));
                entTmp.setEntRegraNegocio(obj);
            }
            if (cmrFlgAtivo != null && cmrFlgAtivo.length > 0 && cmrFlgAtivo[i] != null && !cmrFlgAtivo[i].equals(""))
                entTmp.setCmrFlgAtivo(Integer.parseInt(cmrFlgAtivo[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }



            public void AtualizarComandoperfilRegra(ActionForm form, List<EntComandoperfilRegra> lstPrs, List<EntComandoperfilRegra> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntComandoperfilRegra entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntComandoperfilRegra entTmp = lstTmp.get(j);
                    if (entPrs.getCmrIdtChave().equals(entTmp.getCmrIdtChave())) // Altera��o
                    {
                    entPrs.setEntComandoPerfil(entTmp.getEntComandoPerfil());
                    entPrs.setEntRegraNegocio(entTmp.getEntRegraNegocio());
                    entPrs.setCmrFlgAtivo(entTmp.getCmrFlgAtivo());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }


    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.comandoPerfil." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.comandoPerfil." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
