package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcTipoRegraBase;
//import arquitetura.funcional.health.regra.RngTipoRegra;

public class NgcTipoRegra extends NgcTipoRegraBase
{

}
