package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcConfiguracaoBase;
//import arquitetura.funcional.health.regra.RngConfiguracao;

public class NgcConfiguracao extends NgcConfiguracaoBase
{

}
