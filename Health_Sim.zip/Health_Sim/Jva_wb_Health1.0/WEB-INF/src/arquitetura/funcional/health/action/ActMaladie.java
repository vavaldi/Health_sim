package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActMaladieBase;

public class ActMaladie extends ActMaladieBase
{

}


