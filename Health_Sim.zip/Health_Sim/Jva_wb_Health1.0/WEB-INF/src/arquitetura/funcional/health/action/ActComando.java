package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActComandoBase;

public class ActComando extends ActComandoBase
{

}


