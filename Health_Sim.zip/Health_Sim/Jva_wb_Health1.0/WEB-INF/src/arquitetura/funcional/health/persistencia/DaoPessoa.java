package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoPessoaBase;

public class DaoPessoa extends DaoPessoaBase
{
	public DaoPessoa() throws SerproException
	{
		super();
	}
}
