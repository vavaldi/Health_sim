package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoSistemaBase;

public class DaoSistema extends DaoSistemaBase
{
	public DaoSistema() throws SerproException
	{
		super();
	}
}
