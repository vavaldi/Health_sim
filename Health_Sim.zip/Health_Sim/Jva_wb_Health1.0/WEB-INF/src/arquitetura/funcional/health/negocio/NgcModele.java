package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcModeleBase;
//import arquitetura.funcional.health.regra.RngModele;

public class NgcModele extends NgcModeleBase
{

}
