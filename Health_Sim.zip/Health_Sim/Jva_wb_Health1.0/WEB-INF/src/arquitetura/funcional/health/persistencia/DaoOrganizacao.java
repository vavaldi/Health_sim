package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoOrganizacaoBase;

public class DaoOrganizacao extends DaoOrganizacaoBase
{
	public DaoOrganizacao() throws SerproException
	{
		super();
	}
}
