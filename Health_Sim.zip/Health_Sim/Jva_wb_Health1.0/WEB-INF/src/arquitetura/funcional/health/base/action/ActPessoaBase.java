package arquitetura.funcional.health.base.action;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import arquitetura.funcional.base.persistencia.TransacaoControleHealth;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.action.IAction;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.GerEntidade;
import arquitetura.funcional.base.util.FormatDate;
import arquitetura.funcional.base.util.FormatNumber;
import arquitetura.funcional.base.bean.BtpGrupo;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.health.entidades.EntPessoa;
import arquitetura.funcional.health.negocio.NgcPessoa;
import arquitetura.funcional.health.entidades.EntPessoa;
import arquitetura.funcional.health.negocio.NgcPapel;
import arquitetura.funcional.health.negocio.NgcOrganizacao;
import arquitetura.funcional.health.negocio.NgcUsuario;
import arquitetura.funcional.health.entidades.EntPapel;
import arquitetura.funcional.health.negocio.NgcPerfil;
import arquitetura.funcional.health.negocio.NgcTipoPessoa;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.negocio.NgcTipoSexo;
import arquitetura.funcional.health.entidades.EntPerfil;
import arquitetura.funcional.health.entidades.EntTipoPessoa;
import arquitetura.funcional.health.entidades.EntUsuario;
import arquitetura.funcional.health.entidades.EntTipoSexo;


public class ActPessoaBase extends ActBase implements IAction
{

	public ActionForward prepararConsultar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultarDependencias(map, form, req, res, "par", null);
        try
        {
            // Configura��o padr�o dos grupos de ordena��o
            // List ordenacao = new ArrayList();
            //// Grupo 1 - Forma
            // BtpGrupo btpGrupo = new BtpGrupo();
            // btpGrupo.setCampo("entFormaAuditoria." + getResources(req).getMessage("campo.trabalhoAuditoria.fmaIdtChave.descricao"));
            // btpGrupo.setOrdem("ASC");
            // btpGrupo.setGrupo("1");
            // ordenacao.add(btpGrupo);
            // req.setAttribute("lstOrdenacao", ordenacao);
            // BeanUtils.copyProperties(form, ordenacao);
        }
        catch (Exception e)
        {

        }
        return map.findForward("consulta");
	}

	public ActionForward consultar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntPessoa ent = new EntPessoa();
		NgcPessoa ngc = new NgcPessoa();

		
		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty())				
		        throw new SerproException(erros);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);



            if (!((DynaValidatorForm) form).get("tppIdtChave").equals(""))
            {
                EntTipoPessoa entTpp = new EntTipoPessoa();
                entTpp.setTppIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("tppIdtChave"))); 
                ent.setEntTipoPessoa(entTpp);
            }
            if (!((DynaValidatorForm) form).get("tsxIdtChave").equals(""))
            {
                EntTipoSexo entTsx = new EntTipoSexo();
                entTsx.setTsxIdtChave(Long.parseLong((String) ((DynaValidatorForm) form).get("tsxIdtChave"))); 
                ent.setEntTipoSexo(entTsx);
            }

			
	        // Verifica os agrupamentos selecionados
	        List ordenacaoAux = montarOrdenacao(form, req);
	        List ordenacao = new ArrayList();
	        ordenacao.addAll(ordenacaoAux);
	        req.setAttribute("lstOrdenacao", ordenacao);
	        BeanUtils.copyProperties(form, ordenacao);

			List lista = ngc.consultarQBE(ent, ordenacaoAux);
			req.setAttribute("lstResPes", lista);

			consultarDependencias(map, form, req, res, "par", null);
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "par", null);

		return map.getInputForward();
	}

	public ActionForward prepararSelecionar(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		prepararConsultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward selecionar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		consultar(map, form, req, res);
		
		return map.findForward("consultaLov");
	}

	public ActionForward prepararAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntPessoa ent = new EntPessoa();
		NgcPessoa ngc = new NgcPessoa();

		try
		{
			ent = (EntPessoa) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("pesIdtChave"))));
						
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			


            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoPessoa(), form, req);
            if (null != ent && null != ent.getEntTipoPessoa())
                BeanUtils.copyProperties(form, ent.getEntTipoPessoa());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoSexo(), form, req);
            if (null != ent && null != ent.getEntTipoSexo())
                BeanUtils.copyProperties(form, ent.getEntTipoSexo());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega as listas perif�ricas
			consultarDependencias(map, form, req, res, "cad", ent);
			
			// Carrega listas
            List<EntPapel> lstPap = ent.getLstPapel();
            lstPap = ordenarLista(lstPap, getResources(req).getMessage("papel.ordenacao")); 
            req.setAttribute("lstResPap", lstPap);

            EntUsuario entUsu = ent.getEntUsuario();
            req.setAttribute("entUsu", entUsu);


			

			
			req.setAttribute("ent", ent);
			return map.findForward("cadastro");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		consultarDependencias(map, form, req, res, "cad", ent);

		return map.getInputForward();
	}

	public ActionForward visualizar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntPessoa ent = new EntPessoa();
		NgcPessoa ngc = new NgcPessoa();

		try
		{
			ent = (EntPessoa) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("pesIdtChave"))));

			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
						

            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoPessoa(), form, req);
            if (null != ent && null != ent.getEntTipoPessoa())
                BeanUtils.copyProperties(form, ent.getEntTipoPessoa());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoSexo(), form, req);
            if (null != ent && null != ent.getEntTipoSexo())
                BeanUtils.copyProperties(form, ent.getEntTipoSexo());

//			GerEntidade.copiarVOStringTipo(ent, form, req);
			BeanUtils.copyProperties(form, ent);

			// Carrega listas
            List<EntPapel> lstPap = ent.getLstPapel();
            lstPap = ordenarLista(lstPap, getResources(req).getMessage("papel.ordenacao")); 
            req.setAttribute("lstResPap", lstPap);

            EntUsuario entUsu = ent.getEntUsuario();
            req.setAttribute("entUsu", entUsu);


			
			req.setAttribute("ent", ent);
			return map.findForward("visualiza");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}

		return map.getInputForward();
	}
	
	@SuppressWarnings("unchecked")
	public ActionForward alterar(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntPessoa ent = new EntPessoa();
		NgcPessoa ngc = new NgcPessoa();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);
			
			// Copia as informa��es da tela para as entidades
			ent = (EntPessoa) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("pesIdtChave"))));
			
			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);
			
			GerEntidade.copiarVOStringTipo(form, ent, req);
			// Verificar se isso � realmente necess�rio
            GerEntidade.copiarVOStringTipo(form, ent.getEntUsuario(), req);




            if (getResources(req).getMessage("campo.pessoa.tppIdtChave.exibir.cad").equals("s"))
                this.setaTipoPessoa(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.pessoa.tsxIdtChave.exibir.cad").equals("s"))
                this.setaTipoSexo(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.pessoa.papel.exibir").equals("s"))
            {
                // Salva Papel
                List<EntPapel> lstPrsPap = ent.getLstPapel();
                List<EntPapel> lstTmpPap = montarPapel(req, form, ent, "");
                AtualizarPapel(form, lstPrsPap, lstTmpPap);
            }
            if (getResources(req).getMessage("detalhe.pessoa.usuario.exibir").equals("s"))
            {
                // Salva Usuario
                this.setaUsuario(map, form, req, res, ent);
            }


			// Verifica os erros
			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do Form
		        throw new SerproException(erros);
			
			// Atualiza no banco de dados
			ngc.salvar(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntPessoa) ngc.consultarID(ent.getPesIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResPes", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.atualizacao.sucesso");

			// Carrega as listas de consultas
			consultarDependencias(map, form, req, res, "par", null);

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward excluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntPessoa ent = new EntPessoa();
		NgcPessoa ngc = new NgcPessoa();

		try
		{
			ent = (EntPessoa) ngc.consultarID(new Long(((String) ((DynaValidatorForm)form).get("pesIdtChave"))));

			// Caso n�o exista ou o usu�rio n�o tenha acesso ao ID passado, retorna o erro de conte�do inexistente.
			if (null == ent)
			{
				super.addMensagensErro(req, "erro.conteudo.inexistente");
				return map.findForward("conteudoInexistente");
			}
			
			// Insere na thread o objeto base, ou seja, o objeto de onde o cadastro se inicia
			BtpListaRegras btpListaRegras = BtpContainerRegras.get();
			btpListaRegras.setEntBase(ent);

			consultarDependencias(map, form, req, res, "par", null);

			ngc.excluir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.exclusao.sucesso"); 

			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", ent);


		req.setAttribute("ent", ent);
		return map.getInputForward();
	}

	public ActionForward prepararIncluir(ActionMapping map, ActionForm form, 
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{


		// Carrega listas
		consultarDependencias(map, form, req, res, "cad", null);

		return map.findForward("cadastro");
	}

	@SuppressWarnings("unchecked")
	public ActionForward incluir(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		EntPessoa ent = new EntPessoa();
		NgcPessoa ngc = new NgcPessoa();

		try
		{
			// Convers�o de Valores
			this.converterValores(form);

			GerEntidade.copiarVOStringTipo(form, ent, req);

            if (getResources(req).getMessage("campo.pessoa.tppIdtChave.exibir.cad").equals("s"))
                this.setaTipoPessoa(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.pessoa.tsxIdtChave.exibir.cad").equals("s"))
                this.setaTipoSexo(map, form, req, res, ent);

            if (getResources(req).getMessage("detalhe.pessoa.papel.exibir").equals("s"))
            {
                // Salva Papel
                Integer qtdePapel = Integer.parseInt(req.getParameter("qtdePapel"));
                if (qtdePapel > 0)
                {
                    List<EntPapel> lstTmpPap = montarPapel(req, form, ent, "");
                    ent.setLstPapel(lstTmpPap);
                }

            }
            if (getResources(req).getMessage("detalhe.pessoa.usuario.exibir").equals("s"))
            {
                // Salva Usuario
                this.setaUsuario(map, form, req, res, ent);
            }

			
			consultarDependencias(map, form, req, res, "par", null);			

			ActionErrors erros = form.validate(map, req);
			if (erros != null && !erros.isEmpty()) //Valida��o do form
		        throw new SerproException(erros);


			ngc.inserir(ent);
			
			// Fecha a transa��o
			TransacaoControleHealth.commit();

			// Realiza consulta para enviar de volta o objeto completo
			ent = (EntPessoa) ngc.consultarID(ent.getPesIdtChave());

			ArrayList lista = new ArrayList();
			lista.add(ent);
			req.setAttribute("lstResPes", lista);

			// Envia uma mensagem positiva para o usu�rio
			super.addMensagensSucesso(req, "msg.sistema.inclusao.sucesso");
			
			return map.findForward("consulta");
		}
		catch (SerproException e)
		{
			addErrosValidacao(e, req);
		}
		// Carrega listas
		consultarDependencias(map, form, req, res, "par", null);
		

		req.setAttribute("ent", ent);
		return map.getInputForward();
	}
	
	protected ActionForward unspecified(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		return map.findForward("consulta");
	}

	public void setaImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntPessoa ent) throws Exception
	{
            if (getResources(req).getMessage("campo.pessoa.tppIdtChave.exibir.cad").equals("s"))
                this.setaTipoPessoa(map, form, req, res, ent);
            if (getResources(req).getMessage("campo.pessoa.tsxIdtChave.exibir.cad").equals("s"))
                this.setaTipoSexo(map, form, req, res, ent);

	}

	public void setaExportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntPessoa ent) throws Exception
	{
            if (getResources(req).getMessage("detalhe.pessoa.papel.exibir").equals("s"))
            {
                // Salva Papel
                List<EntPapel> lstPrsPap = ent.getLstPapel();
                List<EntPapel> lstTmpPap = montarPapel(req, form, ent, "");
                AtualizarPapel(form, lstPrsPap, lstTmpPap);
            }
            if (getResources(req).getMessage("detalhe.pessoa.usuario.exibir").equals("s"))
            {
                // Salva Usuario
                this.setaUsuario(map, form, req, res, ent);
            }

	}

	public void setaFormImportsAlterar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, EntPessoa ent) throws Exception
	{
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoPessoa(), form, req);
            if (null != ent && null != ent.getEntTipoPessoa())
                BeanUtils.copyProperties(form, ent.getEntTipoPessoa());
            // N�o funciona aki .GerEntidade.copiarVOStringTipo(ent.getEntTipoSexo(), form, req);
            if (null != ent && null != ent.getEntTipoSexo())
                BeanUtils.copyProperties(form, ent.getEntTipoSexo());

	}

	public void converterValores(ActionForm form)
	{

        // PesFlgEditavel
        if ((((DynaValidatorForm) form).get("pesFlgEditavel")) != null && !(((DynaValidatorForm) form).get("pesFlgEditavel")).equals(""))
        {
            Integer pesFlgEditavel = FormatNumber.parseIntegerWrapper((String) ((DynaValidatorForm) form).get("pesFlgEditavel"));
            ((DynaValidatorForm) form).set("pesFlgEditavel", pesFlgEditavel.toString());
        }



	}

	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo) throws Exception
	{
		consultarDependencias(map, form, req, res, metodo, null);
	}
	public void consultarDependencias(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, EntPessoa ent) throws Exception
	{

	
        if (getResources(req).getMessage("campo.pessoa.tppIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.pessoa.tppIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstTipoPessoa"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntTipoPessoa());
            carregarTipoPessoa(map, form, req, res, metodo, l); 
            
        }
        if (getResources(req).getMessage("campo.pessoa.tsxIdtChave.exibir." + metodo).toLowerCase().equals("s") && !getResources(req).getMessage("campo.pessoa.tsxIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstTipoSexo"))
        {
            List l = new ArrayList();
            if (ent != null)
                l.add(ent.getEntTipoSexo());
            carregarTipoSexo(map, form, req, res, metodo, l); 
            
        }
            if (getResources(req).getMessage("detalhe.pessoa.papel.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.papel.orgIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstOrg"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPapel() != null && ent.getLstPapel().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPapel().iterator(); iterator.hasNext();)
                        //{
                            //EntPapel obj = (EntPapel) iterator.next();
                            //l.add(obj.getEntOrganizacao());
                        //}
                    //}
                //}
                carregarOrganizacao(map, form, req, res, metodo, l);
            }
            if (getResources(req).getMessage("detalhe.pessoa.papel.exibir").toLowerCase().equals("s") && !getResources(req).getMessage("campo.papel.perIdtChave.visual").toLowerCase().equals("l") && null == req.getAttribute("lstPer"))
            {
                List l = new ArrayList();
                //if (ent != null)
                //{
                    //if (ent.getLstPapel() != null && ent.getLstPapel().size() > 0)
                    //{
                        //for (Iterator iterator = ent.getLstPapel().iterator(); iterator.hasNext();)
                        //{
                            //EntPapel obj = (EntPapel) iterator.next();
                            //l.add(obj.getEntPerfil());
                        //}
                    //}
                //}
                carregarPerfil(map, form, req, res, metodo, l);
            }

	}

    public void carregarTipoPessoa(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarTipoPessoa(map, form, req, res, "par", null);

    }
    public void carregarTipoPessoa(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcTipoPessoa ngc = new NgcTipoPessoa();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstTpp", ngc.consultarHabilitados(new String[][]{{"tppDscNome", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstTpp", ngc.consultarTodos(new String[][]{{"tppDscNome", "ASC"}}));
        }
    }

    public void carregarTipoSexo(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarTipoSexo(map, form, req, res, "par", null);

    }
    public void carregarTipoSexo(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcTipoSexo ngc = new NgcTipoSexo();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstTsx", ngc.consultarHabilitados(new String[][]{{"tsxDscNome", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstTsx", ngc.consultarTodos(new String[][]{{"tsxDscNome", "ASC"}}));
        }
    }

    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarOrganizacao(map, form, req, res, "par", null);

    }
    public void carregarOrganizacao(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcOrganizacao ngc = new NgcOrganizacao();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstOrg", ngc.consultarHabilitados(new String[][]{{"orgDscFantasia", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstOrg", ngc.consultarTodos(new String[][]{{"orgDscFantasia", "ASC"}}));
        }
    }

    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws SerproException
    {
        carregarPerfil(map, form, req, res, "par", null);

    }
    public void carregarPerfil(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res, String metodo, List lst) throws SerproException
    {
        NgcPerfil ngc = new NgcPerfil();
        if (metodo != null && metodo.equalsIgnoreCase("cad"))
        {
            req.setAttribute("lstPer", ngc.consultarHabilitados(new String[][]{{"perDscPerfil", "ASC"}}, lst));
        } else
        {
            req.setAttribute("lstPer", ngc.consultarTodos(new String[][]{{"perDscPerfil", "ASC"}}));
        }
    }





            public void setaTipoPessoa(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntPessoa ent) throws Exception
            {
                EntTipoPessoa entTpp;
                if (ent.getEntTipoPessoa() != null && !((String)((DynaValidatorForm)form).get("tppIdtChave")).equals("") && ent.getEntTipoPessoa().getTppIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("tppIdtChave"))) 
                    entTpp = ent.getEntTipoPessoa();
                else
                {
                    entTpp = new EntTipoPessoa();
                    try {
                        entTpp.setTppIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("tppIdtChave")));
                    } catch (Exception e) {
                        entTpp.setTppIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entTpp, req);
                if (entTpp.getTppIdtChave() != null)
                    ent.setEntTipoPessoa(entTpp);
                else
                    ent.setEntTipoPessoa(null);
            }
            public void setaTipoSexo(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntPessoa ent) throws Exception
            {
                EntTipoSexo entTsx;
                if (ent.getEntTipoSexo() != null && !((String)((DynaValidatorForm)form).get("tsxIdtChave")).equals("") && ent.getEntTipoSexo().getTsxIdtChave() == Long.parseLong((String)((DynaValidatorForm)form).get("tsxIdtChave"))) 
                    entTsx = ent.getEntTipoSexo();
                else
                {
                    entTsx = new EntTipoSexo();
                    try {
                        entTsx.setTsxIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("tsxIdtChave")));
                    } catch (Exception e) {
                        entTsx.setTsxIdtChave(null);
                    }
                }
                //GerEntidade.copiarVOStringTipo(form, entTsx, req);
                if (entTsx.getTsxIdtChave() != null)
                    ent.setEntTipoSexo(entTsx);
                else
                    ent.setEntTipoSexo(null);
            }


            public void setaUsuario(ActionMapping map, ActionForm form,HttpServletRequest req, HttpServletResponse res,EntPessoa ent) throws Exception
            {
                EntUsuario entUsu;
                if (ent.getEntUsuario() != null  && ent.getEntUsuario().getUsuIdtChave() == ((DynaValidatorForm)form).get("usuIdtChave")) 
                    entUsu = ent.getEntUsuario();
                else
                {
                    entUsu = new EntUsuario();
                    entUsu.setUsuIdtChave(Long.valueOf((String)((DynaValidatorForm)form).get("pesIdtChave")));
                }
                //GerEntidade.copiarVOStringTipo(form, entUsu, req);
                if (entUsu.getUsuIdtChave() != null)
                    ent.setEntUsuario(entUsu);
                else
                    ent.setEntUsuario(null);
            }


            public List<EntPapel> montarPapel(HttpServletRequest req, ActionForm form, EntPessoa ent, String sufixo) throws Exception
            {
                List<EntPapel> lst = new ArrayList<EntPapel>(); 

                // Campos do detalhe
                String[] papIdtChave = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "papIdtChave"); 
                String[] orgIdtChave = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "orgIdtChave"); 
                String[] orgIdtChaveDsc = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "orgIdtChaveDsc"); 
                String[] pesIdtChave = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "pesIdtChave"); 
                String[] perIdtChave = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "perIdtChave"); 
                String[] perIdtChaveDsc = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "perIdtChaveDsc"); 
                String[] papDatInicio = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "papDatInicio"); 
                String[] papDatFim = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "papDatFim"); 
                String[] papFlgAtivo = (String[])((DynaValidatorForm)form).get("pap_" + sufixo.toUpperCase() + "papFlgAtivo"); 

                // Percorre cada linha 
                for (int i = 0; i < papIdtChave.length; i++) 
                {
                    EntPapel entTmp = new EntPapel();  // Percorre o detalhe
                    // Copia campos - Papel
                if (papIdtChave[i] != null && !papIdtChave[i].equals(""))
                    entTmp.setPapIdtChave(Long.parseLong(papIdtChave[i]));

                if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
                {
                    EntOrganizacao entTmpOrg = new EntOrganizacao();
                    entTmpOrg.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.papel.orgIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpOrg, orgIdtChaveDsc[i], "campo.papel.orgIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntOrganizacao(entTmpOrg);
                }

            if (orgIdtChave != null && orgIdtChave.length > 0 && orgIdtChave[i] != null && !orgIdtChave[i].equals(""))
            {
                EntOrganizacao obj = new EntOrganizacao();
                obj.setOrgIdtChave(Long.parseLong(orgIdtChave[i]));
                entTmp.setEntOrganizacao(obj);
            }
            if (pesIdtChave != null && pesIdtChave.length > 0 && pesIdtChave[i] != null && !pesIdtChave[i].equals(""))
            {
                EntPessoa obj = new EntPessoa();
                obj.setPesIdtChave(Long.parseLong(pesIdtChave[i]));
                entTmp.setEntPessoa(obj);
            }
            else if(("pesIdtChave" + sufixo).replaceAll("_", "").equalsIgnoreCase("pesIdtChave"))
            {
                entTmp.setEntPessoa(ent);
            }
                if (perIdtChave != null && perIdtChave.length > 0 && perIdtChave[i] != null && !perIdtChave[i].equals(""))
                {
                    EntPerfil entTmpPer = new EntPerfil();
                    entTmpPer.setPerIdtChave(Long.parseLong(perIdtChave[i]));
                    // Se o detalhe for um LOV, alimenta o objeto com a descri��o correta
                    if (getResources(req).getMessage("campo.papel.perIdtChave.visual").toLowerCase().equals("l"))
                        alimentarLov(req, entTmpPer, perIdtChaveDsc[i], "campo.papel.perIdtChave.descricao", getResources(req).getMessage("caminho.entidade"));
                    entTmp.setEntPerfil(entTmpPer);
                }

            if (perIdtChave != null && perIdtChave.length > 0 && perIdtChave[i] != null && !perIdtChave[i].equals(""))
            {
                EntPerfil obj = new EntPerfil();
                obj.setPerIdtChave(Long.parseLong(perIdtChave[i]));
                entTmp.setEntPerfil(obj);
            }
            if (papDatInicio != null && papDatInicio.length > 0 && papDatInicio[i] != null && !papDatInicio[i].equals(""))
                entTmp.setPapDatInicio(FormatDate.parse(papDatInicio[i]));

            if (papDatFim != null && papDatFim.length > 0 && papDatFim[i] != null && !papDatFim[i].equals(""))
                entTmp.setPapDatFim(FormatDate.parse(papDatFim[i]));

            if (papFlgAtivo != null && papFlgAtivo.length > 0 && papFlgAtivo[i] != null && !papFlgAtivo[i].equals(""))
                entTmp.setPapFlgAtivo(Integer.parseInt(papFlgAtivo[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }

            public List<EntUsuario> montarUsuario(HttpServletRequest req, ActionForm form, EntPessoa ent, String sufixo) throws Exception
            {
                List<EntUsuario> lst = new ArrayList<EntUsuario>(); 

                // Campos do detalhe
                String[] usuIdtChave = (String[])((DynaValidatorForm)form).get("usu_" + sufixo.toUpperCase() + "usuIdtChave"); 
                String[] usuDscLogin = (String[])((DynaValidatorForm)form).get("usu_" + sufixo.toUpperCase() + "usuDscLogin"); 
                String[] usuDscSenha = (String[])((DynaValidatorForm)form).get("usu_" + sufixo.toUpperCase() + "usuDscSenha"); 
                String[] usuFlgDesativado = (String[])((DynaValidatorForm)form).get("usu_" + sufixo.toUpperCase() + "usuFlgDesativado"); 

                // Percorre cada linha 
                for (int i = 0; i < usuIdtChave.length; i++) 
                {
                    EntUsuario entTmp = new EntUsuario();  // Percorre o detalhe
                    // Copia campos - Usuario
                if (usuIdtChave[i] != null && !usuIdtChave[i].equals(""))
                    entTmp.setUsuIdtChave(Long.parseLong(usuIdtChave[i]));

            if (usuDscLogin != null && usuDscLogin.length > 0 && usuDscLogin[i] != null && !usuDscLogin[i].equals(""))
                entTmp.setUsuDscLogin((usuDscLogin[i]));

            if (usuDscSenha != null && usuDscSenha.length > 0 && usuDscSenha[i] != null && !usuDscSenha[i].equals(""))
                entTmp.setUsuDscSenha((usuDscSenha[i]));

            if (usuFlgDesativado != null && usuFlgDesativado.length > 0 && usuFlgDesativado[i] != null && !usuFlgDesativado[i].equals(""))
                entTmp.setUsuFlgDesativado(Integer.parseInt(usuFlgDesativado[i]));


                    lst.add(entTmp);
                }
                return lst; 
            }



            public void AtualizarPapel(ActionForm form, List<EntPapel> lstPrs, List<EntPapel> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntPapel entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntPapel entTmp = lstTmp.get(j);
                    if (entPrs.getPapIdtChave().equals(entTmp.getPapIdtChave())) // Altera��o
                    {
                    entPrs.setEntOrganizacao(entTmp.getEntOrganizacao());
                    entPrs.setEntPessoa(entTmp.getEntPessoa());
                    entPrs.setEntPerfil(entTmp.getEntPerfil());
                    entPrs.setPapDatInicio(entTmp.getPapDatInicio());
                    entPrs.setPapDatFim(entTmp.getPapDatFim());
                    entPrs.setPapFlgAtivo(entTmp.getPapFlgAtivo());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }
            public void AtualizarUsuario(ActionForm form, List<EntUsuario> lstPrs, List<EntUsuario> lstTmp) throws NumberFormatException, SerproException
            {
            // Salva as informa��es
            boolean achou = false;
            for (int i = 0; i < lstPrs.size(); i++)
            {
                EntUsuario entPrs = lstPrs.get(i); 
                achou = false;
                for (int j = 0; (!achou && (j < lstTmp.size())); j++)
                {
                    EntUsuario entTmp = lstTmp.get(j);
                    if (entPrs.getUsuIdtChave().equals(entTmp.getUsuIdtChave())) // Altera��o
                    {
                    entPrs.setUsuDscLogin(entTmp.getUsuDscLogin());
                    entPrs.setUsuDscSenha(entTmp.getUsuDscSenha());
                    entPrs.setUsuFlgDesativado(entTmp.getUsuFlgDesativado());
                    lstTmp.remove(entTmp);j--;
                    achou = true;
                }
            }
            if (! achou)
            {
                lstPrs.remove(entPrs); i--;
            }
            }
                lstPrs.addAll(lstTmp); //Inclus�o dos campos
            }


    public List montarOrdenacao(ActionForm form, HttpServletRequest req) throws Exception
    {
    	List lst = new ArrayList(); 

	    // Campos do detalhe
	    String[] grupoCampo = (String[])((DynaValidatorForm)form).get("lstCampo"); 
	    String[] grupoOrdem = (String[])((DynaValidatorForm)form).get("lstOrdem"); 
	    String[] grupoGrupo = (String[])((DynaValidatorForm)form).get("lstGrupo"); 

	    // Percorre cada linha 
	    for (int i = 0; i < grupoCampo.length; i++) 
	    {
	    	// Copia valor do Campo
	    	if (grupoCampo[i] != null && !grupoCampo[i].equals(""))
	    	{
		    	BtpGrupo btpGrupo = new BtpGrupo();

		    	// Copia valor do Campo
	    		btpGrupo.setCampo(grupoCampo[i]);

		    	// Copia valor da Ordem
		    	if (grupoOrdem[i] != null && !grupoOrdem[i].equals(""))
		    		btpGrupo.setOrdem(grupoOrdem[i]);

		    	// Copia valor do Grupo
		    	if (grupoGrupo[i] != null && !grupoGrupo[i].equals(""))
		    		btpGrupo.setGrupo(grupoGrupo[i]);

	    		// Captura o t�tulo a ser exibido na coluna de agrupamento.
	    		// Caso seja um objeto...
	    		if (btpGrupo.getCampo().indexOf(".") > -1)
	    		{
		    		String sufixo = btpGrupo.getCampo().substring(btpGrupo.getCampo().indexOf(".") + 1, btpGrupo.getCampo().indexOf(".") + 1 + 3);
		    		btpGrupo.setTitulo("texto.pessoa." + sufixo + "IdtChave.label");
	    		} else
	    		{
		    		btpGrupo.setTitulo("texto.pessoa." + btpGrupo.getCampo() + ".label");
	    		}

	    		// Adiciona � lista
		    	lst.add(btpGrupo);
	    	}
	    }
    	return lst;
    }
}
