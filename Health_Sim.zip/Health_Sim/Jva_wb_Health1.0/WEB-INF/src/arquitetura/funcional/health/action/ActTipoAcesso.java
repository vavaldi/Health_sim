package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActTipoAcessoBase;

public class ActTipoAcesso extends ActTipoAcessoBase
{

}


