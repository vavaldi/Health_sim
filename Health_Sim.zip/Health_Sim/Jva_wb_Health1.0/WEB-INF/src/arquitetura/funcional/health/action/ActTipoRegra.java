package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActTipoRegraBase;

public class ActTipoRegra extends ActTipoRegraBase
{

}


