package arquitetura.funcional.health.persistencia;

import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.health.base.persistencia.DaoComandoRegraBase;

public class DaoComandoRegra extends DaoComandoRegraBase
{
	public DaoComandoRegra() throws SerproException
	{
		super();
	}
}
