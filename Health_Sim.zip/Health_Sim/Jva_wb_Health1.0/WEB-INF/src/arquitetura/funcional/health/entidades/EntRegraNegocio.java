package arquitetura.funcional.health.entidades;

import arquitetura.funcional.health.base.entidades.EntRegraNegocioBase;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "rng_regra_negocio")

public class EntRegraNegocio extends EntRegraNegocioBase
{

}
