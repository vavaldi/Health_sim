package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntConfiguracaoBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "CON_IDT_CHAVE", unique = true, nullable = false)
    private Long conIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="ORG_IDT_CHAVE") 
    private EntOrganizacao entOrganizacao;

    @Column(name = "CON_DSC_CAMPO", nullable = false, length = 200)
    private String conDscCampo;

    @Column(name = "CON_DSC_VALOR", nullable = false, length = 200)
    private String conDscValor;

    public Long getConIdtChave() {
        return this.conIdtChave;
    } 

    public void setConIdtChave(Long valor) {
        this.conIdtChave = valor;
    } 

    public EntOrganizacao getEntOrganizacao() {
        return this.entOrganizacao;
    } 

    public void setEntOrganizacao(EntOrganizacao valor) {
        this.entOrganizacao = valor;
    } 

    public String getConDscCampo() {
        return this.conDscCampo;
    } 

    public void setConDscCampo(String valor) {
        this.conDscCampo = valor;
    } 

    public String getConDscValor() {
        return this.conDscValor;
    } 

    public void setConDscValor(String valor) {
        this.conDscValor = valor;
    } 


}