package arquitetura.funcional.health.base.entidades;

import javax.persistence.ManyToOne;
import arquitetura.funcional.health.entidades.EntPessoa;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntPerfil;
import javax.persistence.Entity;
import java.math.BigDecimal;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntPapelBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "PAP_IDT_CHAVE", unique = true, nullable = false)
    private Long papIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="ORG_IDT_CHAVE") 
    private EntOrganizacao entOrganizacao;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="PES_IDT_CHAVE") 
    private EntPessoa entPessoa;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="PER_IDT_CHAVE") 
    private EntPerfil entPerfil;

    @Column(name = "PAP_DAT_INICIO", nullable = false)
    private Date papDatInicio;

    @Column(name = "PAP_DAT_FIM", nullable = true)
    private Date papDatFim;

    @Column(name = "PAP_FLG_ATIVO", nullable = false)
    private Integer papFlgAtivo;

    public Long getPapIdtChave() {
        return this.papIdtChave;
    } 

    public void setPapIdtChave(Long valor) {
        this.papIdtChave = valor;
    } 

    public EntOrganizacao getEntOrganizacao() {
        return this.entOrganizacao;
    } 

    public void setEntOrganizacao(EntOrganizacao valor) {
        this.entOrganizacao = valor;
    } 

    public EntPessoa getEntPessoa() {
        return this.entPessoa;
    } 

    public void setEntPessoa(EntPessoa valor) {
        this.entPessoa = valor;
    } 

    public EntPerfil getEntPerfil() {
        return this.entPerfil;
    } 

    public void setEntPerfil(EntPerfil valor) {
        this.entPerfil = valor;
    } 

    public Date getPapDatInicio() {
        return this.papDatInicio;
    } 

    public void setPapDatInicio(Date valor) {
        this.papDatInicio = valor;
    } 

    public Date getPapDatFim() {
        return this.papDatFim;
    } 

    public void setPapDatFim(Date valor) {
        this.papDatFim = valor;
    } 

    public Integer getPapFlgAtivo() {
        return this.papFlgAtivo;
    } 

    public void setPapFlgAtivo(Integer valor) {
        this.papFlgAtivo = valor;
    } 


}