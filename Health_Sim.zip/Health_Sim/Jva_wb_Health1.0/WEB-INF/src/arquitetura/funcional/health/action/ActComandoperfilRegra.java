package arquitetura.funcional.health.action;

import arquitetura.funcional.health.base.action.ActComandoperfilRegraBase;

public class ActComandoperfilRegra extends ActComandoperfilRegraBase
{

}


