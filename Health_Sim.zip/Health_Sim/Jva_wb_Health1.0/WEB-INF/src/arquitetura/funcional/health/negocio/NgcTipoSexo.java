package arquitetura.funcional.health.negocio;

import arquitetura.funcional.health.base.negocio.NgcTipoSexoBase;
//import arquitetura.funcional.health.regra.RngTipoSexo;

public class NgcTipoSexo extends NgcTipoSexoBase
{

}
