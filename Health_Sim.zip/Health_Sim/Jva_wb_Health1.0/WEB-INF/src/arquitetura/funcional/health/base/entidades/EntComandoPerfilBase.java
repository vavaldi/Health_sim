package arquitetura.funcional.health.base.entidades;

import arquitetura.funcional.health.entidades.EntComando;
import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Table;
import java.util.List;
import javax.persistence.Id;
import javax.persistence.CascadeType;
import javax.persistence.MappedSuperclass;
import javax.persistence.GenerationType;
import java.util.Date;
import arquitetura.funcional.health.entidades.EntPerfil;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import java.math.BigDecimal;
import arquitetura.funcional.health.entidades.EntComandoperfilRegra;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;

@MappedSuperclass
public class EntComandoPerfilBase implements java.io.Serializable 
{ 


    private static final long serialVersionUID = 1L; 

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "CMP_IDT_CHAVE", unique = true, nullable = false)
    private Long cmpIdtChave;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="CMD_IDT_CHAVE") 
    private EntComando entComando;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name ="PER_IDT_CHAVE") 
    private EntPerfil entPerfil;

    @OneToMany(mappedBy="entComandoPerfil",  fetch = FetchType.LAZY)
    @org.hibernate.annotations.Cascade(value={org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN})
    private List<EntComandoperfilRegra> lstComandoperfilRegra;

    public Long getCmpIdtChave() {
        return this.cmpIdtChave;
    } 

    public void setCmpIdtChave(Long valor) {
        this.cmpIdtChave = valor;
    } 

    public EntComando getEntComando() {
        return this.entComando;
    } 

    public void setEntComando(EntComando valor) {
        this.entComando = valor;
    } 

    public EntPerfil getEntPerfil() {
        return this.entPerfil;
    } 

    public void setEntPerfil(EntPerfil valor) {
        this.entPerfil = valor;
    } 

    public List<EntComandoperfilRegra> getLstComandoperfilRegra() {
        return this.lstComandoperfilRegra;
    } 

    public void setLstComandoperfilRegra(List<EntComandoperfilRegra> valor) {
        this.lstComandoperfilRegra = valor;
    } 


}