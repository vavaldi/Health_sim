package arquitetura.funcional.acesso.controlador;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;

import arquitetura.funcional.acesso.base.controlador.CtrAcessoBase;
import arquitetura.funcional.base.bean.BtpContainerRegras;
import arquitetura.funcional.base.bean.BtpListaRegras;
import arquitetura.funcional.base.persistencia.HibernateDAOHealth;
import arquitetura.funcional.base.util.Constantes;
import arquitetura.funcional.health.entidades.EntComando;
import arquitetura.funcional.health.entidades.EntComandoPerfil;
import arquitetura.funcional.health.entidades.EntComandoRegra;
import arquitetura.funcional.health.entidades.EntComandoperfilRegra;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntPerfil;
import arquitetura.funcional.health.entidades.EntRegraNegocio;
import arquitetura.funcional.health.entidades.EntUsuario;

public class CtrAcesso extends CtrAcessoBase
{

//	@Override
//	public void process(HttpServletRequest request,
//			HttpServletResponse response) throws IOException, ServletException
//	{
//		
//		try {
//			HttpUtil.tratarPrimeiroAcesso(request, response);
//		} catch (SerproException e) {			
//			throw new ServletException(e);
//		}
//		
//		super.process(request, response);
//	}


	
	public boolean processar(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException
	{
		// Captura action
		String action = request.getRequestURI().substring(request.getContextPath().length() + 1);

		if (null != request.getParameter(Constantes.URL_METODO) && !request.getParameter(Constantes.URL_METODO).equals(""))
			action += "?" + Constantes.URL_METODO + "=" + request.getParameter(Constantes.URL_METODO);

		HttpSession sessao = request.getSession();
		ArrayList permissoes = (ArrayList)sessao.getAttribute(Constantes.PERMISSAO);
		List lstPerfis = (ArrayList)sessao.getAttribute(Constantes.PESSOA_PERFIS);
		boolean permitir = true;

		// Se o action n�o for a tela de logon...
//		if (!action.equals("Logon.do") && 
//				!action.equals("Logon.do?cmd=exibir") && 
//				!action.equals("LogonAutenticar.do?cmd=autenticar") &&
//				!action.equals("Logoff.do?cmd=logoff") )
		if (!action.equals("telalogin.do") && 
				!action.equals("entrada.do") && 
				!action.equals("sair.do"))
		{
			// Verifica permiss�es na sess�o
			permitir = verificarPermissao(action, permissoes, request, lstPerfis);
		} 
		return permitir;
	}

	  protected boolean verificarPermissao(String comando, ArrayList permissoes, HttpServletRequest request, List lstPerfis)
	  {
	  	// Verifica se existe o comando passado na lista de permiss�es do usu�rio
	  	int cont = 0, tamanho = 0;
	  	boolean retorno = false;
	  	EntComando entCmd = new EntComando();
	  	
		try {
		  	while (!retorno && null != permissoes && cont < permissoes.size()) 
		  	{
		  		entCmd = (EntComando) permissoes.get(cont);
	    		String action = request.getRequestURI().substring(request.getContextPath().length() + 1);
	    		if (null != request.getParameter(Constantes.URL_METODO) && !request.getParameter(Constantes.URL_METODO).equals(""))
	    			action += "?"+ Constantes.URL_METODO + "=" + request.getParameter(Constantes.URL_METODO);

	    			// "Tosa" o comando at� o primeiro "&"
					tamanho = action.trim().indexOf("&");
					if (tamanho == -1)
					  tamanho = action.trim().length();

					// Verifica se o comando passado e a permiss�o verificada possuem rela��o
					if (null != entCmd.getCmdDscAcao() && entCmd.getCmdDscAcao().toLowerCase().indexOf(action.trim().toLowerCase().substring(0,tamanho)) == 0)
					{
						// Registra o objeto comando no request
						request.setAttribute(Constantes.COMANDO_REQUISICAO, entCmd);
						
						// Levanta as restri��es cadastradas para os perfis que possuem acesso ao referido comando
						BtpListaRegras lstRegras = new BtpListaRegras();
						lstRegras.setLstRegraNegocio(new ArrayList<EntRegraNegocio>());
						
						// Busca informa��es do usu�rio logado
				    	HttpSession session = request.getSession();
				    	EntUsuario entUsu = (EntUsuario)session.getAttribute(Constantes.USUARIO_LOGADO);
//				    	List<EntPerfil> lstPerfis = new ArrayList();
//				    	if (null != entUsu && null != entUsu.getLstPerfilUsuario())
//				    	{
//					    	for (Iterator iterator = entUsu.getLstPerfilUsuario().iterator(); iterator.hasNext();) 
//					    	{
//								EntPerfilUsuario entPfu = (EntPerfilUsuario) iterator.next();
//								if (null != entPfu && null != entPfu.getEntPerfil())
//								{
//									lstPerfis.add(entPfu.getEntPerfil());
//								}
//							} 
//				    	}
				    	
				    	// Consulta Regras de Neg�cio associadas ao Comando e ao ComandoPerfil.
						HibernateDAOHealth hibDaoCmp = new HibernateDAOHealth(Class.forName("arquitetura.funcional.health.entidades.EntComando"));
						Session hibSessionCmp = hibDaoCmp.getSessionFactory().openSession();
						hibSessionCmp.beginTransaction();
				    	entCmd = (EntComando) hibSessionCmp.get(EntComando.class, entCmd.getCmdIdtChave());
						if (null != entCmd.getLstComandoPerfil() && entCmd.getLstComandoPerfil().size() > 0)
						{
							HibernateDAOHealth hibDao = new HibernateDAOHealth(Class.forName("arquitetura.funcional.health.entidades.EntRegraNegocio"));
							Session hibSession = hibDao.getSessionFactory().openSession();
							hibSession.beginTransaction();


							// Busca as regras associadas ao Comando em quest�o.
							for (Iterator iterator = entCmd.getLstComandoRegra().iterator(); iterator.hasNext();) 
							{
								EntComandoRegra entCdr = (EntComandoRegra) iterator.next();
								EntRegraNegocio entRng = (EntRegraNegocio) entCdr.getEntRegraNegocio();
								lstRegras.getLstRegraNegocio().add(entRng);
							}
							
							
							// Busca as regras associadas ao Comando x Perfil do Comando em quest�o
							for (Iterator iterator = entCmd.getLstComandoPerfil().iterator(); iterator.hasNext();) 
							{
								EntComandoPerfil entComandoPerfil = (EntComandoPerfil) iterator.next();
								EntComandoPerfil entCmp = (EntComandoPerfil) hibSession.load(EntComandoPerfil.class, entComandoPerfil.getCmpIdtChave());
								
								if (null != entCmp && null != entCmp.getLstComandoperfilRegra())
								{
									// Para cada rela��o Comando x Perfil, busca as regras de neg�cio associadas. 
									for (Iterator iterator2 = entCmp.getLstComandoperfilRegra().iterator(); iterator2.hasNext();) 
									{
										EntComandoperfilRegra entCmr = (EntComandoperfilRegra)iterator2.next();
										EntRegraNegocio entRng = (EntRegraNegocio) entCmr.getEntRegraNegocio();
										
										// A partir dos perfis do usu�rio logado, coloca na lista as respectivas restri��es...
										// N�o funcionou com a compara��o de objetos
//										if (lstPerfis.contains(entRng.getEntComandoPerfil().getEntPerfil()))
//											lstRegras.getLstRegraNegocio().add(entRng);
										if (null != lstPerfis && lstPerfis.size() > 0)
										{
											for (Iterator iterator3 = lstPerfis.iterator(); iterator3.hasNext();) 
											{
												EntPerfil entPer = (EntPerfil)iterator3.next();
												if (entPer.getPerIdtChave().longValue() == entCmr.getEntComandoPerfil().getEntPerfil().getPerIdtChave().longValue())
													lstRegras.getLstRegraNegocio().add(entRng);
											}
										}
										
									} 
								}
//								sessionFactory.close();
							} 
							hibSession.close();
							hibSessionCmp.close();
						}

						// Insere no container o usu�rio, a pessoa, os perfis e as regras
						lstRegras.setEntUsuarioLogado(entUsu);
						lstRegras.setEntPessoaLogada(entUsu.getEntPessoa());
						lstRegras.setEntOrganizacao((EntOrganizacao)session.getAttribute(Constantes.ORGANIZACAO_ALVO));
						// F�bio - 20130801 - Testar o BtpLstRegras passando agora uma lista de organiza��es de confian�a.
						List<EntOrganizacao> l = new ArrayList<EntOrganizacao>();
						l.add((EntOrganizacao)session.getAttribute(Constantes.ORGANIZACAO_ALVO));
						
						// Organiza��es Liberadas (definidas no Constantes. Dever� ser migrado para um cadastro)
						Long[] lstOrgs = Constantes.ORGANIZACOES_LIBERADAS;
						for (int i = 0; i < lstOrgs.length; i++) 
						{
							EntOrganizacao orgPublica = new EntOrganizacao();
							orgPublica.setOrgIdtChave(lstOrgs[i]);
							l.add(orgPublica);
						}
						
						lstRegras.setLstOrganizacaoConfianca(l);
						lstRegras.setLstPerfis(lstPerfis);

						// Insere no container 
						BtpContainerRegras.set(lstRegras);
						
						retorno = true;
					}
		  		cont++;
		  	}
		} catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		retorno = true; // Est� liberando qualquer comando... Comentar isso depois !!!
	  	return retorno;
	  }
	
}
