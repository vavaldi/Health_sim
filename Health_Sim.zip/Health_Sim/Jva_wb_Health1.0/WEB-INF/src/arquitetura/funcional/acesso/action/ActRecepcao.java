package arquitetura.funcional.acesso.action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import arquitetura.funcional.acesso.negocio.NgcMenu;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.util.Constantes;
import arquitetura.funcional.health.entidades.EntComando;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntPessoa;
import arquitetura.funcional.health.negocio.NgcComando;


public class ActRecepcao extends ActBase
{

	public ActionForward inicializar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		HttpSession session = req.getSession();

		try 
		{
	    	// Captura da sess�o a pessoa logada
			EntPessoa entPes = (EntPessoa)session.getAttribute(Constantes.PESSOA_LOGADA);
	
	    	// Captura da sess�o as poss�veis organiza��es da pessoa logada
			List<EntOrganizacao> lOrg = ((List<EntOrganizacao>)session.getAttribute(Constantes.PESSOA_ORGANIZACOES));
			
			// Pega a organiza��o escolhida
			EntOrganizacao entOrgAlvo = new EntOrganizacao();
			if (null != req && null != req.getParameter("orgIdtChave"))
			{
				String codOrg = req.getParameter("orgIdtChave");
				if (null != codOrg && codOrg.length() > 0)
				{
					for (Iterator<EntOrganizacao> orgs = lOrg.iterator(); orgs.hasNext();) 
					{
						EntOrganizacao entOrganizacao = orgs.next();
						if (entOrganizacao.getOrgIdtChave().intValue() == Integer.valueOf(codOrg).intValue())
						{
							entOrgAlvo = entOrganizacao;
					    	session.setAttribute(Constantes.ORGANIZACAO_ALVO, entOrgAlvo);
							break;
						}
					}
				}
			}
			
			// Consulta as permiss�es para a primeira Organiza��o achada
	    	List<EntComando> p = new ArrayList<EntComando>();
			NgcComando ngc = new NgcComando();
	    	//if (null != lOrg && lOrg.size() > 0)
	        if (null != entOrgAlvo)
				p = ngc.consultarPermissao(entPes, entOrgAlvo);
			
			// Monta o menu principal
			NgcMenu ngcMenu = new NgcMenu();
			List menu = (List)ngcMenu.montarMenu(p, null);
			
			// Registra permiss�es na sess�o do usu�rio
	    	//session.setAttribute("usuario_logado", btp);
			session.setAttribute("permissao", p);    			
			session.setAttribute("menuPrincipal", menu);
	
	        return map.findForward("inicializarOrganizacao");
		} catch (Exception e) {
			// TODO: handle exception
			return map.getInputForward();
		}
	}
}
