package arquitetura.funcional.acesso.bean;

public class BtpLogin
{ 
	private String sistema;

	private String login;

	private String senha;

	private String novaSenha;

	private String confirmaSenha;
	
	private String nome; 

	public String getNome()
	{
		return nome;
	}

	public void setNome(String nome)
	{
		this.nome = nome;
	}

	public String getConfirmaSenha()
	{
		return confirmaSenha;
	}

	public void setConfirmaSenha(String confirmaSenha)
	{
		this.confirmaSenha = confirmaSenha;
	}


	public String getNovaSenha()
	{
		return novaSenha;
	}

	public void setNovaSenha(String novaSenha)
	{
		this.novaSenha = novaSenha;
	}

	public String getSenha()
	{
		return senha;
	}

	public void setSenha(String senha)
	{
		this.senha = senha;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSistema()
	{
		return sistema;
	}

	public void setSistema(String sistema)
	{
		this.sistema = sistema;
	}
}
