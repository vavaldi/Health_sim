package arquitetura.funcional.acesso.negocio;

import java.util.ArrayList;
import java.util.List;

import arquitetura.funcional.health.entidades.EntComando;

public class NgcMenu  
{
	public Object montarMenu(List permissoes, EntComando entPai)
	{
		// Cria entidade Comando
		EntComando entFilho = new EntComando();
		List<EntComando> menu = new ArrayList<EntComando>();
		int cont = 0;
		while (null != permissoes && cont < permissoes.size()) {
			entFilho = (EntComando) permissoes.get(cont);
			// Verifica se o comando da lista � descend�nte do comando pai.
			if (entFilho.getCmdFlgMenu() == 1 && isDescendente(entFilho, entPai))
			{
				menu.add(entFilho);
//				menu.remove(entFilho);
//				cont--;
			}
			cont++;
		}
		return menu;
	}

	protected boolean isDescendente(EntComando filho, EntComando pai)
	{
		// No caso do pai passado ser nulo, traz apenas os "filhos sem pai" (famoso "f� de moita"). 
		if (null == pai)
		{
			if (null == filho.getEntComandoPai())
				return true;
			else
				return false;
		}
		// Se o filho for nulo ou o mesmo n�o tiver pai, encerra a recurs�o.
		if (null == filho || null == filho.getEntComandoPai())
			return false;
		// Caso seja filho do pai passado...
		if (null != pai && filho.getEntComandoPai().getCmdIdtChave().equals(pai.getCmdIdtChave()))
			return true;
		else
			return isDescendente(filho.getEntComandoPai(), pai);
	}
}
