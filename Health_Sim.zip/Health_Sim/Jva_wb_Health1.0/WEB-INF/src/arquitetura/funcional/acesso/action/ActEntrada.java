package arquitetura.funcional.acesso.action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;

import arquitetura.funcional.acesso.bean.BtpLogin;
import arquitetura.funcional.acesso.negocio.NgcMenu;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.base.excecao.SerproException;
import arquitetura.funcional.base.util.Constantes;
import arquitetura.funcional.health.entidades.EntComando;
import arquitetura.funcional.health.entidades.EntOrganizacao;
import arquitetura.funcional.health.entidades.EntPapel;
import arquitetura.funcional.health.entidades.EntPerfil;
import arquitetura.funcional.health.entidades.EntPessoa;
import arquitetura.funcional.health.entidades.EntUsuario;
import arquitetura.funcional.health.negocio.NgcUsuario;


public class ActEntrada extends ActBase
{
//	@Override
//	public ActionForward execute(ActionMapping map, ActionForm form,
//			HttpServletRequest req, HttpServletResponse res) throws Exception
//	{
//
//		BtpLogin login = new BtpLogin();
//		DynaValidatorForm loginForm = (DynaValidatorForm) form;
//
//		login.setCpf((String) loginForm.get("cpf"));
//		login.setSenha((String) loginForm.get("senha"));
//		login.setNovaSenha((String) loginForm.get("novaSenha"));
//		login.setConfirmaSenha((String) loginForm.get("confirmaSenha"));
//		
//		try
//		{
//			NgcLogin ngcLogin = new NgcLogin();
//			Object o = ngcLogin.Consultar(login);
//			if (o != null)
//				return map.findForward("sucesso");
//		}
//		catch (SerproException e)
//		{
//			this.addErrosValidacao(e, req);
//		}
//		return map.findForward("erro");
//	}
	
	public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
//		return map.findForward("sucesso");
    	HttpSession session = req.getSession();
		BtpLogin btp = new BtpLogin();
		EntPessoa entPes = new EntPessoa();

		DynaValidatorForm frm = (DynaValidatorForm) form;

		// Trocar para CopyProperties
		btp.setSistema((String) frm.get("sistema"));
		btp.setLogin((String) frm.get("login"));
		btp.setSenha((String) frm.get("senha"));
		btp.setNovaSenha((String) frm.get("novaSenha"));
		btp.setConfirmaSenha((String) frm.get("confirmaSenha"));
		
		// Informa��es do Sistema
		int sistema = Constantes.SISTEMA;
		
		try
		{
			NgcUsuario ngc = new NgcUsuario();
			List<EntUsuario> lUsu = (List<EntUsuario>)ngc.autenticar(btp);
			EntUsuario entUsu = new EntUsuario();
			entUsu = (EntUsuario)lUsu.get(0);

			if (null != entUsu && null != entUsu.getUsuIdtChave())
			{
				// Busca os objetos Pessoa e Usu�rio
				if (null != entUsu.getEntPessoa())
					entPes = entUsu.getEntPessoa();
				
				// Insere objetos (entPessoa, entUsuario) na sess�o.
				session.setAttribute(Constantes.USUARIO_LOGADO, entUsu);
		    	session.setAttribute(Constantes.PESSOA_LOGADA, entPes);
		    	// Insere na sess�o as listas de Perfis e Organiza��es
		    	List<EntPerfil> lPer = new ArrayList<EntPerfil>();
		    	List<EntOrganizacao> lOrg = new ArrayList<EntOrganizacao>();
		    	List<EntPapel> lPap = new ArrayList<EntPapel>();
		    	lPap = entPes.getLstPapel();
	            
		    	for (Iterator iterator = lPap.iterator(); iterator.hasNext();) 
		    	{
					EntPapel entPap = (EntPapel) iterator.next();
					//if (entPap.getEntPerfil() != null && entPap.getEntPerfil().getEntSistema() != null && entPap.getEntPerfil().getEntSistema().getSisIdtChave().intValue() == Constantes.SISTEMA)
					if (entPap.getEntPerfil() != null && !lPer.contains(entPap.getEntPerfil()))
						lPer.add(entPap.getEntPerfil());
					if (entPap.getEntPerfil() != null && !lOrg.contains(entPap.getEntOrganizacao()))
						lOrg.add(entPap.getEntOrganizacao());
					
					// Ordena a lista
		            //lOrg = ordenarLista(lOrg, "orgDscFantasia"); 

					
					// Captura os perfis por Organiza��o
				}
		    	// Insere na sess�o os Perfis da Pessoa Logada
		    	session.setAttribute(Constantes.PESSOA_PERFIS, lPer);
		    	//session.setAttribute("lstPerfil", lPer); // Avaliar se pode ser removido.
		    	// Insere na sess�o as Organiza��es da Pessoa Logada
		    	session.setAttribute(Constantes.PESSOA_ORGANIZACOES, lOrg);
		    	
				// Consulta as permiss�es para a primeira Organiza��o achada
		    	List<EntComando> p = new ArrayList<EntComando>();
		    	if (null != lOrg && lOrg.size() > 0)
		    	{
		    		p = (List<EntComando>)ngc.registraPermissoes(entPes, lOrg.get(0));
			    	session.setAttribute(Constantes.ORGANIZACAO_ALVO, lOrg.get(0));
		    	}
		    	//List p = (List)ngc.registraPermissoes(btp);
				
				// Monta o menu principal
				NgcMenu ngcMenu = new NgcMenu();
				List menu = (List)ngcMenu.montarMenu(p, null);
				
				// Registra permiss�es na sess�o do usu�rio
		    	session.setAttribute("usuario_logado", btp);
				session.setAttribute("permissao", p);    			
				session.setAttribute("menuPrincipal", menu);
				

			} else
			{
				// Seta padr�es
		    	session.setAttribute(Constantes.USUARIO_LOGADO, new EntUsuario());
		    	session.setAttribute(Constantes.PESSOA_LOGADA, new EntPessoa());
		    	session.setAttribute(Constantes.PESSOA_PERFIS, new ArrayList());
		    	session.setAttribute(Constantes.PESSOA_ORGANIZACOES, new ArrayList());
		    	session.setAttribute(Constantes.ORGANIZACAO_ALVO, new EntOrganizacao());
			}
			return map.findForward("sucesso");
		}
		catch (SerproException e)
		{
			this.addErrosValidacao(e, req);
		}
		return map.findForward("erro");
	}

	public ActionForward inicializar(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
        return map.findForward("inicializarOrganizacao");
	}
}
