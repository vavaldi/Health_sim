package arquitetura.funcional.acesso.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import arquitetura.funcional.acesso.negocio.NgcMenu;
import arquitetura.funcional.base.action.ActBase;
import arquitetura.funcional.health.entidades.EntComando;
import arquitetura.funcional.health.negocio.NgcComando;

public class ActMenu extends ActBase 
{

	// M�todo que busca os comandos filhos de um determinado comando pai  
	public ActionForward prepararMenu(ActionMapping map, ActionForm form,
			HttpServletRequest req, HttpServletResponse res) throws Exception
	{
		// Captura o comando pai, se existir. 
		String strPai = (String)req.getParameter("pai");
		EntComando entPai = new EntComando();
		if (strPai.equals(""))
		{
			entPai = null;
		} else
		{
			NgcComando ngc = new NgcComando();
			entPai = (EntComando) ngc.consultarID(new Long(strPai));
		}
		// Busca a lista de permiss�es do usu�rio atualmente na sess�o 
		HttpSession sessao = req.getSession();
		List menu = new ArrayList();
		menu = (ArrayList)sessao.getAttribute("permissao");

		// Aciona o neg�cio
		NgcMenu ngc = new NgcMenu();
		menu = (ArrayList)ngc.montarMenu(menu, entPai);
		
		// Retorna a lista de permiss�es filtrada
		req.setAttribute("cmdPai", entPai);
		req.setAttribute("lstCmd", menu);
		return map.findForward("sucesso");
	}
	
}