-- Inser��o dos comandos
-- Vari�veis:
-- <COD_SISTEMA> C�digo do sistema.
-- <COD_ADMIN> C�digo do grupo de Administrador (acesso total)
-- <COD_FUNCIONALIDADES> C�digo do menu Funcionalidades.
-- <TIT_ENT> T�tulo da entidade a ser inserida (Ex. tipoAcesso)
-- <DSC_ENT> Descri��o da entidade a ser inserida (Ex. Tipo de Acesso)
-- <DATA> Data atual no formato 2007-03-13.
-- <ORDEM> Ordem no menu (formato '01.02.00').

-- Funcionalidades
--set IDENTITY_INSERT cmd_comando ON
-- Pegar o c�digo do menu Funcionalidades criado e substituir <COD_FUNCIONALIDADES> por ele.
--IF (SELECT COUNT(*) FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_LABEL like '%Funcionalidades%' AND CMD_DSC_ACAO = 'menu.do?metodo=prepararMenu') = 0
--	INSERT INTO cmd_comando (SIS_IDT_CHAVE, CMD_IDT_CHAVE_PAI, CMD_DSC_LABEL, CMD_DSC_ACAO, CMD_DAT_ATIVACAO, CMD_FLG_MENU, CMD_DSC_ORDEM) VALUES 
--	(<COD_SISTEMA>, NULL, 'Funcionalidades', 'menu.do?metodo=prepararMenu', getDate(), 1, '01.00.00')

INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, NULL, 'Funcionalidades', 'menu.do?metodo=prepararMenu', curDate(), 1, '01.00.00' FROM con_configuracao
  WHERE NOT EXISTS (SELECT COUNT(*) FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_LABEL like '%Funcionalidades%' AND CMD_DSC_ACAO = 'menu.do?metodo=prepararMenu'); 
	
--set IDENTITY_INSERT cmd_comando OFF

 

-- ComandoRegra --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoRegra', 'comandoRegraConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoRegraConsulta.do?metodo=prepararConsultar'); 
    
-- ComandoRegra - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoRegra - Consultar', 'comandoRegraConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoRegraConsulta.do?metodo=Consultar'); 
    
-- ComandoRegra - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoRegra', 'comandoRegraConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoRegraConsulta.do?metodo=prepararSelecionar'); 
    
-- ComandoRegra - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoRegra - Selecionar', 'comandoRegraConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoRegraConsulta.do?metodo=selecionar'); 
    
-- ComandoRegra - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoRegra - Visualizar', 'comandoRegra.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoRegra.do?metodo=visualizar'); 
    
-- ComandoRegra - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoRegra - Preparar Alterar', 'comandoRegra.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoRegra.do?metodo=prepararAlterar'); 
    
-- ComandoRegra - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoRegra - Alterar', 'comandoRegra.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoRegra.do?metodo=Alterar'); 
    
-- ComandoRegra - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoRegra - Excluir', 'comandoRegra.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoRegra.do?metodo=excluir'); 
    
-- ComandoRegra - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoRegra - Preparar Incluir', 'comandoRegra.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoRegra.do?metodo=prepararIncluir'); 
    
-- ComandoRegra - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoRegra - Incluir', 'comandoRegra.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoRegra.do?metodo=incluir'); 
    
    
    
-- Comando --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Comando', 'comandoConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoConsulta.do?metodo=prepararConsultar'); 
    
-- Comando - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Comando - Consultar', 'comandoConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoConsulta.do?metodo=Consultar'); 
    
-- Comando - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Comando', 'comandoConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoConsulta.do?metodo=prepararSelecionar'); 
    
-- Comando - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Comando - Selecionar', 'comandoConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoConsulta.do?metodo=selecionar'); 
    
-- Comando - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Comando - Visualizar', 'comando.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comando.do?metodo=visualizar'); 
    
-- Comando - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Comando - Preparar Alterar', 'comando.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comando.do?metodo=prepararAlterar'); 
    
-- Comando - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Comando - Alterar', 'comando.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comando.do?metodo=Alterar'); 
    
-- Comando - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Comando - Excluir', 'comando.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comando.do?metodo=excluir'); 
    
-- Comando - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Comando - Preparar Incluir', 'comando.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comando.do?metodo=prepararIncluir'); 
    
-- Comando - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Comando - Incluir', 'comando.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comando.do?metodo=incluir'); 
    
    
    
-- ComandoPerfil --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoPerfil', 'comandoPerfilConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoPerfilConsulta.do?metodo=prepararConsultar'); 
    
-- ComandoPerfil - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoPerfil - Consultar', 'comandoPerfilConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoPerfilConsulta.do?metodo=Consultar'); 
    
-- ComandoPerfil - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoPerfil', 'comandoPerfilConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoPerfilConsulta.do?metodo=prepararSelecionar'); 
    
-- ComandoPerfil - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoPerfil - Selecionar', 'comandoPerfilConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoPerfilConsulta.do?metodo=selecionar'); 
    
-- ComandoPerfil - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoPerfil - Visualizar', 'comandoPerfil.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoPerfil.do?metodo=visualizar'); 
    
-- ComandoPerfil - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoPerfil - Preparar Alterar', 'comandoPerfil.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoPerfil.do?metodo=prepararAlterar'); 
    
-- ComandoPerfil - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoPerfil - Alterar', 'comandoPerfil.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoPerfil.do?metodo=Alterar'); 
    
-- ComandoPerfil - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoPerfil - Excluir', 'comandoPerfil.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoPerfil.do?metodo=excluir'); 
    
-- ComandoPerfil - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoPerfil - Preparar Incluir', 'comandoPerfil.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoPerfil.do?metodo=prepararIncluir'); 
    
-- ComandoPerfil - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoPerfil - Incluir', 'comandoPerfil.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoPerfil.do?metodo=incluir'); 
    
    
    
-- ComandoperfilRegra --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoperfilRegra', 'comandoperfilRegraConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoperfilRegraConsulta.do?metodo=prepararConsultar'); 
    
-- ComandoperfilRegra - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoperfilRegra - Consultar', 'comandoperfilRegraConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoperfilRegraConsulta.do?metodo=Consultar'); 
    
-- ComandoperfilRegra - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoperfilRegra', 'comandoperfilRegraConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoperfilRegraConsulta.do?metodo=prepararSelecionar'); 
    
-- ComandoperfilRegra - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoperfilRegra - Selecionar', 'comandoperfilRegraConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoperfilRegraConsulta.do?metodo=selecionar'); 
    
-- ComandoperfilRegra - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoperfilRegra - Visualizar', 'comandoperfilRegra.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoperfilRegra.do?metodo=visualizar'); 
    
-- ComandoperfilRegra - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoperfilRegra - Preparar Alterar', 'comandoperfilRegra.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoperfilRegra.do?metodo=prepararAlterar'); 
    
-- ComandoperfilRegra - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoperfilRegra - Alterar', 'comandoperfilRegra.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoperfilRegra.do?metodo=Alterar'); 
    
-- ComandoperfilRegra - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoperfilRegra - Excluir', 'comandoperfilRegra.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoperfilRegra.do?metodo=excluir'); 
    
-- ComandoperfilRegra - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoperfilRegra - Preparar Incluir', 'comandoperfilRegra.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoperfilRegra.do?metodo=prepararIncluir'); 
    
-- ComandoperfilRegra - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'ComandoperfilRegra - Incluir', 'comandoperfilRegra.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='comandoperfilRegra.do?metodo=incluir'); 
    
    
    
-- Configuracao --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Configuracao', 'configuracaoConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='configuracaoConsulta.do?metodo=prepararConsultar'); 
    
-- Configuracao - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Configuracao - Consultar', 'configuracaoConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='configuracaoConsulta.do?metodo=Consultar'); 
    
-- Configuracao - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Configuracao', 'configuracaoConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='configuracaoConsulta.do?metodo=prepararSelecionar'); 
    
-- Configuracao - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Configuracao - Selecionar', 'configuracaoConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='configuracaoConsulta.do?metodo=selecionar'); 
    
-- Configuracao - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Configuracao - Visualizar', 'configuracao.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='configuracao.do?metodo=visualizar'); 
    
-- Configuracao - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Configuracao - Preparar Alterar', 'configuracao.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='configuracao.do?metodo=prepararAlterar'); 
    
-- Configuracao - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Configuracao - Alterar', 'configuracao.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='configuracao.do?metodo=Alterar'); 
    
-- Configuracao - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Configuracao - Excluir', 'configuracao.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='configuracao.do?metodo=excluir'); 
    
-- Configuracao - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Configuracao - Preparar Incluir', 'configuracao.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='configuracao.do?metodo=prepararIncluir'); 
    
-- Configuracao - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Configuracao - Incluir', 'configuracao.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='configuracao.do?metodo=incluir'); 
    
    
    
-- Contamination --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Contamination', 'contaminationConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='contaminationConsulta.do?metodo=prepararConsultar'); 
    
-- Contamination - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Contamination - Consultar', 'contaminationConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='contaminationConsulta.do?metodo=Consultar'); 
    
-- Contamination - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Contamination', 'contaminationConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='contaminationConsulta.do?metodo=prepararSelecionar'); 
    
-- Contamination - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Contamination - Selecionar', 'contaminationConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='contaminationConsulta.do?metodo=selecionar'); 
    
-- Contamination - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Contamination - Visualizar', 'contamination.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='contamination.do?metodo=visualizar'); 
    
-- Contamination - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Contamination - Preparar Alterar', 'contamination.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='contamination.do?metodo=prepararAlterar'); 
    
-- Contamination - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Contamination - Alterar', 'contamination.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='contamination.do?metodo=Alterar'); 
    
-- Contamination - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Contamination - Excluir', 'contamination.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='contamination.do?metodo=excluir'); 
    
-- Contamination - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Contamination - Preparar Incluir', 'contamination.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='contamination.do?metodo=prepararIncluir'); 
    
-- Contamination - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Contamination - Incluir', 'contamination.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='contamination.do?metodo=incluir'); 
    
    
    
-- Coordonees --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Coordonees', 'coordoneesConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='coordoneesConsulta.do?metodo=prepararConsultar'); 
    
-- Coordonees - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Coordonees - Consultar', 'coordoneesConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='coordoneesConsulta.do?metodo=Consultar'); 
    
-- Coordonees - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Coordonees', 'coordoneesConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='coordoneesConsulta.do?metodo=prepararSelecionar'); 
    
-- Coordonees - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Coordonees - Selecionar', 'coordoneesConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='coordoneesConsulta.do?metodo=selecionar'); 
    
-- Coordonees - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Coordonees - Visualizar', 'coordonees.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='coordonees.do?metodo=visualizar'); 
    
-- Coordonees - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Coordonees - Preparar Alterar', 'coordonees.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='coordonees.do?metodo=prepararAlterar'); 
    
-- Coordonees - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Coordonees - Alterar', 'coordonees.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='coordonees.do?metodo=Alterar'); 
    
-- Coordonees - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Coordonees - Excluir', 'coordonees.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='coordonees.do?metodo=excluir'); 
    
-- Coordonees - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Coordonees - Preparar Incluir', 'coordonees.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='coordonees.do?metodo=prepararIncluir'); 
    
-- Coordonees - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Coordonees - Incluir', 'coordonees.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='coordonees.do?metodo=incluir'); 
    
    
    
-- Deplacement --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Deplacement', 'deplacementConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='deplacementConsulta.do?metodo=prepararConsultar'); 
    
-- Deplacement - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Deplacement - Consultar', 'deplacementConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='deplacementConsulta.do?metodo=Consultar'); 
    
-- Deplacement - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Deplacement', 'deplacementConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='deplacementConsulta.do?metodo=prepararSelecionar'); 
    
-- Deplacement - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Deplacement - Selecionar', 'deplacementConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='deplacementConsulta.do?metodo=selecionar'); 
    
-- Deplacement - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Deplacement - Visualizar', 'deplacement.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='deplacement.do?metodo=visualizar'); 
    
-- Deplacement - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Deplacement - Preparar Alterar', 'deplacement.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='deplacement.do?metodo=prepararAlterar'); 
    
-- Deplacement - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Deplacement - Alterar', 'deplacement.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='deplacement.do?metodo=Alterar'); 
    
-- Deplacement - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Deplacement - Excluir', 'deplacement.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='deplacement.do?metodo=excluir'); 
    
-- Deplacement - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Deplacement - Preparar Incluir', 'deplacement.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='deplacement.do?metodo=prepararIncluir'); 
    
-- Deplacement - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Deplacement - Incluir', 'deplacement.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='deplacement.do?metodo=incluir'); 
    
    
    
-- EtatSante --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'EtatSante', 'etatSanteConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='etatSanteConsulta.do?metodo=prepararConsultar'); 
    
-- EtatSante - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'EtatSante - Consultar', 'etatSanteConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='etatSanteConsulta.do?metodo=Consultar'); 
    
-- EtatSante - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'EtatSante', 'etatSanteConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='etatSanteConsulta.do?metodo=prepararSelecionar'); 
    
-- EtatSante - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'EtatSante - Selecionar', 'etatSanteConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='etatSanteConsulta.do?metodo=selecionar'); 
    
-- EtatSante - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'EtatSante - Visualizar', 'etatSante.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='etatSante.do?metodo=visualizar'); 
    
-- EtatSante - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'EtatSante - Preparar Alterar', 'etatSante.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='etatSante.do?metodo=prepararAlterar'); 
    
-- EtatSante - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'EtatSante - Alterar', 'etatSante.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='etatSante.do?metodo=Alterar'); 
    
-- EtatSante - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'EtatSante - Excluir', 'etatSante.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='etatSante.do?metodo=excluir'); 
    
-- EtatSante - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'EtatSante - Preparar Incluir', 'etatSante.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='etatSante.do?metodo=prepararIncluir'); 
    
-- EtatSante - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'EtatSante - Incluir', 'etatSante.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='etatSante.do?metodo=incluir'); 
    
    
    
-- Modele --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Modele', 'modeleConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='modeleConsulta.do?metodo=prepararConsultar'); 
    
-- Modele - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Modele - Consultar', 'modeleConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='modeleConsulta.do?metodo=Consultar'); 
    
-- Modele - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Modele', 'modeleConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='modeleConsulta.do?metodo=prepararSelecionar'); 
    
-- Modele - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Modele - Selecionar', 'modeleConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='modeleConsulta.do?metodo=selecionar'); 
    
-- Modele - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Modele - Visualizar', 'modele.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='modele.do?metodo=visualizar'); 
    
-- Modele - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Modele - Preparar Alterar', 'modele.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='modele.do?metodo=prepararAlterar'); 
    
-- Modele - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Modele - Alterar', 'modele.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='modele.do?metodo=Alterar'); 
    
-- Modele - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Modele - Excluir', 'modele.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='modele.do?metodo=excluir'); 
    
-- Modele - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Modele - Preparar Incluir', 'modele.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='modele.do?metodo=prepararIncluir'); 
    
-- Modele - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Modele - Incluir', 'modele.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='modele.do?metodo=incluir'); 
    
    
    
-- Maladie --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Maladie', 'maladieConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='maladieConsulta.do?metodo=prepararConsultar'); 
    
-- Maladie - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Maladie - Consultar', 'maladieConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='maladieConsulta.do?metodo=Consultar'); 
    
-- Maladie - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Maladie', 'maladieConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='maladieConsulta.do?metodo=prepararSelecionar'); 
    
-- Maladie - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Maladie - Selecionar', 'maladieConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='maladieConsulta.do?metodo=selecionar'); 
    
-- Maladie - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Maladie - Visualizar', 'maladie.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='maladie.do?metodo=visualizar'); 
    
-- Maladie - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Maladie - Preparar Alterar', 'maladie.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='maladie.do?metodo=prepararAlterar'); 
    
-- Maladie - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Maladie - Alterar', 'maladie.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='maladie.do?metodo=Alterar'); 
    
-- Maladie - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Maladie - Excluir', 'maladie.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='maladie.do?metodo=excluir'); 
    
-- Maladie - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Maladie - Preparar Incluir', 'maladie.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='maladie.do?metodo=prepararIncluir'); 
    
-- Maladie - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Maladie - Incluir', 'maladie.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='maladie.do?metodo=incluir'); 
    
    
    
-- Noeud --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Noeud', 'noeudConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='noeudConsulta.do?metodo=prepararConsultar'); 
    
-- Noeud - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Noeud - Consultar', 'noeudConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='noeudConsulta.do?metodo=Consultar'); 
    
-- Noeud - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Noeud', 'noeudConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='noeudConsulta.do?metodo=prepararSelecionar'); 
    
-- Noeud - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Noeud - Selecionar', 'noeudConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='noeudConsulta.do?metodo=selecionar'); 
    
-- Noeud - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Noeud - Visualizar', 'noeud.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='noeud.do?metodo=visualizar'); 
    
-- Noeud - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Noeud - Preparar Alterar', 'noeud.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='noeud.do?metodo=prepararAlterar'); 
    
-- Noeud - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Noeud - Alterar', 'noeud.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='noeud.do?metodo=Alterar'); 
    
-- Noeud - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Noeud - Excluir', 'noeud.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='noeud.do?metodo=excluir'); 
    
-- Noeud - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Noeud - Preparar Incluir', 'noeud.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='noeud.do?metodo=prepararIncluir'); 
    
-- Noeud - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Noeud - Incluir', 'noeud.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='noeud.do?metodo=incluir'); 
    
    
    
-- Organizacao --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Organizacao', 'organizacaoConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='organizacaoConsulta.do?metodo=prepararConsultar'); 
    
-- Organizacao - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Organizacao - Consultar', 'organizacaoConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='organizacaoConsulta.do?metodo=Consultar'); 
    
-- Organizacao - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Organizacao', 'organizacaoConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='organizacaoConsulta.do?metodo=prepararSelecionar'); 
    
-- Organizacao - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Organizacao - Selecionar', 'organizacaoConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='organizacaoConsulta.do?metodo=selecionar'); 
    
-- Organizacao - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Organizacao - Visualizar', 'organizacao.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='organizacao.do?metodo=visualizar'); 
    
-- Organizacao - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Organizacao - Preparar Alterar', 'organizacao.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='organizacao.do?metodo=prepararAlterar'); 
    
-- Organizacao - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Organizacao - Alterar', 'organizacao.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='organizacao.do?metodo=Alterar'); 
    
-- Organizacao - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Organizacao - Excluir', 'organizacao.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='organizacao.do?metodo=excluir'); 
    
-- Organizacao - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Organizacao - Preparar Incluir', 'organizacao.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='organizacao.do?metodo=prepararIncluir'); 
    
-- Organizacao - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Organizacao - Incluir', 'organizacao.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='organizacao.do?metodo=incluir'); 
    
    
    
-- Papel --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Papel', 'papelConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='papelConsulta.do?metodo=prepararConsultar'); 
    
-- Papel - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Papel - Consultar', 'papelConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='papelConsulta.do?metodo=Consultar'); 
    
-- Papel - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Papel', 'papelConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='papelConsulta.do?metodo=prepararSelecionar'); 
    
-- Papel - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Papel - Selecionar', 'papelConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='papelConsulta.do?metodo=selecionar'); 
    
-- Papel - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Papel - Visualizar', 'papel.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='papel.do?metodo=visualizar'); 
    
-- Papel - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Papel - Preparar Alterar', 'papel.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='papel.do?metodo=prepararAlterar'); 
    
-- Papel - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Papel - Alterar', 'papel.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='papel.do?metodo=Alterar'); 
    
-- Papel - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Papel - Excluir', 'papel.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='papel.do?metodo=excluir'); 
    
-- Papel - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Papel - Preparar Incluir', 'papel.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='papel.do?metodo=prepararIncluir'); 
    
-- Papel - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Papel - Incluir', 'papel.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='papel.do?metodo=incluir'); 
    
    
    
-- Perfil --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Perfil', 'perfilConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilConsulta.do?metodo=prepararConsultar'); 
    
-- Perfil - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Perfil - Consultar', 'perfilConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilConsulta.do?metodo=Consultar'); 
    
-- Perfil - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Perfil', 'perfilConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilConsulta.do?metodo=prepararSelecionar'); 
    
-- Perfil - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Perfil - Selecionar', 'perfilConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilConsulta.do?metodo=selecionar'); 
    
-- Perfil - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Perfil - Visualizar', 'perfil.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfil.do?metodo=visualizar'); 
    
-- Perfil - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Perfil - Preparar Alterar', 'perfil.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfil.do?metodo=prepararAlterar'); 
    
-- Perfil - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Perfil - Alterar', 'perfil.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfil.do?metodo=Alterar'); 
    
-- Perfil - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Perfil - Excluir', 'perfil.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfil.do?metodo=excluir'); 
    
-- Perfil - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Perfil - Preparar Incluir', 'perfil.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfil.do?metodo=prepararIncluir'); 
    
-- Perfil - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Perfil - Incluir', 'perfil.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfil.do?metodo=incluir'); 
    
    
    
-- Pessoa --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Pessoa', 'pessoaConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='pessoaConsulta.do?metodo=prepararConsultar'); 
    
-- Pessoa - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Pessoa - Consultar', 'pessoaConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='pessoaConsulta.do?metodo=Consultar'); 
    
-- Pessoa - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Pessoa', 'pessoaConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='pessoaConsulta.do?metodo=prepararSelecionar'); 
    
-- Pessoa - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Pessoa - Selecionar', 'pessoaConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='pessoaConsulta.do?metodo=selecionar'); 
    
-- Pessoa - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Pessoa - Visualizar', 'pessoa.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='pessoa.do?metodo=visualizar'); 
    
-- Pessoa - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Pessoa - Preparar Alterar', 'pessoa.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='pessoa.do?metodo=prepararAlterar'); 
    
-- Pessoa - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Pessoa - Alterar', 'pessoa.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='pessoa.do?metodo=Alterar'); 
    
-- Pessoa - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Pessoa - Excluir', 'pessoa.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='pessoa.do?metodo=excluir'); 
    
-- Pessoa - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Pessoa - Preparar Incluir', 'pessoa.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='pessoa.do?metodo=prepararIncluir'); 
    
-- Pessoa - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Pessoa - Incluir', 'pessoa.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='pessoa.do?metodo=incluir'); 
    
    
    
-- PerfilUsuario --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'PerfilUsuario', 'perfilUsuarioConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilUsuarioConsulta.do?metodo=prepararConsultar'); 
    
-- PerfilUsuario - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'PerfilUsuario - Consultar', 'perfilUsuarioConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilUsuarioConsulta.do?metodo=Consultar'); 
    
-- PerfilUsuario - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'PerfilUsuario', 'perfilUsuarioConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilUsuarioConsulta.do?metodo=prepararSelecionar'); 
    
-- PerfilUsuario - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'PerfilUsuario - Selecionar', 'perfilUsuarioConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilUsuarioConsulta.do?metodo=selecionar'); 
    
-- PerfilUsuario - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'PerfilUsuario - Visualizar', 'perfilUsuario.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilUsuario.do?metodo=visualizar'); 
    
-- PerfilUsuario - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'PerfilUsuario - Preparar Alterar', 'perfilUsuario.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilUsuario.do?metodo=prepararAlterar'); 
    
-- PerfilUsuario - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'PerfilUsuario - Alterar', 'perfilUsuario.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilUsuario.do?metodo=Alterar'); 
    
-- PerfilUsuario - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'PerfilUsuario - Excluir', 'perfilUsuario.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilUsuario.do?metodo=excluir'); 
    
-- PerfilUsuario - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'PerfilUsuario - Preparar Incluir', 'perfilUsuario.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilUsuario.do?metodo=prepararIncluir'); 
    
-- PerfilUsuario - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'PerfilUsuario - Incluir', 'perfilUsuario.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='perfilUsuario.do?metodo=incluir'); 
    
    
    
-- RegraNegocio --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'RegraNegocio', 'regraNegocioConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='regraNegocioConsulta.do?metodo=prepararConsultar'); 
    
-- RegraNegocio - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'RegraNegocio - Consultar', 'regraNegocioConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='regraNegocioConsulta.do?metodo=Consultar'); 
    
-- RegraNegocio - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'RegraNegocio', 'regraNegocioConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='regraNegocioConsulta.do?metodo=prepararSelecionar'); 
    
-- RegraNegocio - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'RegraNegocio - Selecionar', 'regraNegocioConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='regraNegocioConsulta.do?metodo=selecionar'); 
    
-- RegraNegocio - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'RegraNegocio - Visualizar', 'regraNegocio.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='regraNegocio.do?metodo=visualizar'); 
    
-- RegraNegocio - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'RegraNegocio - Preparar Alterar', 'regraNegocio.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='regraNegocio.do?metodo=prepararAlterar'); 
    
-- RegraNegocio - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'RegraNegocio - Alterar', 'regraNegocio.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='regraNegocio.do?metodo=Alterar'); 
    
-- RegraNegocio - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'RegraNegocio - Excluir', 'regraNegocio.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='regraNegocio.do?metodo=excluir'); 
    
-- RegraNegocio - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'RegraNegocio - Preparar Incluir', 'regraNegocio.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='regraNegocio.do?metodo=prepararIncluir'); 
    
-- RegraNegocio - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'RegraNegocio - Incluir', 'regraNegocio.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='regraNegocio.do?metodo=incluir'); 
    
    
    
-- Scenario --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Scenario', 'scenarioConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='scenarioConsulta.do?metodo=prepararConsultar'); 
    
-- Scenario - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Scenario - Consultar', 'scenarioConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='scenarioConsulta.do?metodo=Consultar'); 
    
-- Scenario - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Scenario', 'scenarioConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='scenarioConsulta.do?metodo=prepararSelecionar'); 
    
-- Scenario - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Scenario - Selecionar', 'scenarioConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='scenarioConsulta.do?metodo=selecionar'); 
    
-- Scenario - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Scenario - Visualizar', 'scenario.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='scenario.do?metodo=visualizar'); 
    
-- Scenario - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Scenario - Preparar Alterar', 'scenario.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='scenario.do?metodo=prepararAlterar'); 
    
-- Scenario - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Scenario - Alterar', 'scenario.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='scenario.do?metodo=Alterar'); 
    
-- Scenario - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Scenario - Excluir', 'scenario.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='scenario.do?metodo=excluir'); 
    
-- Scenario - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Scenario - Preparar Incluir', 'scenario.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='scenario.do?metodo=prepararIncluir'); 
    
-- Scenario - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Scenario - Incluir', 'scenario.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='scenario.do?metodo=incluir'); 
    
    
    
-- Sistema --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Sistema', 'sistemaConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaConsulta.do?metodo=prepararConsultar'); 
    
-- Sistema - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Sistema - Consultar', 'sistemaConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaConsulta.do?metodo=Consultar'); 
    
-- Sistema - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Sistema', 'sistemaConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaConsulta.do?metodo=prepararSelecionar'); 
    
-- Sistema - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Sistema - Selecionar', 'sistemaConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaConsulta.do?metodo=selecionar'); 
    
-- Sistema - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Sistema - Visualizar', 'sistema.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistema.do?metodo=visualizar'); 
    
-- Sistema - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Sistema - Preparar Alterar', 'sistema.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistema.do?metodo=prepararAlterar'); 
    
-- Sistema - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Sistema - Alterar', 'sistema.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistema.do?metodo=Alterar'); 
    
-- Sistema - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Sistema - Excluir', 'sistema.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistema.do?metodo=excluir'); 
    
-- Sistema - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Sistema - Preparar Incluir', 'sistema.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistema.do?metodo=prepararIncluir'); 
    
-- Sistema - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Sistema - Incluir', 'sistema.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistema.do?metodo=incluir'); 
    
    
    
-- StatutSante --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'StatutSante', 'statutSanteConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='statutSanteConsulta.do?metodo=prepararConsultar'); 
    
-- StatutSante - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'StatutSante - Consultar', 'statutSanteConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='statutSanteConsulta.do?metodo=Consultar'); 
    
-- StatutSante - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'StatutSante', 'statutSanteConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='statutSanteConsulta.do?metodo=prepararSelecionar'); 
    
-- StatutSante - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'StatutSante - Selecionar', 'statutSanteConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='statutSanteConsulta.do?metodo=selecionar'); 
    
-- StatutSante - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'StatutSante - Visualizar', 'statutSante.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='statutSante.do?metodo=visualizar'); 
    
-- StatutSante - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'StatutSante - Preparar Alterar', 'statutSante.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='statutSante.do?metodo=prepararAlterar'); 
    
-- StatutSante - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'StatutSante - Alterar', 'statutSante.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='statutSante.do?metodo=Alterar'); 
    
-- StatutSante - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'StatutSante - Excluir', 'statutSante.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='statutSante.do?metodo=excluir'); 
    
-- StatutSante - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'StatutSante - Preparar Incluir', 'statutSante.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='statutSante.do?metodo=prepararIncluir'); 
    
-- StatutSante - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'StatutSante - Incluir', 'statutSante.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='statutSante.do?metodo=incluir'); 
    
    
    
-- SistemaUsuario --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'SistemaUsuario', 'sistemaUsuarioConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaUsuarioConsulta.do?metodo=prepararConsultar'); 
    
-- SistemaUsuario - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'SistemaUsuario - Consultar', 'sistemaUsuarioConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaUsuarioConsulta.do?metodo=Consultar'); 
    
-- SistemaUsuario - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'SistemaUsuario', 'sistemaUsuarioConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaUsuarioConsulta.do?metodo=prepararSelecionar'); 
    
-- SistemaUsuario - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'SistemaUsuario - Selecionar', 'sistemaUsuarioConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaUsuarioConsulta.do?metodo=selecionar'); 
    
-- SistemaUsuario - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'SistemaUsuario - Visualizar', 'sistemaUsuario.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaUsuario.do?metodo=visualizar'); 
    
-- SistemaUsuario - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'SistemaUsuario - Preparar Alterar', 'sistemaUsuario.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaUsuario.do?metodo=prepararAlterar'); 
    
-- SistemaUsuario - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'SistemaUsuario - Alterar', 'sistemaUsuario.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaUsuario.do?metodo=Alterar'); 
    
-- SistemaUsuario - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'SistemaUsuario - Excluir', 'sistemaUsuario.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaUsuario.do?metodo=excluir'); 
    
-- SistemaUsuario - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'SistemaUsuario - Preparar Incluir', 'sistemaUsuario.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaUsuario.do?metodo=prepararIncluir'); 
    
-- SistemaUsuario - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'SistemaUsuario - Incluir', 'sistemaUsuario.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='sistemaUsuario.do?metodo=incluir'); 
    
    
    
-- TipoOrganizacao --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoOrganizacao', 'tipoOrganizacaoConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoOrganizacaoConsulta.do?metodo=prepararConsultar'); 
    
-- TipoOrganizacao - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoOrganizacao - Consultar', 'tipoOrganizacaoConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoOrganizacaoConsulta.do?metodo=Consultar'); 
    
-- TipoOrganizacao - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoOrganizacao', 'tipoOrganizacaoConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoOrganizacaoConsulta.do?metodo=prepararSelecionar'); 
    
-- TipoOrganizacao - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoOrganizacao - Selecionar', 'tipoOrganizacaoConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoOrganizacaoConsulta.do?metodo=selecionar'); 
    
-- TipoOrganizacao - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoOrganizacao - Visualizar', 'tipoOrganizacao.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoOrganizacao.do?metodo=visualizar'); 
    
-- TipoOrganizacao - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoOrganizacao - Preparar Alterar', 'tipoOrganizacao.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoOrganizacao.do?metodo=prepararAlterar'); 
    
-- TipoOrganizacao - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoOrganizacao - Alterar', 'tipoOrganizacao.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoOrganizacao.do?metodo=Alterar'); 
    
-- TipoOrganizacao - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoOrganizacao - Excluir', 'tipoOrganizacao.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoOrganizacao.do?metodo=excluir'); 
    
-- TipoOrganizacao - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoOrganizacao - Preparar Incluir', 'tipoOrganizacao.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoOrganizacao.do?metodo=prepararIncluir'); 
    
-- TipoOrganizacao - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoOrganizacao - Incluir', 'tipoOrganizacao.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoOrganizacao.do?metodo=incluir'); 
    
    
    
-- TipoAcesso --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoAcesso', 'tipoAcessoConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoAcessoConsulta.do?metodo=prepararConsultar'); 
    
-- TipoAcesso - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoAcesso - Consultar', 'tipoAcessoConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoAcessoConsulta.do?metodo=Consultar'); 
    
-- TipoAcesso - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoAcesso', 'tipoAcessoConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoAcessoConsulta.do?metodo=prepararSelecionar'); 
    
-- TipoAcesso - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoAcesso - Selecionar', 'tipoAcessoConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoAcessoConsulta.do?metodo=selecionar'); 
    
-- TipoAcesso - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoAcesso - Visualizar', 'tipoAcesso.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoAcesso.do?metodo=visualizar'); 
    
-- TipoAcesso - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoAcesso - Preparar Alterar', 'tipoAcesso.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoAcesso.do?metodo=prepararAlterar'); 
    
-- TipoAcesso - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoAcesso - Alterar', 'tipoAcesso.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoAcesso.do?metodo=Alterar'); 
    
-- TipoAcesso - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoAcesso - Excluir', 'tipoAcesso.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoAcesso.do?metodo=excluir'); 
    
-- TipoAcesso - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoAcesso - Preparar Incluir', 'tipoAcesso.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoAcesso.do?metodo=prepararIncluir'); 
    
-- TipoAcesso - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoAcesso - Incluir', 'tipoAcesso.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoAcesso.do?metodo=incluir'); 
    
    
    
-- TipoPessoa --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoPessoa', 'tipoPessoaConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoPessoaConsulta.do?metodo=prepararConsultar'); 
    
-- TipoPessoa - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoPessoa - Consultar', 'tipoPessoaConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoPessoaConsulta.do?metodo=Consultar'); 
    
-- TipoPessoa - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoPessoa', 'tipoPessoaConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoPessoaConsulta.do?metodo=prepararSelecionar'); 
    
-- TipoPessoa - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoPessoa - Selecionar', 'tipoPessoaConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoPessoaConsulta.do?metodo=selecionar'); 
    
-- TipoPessoa - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoPessoa - Visualizar', 'tipoPessoa.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoPessoa.do?metodo=visualizar'); 
    
-- TipoPessoa - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoPessoa - Preparar Alterar', 'tipoPessoa.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoPessoa.do?metodo=prepararAlterar'); 
    
-- TipoPessoa - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoPessoa - Alterar', 'tipoPessoa.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoPessoa.do?metodo=Alterar'); 
    
-- TipoPessoa - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoPessoa - Excluir', 'tipoPessoa.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoPessoa.do?metodo=excluir'); 
    
-- TipoPessoa - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoPessoa - Preparar Incluir', 'tipoPessoa.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoPessoa.do?metodo=prepararIncluir'); 
    
-- TipoPessoa - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoPessoa - Incluir', 'tipoPessoa.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoPessoa.do?metodo=incluir'); 
    
    
    
-- TipoRegra --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoRegra', 'tipoRegraConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoRegraConsulta.do?metodo=prepararConsultar'); 
    
-- TipoRegra - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoRegra - Consultar', 'tipoRegraConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoRegraConsulta.do?metodo=Consultar'); 
    
-- TipoRegra - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoRegra', 'tipoRegraConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoRegraConsulta.do?metodo=prepararSelecionar'); 
    
-- TipoRegra - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoRegra - Selecionar', 'tipoRegraConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoRegraConsulta.do?metodo=selecionar'); 
    
-- TipoRegra - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoRegra - Visualizar', 'tipoRegra.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoRegra.do?metodo=visualizar'); 
    
-- TipoRegra - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoRegra - Preparar Alterar', 'tipoRegra.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoRegra.do?metodo=prepararAlterar'); 
    
-- TipoRegra - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoRegra - Alterar', 'tipoRegra.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoRegra.do?metodo=Alterar'); 
    
-- TipoRegra - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoRegra - Excluir', 'tipoRegra.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoRegra.do?metodo=excluir'); 
    
-- TipoRegra - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoRegra - Preparar Incluir', 'tipoRegra.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoRegra.do?metodo=prepararIncluir'); 
    
-- TipoRegra - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoRegra - Incluir', 'tipoRegra.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoRegra.do?metodo=incluir'); 
    
    
    
-- TipoSexo --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoSexo', 'tipoSexoConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoSexoConsulta.do?metodo=prepararConsultar'); 
    
-- TipoSexo - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoSexo - Consultar', 'tipoSexoConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoSexoConsulta.do?metodo=Consultar'); 
    
-- TipoSexo - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoSexo', 'tipoSexoConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoSexoConsulta.do?metodo=prepararSelecionar'); 
    
-- TipoSexo - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoSexo - Selecionar', 'tipoSexoConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoSexoConsulta.do?metodo=selecionar'); 
    
-- TipoSexo - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoSexo - Visualizar', 'tipoSexo.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoSexo.do?metodo=visualizar'); 
    
-- TipoSexo - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoSexo - Preparar Alterar', 'tipoSexo.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoSexo.do?metodo=prepararAlterar'); 
    
-- TipoSexo - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoSexo - Alterar', 'tipoSexo.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoSexo.do?metodo=Alterar'); 
    
-- TipoSexo - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoSexo - Excluir', 'tipoSexo.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoSexo.do?metodo=excluir'); 
    
-- TipoSexo - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoSexo - Preparar Incluir', 'tipoSexo.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoSexo.do?metodo=prepararIncluir'); 
    
-- TipoSexo - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'TipoSexo - Incluir', 'tipoSexo.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='tipoSexo.do?metodo=incluir'); 
    
    
    
-- Usuario --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Usuario', 'usuarioConsulta.do?metodo=prepararConsultar', curDate(), 1, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='usuarioConsulta.do?metodo=prepararConsultar'); 
    
-- Usuario - Consultar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Usuario - Consultar', 'usuarioConsulta.do?metodo=Consultar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='usuarioConsulta.do?metodo=Consultar'); 
    
-- Usuario - Preparar Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Usuario', 'usuarioConsulta.do?metodo=prepararSelecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='usuarioConsulta.do?metodo=prepararSelecionar'); 
    
-- Usuario - Selecionar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Usuario - Selecionar', 'usuarioConsulta.do?metodo=Selecionar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='usuarioConsulta.do?metodo=selecionar'); 
    
-- Usuario - Visualizar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Usuario - Visualizar', 'usuario.do?metodo=visualizar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='usuario.do?metodo=visualizar'); 
    
-- Usuario - Preparar Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Usuario - Preparar Alterar', 'usuario.do?metodo=prepararAlterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='usuario.do?metodo=prepararAlterar'); 
    
-- Usuario - Alterar --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Usuario - Alterar', 'usuario.do?metodo=Alterar', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='usuario.do?metodo=Alterar'); 
    
-- Usuario - Excluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Usuario - Excluir', 'usuario.do?metodo=excluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='usuario.do?metodo=excluir'); 
    
-- Usuario - Preparar Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Usuario - Preparar Incluir', 'usuario.do?metodo=prepararIncluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='usuario.do?metodo=prepararIncluir'); 
    
-- Usuario - Incluir --
INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, <COD_FUNCIONALIDADES>, 'Usuario - Incluir', 'usuario.do?metodo=incluir', curDate(), 0, '01.01.00' FROM con_configuracao 
  WHERE NOT EXISTS (SELECT * FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_ACAO='usuario.do?metodo=incluir'); 
    
    
    
    
    
-- -- TOKEN_SQL -- -- 



-- Sair
--IF (SELECT COUNT(*) FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_LABEL like '%Sair%' AND CMD_DSC_ACAO = 'sair.do') = 0
--	INSERT INTO cmd_comando (SIS_IDT_CHAVE, CMD_IDT_CHAVE_PAI, CMD_DSC_LABEL, CMD_DSC_ACAO, CMD_DAT_ATIVACAO, CMD_FLG_MENU, CMD_DSC_ORDEM) VALUES 
--	(<COD_SISTEMA>, NULL, 'Sair', 'sair.do', getDate(), 1, '99.00.00');

INSERT INTO cmd_comando (SIS_IDT_CHAVE,  CMD_IDT_CHAVE_PAI,  CMD_DSC_LABEL,  CMD_DSC_ACAO,  CMD_DAT_ATIVACAO,  CMD_FLG_MENU,  CMD_DSC_ORDEM ) 
  SELECT DISTINCT <COD_SISTEMA>, NULL, 'Sair', 'sair.do', getDate(), 1, '99.00.00' FROM con_configuracao
  WHERE NOT EXISTS (SELECT COUNT(*) FROM cmd_comando WHERE SIS_IDT_CHAVE = <COD_SISTEMA> and CMD_DSC_LABEL like '%Sair%' AND CMD_DSC_ACAO = 'sair.do'); 

-- Acesso total ao perfil Administrador
--DELETE FROM CMP_COMANDO_PERFIL WHERE PER_IDT_CHAVE=<COD_ADMIN>;
--INSERT INTO cmp_comando_perfil (CMD_IDT_CHAVE, PER_IDT_CHAVE) (SELECT CMD_IDT_CHAVE, <COD_ADMIN> PER_IDT_CHAVE FROM cmd_comando WHERE SIS_IDT_CHAVE=<COD_SISTEMA>);
INSERT INTO cmp_comando_perfil (CMD_IDT_CHAVE, PER_IDT_CHAVE) (SELECT CMD_IDT_CHAVE, <COD_ADMIN> PER_IDT_CHAVE FROM cmd_comando cmd WHERE SIS_IDT_CHAVE=<COD_SISTEMA>
and CMD_IDT_CHAVE not in (SELECT CMD_IDT_CHAVE FROM cmp_comando_perfil cmp where cmp.CMD_IDT_CHAVE = cmd.CMD_IDT_CHAVE and per_idt_chave=<COD_ADMIN>));

-- Obs: N�o esquecer de aplicar a correta ordem aos comandos do menu
