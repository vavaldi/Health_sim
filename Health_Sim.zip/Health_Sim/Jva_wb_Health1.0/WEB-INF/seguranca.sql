
-- TOKEN_SQL --

-- LOGOFF --
INSERT INTO COM_COMANDO ( SIS_COD_SISTEMA,  COM_DSC_NOME,  COM_DSC_FUNCIONALIDADE,  COM_DSC_ACAO,  COM_DAT_ATIVACAO,  COM_NUM_ORDEM,  COM_FLG_MENU,  NSE_COD_NIVEL ) VALUES ( <CODSIS>, 'Logoff', 'Sair do sistema.', 'Logoff.do?cmd=logoff', SYSDATE(), 1, 1, 1 );     

-- ACS_ACESSO --
INSERT INTO ACS_ACESSO (select <CODGRUPO> grp_cod_grupo, com_cod_comando, <CODTIPO> from com_comando where sis_cod_sistema=<CODSIS>);
