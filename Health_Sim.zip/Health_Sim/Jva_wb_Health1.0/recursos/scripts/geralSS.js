// Checa a vers�o do browser
//vari�veis especificam qual � o browser e a sua vers�o
//Netscape 4 ou 5 e IE 4
var isNav4 = false, isNav5 = false, isIE4 = false;
//vari�veis especificam qual o formato da data a ser utilizado
//e qual o separador entra dia, m�s e ano
var strSeperator = "/";
//tipo de formato da data
// 1 = mm/dd/yyyy
// 2 = yyyy/dd/mm  (Unable to do date check at this time)
// 3 = dd/mm/yyyy
var vDateType = 3; // Tipo de formato global de data(dd/mm/yyyy)
var vYearType = 4; //No Netscape podee ser setado 2 ou 4 d�gitos para representar o ano
var vYearLength = 2; // Caso queira for�ar o usu�rio a colocar 4 d�gitos para o ano, setar vari�vel com valor 4
var err = 0; // Code erro default - 0
//se o browser for Netscape
if(navigator.appName == "Netscape")
{  //se a vers�o do browser for menor que a vers�o 5
   if (navigator.appVersion < "5")
   {
      //seta a vers�o do browser como 4
      isNav4 = true;
      isNav5 = false;
   }
   else
   //se a vers�o do browser for menor que a vers�o 4
   if (navigator.appVersion > "4")
   {
      //seta a vers�o do browser como 5
      isNav4 = false;
      isNav5 = true;
   }
}
//Caso o browser n�o seja Netscape. o Tipo de browser � setado para IE vers�o 4
else
{
   isIE4 = true;
}

//****************************************************************
//FUN��ES PARA FORMATAR VALORES
//****************************************************************
function fn_monta_inteiro( valor )
{
   var tam     = valor.length;
   var qtd     =  tam / 3 ;
   var posicao = 0;
   for ( lnx = 1 ; ( lnx < qtd ) ; lnx++)
   {
	  valor = valor.substring( 0, valor.length - (( 3 * lnx )+posicao) ) + '.' + valor.substring( valor.length - (( 3 * lnx ) + posicao++) );
   }
   return valor;
}

function delMascara( strValue )
{

  var objRegExp = new RegExp( "\\.", "g" );

  return strValue.replace(objRegExp,'');

 }


function addMascara( strValue )
{
   strValue = delMascara( strValue );

   // Inicio da Mudanca na Mascara 15/05/2003
   lnegativo = "";
   if ( strValue.length > 1 )
   {
      if ( strValue.substring(0,1) == '-' )
      {
	     lnegativo = "-";
         strValue = strValue.substring( 1 );
	  }
   }
   // Final da Mudanca na Mascara 15/05/2003

   if ( strValue.indexOf( ',' ) != -1  )
      {
	      valor = strValue.substring( 0, strValue.indexOf( ',' )  );
		  fraca = strValue.substring( strValue.indexOf( ',' )  );
	   }
	else
	   {
	     valor = strValue;
		 fraca = "";
	    }

    if (( fraca != "" ) && ( valor == "" ))
	   valor = "0";

	// strValue  = fn_monta_inteiro( valor ) + fraca;	        // Mudanca na Mascara 15/05/2003
	strValue  = lnegativo + fn_monta_inteiro( valor ) + fraca;  // Mudanca na Mascara 15/05/2003

  return strValue;
}

function trata_selecao( pcampo, pselecao, ptecla, pisselecao )
{
    /*if ( pisselecao )
    {
	   document.selection.clear();
	   pselecao.text = String.fromCharCode( ptecla );
       pcampo.value = addMascara( pcampo.value ) ;
	   pselecao = null;
	}
    return pisselecao;*/
}

function formataMoeda(campo, tammax, decimal, teclapres)
{
	var vr        = new String( delMascara( campo.value ) );
	var tecla     = 0;
	var maxint    = tammax - decimal;
	var isvirg    = false;
	var qtddig    = 0;
	var qtdint    = 0;
	var selecao   = null;
	var isselecao = false;
	var virgsele  = false;
	
	if ( navigator.appName=="Netscape" )
	{
	   tecla     = teclapres.which;
       //selecao   = document.getSelection();

	}
	else
	{
	   tecla     = teclapres.keyCode;
       selecao   = document.selection.createRange().duplicate();
	}
    /************************************************************************
       	         Verifica a Existencia de selecao neste campo
    ************************************************************************/
	if ( navigator.appName!="Netscape" )
    {
      if ( selecao.text != "" )
	  {
    	 if ( selecao.parentElement().name == campo.name )
	     {
	        isselecao = true;
	        if ( selecao.text.indexOf( ',' ) != -1 )
	           virgsele = true;

	    }
	  }
    }


	// Pressionado o Back-Space
	if ( tecla == 8 )
	   return true;


	if ( selecao != null )
	{
	   ltamsele = selecao.text.length;
	}
	else
	{
	   ltamsele = 0;
	}

	// Inicio da Mudanca na Mascara 15/05/2003
    if ( ( vr.length == 0 ) || ( campo.value.length == ltamsele ) )
	{
	   if ( tecla == 45 )
	   {
	      return true;
	   }
	}
    // Inicio da Mudanca na Mascara 15/05/2003

	// Se ja existe virgula no texto pega as qtd de inteiro e decimal se nao existe coloca zero
    if ( vr.indexOf( ',' )  != -1)
    {
       isvirg = true;
       qtddig = vr.length - vr.indexOf( ',' ) -1 ;
       qtdint = vr.indexOf( ',' );
	}
	else
	{
   	   qtdint  = vr.length ;
	}
	// Se a qtd digitada for menor que o tamanho do campo ou houver selecao ele aceita
	if ( ( vr.length <= tammax ) || ( isselecao ) )
	{

	    if ( ( tecla == 44 ) && ( decimal != 0 ) )
		{
	       // Se ja existe uma virgula e a tecla pressionada e virgula ou existe uma virgula na selecao
   	       if ( ( isvirg ) && ( virgsele ) )
		      return true;

		   if ( ( !isvirg ) || ( virgsele ) )
		      return true;

		   return false;
		}
	    if ( ( tecla >= 48 ) && ( tecla <= 57 ) )
		{
		   if ( ( isvirg ) && ( qtddig >= decimal ) && ( !virgsele ) )
		      return false;


		   if ( ( ( isvirg ) && ( qtddig <= decimal ) ) || ( isselecao ) )
		      return true;

		   if ( ( ( !isvirg ) && ( qtdint < maxint ) ) || ( isselecao ) )
		      return true;


  		   return false;
		}

		return false;

	}
	else
	{
	   return false;
	}
}


function fn_MostraMascara( campo, tecla )
{

   // Acrescentou na Mudanca na Mascara 15/05/2003
   // ( ( tecla.keyCode == 45 ) || ( tecla.keyCode == 109 ) ) )

   if ( (tecla.keyCode==8) || ( ( tecla.keyCode >= 48 ) && ( tecla.keyCode <= 57 )) ||
      ( ( tecla.keyCode >= 96 ) && ( tecla.keyCode <= 105 )) ||
      ( tecla.keyCode == 44 ) || ( ( tecla.keyCode == 45 ) || ( tecla.keyCode == 109 ) ) || ( tecla.keyCode == 46 ) )
   {
	 campo.value = addMascara( campo.value ) ;
   }
	return true;
}

//***********************************************************
//***********************************************************


/**formatar uma data
* vDateName = nome do objeto
* vDateValue = valor a ser checado
* e = event disparado
* dateCheck = True(verifica se a data � v�lida);False(formata os valores da vDateValue)
* dateType = 1(mm/dd/yyyy),2(yyyy/mm/dd),3(dd/mm/yyyy)
*
* Entre com o sinal "~" como o primeiro valor para checar informa��es da fun��o
*/
function DateFormat(vDateName, vDateValue, e, dateCheck, dateType)
{
   vDateType = dateType;

   if (vDateValue == "~")
   {
      alert("AppVersion = "+navigator.appVersion+" \nNav. 4 Version = "+isNav4+" \nNav. 5 Version = "+isNav5+" \nIE Version = "+isIE4+" \nYear Type = "+vYearType+" \nDate Type = "+vDateType+" \nSeparator = "+strSeperator);
      vDateName.value = "";
      vDateName.focus();
      return true;
   }

   var whichCode = (window.Event) ? e.which : e.keyCode;
   //checa se j� h� um separador na datan e qual o tamanho dela
   if (vDateValue.length > 8 && isNav4)
   {
      if ((vDateValue.indexOf("-") >= 1) || (vDateValue.indexOf("/") >= 1))
      return true;
   }

   //elimina os caracteres ASCII inv�lidos
   var alphaCheck = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ/-";
   if (alphaCheck.indexOf(vDateValue) >= 1)
   {
      if (isNav4)
      {
         vDateName.value = "";
         vDateName.focus();
         vDateName.select();
         return false;
      }
      else
      {
         vDateName.value = vDateName.value.substr(0, (vDateValue.length-1));
         return false;
      }
   }

   //Ignora o valor de backspace para o Netscape. IE n�o possui valor
   if (whichCode == 8)
      return false;
   else
   {
      //Especifica valores de c�digos para 0123456789/
      var strCheck = '47,48,49,50,51,52,53,54,55,56,57,58,59,95,96,97,98,99,100,101,102,103,104,105';

      if (strCheck.indexOf(whichCode) != -1)
      {
         if (isNav4)
         {
            if (((vDateValue.length < 6 && dateCheck) || (vDateValue.length == 7 && dateCheck)) && (vDateValue.length >=1))
            {
               alert("Data Inv�lida\nFavor Digitar Novamente");
               vDateName.value = "";
               vDateName.focus();
               vDateName.select();
               return false;
            }
            if (vDateValue.length == 6 && dateCheck)
            {
               var mDay = vDateName.value.substr(2,2);
               var mMonth = vDateName.value.substr(0,2);
               var mYear = vDateName.value.substr(4,4)

               //transforma o formato do ano de dois d�gitos para quatro d�gitos
               if (mYear.length == 2 && vYearType == 4)
               {
                  var mToday = new Date();
                  //Se o ano � maior que trinta anos apartir de hoje, ser� concatenado 19 � data,sen�o 20
                  var checkYear = mToday.getFullYear() + 30;
                  var mCheckYear = '20' + mYear;
                  if (mCheckYear >= checkYear)
                     mYear = '19' + mYear;
                  else mYear = '20' + mYear;
               }

               var vDateValueCheck = mMonth+strSeperator+mDay+strSeperator+mYear;
               if (!dateValid(vDateValueCheck))
               {
                  alert("Data Inv�lida\nFavor Digitar Novamente");
                  vDateName.value = "";
                  vDateName.focus();
                  vDateName.select();
                  return false;
               }
               return true;
            }
            else
            {
               // Reformata a data para o tipo desejado
               if (vDateValue.length >= 8  && dateCheck)
               {
                  if (vDateType == 1) // mmddyyyy
                  {
                     var mDay = vDateName.value.substr(2,2);
                     var mMonth = vDateName.value.substr(0,2);
                     var mYear = vDateName.value.substr(4,4)
                     vDateName.value = mMonth+strSeperator+mDay+strSeperator+mYear;
                  }
                  if (vDateType == 2) // yyyymmdd
                  {
                     var mYear = vDateName.value.substr(0,4);
                     var mMonth = vDateName.value.substr(4,2);
                     var mDay = vDateName.value.substr(6,2);

                     vDateName.value = mYear+strSeperator+mMonth+strSeperator+mDay;
                  }
                  if (vDateType == 3) // ddmmyyyy
                  {
                     var mMonth = vDateName.value.substr(2,2);
                     var mDay = vDateName.value.substr(0,2);
                     var mYear = vDateName.value.substr(4,4);

                     vDateName.value = mDay+strSeperator+mMonth+strSeperator+mYear;
                  }
                  //Cria uma vari�vel tempor�ria para guardar o valor original de vDateType e muda
                  //o valor de vDateType para 1 para valida��o
                  var vDateTypeTemp = vDateType;
                  vDateType = 1;
                  var vDateValueCheck = mMonth+strSeperator+mDay+strSeperator+mYear;
                  if (!dateValid(vDateValueCheck))
                  {
                     alert("Data Inv�lida\nFavor Digitar Novamente");
                     vDateType = vDateTypeTemp;
                     vDateName.value = "";
                     vDateName.focus();
                     vDateName.select();
                     return false;
                  }
                  vDateType = vDateTypeTemp;
                  return true;
               }
               else
               {
                  if (((vDateValue.length < 8 && dateCheck) || (vDateValue.length == 9 && dateCheck)) && (vDateValue.length >=1))
                  {
                     alert("Data Inv�lida\nFavor Digitar Novamente");
                     vDateName.value = "";
                     vDateName.focus();
                     vDateName.select();
                     return false;
                  }
               }
            }
         }
         else
         {
            // data � innv�lida para o browser Netscape vers�o 4?
            if (((vDateValue.length < 8 && dateCheck) || (vDateValue.length == 9 && dateCheck)) && (vDateValue.length >=1))
            {
               alert("Data Inv�lida\nFavor Digitar Novamente");
               vDateName.value = "";
               vDateName.focus();
               return true;
            }
            // Reformata a data para ser validada a partir do tipo que foi especificado
            if (vDateValue.length >= 8 && dateCheck)
            {
               if (vDateType == 1) // mm/dd/yyyy
               {
                  var mMonth = vDateName.value.substr(0,2);
                  var mDay = vDateName.value.substr(3,2);
                  var mYear = vDateName.value.substr(6,4)
               }
               if (vDateType == 2) // yyyy/mm/dd
               {
                  var mYear = vDateName.value.substr(0,4)
                  var mMonth = vDateName.value.substr(5,2);
                  var mDay = vDateName.value.substr(8,2);
               }
               if (vDateType == 3) // dd/mm/yyyy
               {
                  var mDay = vDateName.value.substr(0,2);
                  var mMonth = vDateName.value.substr(3,2);
                  var mYear = vDateName.value.substr(6,4)
               }
               if (vYearLength == 4)
               {
                  if (mYear.length < 4)
                  {
                     alert("Data Inv�lida\nFavor Digitar Novamente");
                     vDateName.value = "";
                     vDateName.focus();
                     return true;
                  }
               }
               //Cria uma vari�vel tempor�ria para guardar o valor original de vDateType e muda
               //o valor de vDateType para 1 para valida��o
               var vDateTypeTemp = vDateType;
    		   vDateType = 1;
               // Guarda a data reformatada
			   var vDateValueCheck = mMonth+strSeperator+mDay+strSeperator+mYear;
                //transforma o formato do ano de dois d�gitos para quatro d�gitos
			   if (mYear.length == 2 && vYearType == 4 && dateCheck) {
			   var mToday = new Date();
              //Se o ano � maior que trinta anos apartir de hoje, ser� concatenado 19 � data,sen�o 20
			  var checkYear = mToday.getFullYear() + 30;
			  var mCheckYear = '20' + mYear;
			  if (mCheckYear >= checkYear)
			  mYear = '19' + mYear;
			  else
			  mYear = '20' + mYear;
			  //armazena o novo valor da data
			  vDateValueCheck = mMonth+strSeperator+mDay+strSeperator+mYear;
             // esta fun��o n�o ir� funcionar com a data de tipo dois, pois o ano � digitado primeiro
			 if (vDateTypeTemp == 1) // mm/dd/yyyy
			 vDateName.value = mMonth+strSeperator+mDay+strSeperator+mYear;
			 if (vDateTypeTemp == 3) // dd/mm/yyyy
			 vDateName.value = mDay+strSeperator+mMonth+strSeperator+mYear;
		 }
		 if (!dateValid(vDateValueCheck)) {
		 	alert("Data Inv�lida\nFavor Digitar Novamente");
			vDateType = vDateTypeTemp;
			vDateName.value = "";
			vDateName.focus();
			return true;
	     }
		 vDateType = vDateTypeTemp;
		 return true;
	 }else {
	 	if (vDateType == 1) {
			if (vDateValue.length == 2) {
				vDateName.value = vDateValue+strSeperator;
			}
			if (vDateValue.length == 5) {
				vDateName.value = vDateValue+strSeperator;
		   }
		}
		if (vDateType == 2) {
			if (vDateValue.length == 4) {
				vDateName.value = vDateValue+strSeperator;
			}
			if (vDateValue.length == 7) {
				vDateName.value = vDateValue+strSeperator;
		    }
		}
		if (vDateType == 3) {
			if (vDateValue.length == 2) {
				vDateName.value = vDateValue+strSeperator;
			}
			if (vDateValue.length == 5) {
				vDateName.value = vDateValue+strSeperator;
		   }
		}
		return true;
   	}
  }
  if (vDateValue.length == 10&& dateCheck) {
	 if (!dateValid(vDateName)) {
		// Descomentar a linha abaixo para dedbugar a funn��o dateValid()
		//alert(err);
		alert("Data Inv�lida\nFavor Digitar Novamente");
		vDateName.focus();
		vDateName.select();
     }
  }
  return false;
  }
   else {
	// se no valor n�o existir uma string sem a �ltima KEY
	if (isNav4) {
		vDateName.value = "";
		vDateName.focus();
		vDateName.select();
		return false;
	}
	else
	{
		vDateName.value = vDateName.value.substr(0, (vDateValue.length-1));
		return false;
	 }
  }
 }
}
/**
 * Valida uma data passada como parametro
 * objName - objeto com o valor da data a ser validada
 */
function dateValid(objName) {
	var strDate;
	var strDateArray;
	var strDay;
	var strMonth;
	var strYear;
	var intday;
	var intMonth;
	var intYear;
	var booFound = false;
	var datefield = objName;
	var strSeparatorArray = new Array("-"," ","/",".");
	var intElementNr;
	// var err = 0;
	var strMonthArray = new Array(12);
	strMonthArray[0] = "Jan";
	strMonthArray[1] = "Feb";
	strMonthArray[2] = "Mar";
	strMonthArray[3] = "Apr";
	strMonthArray[4] = "May";
	strMonthArray[5] = "Jun";
	strMonthArray[6] = "Jul";
	strMonthArray[7] = "Aug";
	strMonthArray[8] = "Sep";
	strMonthArray[9] = "Oct";
	strMonthArray[10] = "Nov";
	strMonthArray[11] = "Dec";
	//strDate = datefield.value;
	strDate = objName;
	if (strDate.length < 1) {
		return true;
	}
	for (intElementNr = 0; intElementNr < strSeparatorArray.length; intElementNr++) {
		if (strDate.indexOf(strSeparatorArray[intElementNr]) != -1) {
			strDateArray = strDate.split(strSeparatorArray[intElementNr]);
			if (strDateArray.length != 3) {
				err = 1;
				return false;
			}
			else {
				strDay = strDateArray[0];
				strMonth = strDateArray[1];
				strYear = strDateArray[2];
			}
			booFound = true;
	   }
	}
	if (booFound == false) {
		if (strDate.length>5) {
			strDay = strDate.substr(0, 2);
			strMonth = strDate.substr(2, 2);
			strYear = strDate.substr(4);
	   }
	}
	if (strYear.length == 2) {
		strYear = '20' + strYear;
	}
	strTemp = strDay;
	strDay = strMonth;
	strMonth = strTemp;
	intday = parseInt(strDay, 10);
	if (isNaN(intday)) {
		err = 2;
		return false;
	}
	intMonth = parseInt(strMonth, 10);
	if (isNaN(intMonth)) {
		for (i = 0;i<12;i++) {
			if (strMonth.toUpperCase() == strMonthArray[i].toUpperCase()) {
				intMonth = i+1;
				strMonth = strMonthArray[i];
				i = 12;
		   }
		}
		if (isNaN(intMonth)) {
			err = 3;
			return false;
 	    }
	}
	intYear = parseInt(strYear, 10);
	if (isNaN(intYear)) {
		err = 4;
		return false;
	}
	if (intMonth>12 || intMonth<1) {
		err = 5;
		return false;
	}
	if ((intMonth == 1 || intMonth == 3 || intMonth == 5 || intMonth == 7 || intMonth == 8 || intMonth == 10 || intMonth == 12) && (intday > 31 || intday < 1)) {
		err = 6;
		return false;
	}
	if ((intMonth == 4 || intMonth == 6 || intMonth == 9 || intMonth == 11) && (intday > 30 || intday < 1)) {
		err = 7;
		return false;
	}
	if (intMonth == 2) {
		if (intday < 1) {
			err = 8;
			return false;
		}
		if (LeapYear(intYear) == true) {
			if (intday > 29) {
				err = 9;
				return false;
		    }
		}
		else {
			if (intday > 28) {
				err = 10;
				return false;
		    }
	    }
	}
	return true;
}
/**
*Verifica se o ano � bissexto ou n�o
*intYear - valor correspondente ao ano
*/
function LeapYear(intYear) {
	if (intYear % 100 == 0) {
		if (intYear % 400 == 0) { return true; }
	}
	else {
		if ((intYear % 4) == 0) { return true; }
	}
	return false;
}

/**
* Formata um campo decimal enquanto v�o sendo digitados os valores
* fld - valor a ser formatado
* milSep - separador de milhar
* decSep - separador de decimais
* e - evento disparado
*/
function currencyFormat(fld, milSep, decSep, e) {
	var sep = 0;
	var key = '';
	var i = j = 0;
	var len = len2 = 0;
	var strCheck = '0123456789';
	var aux = aux2 = '';
	var whichCode = (window.Event) ? e.which : e.keyCode;
	if (whichCode == 13) return true;  // Enter
	key = String.fromCharCode(whichCode);  // retorna o valor da Key
	if (strCheck.indexOf(key) == -1) return false;  // N�o � uma Key v�lida
	len = fld.value.length;
	for(i = 0; i < len; i++)
		if ((fld.value.charAt(i) != '0') && (fld.value.charAt(i) != decSep)) break;
		aux = '';
		for(; i < len; i++)
		if (strCheck.indexOf(fld.value.charAt(i))!=-1) aux += fld.value.charAt(i);
		aux += key;
		len = aux.length;
		if (len == 0) fld.value = '';
		if (len == 1) fld.value = '0'+ decSep + '0' + aux;
		if (len == 2) fld.value = '0'+ decSep + aux;
		if (len > 2) {
		aux2 = '';
		for (j = 0, i = len - 3; i >= 0; i--) {
		  if (j == 3) {
		    aux2 += milSep;
		    j = 0;
	      }
	      aux2 += aux.charAt(i);
	      j++;
	    }
	    fld.value = '';
	    len2 = aux2.length;
	    for (i = len2 - 1; i >= 0; i--)
	      fld.value += aux2.charAt(i);
	      fld.value += decSep + aux.substr(len - 2, len);
	    }
	return false;
}

  /**
  * Formata um dado n�mero num dado formato
  * number - valor a ser formatado
  * format - formato que ser� aplicado
  * Ex.: formatNumber(14000,'0,000.00')
  */
  var separator = ",";  // utiliza "," como separador de milhar
  var decpoint = ".";  // utiliza "." como separador de decimais
  var percent = "%";   // utiliza "%" como perceentual
  var currency = "$";  // utiliza "$" como sinal de valores

  function formatNumber(number, format, print) {  // use: formatNumber(number, "format")
    if (print) document.write("formatNumber(" + number + ", \"" + format + "\")<br>");

    if (number - 0 != number) return "";  // se number is NaN retorna null
    var useSeparator = format.indexOf(separator) != -1;  // utiliza separadores?
    var usePercent = format.indexOf(percent) != -1;  // converter para percentagem
    var useCurrency = format.indexOf(currency) != -1;  // utilizazr formato de monet�rio
    var isNegative = (number < 0);
    number = Math.abs (number);
    if (usePercent) number *= 100;
    format = strip(format, separator + percent + currency);  // remove caraceters de formato
    number = "" + number;  // transforma number em um string

    // split number em LHS e RHS usando decpoint como separador
    var dec = number.indexOf(decpoint) != -1;
    var nleftEnd = (dec) ? number.substring(0, number.indexOf(".")) : number;
    var nrightEnd = (dec) ? number.substring(number.indexOf(".") + 1) : "";

    // split number no formato string em LHS e RHS usando decpoint como separador
    dec = format.indexOf(decpoint) != -1;
    var sleftEnd = (dec) ? format.substring(0, format.indexOf(".")) : format;
    var srightEnd = (dec) ? format.substring(format.indexOf(".") + 1) : "";

    // ajusta a parte decimal do numero retirando ou colocando zeros na parte LHS do numero
    if (srightEnd.length < nrightEnd.length) {
      var nextChar = nrightEnd.charAt(srightEnd.length) - 0;
      nrightEnd = nrightEnd.substring(0, srightEnd.length);
      if (nextChar >= 5) nrightEnd = "" + ((nrightEnd - 0) + 1);  // round up

      while (srightEnd.length > nrightEnd.length) {
        nrightEnd = "0" + nrightEnd;
      }

      if (srightEnd.length < nrightEnd.length) {
        nrightEnd = nrightEnd.substring(1);
        nleftEnd = (nleftEnd - 0) + 1;
      }
    } else {
      for (var i=nrightEnd.length; srightEnd.length > nrightEnd.length; i++) {
        if (srightEnd.charAt(i) == "0") nrightEnd += "0";  // adiciona zero a parte RHS do numero
        else break;
      }
    }

    // ajusta o valor com zeros
    sleftEnd = strip(sleftEnd, "#");
    while (sleftEnd.length > nleftEnd.length) {
      nleftEnd = "0" + nleftEnd;
    }

    if (useSeparator) nleftEnd = separate(nleftEnd, separator);  // adiciona um separador
    var output = nleftEnd + ((nrightEnd != "") ? "." + nrightEnd : "");  // ajusta as partes do numero
    output = ((useCurrency) ? currency : "") + output + ((usePercent) ? percent : "");
    if (isNegative) {
      output = (useCurrency) ? "(" + output + ")" : "-" + output;
    }
    output  = output.replace( ".", "*" );
	output  = output.replace( ",", "." );
	output  = output.replace( "*", "," );
	alert('sa�da:' + output);
	return output;
  }

/*
* Retira todos os caracteres de chars da vari�vel input
* input - valor que ter� caracteres retirados se existirem
* chars - string de caracteres que deve ser retirados de input
*/
  function strip(input, chars) {  // strip all characters in 'chars' from input
    var output = "";  // initialise output string
    for (var i=0; i < input.length; i++)
      if (chars.indexOf(input.charAt(i)) == -1)
        output += input.charAt(i);
    return output;
  }

/*
* input � percorrido at� encontrar o ponto em que ser� aplicado separator
* input - valor que ets� sendo processado
* chars - separador que ser� aplicado a input
*/
  function separate(input, separator) {
    input = "" + input;
    var output = "";
    for (var i=0; i < input.length; i++) {
      if (i != 0 && (input.length - i) % 3 == 0) output += separator;
      output += input.charAt(i);
    }
    return output;
  }

/**Abre uma janela com os parametros setados na fun��o*/
function Start(page)
{
  OpenWin = this.open(page,'popupwindow','width=650,height=400,top=100,left=300,scrollbars=yes,resizable');
}

/**
* Alerta de preenchimento obrigatorio
* Campo que ser� verificado
*/
function poAlert (field)
{
  if(field.value=="")
  {
    alert ("Aten��o campo de prenchimento obrigat�rio!");
  }
}

/**Verifica os qual o browser est� sendo utilizado*/
var OPERA = (navigator.userAgent.indexOf("Opera") > 0) ? 1 : 0;
var MAC = (navigator.platform.indexOf("PPC") > 0) ? 1 : 0;
var getID =document.getElementById ? true : false;
var IE5,IE6,IE5_5,N4,N5,MAC_IE5;

if(!OPERA){
	IE6 = (navigator.userAgent.indexOf("MSIE 6") > 0) ? 1 : 0;
	IE5_5 = (navigator.userAgent.indexOf("MSIE 5.5") > 0) ? 1 : 0;
	IE5 = (navigator.userAgent.indexOf("MSIE 5") > 0  || IE6 || IE5_5) ? 1 : 0;
	N4 = (document.layers) ? 1 : 0;
	N5 = (navigator.userAgent.indexOf("Gecko") > 0) ? 1 : 0;
	MAC_IE5 = (MAC && IE5) ? 1 : 0;
}

var getID=document.getElementById ? true : false;
var d = new Object(this.document);
d.getID=document.getElementById;
/**Abre uma p�gina
* url - URL da p�gina que ser� aberta
* Ex.: demo('http://www.softsite.com.br')
*/
function demo(url){
	var demoWin=window.open(url);
}
/**Esconde um determinado elemento da p�gina
* ID - id do elemento que ir� esconder
*/
function hideTooltip(ID){
	if(getID)d.getElementById(ID).style.display="none";
}
/**Mostra ou esconde um determinado elemento da p�gina
* ID - id do elemento que ir� aparecer/esconder
* display - dedtermina se o elemento aparece ou desaparece
* Ex.: setDisplay('test',''); ou setDisplay('test','none');
*/
function setDisplay(ID,display){
	if(getID){
		this.obj=getRef(ID);
		this.obj.style.display=display;
	}
}
/**Seta a cor de um elemento com um ID especificado
* O elemento deve ter a propriedade color.
*/
function setColor(ID,color){
	if(getID)ID=getRef(ID);
	d.getElementById(ID).style.color=color;
}
/** Seta a posi��o de um elemento indicado por ID
*/
function setPosition(ID,pos){
	if(getID)d.getElementById(ID).style.position=pos;
}
/**Mostra um elemento por um determinado tempo
*ID - indica um elemento que ser� mostrado
*event - uindica o evento que foi disparado
*timeDelay - tempo em que objeto permanecer� sendo mostrado
*offsetX - posi��o X que o elemento aparecer�
*offsetY - posi��o Y que o elemento aparecer�
*/
function showTooltip(ID,event,timeDelay,offsetX,offsetY){
	this.timeDelay=timeDelay?timeDelay:100;
	this.obj=d.getElementById(ID);
	var x,y;
	if(IE5){
		x=event.x+document.body.scrollLeft;
		y=event.y+document.body.scrollTop;
	}
	if(N5){
		x=event.pageX;
		y=event.pageY;
	}
	x+=offsetX?offsetX:10;
	y+=offsetY?offsetY:10;
	this.obj.style.left=x+"px";
	this.obj.style.top=y+"px";
	this.obj.style.position="absolute";
	setTimeout("setDisplay(this.obj,'block')",this.timeDelay)
}
/**
* Altera o source de uma image
*ID -  especifica a image que ter� seu source modificado
*source1/source2  - source da image que ser�o alternados
*/
function toggleImg(ID,source1,source2){
if(getID){
	ID=getRef(ID);
	if(ID.src.indexOf(removePath(source2))!=-1)
		ID.src=source1;else (ID.src=source2)
	}
}
function toggleImgObj(ID1,ID2){
	if(getID){
		ID1=getRef(ID1);
		if(ID1.src!=ID2.src)
				ID1.src=ID2.src;
		else(ID1.src=ID1)
	}
}
function removePath(path){
	file=path.substring(path.lastIndexOf("/")+1,path.length);
	return file;
}
/**
* constroi um ID a partir ded um path passado para a fun��o
*/
function makeId(path){
	var id=path.substring(path.lastIndexOf("/")+1,path.lastIndexOf("."));
	return id
}
function getOffset(el,offset){
	return el[offset]+(el.offsetParent?getOffset(el.offsetParent,offset):0);
}
function getPos(el,pos) {
	return el.style[pos]+(el.parentNode.style[pos] !=0?getPos(el.parentNode.style[pos]):0);
}
/**Seta um source para um elemento especificado por ID*/
function setImg(ID,source){
	if(getID){
		ID=getRef(ID);
		return ID.src=source;
	}
}
/**Troca a imagem de um objeto pela imagem de outro objeto*/
function swapImg(img,ImgObjName){
	if(getID) {
		this.img=getRef(img);
		this.img.src=ImgObjName.src;
	}
}
/**Verifica o status da propriedade display de um elemento*/
function getDisplay(ID,value){
	if(getID)
		if(d.getElementById(ID).style.display==value)
			return true
}
/**cria um objeto Image e seta um source para ele*/
function preload(name,src){
	eval(name +'=new Image()');
	eval(name+'.src="'+src+'"');
}
/**seta a propriedade visibility de um objeto*/
function setVisible(obj,bool){
  obj=getRef(obj);
  if(bool==false)
     obj.style.visibility='hidden';
  else
     obj.style.visibility='visible';
}
function getStyleBool(obj,style,value){
	if(getID)
		if(d.getID(obj).style[style]==value)
			return true;
	return false
}
function getStyle(obj,style){
	this.obj=getRef(obj);
	var value=this.obj.style[style];
	return value;
}
function setStyle(obj,style,value){
	this.obj=getRef(obj);
	this.obj.style[style]=value;
}
function toggleStyle(obj,style,value1,value2){
	this.obj=getRef(obj);
	if(this.obj.style[style]==value1)
		setStyle(this.obj,style,value2);
	else
		setStyle(this.obj,style,value1);
}
function getRef(obj){
	if(typeof obj=="string")
		obj=d.getElementById(obj);
	return obj;
}
function toggleDisplay(obj,display1,display2){
	if(getID){
		this.obj=getRef(obj);
		if(this.obj.style.display==display1)
			this.obj.style.display=display2;
		else
			this.obj.style.display=display1;
		if(MAC_IE5){
			self.resizeBy(0,1);
			self.resizeBy(0,-1);
		}
	}
}
function setStyleByClass(tagName,className,style,value){
	var elements,a=arguments;
	if(a.length==3){
		value=a[2];
		a[2]=a[1];
		a[1]=a[0];
		tagName="*";
	}
	if(tagName=='*')
		elements=(IE5)?document.all:document.getElementsByTagName('*');
	else
		elements=document.getElementsByTagName(tagName);
	for(var i=0;i<elements.length;i++){
		var node=elements.item(i);
		if(node.className==className)
			node.style[style]=value;
	}
}
function setStyleByTag(tagName, style,value){
	var elements=document.getElementsByTagName(tagName);
	for(var i=0;i<elements.length;i++){
		elements.item(i).style[style]=value;
	}
}
function getStyleByClass(className,style){
	var i,j;
	var elements,node,value;
	elements=document.getElementsByTagName('*');
	if(IE5)
		value=IEgetStyleByClass(className,style);
	else{
		for(i=0;i<elements.length; i++){
			node=elements[i];
			if(node.className==className)
				value=document.defaultView.getComputedStyle(node,'').getPropertyValue(style);
		}
	}
	return value;
}
function addEventHandlerToClass(className,etype,fn){
	this.fn=fn;
	var i,counter=0,elements,node,value;
	eval(className +'=new Array()');
	elements=(IE5)?document.all:document.getElementsByTagName('*');
	for(i=0; i<elements.length;i++){
		node=elements[i];
		if(node.className==className){
			eval(className+"["+counter+"]=elements[i]");
			if(typeof fn=="string")
				if(IE5)eval(className+"["+counter+"]."+etype+"=new Function([this.fn])");
				else eval(className+'['+counter+'].setAttribute("'+etype+'","'+this.fn+'")');
			else eval(className+"["+counter+"]."+etype+"=[this.fn]");
			counter++;
		}
	}
}
function IEgetStyleByClass(className, style){
	var elements=(IE5)?document.all:document.getElementsByTagName('*');
	var sheets=document.styleSheets, importSheets,stxt;
	var i,y,j,k;
	for(var i=0;i<sheets.length;i++){
		rules=sheets[i].cssRules;
		if(rules.length > 0){
			for(y=0; y<rules.length; y++){
				if(rules[y].selectorText.substring(rules[y].selectorText.indexOf(".")+1)==className)
					return rules[y].style[style];
			}
		}
		importSheets=sheets[i].imports;
		if(sheets[i].imports.length>0){
			for(var j=0;j<sheets[i].imports.length; j++){
				rules=sheets[i].imports[j].cssRules;
				for(k=0; k<rules.length; k++){
					if(rules[k].selectorText.substring(rules[k].selectorText.indexOf(".")+1)==className)
						return sheets[i].imports[j].cssRules[k].style[style];
				}
			}
		}
	}
}


var tabs, activeTab = null,normStyle = new Object(),overStyle = new Object(),downStyle= new Object();

	normStyle.color="#333";
	normStyle.BGcolor="#dcb";
	normStyle.BGimage='none';
	normStyle.borderColor="#aa9";
	normStyle.top="1px";

	// overStyle: an inactive tab with a hover.
	overStyle.color="#fff";
	overStyle.BGcolor="#d0c0b0";
	overStyle.top="1px";

	// downStyle: an active tab.
	downStyle.color="#000";
	downStyle.BGcolor="transparent";
	downStyle.borderColor="#999";
	downStyle.top="2px";

	function tabInit(){ //protected
		if(arguments[0]!="undefined") bgImg = arguments[0];
		tabs = document.getElementById('tabs');
		tabs.top=tabs.offsetTop;
		if(IE5 && !MAC){
			 if(parseInt(ScriptEngineBuildVersion())<=5207)tabs.top+=1;
			 tabs.style.top=(tabs.top-2)+"px";
		}
		activeTab = document.getElementById("tab1");
		//if(IE5 && !MAC) activeTab.filters.alpha.opacity=90;
		activeTab.content= document.getElementById("content1");

		tabs.onmouseover=tabOver;
		tabs.onmouseout=tabOff;
		tabs.onmouseup=tabClick;

		downStyle.BGimg= bgImg ? bgImg : "url(napkin.png)";
		if(MAC_IE5) document.body.setAttribute("onunload","switchTabs('tab1')"); // odd fix for odd behavior.
	}

	function tabOver(e) {
		var tab;
		if (IE5|| OPERA)
			tab = window.event.srcElement;
		if (N5)
			tab = (e.target.className ?
			e.target : e.target.parentNode);

			//this let's me put other tags, such as <code>, within a tab
		if (tab.className.indexOf("tab") == -1 && tab.parentNode.className.indexOf("tab") == -1) return;
		if(!tab.id) tab = tab.parentNode;
		if (activeTab != tab)
			// don't give an id to elements that are nested in a tab.
		hoverTab(tab);
	}
	function tabOff(e) {
		var tab;
		var contentName;
		if (IE5|| OPERA)
			tab = window.event.srcElement;
		if (N5)
			tab = (e.target.id ?
			e.target : e.target.parentNode);

		if (tab.className.indexOf("tab") == -1 && tab.parentNode.className.indexOf("tab") == -1) return;
		if(!tab.id) tab = tab.parentNode;

		if (activeTab != tab)
				hoverOff(tab);
	}
	function tabClick(e) {
		var tab;
		if (IE5 || OPERA)
			tab = window.event.srcElement;
		if (N5)
			tab = (e.target.className ?
			e.target : e.target.parentNode);

		if (tab.className.indexOf("tab") == -1 && tab.parentNode.className.indexOf("tab") == -1) return;
		if(!tab.id) tab = tab.parentNode;
		contentName = "content"+parseInt(tab.id.substring(tab.id.length-1,tab.id.length));

		tab.content=document.getElementById(contentName);

		if (activeTab == tab) return;
		else {
			//alert(tab.className);alert("activeTab: "+activeTab.id+ "\tactiveTab.style.top=" +activeTab.style.top);
			resetTab(activeTab);
			//alert("activeTab: "+activeTab.id+"\thas been reset. activeTab.style.top=" +activeTab.style.top);
			depressTab(tab);
			//alert("activeTab: "+activeTab.id+"\thas been depressed. activeTab.style.top=" +activeTab.style.top);
		}

	}
	function hoverTab(tab) {
		tab.style.color=overStyle.color;
		tab.style.backgroundColor=overStyle.BGcolor;
	}
	function hoverOff(tab) {
		tab.style.color=normStyle.color;
		tab.style.backgroundColor=normStyle.BGcolor;
	}
	function depressTab(tab) {
		activeTab=tab;

	 	tab.style.color=downStyle.color;
		tab.style.backgroundColor=downStyle.BGcolor;
		tab.style.backgroundImage=downStyle.BGimg;
		tab.style.borderColor=downStyle.borderColor;
	 	tab.style.top=downStyle.top;
	 	//if(IE5 && !MAC) activeTab.filters.alpha.opacity=90;
		setVisible(tab.content,true);
	 	if(MAC_IE5) { //only done once; no need to do again when we call resetTab
				self.resizeBy(0,1);
				self.resizeBy(0,-1);
		}
	}
	function resetTab(tab) {
		tab.style.backgroundColor=normStyle.BGcolor;
	 	tab.style.color=normStyle.color;
		tab.style.backgroundImage=normStyle.BGimage;
		tab.style.borderColor=normStyle.borderColor;
	 	tab.style.top=normStyle.top;
	 	//if(IE5 && !MAC) activeTab.filters.alpha.opacity=100;
		setVisible(tab.content,false);
	 	//alert("tab.id="+tab.id + "\n tab.style.top=" +tab.style.top+"\n\nactiveTab.id="+activeTab.id + "\n activeTab.style.top=" +activeTab.style.top);
	}

	function switchTabs(tab){
		tab=document.getElementById(tab);
		if(!tab.content){//this is true only when the tab has not been clicked yet.
				contentName = "content"+parseInt(tab.id.substring(tab.id.length-1,tab.id.length))
				tab.content=document.getElementById(contentName);
		}
		resetTab(activeTab);
		depressTab(tab);
		window.scrollTo(0,0);
	}

   //projeto odonto
   var win;
   function reopenWindowCreator(val)
   {
      window.opener.location.replace(val);
   }
   function openSelectWindow(mypage,myname, winprops)
   {
      if(win != null) win.close();
      if ( winprops.indexOf("left") == -1 && winprops.indexOf("top") == -1 )
      {
         var w = 480, h = 340, topPos = 0, leftPos = 0;
	 w = screen.availWidth;
	 h = screen.availHeight;
	 topPos = h/3;  //Canto superior esquerdo da janela a 1/3 da altura dispon�vel.
	 leftPos = w/5; //Canto superior esquerdo da janela a 1/5 da largura dispon�vel.
	 winprops += ',top=' + topPos+',left='+leftPos;
      }
      win = window.open(mypage, myname, winprops);
      win.creator = self;
   }

   function closeWindow(wind)
   {
      if (wind) wind.close();
   }
   function closeWindows()
   {
      if (win) win.close();
   }
/**Limpa o valor de um determinado campo*/
   function clearField(act,field)
   {
	  var caracter = getCharCode(act);
      if (caracter != 9)
      {
         field.value = "";
	  }
   }
/**Seta o foco de um objeto*/
   function setAlert(msg, foco)
   {
      foco.focus();
   }
   function getCharCode(act)
   {
      return (navigator.appName == "Netscape") ? act.which : act.keyCode;
   }
   function checkIt(act,ref,titlewindow,props,field1, field2)
   {
      var charCode = getCharCode(act);
      if (charCode == 113)
      {
	      field2.value="";
   	      openSelectWindow(ref,titlewindow,props);
      }
      else
      {
         if (field1) {
         	clearField(act,field1);
         }
      }
   }
/**Fun��es para envio de dados(values) de uma janela para outra
 * com os respectivos campos
 */
   function sendValue(value1,value2,field1,field2,win,fieldsel)
   {
      field1.value = value1;
      if (field2 ) {
			field2.value = value2;
	  }
	  //fieldsel.focus();
      closeWindow(win);
   }

    function sendValuesStr(  value1 , value2 , field1 , field2 , fields , values  , win , fieldsel)
    {

		field1.value = value1;
		if (field2  ) { /**&& field2.type!='hidden' */
			field2.value = value2;
		}

		var valor = values.split(";");
		for( var i = 0; i < fields.length; i++)
		{
			valor[i] = trim(valor[i]);
			for( var k = 0; k < valor.length; k++)
			{
				var c = valor[k].split(":");
				if(fields[i].name == trim(c[0]) )
				{
					 if (fields[i].type=='checkbox') {
		 	     	     if (fields[i].value == c[1]) {
		 	     	           	fields[i].checked=true;
		 	     	     }
		 	     	 } else {
		 	     	      		fields[i].value =  c[1];
	  	 	     	 }
				}
			}
		}
		//fieldsel.focus();
		closeWindow(win);

	}
  function sendValues(field1 , value1 ,fields , values  , win , fieldsel)
  {
	field1.value = value1;
		if (field2  ) { /**&& field2.type!='hidden' */
			field2.value = value2;
		}

		var valor = values.split(";");
		for( var i = 0; i < fields.length; i++)
		{
			valor[i] = trim(valor[i]);
			for( var k = 0; k < valor.length; k++)
			{
				var c = valor[k].split(":");
				if(fields[i].name == trim(c[0]) )
				{
					 if (fields[i].type=='checkbox') {
		 	     	     if (fields[i].value == c[1]) {
		 	     	           	fields[i].checked=true;
		 	     	     }
		 	     	 } else {
		 	     	      		fields[i].value =  c[1];
	  	 	     	 }
				}
			}
		}
		//fieldsel.focus();
		closeWindow(win);
	}

    /**Realiza o trim em uma string do lado esquerdo*/
    function ltrim ( s )
	{
		return s.replace( /^\s*/, "" )
	}


	function rtrim ( s )
	{
		return s.replace( /\s*$/, "" );
	}

	function trim ( s )
	{
		return rtrim(ltrim(s));
	}

   function sendString(value1,field1,win,fieldsel,valDefault) {
		if (window.opener) {
		  if (field1) {
			if (value1 == "")
			 value1 = valDefault;
			field1.value = value1;
		  }
		}
	  closeWindow(win);
   }



   function sendStrings(value1,field1, values , fields, win,fieldsel)
   {
		if (window.opener) {
			 if (field1 ) { //&& field1.type!='hidden'
				field1.value = value1;
			  }
			  var valor = values.split(";");
				for( var i = 0; i < fields.length; i++)
				{
					valor[i] = trim(valor[i]);
					for( var k = 0; k < valor.length; k++)
					{
						var c = valor[k].split(":");
						if(fields[i].name == trim(c[0]) )
						{
							 if (fields[i].type=='checkbox') {
								 if (fields[i].value == c[1]) {
									fields[i].checked=true;
								 }
							  } else {
									fields[i].value =  c[1];
							  }

						}
					}
				}
		   }
			   /*fieldsel.focus();*/
		   closeWindow(win);
   }


function sendStringArray(value1Array,field1Array,fieldsel,valDefault, indexDefault)
   {
      if (value1Array[0] == "")
	  {
	     value1Array[indexDefault] = valDeafult;
	  }
	  else
	  {
		  for (var i = 0; i < value1Array.length; i++)
		  {
		     value1Array[i] = field1Array[i];
		  }
	  }
	  //fieldsel.focus();
	  closeWindow(win);
   }
   function selectField(field,flag)
   {
      field.disabled = flag;
   }
   function getStringAble(field1,field2,ref,titlewindow,props,sel,ableField,ableValue)
   {
      var atrib = ref + ',' + titlewindow + ',' + '\'' + props + '\'';
      if (field1.value == "" && field2.value != "")
      {
         openSelectWindow(ref,titlewindow,props);
         //sel.focus();
      }
      else ableField.disabled = ableValue;
   }

   /**
   * Baseando-se no conte�do do campo no qual o usu�rio digita um c�digo e no campo de string
   * correspondente, a janela que faz a pesquisa espec�fica do c�digo digitado � aberta para
   * que seja setado a 'String' no campo ao lado.
   */

   function getString(field1,field2,ref,titlewindow,props,sel , evt)
   {
      var atrib = ref + ',' + titlewindow + ',' + '\'' + props + '\'';
       /** field 1 = str and field2 = code */

      if (field2.value != "")
      {
      		if (field1.name == 'nohave_' + field2.name) {
				if (trim(field1.value)!='') {
	      			field1.value='';
    	  			openSelectWindow(ref,titlewindow,props);
	    	    	//sel.focus();
      			}

      		} else {

      			if ((field1 && field1.value == "") || !field1 )  {
         			openSelectWindow(ref,titlewindow,props);
	        		//sel.focus();
	 		 	}
	  		}
	  }
   }

   function NewWindow(mypage, myname, w, h, scroll) {
      var winl = (screen.width - w) / 2;
      var wint = (screen.height - h) / 2;
      winprops = 'height='+h+',width='+w+',top='+ wint +',left='+winl+',scrollbars='+scroll+',resizable'
      win = window.open(mypage, myname, winprops)
      win.creator = self
      if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
   }

   function NewWindowLocationDefault(mypage,myname,scroll)
   {
      winprops = 'scrollbars='+scroll+',resizable';
	  win = window.open(mypage,myname,winprops);
	  win.creator = self;
	  if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
   }
/**seleciona todos os elementos checkbox existentes em um grid*/
   function selTodas(value,formt)
   {
      for (var i = 0; i < formt.elements.length; i++)
      {
         var element = formt.elements[i];
		 if (element.type == 'checkbox')
		 {
      	   if (value)
        	 	element.checked=true;
	   	 	 else element.checked=false;
		 }
      }
   }

   /**
      * Fun��o usada para deletar registro selecionados no grid.
      * msg - Mensagem de alerta exibida antes de se deletar o registro. Exemplo: Deseja deletar o registro?
      * formt - Formul�rio html que sofrer� o submit. Exemplo: document.forms[0]
      * parameters - Lista de par�metros que vai na requisi��o na URL.
      */
      function delRegistro(msg , formt  , parameters)
      {
   	   if ( confirm(msg) )
   	   {
   			formt.action = formt.action + '?actionParameter=delete&' + parameters;
   			formt.submit();
   	   }
      }

      /**
      * Fun��o usada para deletar registro selecionados no grid.
      * msg - Mensagem de alerta exibida antes de se deletar o registro. Exemplo: Deseja deletar o registro?
      * formt - String do Formul�rio html que sofrer� o submit. Exemplo: 'document.forms[0]'
      * paramStr - Lista dos nomes dos campos do formul�rio que ser�o setados na requisi��o.
      * paramValue - Lista dos valores dos campos do formul�rio que ser�o setados no form antes da requisi��o.
      */
      function delRegistroGet(msg, formt, actionParameterValue, paramStr, valueStr)
      {
      	   if ( confirm(msg) )
   	   {
   			var frm = eval(formt);
   			frm.actionParameter.value = actionParameterValue;
   			if (paramStr != null && valueStr != null)
   			{
   				var params = paramStr.split(",");
   				var values = valueStr.split(",");
   				var o;
   				for (var index = 0; index < params.length; index++)
   				{
   					o = eval(formt + '.' + params[index]);
   					o.value = values[index];
   				}
   			}

   			frm.submit();
   	   }
   }

/**confirma o pedido de deele��o de registros baseado em uma pergunta(msg)*/
   function delRegistros(msg,formt)
   {
      var flag = false;
      for (var i = 0; i < formt.elements.length; i++)
      {
         if (formt.elements[i].checked)
         {
            flag = true;
            break;
         }
      }

      if (flag)
      {
         if (confirm(msg))
         {
	    formt.submit();
         }
      }
      else alert("Nenhum item foi selecionado.");
   }

	/** Esta fun��o d� o submit em um certo formul�rio,
	caso o usu�rio responsa 'ok' na 'MessageBox'. **/
	function confirmaSubmit(msg, formt)
   	{
		if (confirm(msg))
		{
			formt.submit();
		}
	}

	/** Esta fun��o d� o submit em um certo formul�rio,
	caso o usu�rio responsa 'ok' na 'MessageBox', setando
	um campo do formul�rio. **/
	function confirmaSubmit(msg, formt, field, val)
   	{
		if (confirm(msg))
		{
			field.value = val;
			formt.submit();
		}
	}
   //esta func��o varre todos os checkboxes do formul�rio � procura de algum checado e
   //com determinado array de valores, especificado pelo par�metro index.
   function isChecked(formt, index)
	{
		var ret = false;
		for (var i = 0; i < formt.elements.length; i++)
	    {
			if (formt.elements[i].type == "checkbox")
			{
		        if (formt.elements[i].checked)
		        {
					var comp = true;
					for(var j = 0; j < index.length; j++)
					{
						if (index[j] == formt.elements[i].value)
						{
							comp = false;
							break;
						}
					}
					ret = comp;
				}
			}
	    }
		return ret;
	}
/**realiza uum reload na p�gina*/
   function recarregar()
   {
      location.reload();
   }
   //var flag = true;
   function MaskCheck(mask,e)
   {
       // Code to check input against mask character.
       var PosCharEntered
       var MaskCharacter
       var CharEntered
	   e.srcElement.maxlength = mask.length;
       /**
	   if (e.srcElement.value.length > mask.length-1)
       {
		  //e.srcElement.value = "";
		  e.returnValue = false;
       }
	   */

       // Retrieve the character position within the control.
       PosCharEntered = e.srcElement.value.length + 1;

       // Retrieve the same position within the mask.
       MaskCharacter = mask.charAt(PosCharEntered-1);

       // Verify the value entered in the control.
       CharEntered = e.srcElement.value

       switch(MaskCharacter)
       {
           case 'L':
   		// Check character against the mask.
   	        if (((e.keyCode >= 65) && (e.keyCode <= 90)) ||
                      ((e.keyCode >= 97) && (e.keyCode <= 122)))
                {
                   // Only allow for alpha characters as valid entries.
   		   e.returnValue = true
   		}
   		else
   		{
   		   e.returnValue = false
   		// Character entered is not allowed; cancel the keypress.
   		}
           break;

   	   case '#':
   		// Check character against the mask.
   	        if ((e.keyCode >= 48) && (e.keyCode <= 57))
   	        {
                   // Only allow for numeric values as valid entries.
   		   e.returnValue = true
   		}
   		else
   		{
   		   e.returnValue = false
                   // Character entered is not allowed; cancel the keypress.
   		}
   	   break;

           default:
   		// When a mask is not applied by the control.
                if (String.fromCharCode(e.keyCode) == MaskCharacter)
                {
                   // Allow the character if its not a mask character.
                   e.returnValue=true
                }
                else
                {
                   // If a mask character was not entered, add it to the control.
   		   if (e.keyCode != 8)
                      e.srcElement.value = e.srcElement.value + MaskCharacter
                }
        }
   }
   //fun��o para desabilitar os bot�es 'sunmit' de um formul�rio
   function disableSubmits(form)
   {
	   for (var i = 0; i < form.elements.length; i++)
	   {
	      if (form.elements[i].type == "submit")
	   	     form.elements[i].disabled = true;
	   }
   }

   /*
   Este script � usado como um timer para submitar determinado formul�rio.
   Par�metros:
   element - campo checkbox que se estiver checado, o formul�rio sofrer� o submit.
   form    - formul�rio que sofrer� o submit.
   */

   var interval = null;
   var element = null;
   var form = null;
   var timer = 0;
   /*
   Esta fun��o � geralmente usada no evento onload da tag body.
   */
   function setTimer(element, form, interval)
   {
   		this.element = element;
		this.form = form;
		this.interval = interval;
		startTimer()
   }
   function startTimer()
   {
   		timer++;
   		if (timer == interval)
		{
		    if (element.checked)
			{
				form.submit();
			}
		}
		setTimeout("startTimer()",1000);
   }
   function initTimer()
   {
   		timer = 0;
   }
   /*
   Esta fun��o direciona uma p�giga html para um documento.
   */
   function toGo(direction)
   {
        document.location = direction;
   }

/**Formata um determinado valor (argumento digit == 0
   quando n�o h� casas decimais)*/
function FormataValor(campo,tammax,teclapres,ndigitos,digit) {
	var tecla = teclapres.keyCode;
	var numdigitos = 2;

	if (ndigitos)
		numdigitos = ndigitos;
    else{
         if( ndigitos == '0' ){
             numdigitos = ndigitos;
         }
    }
    vr = teclapres.srcElement.value;

	vr = vr.replace( "/", "" );
	vr = vr.replace( "/", "" );
	vr = vr.replace( ",", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	tam = vr.length;

	if (tecla == 8 ) // backspace
		return;

	if(teclapres.srcElement.readOnly == true) //campo eh readOnly
		return;

	if (!((tecla >= 48 && tecla <= 57) || (tecla >= 96 && tecla <= 105))){
		if (!(((tecla >= 35) && (tecla <= 40)) || (tecla == 45) || (tecla == 46) || (tecla == 9)))
			teclapres.returnValue = false;
		return;
	}

	if (tam < tammax){ tam = vr.length + 1 ; }

	if ( tam <= numdigitos ){
		teclapres.srcElement.value = vr ;
	}

	if(eval(digit) == 0){
	    if ( (tam > 3) && (tam <= 6) ){
     		teclapres.srcElement.value = vr.substr( 0, tam - 3 ) + '.' + vr.substr( tam - 3, tam ) ;
    	}
     	if ( (tam >= 7) && (tam <= 9) ){
    		teclapres.srcElement.value = vr.substr( 0, tam - 6 ) + '.' + vr.substr( tam - 6, 3 ) + '.' + vr.substr( tam - 3, tam ) ;
    	}
    	if ( (tam >= 10) && (tam <= 12) ){
     		teclapres.srcElement.value = vr.substr( 0, tam - 9 ) + '.' + vr.substr( tam - 9, 3 ) + '.' + vr.substr( tam - 6, 3 ) + '.' + vr.substr( tam - 3, tam ) ;
    	}
	}else{
    	if ( (tam > numdigitos) && (tam <= numdigitos+3) ){
     		teclapres.srcElement.value = vr.substr( 0, tam - numdigitos ) + ',' + vr.substr( tam - numdigitos, tam ) ;
    	}
     	if ( (tam >= numdigitos+4) && (tam <= numdigitos+6) ){
    		teclapres.srcElement.value = vr.substr( 0, tam - numdigitos-3 ) + '.' + vr.substr( tam - numdigitos-3, 3 ) + ',' + vr.substr( tam - numdigitos, tam ) ;
    	}
    	if ( (tam >= numdigitos+7) && (tam <= numdigitos+9) ){
     		teclapres.srcElement.value = vr.substr( 0, tam - numdigitos-6 ) + '.' + vr.substr( tam - numdigitos-6, 3 ) + '.' + vr.substr( tam - numdigitos-3, 3 ) + ',' + vr.substr( tam - numdigitos, tam ) ;
    	}
     	if ( (tam >= numdigitos+10) && (tam <= numdigitos+12) ){
    		teclapres.srcElement.value = vr.substr( 0, tam - numdigitos-9 ) + '.' + vr.substr( tam - numdigitos-9, 3 ) + '.' + vr.substr( tam - numdigitos-6, 3 ) + '.' + vr.substr( tam - numdigitos-3, 3 ) + ',' + vr.substr( tam - numdigitos, tam ) ;
    	}
    	if ( (tam >= numdigitos+13) && (tam <= numdigitos+15) ){
     		teclapres.srcElement.value = vr.substr( 0, tam - numdigitos-12 ) + '.' + vr.substr( tam - numdigitos-12, 3 ) + '.' + vr.substr( tam - numdigitos-9, 3 ) + '.' + vr.substr( tam - numdigitos-6, 3 ) + '.' + vr.substr( tam - numdigitos-3, 3 ) + ',' + vr.substr( tam - numdigitos, tam ) ;
    	}
    }
}


/**Prepara o action de form com os campos e valores passados a ele*/
function prepareSubmit(form , valide) {
    var x = form.action.indexOf("actionParameter");
    if (x!= -1) {
		var ac = form.action.substring(x+16  , x + 22);
		if (trim(ac) =='delete') {
			var twoDot = form.action.indexOf(":");

			if ( twoDot != -1 ) {
			    var message;
			    var action = form.action.substring( 0, twoDot );
			    var params = form.action.substring( twoDot +1, form.action.length );

			    if ( params.indexOf( "&" ) == -1 ) {
			        message = params;
			    }else {
			        message = params.substring( 0, params.indexOf( "&" ) );
			        params = params.substring( params.indexOf( "&" ), params.length );
			    }

			    form.action = action + params;

			    return confirm( ( ( message.indexOf( "?" ) == -1 ) ? message + "?" : message ) );

			}else {
            	return confirm('Excluir registro?');
            }
  	  	}
     }
       // faz a valid��o
	var i = 0;
	var j = 0;
	var a = valide.split(";");
	for ( i = 0 ; i < a.length ; i++) {
		var b = a[i].split(":");
		b[0] = trim(b[0]);
		for ( j = 0; j < form.elements.length;j++) {
			if (form.elements[j].name == b[0]){
				if (form.elements[j].value=="") {
					if (b.length > 1) {
						alert(b[1] + ' preenchimento obrigat�rio');
						document.forms[0].elements[j].focus();
						return false;
					}else {
						alert("Preenchimento obrigat�rio!");
						document.forms[0].elements[j].focus();
						return false;
					}
				}
			 }
		}
	}


}

/**
* Fun��o que dispara uma requisi��o(normalmente usada para POST) setando
* os par�metros necess�rios na URL.
* form - Objeto que representa o formul�rio. Exemplo: document.forms[0].
* actionParameter - String que indica qual o m�todo do objeto Action que ser� chamado. Exemplo: 'search'.
* parameters - Par�metros que ser�o escritos na URL. Exemplo: 'cdCliente=10,nmCliente=rubensgama'.
*/
function setParameters(form , actionParameter, parameters) {
	var action = form.action;
	var i = action.indexOf(".do");
	action = action.substring(0 , i+3);
	form.action = action + '?actionParameter=' + actionParameter + (trim(parameters)==""?"":'&' + parameters);
}

/**
* Fun��o que dispara uma requisi��o(normamente usada para GET) setando
* os valores dos par�metros necess�rios no form.
* form - String que representa o objeto form. Exemplo: 'document.forms[0]'.
* actionParameter - String que indica qual o m�todo do objeto Action que ser� chamado. Exemplo: 'search'.
* paramStr - String que representa os nomes dos campos do form que ser�o setados antes da requisi��o. Exemplo: 'cdCliente,nmCliente'.
* valueStr - String que representa os valores dos campos do form que ser�o setados antes da requisi��o. Exemplo: '00001, rubensgama'.
*/
function setParametersGet(form, actionParameter, paramStr, valueStr)
{
	var frm = eval(form);
	frm.actionParameter.value = actionParameter;
	if (paramStr != null && valueStr != null)
	{
		var params = paramStr.split(",");
		var values = valueStr.split(",");
		var o;
		for (var index = 0; index < params.length; index++)
		{
			o = eval(form + '.' + params[index]);
			o.value = values[index];
		}
	}
}

/**Realiza a transforma��o do action de um form adicionando parametros*/
function setParametersAction( newAction, form , actionParameter, parameters) {
	var action = newAction;
	var i = action.indexOf(".do");
	action = action.substring(0 , i+3);
	form.action = action + '?actionParameter=' + actionParameter + (trim(parameters)==""?"":'&' + parameters);
}

/**Auxilia a utiliza��o de tecla de atalho para links (href)*/
function accesskeys(desc , evt) {

	var  j, i ,key ;
   	key = String.fromCharCode(evt.keyCode).toLowerCase();
   	var a = desc.split(";");
	for (i = 0 ; i < a.length ; i++) {
		var b = a[i].split(":");
		if (trim(b[1]) == key) {
			if (evt.altKey) {
				for ( j = 0 ; j < document.links.length; j++) {
					if (trim(b[0]) == document.links[j].name) {
						location.href = document.links[j].href;
						 return;
					}
				}
			}
		}

	}

}

/*
*  Fun��o que converte um n�mero no formato monet�rio
*  a partir de um decimal
*
*  @param money - Valor: Ex 1000.0
*  @return String - Ex: 1.000,00
*/
function toMoneyFormat( money ) {

   var number, comma, numberAux = "";

   number = ( money + "" ).replace( ".", "," );
   number = ( number.indexOf( "," ) == -1 ? number + ",00" : number ); //se for numero inteiro, coloca-se as casas decimais
   comma = number.indexOf( "," ) -1; //posicao da virgula

   for ( var x = comma, count = 1; x >= 0; x--, count++ )
   {
	   numberAux = number.substring( x, x +1 ) + numberAux;
	   if ( count == 3 ) {
		   if ( x != 0 && number.substring( x -1, x ) != "-" ) {
		       numberAux = "." + numberAux;
		       count = 0;
		   }
	   }
   }

   var comma_casas_decimais = number.substring( comma +1, number.length );
   if (comma_casas_decimais.length == 2)
   {
   		comma_casas_decimais += '0';
   }

   return numberAux + comma_casas_decimais;
}

/*
*  Fun��o que converte um n�mero no formato decimal
*  a partir de um monet�rio
*
*  @param value - Valor: Ex 10.000,00
*  @return String - Ex: 100.0
*/
function toDoubleFormat( value ) {

    while ( value.indexOf( "." ) != -1 ) {
	value = value.replace( ".", "" );
    }

    value = value.replace( ",", "." );

    if ( isNaN( value ) ) {
	throw "original: " + value + " : convertido: " + parseFloat( value );
    }

    var paleativo = value.substring( 0, value.indexOf( "." ) +3 );

    return parseFloat( paleativo );
}



/** ------ ALGUMAS FUNC��ES DA MACROMEDIA  ---------*/


function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}


function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&id.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}


function MM_showHideLayers() { //v6.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) if ((obj=MM_findObj(args[i]))!=null) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}

function tmt_findObj(n){
	var x,t; if((n.indexOf("?"))>0&&parent.frames.length){t=n.split("?");
	x=eval("parent.frames['"+t[1]+"'].document.getElementById('"+t[0]+"')");
	}else{x=document.getElementById(n)}return x;
}

function tmt_DivMove(theDiv, l, t){
	var x = (document.layers) ? ".left" : ".style.left";
	var y = (document.layers) ? ".top" : ".style.top";
	var fun = (document.getElementById) ? "tmt_findObj" : "MM_findObj";
	var obj = eval(fun+"(theDiv)");if(obj){
	eval(fun+"('"+theDiv+"')"+y+"="+t);
	eval(fun+"('"+theDiv+"')"+x+"="+l);}
}

function tmt_DivMoveModified(theDiv, evt){
	var l = evt.clientX + 15;
	var t = evt.clientY - 15;
	var x = (document.layers) ? ".left" : ".style.left";
	var y = (document.layers) ? ".top" : ".style.top";
	var fun = (document.getElementById) ? "tmt_findObj" : "MM_findObj";
	var obj = eval(fun+"(theDiv)");if(obj){
	eval(fun+"('"+theDiv+"')"+y+"="+t);
	eval(fun+"('"+theDiv+"')"+x+"="+l);}
}

function MM_setTextOfLayer(objName,x,newText) { //v4.01
  if ((obj=MM_findObj(objName))!=null) with (obj)
    if (document.layers) {document.write(unescape(newText)); document.close();}
    else innerHTML = unescape(newText);
}

/**Fun��o gerada pela Macromedia e permite que um layer possa ser arrastado por uma p�gina*/
function MM_dragLayer(objName,x,hL,hT,hW,hH,toFront,dropBack,cU,cD,cL,cR,targL,targT,tol,dropJS,et,dragJS) { //v4.01
  //Copyright 1998 Macromedia, Inc. All rights reserved.
  var i,j,aLayer,retVal,curDrag=null,curLeft,curTop,IE=document.all,NS4=document.layers;
  var NS6=(!IE&&document.getElementById), NS=(NS4||NS6); if (!IE && !NS) return false;
  retVal = true; if(IE && event) event.returnValue = true;
  if (MM_dragLayer.arguments.length > 1) {
    curDrag = MM_findObj(objName); if (!curDrag) return false;
    if (!document.allLayers) { document.allLayers = new Array();
      with (document) if (NS4) { for (i=0; i<layers.length; i++) allLayers[i]=layers[i];
        for (i=0; i<allLayers.length; i++) if (allLayers[i].document && allLayers[i].document.layers)
          with (allLayers[i].document) for (j=0; j<layers.length; j++) allLayers[allLayers.length]=layers[j];
      } else {
        if (NS6) { var spns = getElementsByTagName("span"); var all = getElementsByTagName("div");
          for (i=0;i<spns.length;i++) if (spns[i].style&&spns[i].style.position) allLayers[allLayers.length]=spns[i];}
        for (i=0;i<all.length;i++) if (all[i].style&&all[i].style.position) allLayers[allLayers.length]=all[i];
    } }
    curDrag.MM_dragOk=true; curDrag.MM_targL=targL; curDrag.MM_targT=targT;
    curDrag.MM_tol=Math.pow(tol,2); curDrag.MM_hLeft=hL; curDrag.MM_hTop=hT;
    curDrag.MM_hWidth=hW; curDrag.MM_hHeight=hH; curDrag.MM_toFront=toFront;
    curDrag.MM_dropBack=dropBack; curDrag.MM_dropJS=dropJS;
    curDrag.MM_everyTime=et; curDrag.MM_dragJS=dragJS;
    curDrag.MM_oldZ = (NS4)?curDrag.zIndex:curDrag.style.zIndex;
    curLeft= (NS4)?curDrag.left:(NS6)?parseInt(curDrag.style.left):curDrag.style.pixelLeft;
    if (String(curLeft)=="NaN") curLeft=0; curDrag.MM_startL = curLeft;
    curTop = (NS4)?curDrag.top:(NS6)?parseInt(curDrag.style.top):curDrag.style.pixelTop;
    if (String(curTop)=="NaN") curTop=0; curDrag.MM_startT = curTop;
    curDrag.MM_bL=(cL<0)?null:curLeft-cL; curDrag.MM_bT=(cU<0)?null:curTop-cU;
    curDrag.MM_bR=(cR<0)?null:curLeft+cR; curDrag.MM_bB=(cD<0)?null:curTop+cD;
    curDrag.MM_LEFTRIGHT=0; curDrag.MM_UPDOWN=0; curDrag.MM_SNAPPED=false; //use in your JS!
    document.onmousedown = MM_dragLayer; document.onmouseup = MM_dragLayer;
    if (NS) document.captureEvents(Event.MOUSEDOWN|Event.MOUSEUP);
  } else {
    var theEvent = ((NS)?objName.type:event.type);
    if (theEvent == 'mousedown') {
      var mouseX = (NS)?objName.pageX : event.clientX + document.body.scrollLeft;
      var mouseY = (NS)?objName.pageY : event.clientY + document.body.scrollTop;
      var maxDragZ=null; document.MM_maxZ = 0;
      for (i=0; i<document.allLayers.length; i++) { aLayer = document.allLayers[i];
        var aLayerZ = (NS4)?aLayer.zIndex:parseInt(aLayer.style.zIndex);
        if (aLayerZ > document.MM_maxZ) document.MM_maxZ = aLayerZ;
        var isVisible = (((NS4)?aLayer.visibility:aLayer.style.visibility).indexOf('hid') == -1);
        if (aLayer.MM_dragOk != null && isVisible) with (aLayer) {
          var parentL=0; var parentT=0;
          if (NS6) { parentLayer = aLayer.parentNode;
            while (parentLayer != null && parentLayer.style.position) {
              parentL += parseInt(parentLayer.offsetLeft); parentT += parseInt(parentLayer.offsetTop);
              parentLayer = parentLayer.parentNode;
          } } else if (IE) { parentLayer = aLayer.parentElement;
            while (parentLayer != null && parentLayer.style.position) {
              parentL += parentLayer.offsetLeft; parentT += parentLayer.offsetTop;
              parentLayer = parentLayer.parentElement; } }
          var tmpX=mouseX-(((NS4)?pageX:((NS6)?parseInt(style.left):style.pixelLeft)+parentL)+MM_hLeft);
          var tmpY=mouseY-(((NS4)?pageY:((NS6)?parseInt(style.top):style.pixelTop) +parentT)+MM_hTop);
          if (String(tmpX)=="NaN") tmpX=0; if (String(tmpY)=="NaN") tmpY=0;
          var tmpW = MM_hWidth;  if (tmpW <= 0) tmpW += ((NS4)?clip.width :offsetWidth);
          var tmpH = MM_hHeight; if (tmpH <= 0) tmpH += ((NS4)?clip.height:offsetHeight);
          if ((0 <= tmpX && tmpX < tmpW && 0 <= tmpY && tmpY < tmpH) && (maxDragZ == null
              || maxDragZ <= aLayerZ)) { curDrag = aLayer; maxDragZ = aLayerZ; } } }
      if (curDrag) {
        document.onmousemove = MM_dragLayer; if (NS4) document.captureEvents(Event.MOUSEMOVE);
        curLeft = (NS4)?curDrag.left:(NS6)?parseInt(curDrag.style.left):curDrag.style.pixelLeft;
        curTop = (NS4)?curDrag.top:(NS6)?parseInt(curDrag.style.top):curDrag.style.pixelTop;
        if (String(curLeft)=="NaN") curLeft=0; if (String(curTop)=="NaN") curTop=0;
        MM_oldX = mouseX - curLeft; MM_oldY = mouseY - curTop;
        document.MM_curDrag = curDrag;  curDrag.MM_SNAPPED=false;
        if(curDrag.MM_toFront) {
          eval('curDrag.'+((NS4)?'':'style.')+'zIndex=document.MM_maxZ+1');
          if (!curDrag.MM_dropBack) document.MM_maxZ++; }
        retVal = false; if(!NS4&&!NS6) event.returnValue = false;
    } } else if (theEvent == 'mousemove') {
      if (document.MM_curDrag) with (document.MM_curDrag) {
        var mouseX = (NS)?objName.pageX : event.clientX + document.body.scrollLeft;
        var mouseY = (NS)?objName.pageY : event.clientY + document.body.scrollTop;
        newLeft = mouseX-MM_oldX; newTop  = mouseY-MM_oldY;
        if (MM_bL!=null) newLeft = Math.max(newLeft,MM_bL);
        if (MM_bR!=null) newLeft = Math.min(newLeft,MM_bR);
        if (MM_bT!=null) newTop  = Math.max(newTop ,MM_bT);
        if (MM_bB!=null) newTop  = Math.min(newTop ,MM_bB);
        MM_LEFTRIGHT = newLeft-MM_startL; MM_UPDOWN = newTop-MM_startT;
        if (NS4) {left = newLeft; top = newTop;}
        else if (NS6){style.left = newLeft; style.top = newTop;}
        else {style.pixelLeft = newLeft; style.pixelTop = newTop;}
        if (MM_dragJS) eval(MM_dragJS);
        retVal = false; if(!NS) event.returnValue = false;
    } } else if (theEvent == 'mouseup') {
      document.onmousemove = null;
      if (NS) document.releaseEvents(Event.MOUSEMOVE);
      if (NS) document.captureEvents(Event.MOUSEDOWN); //for mac NS
      if (document.MM_curDrag) with (document.MM_curDrag) {
        if (typeof MM_targL =='number' && typeof MM_targT == 'number' &&
            (Math.pow(MM_targL-((NS4)?left:(NS6)?parseInt(style.left):style.pixelLeft),2)+
             Math.pow(MM_targT-((NS4)?top:(NS6)?parseInt(style.top):style.pixelTop),2))<=MM_tol) {
          if (NS4) {left = MM_targL; top = MM_targT;}
          else if (NS6) {style.left = MM_targL; style.top = MM_targT;}
          else {style.pixelLeft = MM_targL; style.pixelTop = MM_targT;}
          MM_SNAPPED = true; MM_LEFTRIGHT = MM_startL-MM_targL; MM_UPDOWN = MM_startT-MM_targT; }
        if (MM_everyTime || MM_SNAPPED) eval(MM_dropJS);
        if(MM_dropBack) {if (NS4) zIndex = MM_oldZ; else style.zIndex = MM_oldZ;}
        retVal = false; if(!NS) event.returnValue = false; }
      document.MM_curDrag = null;
    }
    if (NS) document.routeEvent(objName);
  } return retVal;
}


/**	Fun��o para trocar a figura.*/
function swap_Image_Hide_Div( flag , imageName , file1 , file2 , obj_div) {
	var image = document.getElementById(imageName);
	if (flag=='' || flag == 'hidden' || flag == false) {
		image.src = file1;
		if (obj_div) {
		   obj_div.style.visibility='visible';
		}
	} else {
		image.src = file2;
		if (obj_div) {
		   obj_div.style.visibility='hidden';
		}
	}
}

/**Muda o source de uma imagem*/
function swap_Image( flag , imageName , file1 , file2) {
	var image = document.getElementById(imageName);
	if (flag=='' || flag == 'hidden' || flag == false) {
		image.src = file2;
	} else {
	    image.src = file1;
	}
}


  /*
   * Fun��o que d� um append `a esquerda de uma string, para que fique
   * com um tamanho de num.
   * Exemplo:
   * <input type="text" name="teste" onblur="formatLeftString('9','0',3)">
   */
   function formatLeftString(obj,str,num)
   {
   	var val = obj.value;
   	var tam = val.length;

   	if (val.length > 0)
   	{
		for (var index = 0; index < num - tam; index++)
		{
			val = str + val;
		}
		obj.value = val;
	}
   }

  /*
   * Funcao que aplica uma mascara geral a uma string qualquer,
   * enquanto o usuario digita.
   * Exemplo:
   * <input type="text" name="teste" onkeypress="formataString(event,this,'#####*###.###%###/##')">
   */
 function formatString(evt,element,mask)
 {
     var whichCode = ((window.Event) ? evt.which : evt.keyCode) + "";
     var numbers = "47,48,49,50,51,52,53,54,55,56,57";

     if (numbers.indexOf(whichCode) >= 1)
     {
        var length = element.value.length;
        var val = element.value;
        if (!(mask.charAt(length) == '#'))
        {
           element.value += mask.charAt(length);
        }
     }
     else
     {
        evt.returnValue = false;
     }
 }

/** setar o texto na ssMessage */
function setText_in_SSHelp(title, text) {
	layer = document.getElementById('helpLayer1');
	if (layer.style.visibility == 'hidden') {

	   swap_Image_Hide_Div(document.getElementById('helpLayer1').style.visibility , 'setas' , './images/ajuda_setacima.gif' , './images/ajuda_setabaixo.gif', document.getElementById('helpLayer1'));
	   swap_Image(document.getElementById('helpLayer1').style.visibility , 'ajd_topo' , 'images/ajuda_topo.gif' , 'images/ajuda_topodescricao.gif');
	   layer.style.visibility = 'visible';
	}
	layer1 = document.getElementById('helpLayer2');
	if (layer1.style.visibility == 'hidden') {
		swap_Image(document.getElementById('helpLayer1').style.visibility , 'setas' , './images/ajuda_setacima.gif' , './images/ajuda_setabaixo.gif');
		swap_Image(document.getElementById('helpLayer1').style.visibility , 'ajd_topo' , 'images/ajuda_topo.gif' , 'images/ajuda_topodescricao.gif');
	    layer1.style.visibility = 'visible';
	}

	element = document.getElementById('helpMsg');
	element.innerHTML = text;

   	element = document.getElementById('helpTitle');
	element.innerHTML = title;
}
/**
* realiza um submit no form caso a tecla enter for disparada
* @see setParameters(...)
*/
function checkSubmit(evt, form, acao, params)
{
	var code = evt.keyCode;
	if (code == 13)
	{
		setParameters(form,acao,params);
	}
}

/**
* M�scara de IP
* Exemplo: <input type="text" name="ip" onKeyDown="maskIp(event,this)" >
*/
var charBefore = NaN;
var seqNumbers = '';
function maskIp(evt, element)
{
	 var val = element.value;
	 if (val.length == 0)
	 {
		seqNumbers = '';
		charBefore = NaN;
	 }
	 var whichCode = ((window.Event) ? evt.which : evt.keyCode);
	 var whichChar = String.fromCharCode(evt.keyCode).toLowerCase();
	 var tam = val.length;
	 var isNumber = ((whichCode >= 48 && whichCode <= 57) || (whichCode >= 96 && whichCode <= 105));
	 var isPoint = ((whichCode == 190) || (whichCode == 194) || (whichCode == 110));
	 var isBackSpace = (whichCode == 8);
	 var isBeforePoint = ((charBefore == 194) || (charBefore == 110) || (charBefore == 190));
	 var hasThreePoints = (val.split('.').length == 4);
	 var isTab = (whichCode == 9);
	 var isControl = ((whichCode == 35) || (whichCode == 36) || (whichCode == 37) || (whichCode == 38) || (whichCode == 39));
	 var isDel     = (whichCode == 46);

	 if ((isNumber || isPoint) && (tam < 15))
	 {
		if ( ((isNaN(charBefore)) && isPoint) )
		{
			evt.returnValue = false;
			return false;
		}
		else
		if ((seqNumbers.length == 3) && isNumber && (!hasThreePoints))
		{
			element.value = element.value + '.';
			isPoint = false;
			seqNumbers = '';
		}
		else
		if ((isBeforePoint && isPoint) ||
		   (isPoint && hasThreePoints) ||
		   (isNumber && (seqNumbers.length == 3) && hasThreePoints))
		{
			evt.returnValue = false;
			return false;
		}
	 }
	 else
	 if (isBackSpace)
	 {
		//especificar o octeto atual
		if (val.length > 0)
		{
			if (val.lastIndexOf('.') == -1)
			{
				seqNumbers = val.substring(0,val.length - 1);
			}
			else
			if (val.lastIndexOf('.') == (val.length - 2))
			{
				seqNumbers = '';
			}
			else
			if (val.lastIndexOf('.') == (val.length - 1))
			{
				var temp = val.substring(0,val.length - 1);
				seqNumbers = temp.substring(temp.lastIndexOf('.') + 1, temp.length);
			}
			else
			{
				seqNumbers = val.substring(val.lastIndexOf('.') + 1,val.length - 1);
			}
			charBefore = val.charCodeAt(val.length - 2);
			return;
		}
		else
		{
			evt.returnValue = false;
			return false;
		}
	 }
	 else
	 if (isTab || isControl || isDel)
	 {
		return;
	 }
	 else
	 {
		evt.returnValue = false;
		return false;
	 }

	 charBefore = whichCode;
	 if (isPoint)
	 {
		 seqNumbers = '';
	 }
	 else
	 {
		 seqNumbers = seqNumbers + whichChar;
	 }
}

/** formata uma string para valor retirando pontos,
    substituindo virgula por ponto e removendo os zeros
*/
function strToVal(strVal){
	strVal = strVal.replace(".","");
	strVal = strVal.replace(".","");
	strVal = strVal.replace(".","");
	strVal = strVal.replace(",",".");
	strVal = retiraZero(strVal);
	return strVal;
}

/** verifica se valor � v�lido
*/
function isValidValue(campoVal, strVr){
	if(isNaN(strVr)){
		alert('Valor inv�lido');
		campoVal.value = '';
		campoVal.focus();
		return false;
	}
	return true;
}

/** retira os zeros do valor
*/
function retiraZero(strstr){
	k = 0;
	while(k==0){
		if(strstr.substring(0,1)=='0'){
			strstr = strstr.substring(1,strstr.length);
		}else{
			k = 1;
		}
	}
	return strstr;
}

/** formata uma string em um valor (argumento digit == 0
   quando n�o h� casas decimais)
*/
function formataValores(strValor, digit){
    var tam = strValor.length;

	if(eval(digit) == 0){
        if ( (tam > 3) && (tam <= 6) ){
     		strValor = strValor.substr( 0, tam - 3 ) + '.' + strValor.substr( tam - 3, tam ) ;
    	}
     	if ( (tam >= 7) && (tam <= 9) ){
    		strValor = strValor.substr( 0, tam - 6 ) + '.' + strValor.substr( tam - 6, 3 ) + '.' + strValor.substr( tam - 3, tam ) ;
    	}
    	if ( (tam >= 10) && (tam <= 12) ){
     		strValor = strValor.substr( 0, tam - 9 ) + '.' + strValor.substr( tam - 9, 3 ) + '.' + strValor.substr( tam - 6, 3 ) + '.' + vr.substr( tam - 3, tam ) ;
    	}
	}else{
        decPlaces = tam-2;

    	if(tam<6){
    		strValor = strValor.substring(0,decPlaces)+","+strValor.substring(decPlaces,tam);
    	}else if((tam==6)||(tam==7)||(tam==8)){
   			strValor = strValor.substring(0,decPlaces-3)+"."+strValor.substring(decPlaces-3,decPlaces)+","+strValor.substring(decPlaces,tam);
    	}else if((tam==9)||(tam==10)||(tam==11)){
   			strValor = strValor.substring(0,decPlaces-6)+"."+strValor.substring(decPlaces-6,decPlaces-3)+"."+strValor.substring(decPlaces-3,decPlaces)+","+strValor.substring(decPlaces,tam);
    	}else if((tam==12)){
   			strValor = strValor.substring(0,decPlaces-9)+"."+strValor.substring(decPlaces-9,decPlaces-6)+"."+strValor.substring(decPlaces-6,decPlaces-3)+"."+strValor.substring(decPlaces-3,decPlaces)+","+strValor.substring(decPlaces,tam);
    	}
    }
	return strValor;
}

/** recebe um valor e inclui duas casas decimais
*/
function transformaValor(strValor){
	strValor = ""+ Math.round(eval(strValor)*Math.pow(10,2));

	while(strValor.length <= 2)
		strValor = "0" + strValor;

	return formataValores(strValor);
}

//*****************************************************************
//FUNCOES PARA A FORMATACAO DE QUALQUER TIPO DE VALOR, ATE AS DATAS
//*****************************************************************

	var NUMBER = '#';
	var UPPER = '!';
	var LOWER = '^';
	var ANY = '*';
	var ALPHA = '@';
	var DAY = 'd';
	var MONTH = 'm';
	var YEAR = 'y';
	var NULL_CHAR = 'X';
	var RX_NUMBER = "[0-9]";
	var RX_UPPER = "[A-Z�-�]";
	var RX_LOWER = "[a-z�-�]";
	var RX_ANY = "[a-zA-Z0-9�-�]";
	var RX_ALPHA = "[a-zA-Z�-�]";
	var EXP_CHARS = RX_ANY;

	/**
	* Fun��o que formata o valor digitado de acordo com a m�scara passada.
	*
	* @param event Object evento.
	* @param input Campo.
	* @param mask  M�scara.
	*/
	function maskGenerator(event,input,mask) {

		var key = String.fromCharCode(event.keyCode);
		var reg = new RegExp(EXP_CHARS);

		//testa os caracteres permitidos: somente letras e numeros e tecla delete e backspace.
		if (reg.test(key) || event.keyCode == 8 || event.keyCode == 46) {
			var lenValue = input.value.length;

			//apaga todo o conteudo se o texto estiver todo selecionado.
			var sel = document.selection.createRange().duplicate();
			if (sel.text == input.value ) {
			    document.selection.clear();
			    lenValue = 0;
			}

			//verifica se o valor j� alcancou o tamanho maximo
			if (lenValue != mask.length) {
				if (isDateMask(mask)) {
					mask = mask.toLowerCase();
				}

			    //este bloco de codigo percorre a mascara a procura de caracteres
			    //nao "literais", aqueles que nao representam uma letra ou numero.
			    //Como um ponto, virgula ou qualquer outro caractere especial.
			    var charMask = mask.charAt(lenValue);
			    var valNotLit = "";
			    while(!isLiteral(charMask) && lenValue < mask.length) {
			    	valNotLit += charMask;
			    	charMask = mask.charAt(++lenValue);
			    }

			    //obtem a expressao regular que indica se o caractere digitado e valido.
			    var regexp = getRegexpLiteral(charMask);
			    reg = new RegExp(regexp);

			    var isValidChar = reg.test(key);
			    if (isValidChar) { //caractere valido.
			        if (valNotLit != "") {
			            //concatena no valor atual todos os caracteres especiais encontrados
			            input.value += valNotLit;
			        }
				}

			    return isValidChar;
			}
		}

		return false;
	}

	/**
	* Fun��o que formata o valor digitado numa data e valida a mesma.
	*
	* @param mask  M�scara.
	* @param value Valor do campo.
	*
	* @return boolean Se a data � v�lida ou n�o.
	*/
	function isValidInputDate(mask,value) {

		var dataAr = new Array(mask.length -2); //-2, tirando as barras.
		var i = 0;
		for(;i < dataAr.length;i++) {
			dataAr[i] = NULL_CHAR;
		}

		var maskAux = mask;
		while (maskAux.indexOf("/") != -1) { //retirar todas as barras.
			value = value.replace("/","");
			maskAux = maskAux.replace("/","");
		}

		var indexAr = new Array(3);

		indexAr[0] = maskAux.indexOf(DAY);
		indexAr[1] = maskAux.indexOf(MONTH);
		indexAr[2] = maskAux.indexOf(YEAR);

		//Este bloco percorre o valor do campo e quebra as partes referentes
		//ao dia, ao m�s e ao ano independente da m�scara da data.
		var countIter;
		for (i = 0; i < indexAr.length; i++) {
			countIter = i;
			while (indexAr[i] != -1 && indexAr[i] < value.length) {
				dataAr[i + countIter] = value.charAt(indexAr[i]);
				countIter++;
				indexAr[i]++;

				if ((i == 0 && countIter == 2) || (i == 1 && countIter == 4)) {
					break;
				}
			}
		}

        //devido ao bug do parseInt que retorna 0 na convers�o de "08" ou "09".
        //este c�digo foi feito. n�o pensem besteira.
        var day = "";
        if (dataAr[0] != '0') {
            day = dataAr[0];
        }
        day += dataAr[1];

        var month = "";
        if (dataAr[2] != '0') {
            month = dataAr[2];
        }
        month += dataAr[3];

        var year = "";
        if (dataAr[4] == '0') {
            if (dataAr[5] == '0') {
            	if (dataAr[6] == '0') {
            		if (dataAr[7] == '0') {
            			year = "0";
            		}else {
            			year = dataAr[7];
            		}
            	}else {
            	    year = dataAr[6] + dataAr[7];
            	}
            }else {
                year = dataAr[5] + dataAr[6] + dataAr[7];
            }
        }else {
        	year = dataAr[4] + dataAr[5] + dataAr[6] + dataAr[7];
        }

        //alert(day+"/"+month+"/"+year);
        //alert(parseInt(day)+"/"+parseInt(month)+"/"+parseInt(year));
        //------------------------

		return isValidDate(
		    parseInt(day),
		    parseInt(month),
		    parseInt(year)
		);
	}

	/**
	* Fun��o que valida uma determinada data.
	*
	* @param day   Dia.
	* @param month M�s.
	* @param year  Ano.
	*
	* @return boolean Se a data � v�lida ou n�o.
	*/
    function isValidDate(day,month,year) {

		//n�meros al�m dos limites.
		if (day > 31 || day < 1 || month > 12 || month < 1) {
		    return false;

		//m�s de fevereiro.
		}else if (month == 2) {
		    if ((day == 29 && isLeapYear(year)) || day <= 28) {
		    	return true;
		    }else {
		    	return false;
		    }
		//dia 31.
		}else if (day == 31) {
			if (month == 1 || month == 3 || month == 5 || month == 7 ||
			    month == 8 || month == 10 || month == 12) {
				return true;
			}else {
				return false;
			}
		//qualquer outro dia � valido.
		}else {
			return true;
		}
	}

	/**
	* Fun��o que verifica se um deteminado ano � bissexto.
	*
	* @param day   Dia.
	* @param month M�s.
	* @param year  Ano.
	*
	* @return boolean Se o ano � bissexto.
	*/
    function isLeapYear(year) {

		if ((year % 400) == 0 || ((year % 4) == 0 && (year % 100) != 0)) {
			return true;
		}else {
			return false;
		}
    }

	/**
	* Fun��o que checa se a o valor do campo est� de acordo com a m�scara.
	*
	* @param mask  M�scara.
	* @param input Campo a ser validado.
	*/
	function checkValidMask(mask,input) {

		if (isDateMask(mask)) {
			mask = mask.toLowerCase();
		}

		if (input.value != "") {
		    var message;
		    var reg = new RegExp(generateRegexpFromMask(mask));
		    var isValidInput = true;
			if (isDateMask(mask)) {
				var newInput;
				var newMask = mask;
				var lenInput = input.value.length;

				if (lenInput == 8) {
					var indexYear = mask.indexOf("y");
					var yearToday = (new Date()).getYear();

					newInput = input.value.substring(0,indexYear);
					newInput += (""+yearToday).substring(0,2);
					newInput += input.value.substring(
						indexYear,input.value.length
					);

					if (mask.length == 8) {
						if (indexYear == 0) {
							newMask = "yy" + mask;
						}else {
							newMask = mask + "yy";
						}
					}else {
						input.value = newInput;
					}

				}else {
					newInput = input.value;
				}

				isValidInput = isValidInputDate(newMask,newInput);
				message = "Data inv�lida!";
			}else {
				message = "Valor inv�lido!";
			}

			isValidInput = isValidInput && reg.test(input.value);

			if (!isValidInput) {
				input.value = "";
				alert(message);
				input.focus();
			}
		}
	}

	/**
	* Fun��o que retorna uma express�o regular a partir de uma m�scara.
	*
	* @param mask M�scara.
	*
	* @return String Express�o regular.
	*/
	function generateRegexpFromMask(mask) {

	    var regexp = "";
	    var charMask;
	    for (var i = 0; i < mask.length; i++) {
	        charMask = mask.charAt(i);
			switch (charMask) {
				case NUMBER:
				case DAY:
				case MONTH:
				case YEAR:  regexp += RX_NUMBER; break;
				case UPPER: regexp += RX_UPPER; break;
				case LOWER: regexp += RX_LOWER; break;
				case ANY:   regexp += RX_ANY; break;
				case ALPHA: regexp += RX_ALPHA; break;
				default:    regexp += "\\" + charMask; break;
			}
	    }

	    return regexp;
	}

	/**
	* Fun��o que checa se uma deteminada m�scara � uma m�scara de data.
	*
	* @param mask  M�scara.
	*
	* @return boolean � uma m�scara de data.
	*/
	function isDateMask(mask) {

	    mask = mask.toLowerCase();
	    if (mask == "dd/mm/yyyy" || mask == "dd/mm/yy" ||
	        mask == "mm/dd/yyyy" || mask == "mm/dd/yy" ||
	        mask == "yyyy/mm/dd" || mask == "yy/mm/dd") {
	        return true;
	    }else {
	    	return false;
	    }
	}

	/**
	* Fun��o que checa se o caractere passado � um "literal".
	*
	* @param char Caractere.
	*
	* @return boolean � um literal.
	*/
	function isLiteral(ch) {

		switch (ch) {
			case NUMBER:
			case UPPER:
			case LOWER:
			case ANY:
			case ALPHA:
			case DAY:
			case MONTH:
			case YEAR:
			    return true;
		}

		return false;
	}

	/**
	* Fun��o que retorna uma express�o regular de acordo com o "literal" para a
	* valida��o do caractere digitado.
	*
	* @param char Caractere.
	*
	* @return String Express�o regular.
	*/
	function getRegexpLiteral(charMask) {

		var regexp;
		if ( (charMask == NUMBER) || (charMask == DAY) ||
		     (charMask == MONTH)  || (charMask == YEAR) ) {
			regexp = RX_NUMBER;
		}else if ( charMask == UPPER ) {
			regexp = RX_UPPER;
		}else if ( charMask == LOWER ) {
			regexp = RX_LOWER;
		}else if ( charMask == ALPHA ) {
			regexp = RX_ALPHA;
		}else if ( charMask == ANY ) {
			regexp = RX_ANY;
		}else {
			regexp = "AA";
			//alert("erro na m�scara!");
		}

		return regexp;
	}


//*****************************************************************
//*****************************************************************


   function delRegistroParameter(msg , formt  , parameters, actionParameterValue)
   {
	   if ( confirm(msg) )
	   {
			formt.action = formt.action + '?actionParameter='+ actionParameterValue +'&' + parameters;
			formt.submit();
	   }
   }

   function MM_swapImage() { //v3.0
      var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
      if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
   }

   function MM_swapImgRestore() { //v3.0
      var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
   }

//*****************************************************************
//*****************************************************************

//*****************************************************
//Fun��o para alterar a posi��o de um <DIV>************

var IEgetMouseXY = document.all?true:false

if (!IEgetMouseXY) document.captureEvents(Event.MOUSEMOVE)

document.onmousemove = getMouseXY;

var tempGetMouseX = 0
var tempGetMouseY = 0

function getMouseXY(e) {
  if (IEgetMouseXY) { // grab the x-y pos.s if browser is IE
    tempGetMouseX = event.clientX + document.body.scrollLeft
    tempGetMouseY = event.clientY + document.body.scrollTop
  } else {  // grab the x-y pos.s if browser is NS
    tempGetMouseX = e.pageX
    tempGetMouseY = e.pageY
  }
  // catch possible negative values in NS4
  if (tempGetMouseX < 0){tempGetMouseX = 0}
  if (tempGetMouseY < 0){tempGetMouseY = 0}

  // show the position values in the form named Show
  // in the text fields named MouseX and MouseY
  return true
}

/**
 * Fun��o usada para posicionar um layer ao lado e na mesma altura do cursor do mouse.
 * @param objName Nome do layer.
 * @param alinhamento determina em que lado o <DIV> deve aparece  (left, rigth)
 * @param margem determina o espa�o entra a <DIV> e o curso do mouse
 */

function setPosicaoTop( objName , alinhamento, margem){
	var obj = MM_findObj(objName);
	altura = obj.style.height;
	alturaDif = (altura.substring(0, altura.indexOf("px"))/2);
	alturaNoPx = (altura.substring(0, altura.indexOf("px")));

	if ((tempGetMouseY-alturaDif) < 0) {
		eval("obj.style.top="+"0");
	} else {
		eval("obj.style.top="+(tempGetMouseY-alturaDif));
	}

	if (alinhamento == "left") {
		largura = obj.style.width;
		larguraDif = (largura.substring(0, largura.indexOf("px")));
		eval("obj.style.left="+(Number(tempGetMouseX)+Number(margem)));

	} else {
		largura = obj.style.width;
		larguraDif = (largura.substring(0, largura.indexOf("px")));
		eval("obj.style.left="+(Number(tempGetMouseX)-Number(larguraDif)-Number(margem)));
	}
}

/***********************************************************/

    /**
     * Fun��o que checa quantos caracteres tem no campo. Caso
     * seja menor ao n�mero passado, ele retorna falso e mostra a mensagem
     * @param field - Campo a ser usado
     * @param nrChar - N�mero de caracteres a ser checado
     * @param msg - Mensagem que ser� exibida caso seja falso
     */
    function checkInputLength( field, nrChar, msg ){
        if( field.value.length < 3 ){
            alert( msg );
            return false;
        }else{
            return true;
        }
    }