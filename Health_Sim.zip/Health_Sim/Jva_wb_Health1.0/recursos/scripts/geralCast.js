 
function Limpar()
{
	num_elementos = document.forms[0].elements.length;
	for (i=0; i < num_elementos; i++)
	{
		if (document.forms[0].elements[i].type != "hidden" && 
			document.forms[0].elements[i].type != "button" &&
			document.forms[0].elements[i].type != "reset" &&
			document.forms[0].elements[i].type != "submit" &&
			document.forms[0].elements[i].type != "checkbox")
			{
				document.forms[0].elements[i].value = "";
			}
		  
		if (document.forms[0].elements[i].type == "radio")
		{
			document.forms[0].elements[i].checked = false;
		}
		
		if (document.forms[0].elements[i].type == "checkbox")
		{
			document.forms[0].elements[i].checked = false;
		}
	}
}



function verifica_branco(parametro)   // FUNCAO PARA VERIFICA??O DE CAMPOS N?O PREENCHIDOS
									// OU PREENCHIDOS APENAS COM ESPA?OS EM BRANCO
{
	teste_parametro = "false"; //variavel para teste de espacos em branco
	tamanho_parametro = parametro.length;
	if (tamanho_parametro != 0)
	{
		for (i = 0; i < tamanho_parametro; i++)
			{if (parametro.charAt(i) != " ")
				{
					teste_parametro = "true"; /*existe caracter diferente de branco*/
				}
			}
		if (teste_parametro == "false")  //todos os caracteres digitados s?o brancos
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	else
	{
		return false;
	}
		
}


function valida_inteiro(parametro)  //FUNCAO PARA VALIDACAO DE N?MEROS INTEIROS, E ESPA?OS EM BRANCO
{
	if (parametro.length != 0)
	{
		if (!verifica_branco(parametro))
		{
			return true;
		}
		
		teste_ponto = "false";
		tamanho_parametro = parametro.length;
		
		if (isNaN(parametro)) //valor digitado n?o ? num?rico
		{
			return false;
		}
		else //valor digitado ? um num?rico v?lido
		{	
			
			for (k = 0; k < tamanho_parametro; k++)
			{if ((parametro.charAt(k) == '.') || (parametro.charAt(k) == '-') || (parametro.charAt(k) == '+'))
				{
					teste_ponto = "true"; /*existe caracter ponto*/
				}
			}
			
			if (teste_ponto == "true") //encontrou caracter ponto(numero real)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}
	else
	{
		return true;
	}
	
}



function valida_float(parametro)  //FUNCAO PARA VALIDACAO DE N?MEROS INTEIROS, E ESPA?OS EM BRANCO
{
	teste_ponto = "false";
	teste_parametro = "false"; //variavel para teste de espacos em branco
	tamanho_parametro = parametro.length;
	parametro_conv = "";	//armazena o par?metro trocando v?rgulas por ponto e vice-versa

	if (tamanho_parametro != 0)
	{
		//procedimento p/ trocar v?rgulas por ponto e vice-versa, armazenando noutra variavel
		for (i = 0; i < tamanho_parametro; i++)
		{			
			if (parametro.charAt(i) == ",")
			{
				parametro_conv = parametro_conv + ".";
			}
			else
			{
				if (parametro.charAt(i) == ".")
				{
					parametro_conv = parametro_conv + ",";
				}
				else
				{
					parametro_conv = parametro_conv + parametro.charAt(i);
				}
			}
			
			if ((parametro.charAt(i) == "+") || (parametro.charAt(i) == "-"))
			{
				return false;
			}
		}

		if (isNaN(parametro_conv)) //valor digitado n?o ? num?rico
		{
			return false;
		}
		else
		{
			return true;
		}
/*		else valor digitado ? um num?rico v?lido
		{
			for (k = 0; k < tamanho_parametro; k++)
			{
				encontrou caracter ponto na primeira ou ?ltima posi??o (inv?lido)
				if (parametro_conv.charAt(k) == '.' && (k == tamanho_parametro - 1 || k == 0))
					{
						teste_ponto = "true"; existe caracter ponto em local inv?lido
					}
			}
			
			if (teste_ponto == "true") encontrou caracter ponto(numero real)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
*/		
	}
	else
	{
		return true;
	}
	
}


function valida_fracionario(numero,inteiro,decimal,separador)
{
	//Antes de se utilizar esta fun??o, deve-se verificar
	//se o n?mero ? realmente um num?rico v?lido, com v?rgula ou ponto
	//utilizando o valida_float ou valida_inteiro
	
	//parametro numero: n?mero a ser validado
	//parametro inteiro: n?mero de casas inteiras do n?mero
	//parametro decimal: n?mero de casas decimais do n?mero
	//parametro separador: indica se deve separar o inteiro do decimal
	//					   com ponto ou v?rgula
	
	
	var posicao = 0;
	var	tamanho_numero = numero.length;
	var casas_inteiras;
	var casas_decimais = 0;
	var achou_separador = "false";
	
	if (tamanho_numero == 0)
	{
		return true;
	}
	else
	{
		while (posicao < tamanho_numero)
		{
			if (numero.charAt(posicao) == separador)	//ACHOU V?RGULA OU PONTO
			{
				casas_inteiras = posicao;
				achou_separador = "true";
				posicao = parseInt(posicao) + 1;
				while (posicao < tamanho_numero)
				{
					casas_decimais = parseInt(casas_decimais) + 1;
					posicao = parseInt(posicao) + 1;	
				}
			}
			posicao = parseInt(posicao) + 1;
		}
		
		if (achou_separador == "false")	//N?O ACHOU NEM V?RGULA NEM PONTO
		{
			casas_inteiras = tamanho_numero;
			casas_decimais = 0;
		}
		
		if ((casas_inteiras > inteiro) || (casas_decimais > decimal))
		{
			return false;
		}
		else
		{
			return true;
		}
		
	}	//fim teste de tamanho
						   
}	//fim fun??o


	

function verifica_percentual(percentual) //FUN??O QUE VERIFICA SE UM PERCENTUAL FORNECIDO EST? ENTRE 0 E 100% 
										 //(SER?O ACEITOS N?MEROS FRACION?RIOS E INTEIROS).
{
	var posicao;
	var	tamanho_numero = percentual.length;
	var casas_inteiras;
	var casas_decimais;
	var valido = false;
			
	posicao = percentual.indexOf(",");
			
	
	if (posicao != -1 )//? um n?mero fracion?rio
	{
		casas_inteiras = percentual.substring(0, posicao);
		casas_decimais = percentual.substring(posicao + 1,tamanho_numero );
		//verificando se as casas inteiras ? menor que 100, se for, o n?mero ? v?lido
		if ( casas_inteiras < 100)
		{
			valido= true;
		}
		//verificando se as casas inteiras ? igual a 100, se for, verifica se as casas decimais ? igual a 0, se for, o n?mero ? v?lido
		if ( casas_inteiras == 100 && casas_decimais == 0)
		{
			valido= true;
		}
		//se as casas inteiras for maior que 100, o n?mero por default ? inv?lido		
	}
	else //? um n?mero inteiro
	{
		//O percentual ? um inteiro menor ou igual a 100
		if (percentual <= 100 )
		{
			valido= true;
		}
	}	
		
	return valido;
}
//fecha o sistema
function fechar()
{
	window.close();
}


function Valida_Email(email)
	{	//Funcionalidade:	Valida o e-mail retornando True se for
		//					um email v?lido e False caso contr?rio
		// PAR?METROS: 
		//		email: E-mail a ser validado
		
		teste_arroba = "false";         //VAR P/ VERIFICAR SE FOI DIGITADO PELO MENOS 
							            //UM ARROBA NO E-MAIL
		teste_ponto = "false";         //VAR P/ VERIFICAR SE FOI DIGITADO PELO MENOS 
							          //UM PONTO NO E-MAIL
		tamanho_email = email.length;
		
		if (tamanho_email > 4)
		{
			for (i=0; i < tamanho_email; i++)
			{
				if (((email.charAt(i) == "@") || (email.charAt(i) == ".")) && ((i == 0) || (i == parseInt(tamanho_email) - 1)))
				{   //DIGITOU'@' OU '.' NA PRIMEIRA OU ?LTIMA POSI??O
					return (false);
				}
				else
				{
					if (email.charAt(i) == "@") //ACHOU ARROBA
					{
						if (teste_arroba == "true") //ENCONTROU 2 ARROBAS
						{
							return (false);
						}
						else
						{
							teste_arroba = "true";
							if ((email.charAt(i + 1) == ".") || (email.charAt(i - 1) == ".") || (email.charAt(i + 1) == "@"))
							{	//ACHOU "@.", ".@" OU "@@"
								return (false);
							}
						}
					}
					else
					{
						if (email.charAt(i) == ".") //ACHOU PONTO
						{
							teste_ponto = "true";
							if ((email.charAt(i + 1) == ".") || (email.charAt(i - 1) == "."))
							{	//ACHOU ".."
								return (false);
							}
							
						}


					}

				}
			}

			if (teste_arroba == "false" || teste_ponto == "false") //N?O ENCONTROU ARROBA OU PONTO NO EMAIL
			{
				return (false);
			}
		}
		else //email com menos de 5 caracteres
		{
			return (false);
		}

		return (true);
		
	}

function valida_fone(numero){  

	numero = numero.replace("-","");
	
	if (isNaN(numero) || numero.length < 7) //valor digitado n?o ? num?rico / ou n?o ? um cep v?lido
	{
		return false;
	}
	else
	{
		return true;
	}
}



function Valida_Valor(valor)
//Retorno:	Retorna true se o valor for v?lido e false caso contr?rio.
{
	
	//express?o de caracteres inv?lidos para valor
	var expressaoRegular= /[a-zA-Z\''\"!@#\$%?\&\*\(\)\-_\+=\{\}\[\]?`\^~|<>:;?\\\/]/g; 
	resposta = valor.match(expressaoRegular); 
	if (resposta == null)//n?o tem nenhum dos caracteres que n?o podem ser aceitos
	{
		//express?o de caracteres aceitos - d?gitos, ponto e v?rgula
		expressaoRegular= /[0-9.,]/;
		resposta = valor.match(expressaoRegular);
		if (resposta)
			return true;
		else
			return false;
	}
	else
		return false;
}


function Valida_CNPJ(strCNPJ)
//Retorno:	Retorna true se o CGC/CNPJ for v?lido e false caso contr?rio.
{
	if (strCNPJ == ""){
		return false;
	}
	
	var
		strDV = strCNPJ.substr(12, 2),
		intSoma,
		intDigito = 0,
		strControle = "",
		strMultiplicador = "543298765432";
	strCNPJ = strCNPJ.substr(0, 12);
	for(var j = 1; j <= 2; j++)
	{
		intSoma = 0;
		for(var i = 0; i <= 11; i++)
		{
			intSoma += (parseInt(strCNPJ.substr(i, 1), 10) * 			parseInt(strMultiplicador.substr(i, 1), 10))
		}
		if(j == 2){intSoma += (2 * intDigito)}
		intDigito = (intSoma * 10) % 11;
		if(intDigito == 10){intDigito = 0}
		strControle += intDigito.toString();
		strMultiplicador = "654329876543";
	}
	return(strControle == strDV);
}

//Funcionalidade: Verifica se o par?metro ? um CPF v?lido

function Valida_CPF(cpf) 
{
	rcpf1 = cpf.substr(0,9) 
	rcpf2 = cpf.substr(9,2)	
  d1 = 0;
  for (i=0;i<9;i++) 
    d1 += rcpf1.charAt(i)*(10-i);
  d1 = 11 - (d1 % 11);
  if (d1>9) d1 = 0;
  
  if (rcpf2.charAt(0) != d1) 
    return false;
  
  d1 *= 2;
  for (i=0;i<9;i++) 
    d1 += rcpf1.charAt(i)*(11-i);
  d1 = 11 - (d1 % 11);
  if (d1>9) d1 = 0;
  
  if (rcpf2.charAt(1) != d1) 
    return false;

  return true;

}

	function mascara_ddd(f) {
		var fone;
		var num;
		num = "";
		//separar os n?meros
		for ( var j=0; j<f.length + 1; j++ ) {
			switch(f.substr(j,1)){
				case "0":
					if(j != 1 && j!= 0 && j !=2 && j != 3){
						num = num + f.substr(j,1);
					}else if(f.length == 1){
						num = num + f.substr(j,1);
					}
 					break;
				case "1":
					num = num + f.substr(j,1);
 					break;
				case "2":
					num = num + f.substr(j,1);
 					break;
				case "3":
					num = num + f.substr(j,1);
 					break;
				case "4":
					num = num + f.substr(j,1);
 					break;
				case "5":
					num = num + f.substr(j,1);
 					break;
				case "6":
					num = num + f.substr(j,1);
 					break;
				case "7":
					num = num + f.substr(j,1);
 					break;
				case "8":
					num = num + f.substr(j,1);
 					break;
				case "9":
					num = num + f.substr(j,1);
 					break;
			}
		}
		if(f.substr(f.length -2,1) != ")" && f.length >1 && f.substr(f.length -1,1) != ")"){
			num = num.substr(0,num.length -1);
		}
		fone = "(0xx" + num + ")";
		if (num.length == 0 ) {
   			fone = "";
		}
		return fone;
	}

	function mascara_fone(f) {
		var fone;
		var num;
		num = "";
		//separar os n?meros
		for ( var j=0; j<f.length + 1; j++ ) {
			switch(f.substr(j,1)){
				case "0":
					if(j != 1){
						num = num + f.substr(j,1);
					}else if(f.length == 1){
						num = num + f.substr(j,1);
					}
 					break;
				case "1":
					num = num + f.substr(j,1);
 					break;
				case "2":
					num = num + f.substr(j,1);
 					break;
				case "3":
					num = num + f.substr(j,1);
 					break;
				case "4":
					num = num + f.substr(j,1);
 					break;
				case "5":
					num = num + f.substr(j,1);
 					break;
				case "6":
					num = num + f.substr(j,1);
 					break;
				case "7":
					num = num + f.substr(j,1);
 					break;
				case "8":
					num = num + f.substr(j,1);
 					break;
				case "9":
					num = num + f.substr(j,1);
 					break;
			}
		}

		if(num.length < 8){
			if(num.length < 4){
				fone = num;
			}else{
				fone = num.substr(0,3) + "-" + num.substr(3,4);
			}
		}else{
			if(num.length < 5){
				fone = num;
			}else{
				fone = num.substr(0,4) + "-" + num.substr(4,4);
			}
		}
		return fone;
	}


function Mascara_Hora(obj){
	var num;
	num = "";
	//separar os n?meros
	for ( var j=0; j<obj.length + 1; j++ ) {
		switch(obj.substr(j,1)){
			case "0":
				num = num + obj.substr(j,1);
 				break;
			case "1":
				num = num + obj.substr(j,1);
 				break;
			case "2":
				num = num + obj.substr(j,1);
 				break;
			case "3":
				num = num + obj.substr(j,1);
 				break;
			case "4":
				num = num + obj.substr(j,1);
 				break;
			case "5":
				num = num + obj.substr(j,1);
 				break;
			case "6":
				num = num + obj.substr(j,1);
 				break;
			case "7":
				num = num + obj.substr(j,1);
 				break;
			case "8":
				num = num + obj.substr(j,1);
 				break;
			case "9":
				num = num + obj.substr(j,1);
 				break;
		}
	}
	if(num.length < 3){
		hora = num;
	}else{
		hora = num.substring(0,2) + ":" + num.substring(2,4);
	}
	return hora;
}


//var reTime1 = /^\d{2}:\d{2}$/;
//var reTime2 = /^([0-1]\d|2[0-3]):[0-5]\d$/;
//var reTime3 = /^(0[1-9]|1[0-2]):[0-5]\d$/;
//var reTime5 = /^\d+:[0-5]\d:[0-5]\.\d{3}\d$/;

function isValidHora(pStr)
{
	var reTipo = /^([0-1]\d|2[0-3]):[0-5]\d$/; // Onde ... � a express�o regular apropriada
	return reTipo.test(pStr);
}

function Mascara_Data(obj){
	var data;
	var num;
	num = "";
	//separar os n?meros
	for ( var j=0; j<obj.length + 1; j++ ) {
		switch(obj.substr(j,1)){
			case "0":
				num = num + obj.substr(j,1);
 				break;
			case "1":
				num = num + obj.substr(j,1);
 				break;
			case "2":
				num = num + obj.substr(j,1);
 				break;
			case "3":
				num = num + obj.substr(j,1);
 				break;
			case "4":
				num = num + obj.substr(j,1);
 				break;
			case "5":
				num = num + obj.substr(j,1);
 				break;
			case "6":
				num = num + obj.substr(j,1);
 				break;
			case "7":
				num = num + obj.substr(j,1);
 				break;
			case "8":
				num = num + obj.substr(j,1);
 				break;
			case "9":
				num = num + obj.substr(j,1);
 				break;
		}
	}
	data = "";
	switch(num.length){
			case 0:
				data = "";
 				break;
			case 1:
				data = num;
 				break;
			case 2:
				data = num;
 				break;
			case 3:
				data = num.substring(0,2) + "/" + num.substring(2);
 				break;
			case 4:
				data = num.substring(0,2) + "/" + num.substring(2);
 				break;
			case 5:
				data = num.substring(0,2) + "/" + num.substring(2,4) + "/" + num.substring(4);
 				break;
			case 6:
				data = num.substring(0,2) + "/" + num.substring(2,4) + "/" + num.substring(4);
 				break;
			case 7:
				data = num.substring(0,2) + "/" + num.substring(2,4) + "/" + num.substring(4);
 				break;
			case 8:
				data = num.substring(0,2) + "/" + num.substring(2,4) + "/" + num.substring(4);
 				break;
 			case 9:
				data = num.substring(0,2) + "/" + num.substring(2,4) + "/" + num.substring(4,8);
 				break;
 	}
	return data;
}


function isValidData(vardata)
	{
		var v_dia;
		var v_mes;
		var v_ano;
		v_dia = vardata.substring(0,2);
		v_mes = vardata.substring(3,5);
		v_ano = vardata.substring(6,10);		
		
		if (v_dia.length < 2){
			return(false);
		}
		
		if (v_mes.length < 2){
			return(false);
		}
		
		if (v_ano.length < 4){
			return(false);
		}

			
		if (((v_ano < 1900) || (v_ano > 2079)) && (v_ano.length != 0)){
			return(false);
		}

		if (v_dia > 31){
			return(false);
		}
		
		if (v_mes > 12){
			return(false);
		}
		
		if (v_dia == "31") 
		{
			if ((v_mes == "04") || (v_mes == "06") || (v_mes == "09") || (v_mes == "11"))
			{
				return(false);
			}
		}
	

		if (v_mes == "02")
		{
			if (!(v_ano%4)) 
			{
				if (v_dia > 29)
				{
					return(false);
				}
			}
			else if (v_dia > 28)
			{
				return(false);
			}
		}
		
		//o -if- abaixo testa se algum campo foi preenchido e outro deixado em branco deixando a data incompleta

		if (((v_dia != "") || (v_mes != "") || (v_ano != "")) && ((v_dia == "") || (v_mes == "") || (v_ano == "")))
		{
			return(false);
		}
		
		return(true);
	}




function valida_data(dia,mes,ano)
	{
		var v_dia;
		var v_mes;
		var v_ano;
		v_dia = dia;
		v_mes = mes;
		v_ano = ano;
	
	
		
		if (v_dia.length < 2){
			return(false);
		}
		
		if (v_mes.length < 2){
			return(false);
		}
		
		if (v_ano.length < 4){
			return(false);
		}

			
		if (((v_ano < 1900) || (v_ano > 2079)) && (v_ano.length != 0)){
			return(false);
		}

		if (v_dia > 31){
			return(false);
		}
		
		if (v_mes > 12){
			return(false);
		}
		
		if (v_dia == "31") 
		{
			if ((v_mes == "04") || (v_mes == "06") || (v_mes == "09") || (v_mes == "11"))
			{
				return(false);
			}
		}
	

		if (v_mes == "02")
		{
			if (!(v_ano%4)) 
			{
				if (v_dia > 29)
				{
					return(false);
				}
			}
			else if (v_dia > 28)
			{
				return(false);
			}
		}
		
		//o -if- abaixo testa se algum campo foi preenchido e outro deixado em branco deixando a data incompleta

		if (((v_dia != "") || (v_mes != "") || (v_ano != "")) && ((v_dia == "") || (v_mes == "") || (v_ano == "")))
		{
			return(false);
		}
		
		return(true);
	}


function Mascara_CPF(obj) 
{
	var num;
	var cep;
	num = "";
	//separar os n?meros
	for ( var j=0; j<obj.length + 1; j++ ) {
		switch(obj.substr(j,1)){
			case "0":
				num = num + obj.substr(j,1);
 				break;
			case "1":
				num = num + obj.substr(j,1);
 				break;
			case "2":
				num = num + obj.substr(j,1);
 				break;
			case "3":
				num = num + obj.substr(j,1);
 				break;
			case "4":
				num = num + obj.substr(j,1);
 				break;
			case "5":
				num = num + obj.substr(j,1);
 				break;
			case "6":
				num = num + obj.substr(j,1);
 				break;
			case "7":
				num = num + obj.substr(j,1);
 				break;
			case "8":
				num = num + obj.substr(j,1);
 				break;
			case "9":
				num = num + obj.substr(j,1);
 				break;
		}
	}
	cpf = "";	
	switch(num.length){
			case 0:
				cpf = "";
 				break;
			case 1:
				cpf = num;
 				break;
			case 2:
				cpf = num;
 				break;
			case 3:
				cpf = num;
 				break;
			case 4:
				cpf = num.substring(0,3) + "." + num.substring(4);
 				break;
			case 5:
				cpf = num;
 				break;
			case 6:
				cpf = num.substring(0,5) + "-" + num.substring(5);
 				break;
			case 7:
				cpf = num.substring(0,5) + "-" + num.substring(5,7);
 				break;
			case 8:
				cpf = num.substring(0,5) + "-" + num.substring(5,8);
 				break;
 	}
	return cpf;


/*	valor = obj
	if(valor.length == 3)
	{
		valor = valor + ".";
	}
	if(valor.length == 7)
	{
		valor = valor + ".";
	}	
	if(valor.length == 11)
	{
		valor = valor + "-";
	}	
	return valor;	
*/	
}



function tira_mascara_cnpj(cnpj)
{
	x = cnpj;
	var temp = "";
	for(i=0;i<18;i++)
	{
		if(x.substr(i,1) != "." && x.substr(i,1) != "/" && x.substr(i,1) != "-"){
			temp = temp + x.substr(i,1);
		}
	}
	return 	temp;
}
		
function tira_mascara_cpf(cpf)
{
	x = cpf;
	var temp = "";
	for(i=0;i< 14; i++)
	{
		if(x.substr(i,1) != "." &&  x.substr(i,1) != "-"){
			temp = temp + x.substr(i,1);
		}
	}
	return 	temp;
}

/**
 * Valida uma data passada como parametro
 * objName - objeto com o valor da data a ser validada
 */
function dateValid(objName) {
	var strDate;
	var strDateArray;
	var strDay;
	var strMonth;
	var strYear;
	var intday;
	var intMonth;
	var intYear;
	var booFound = false;
	var datefield = objName;
	var strSeparatorArray = new Array("-"," ","/",".");
	var intElementNr;
	// var err = 0;
	var strMonthArray = new Array(12);
	strMonthArray[0] = "Jan";
	strMonthArray[1] = "Feb";
	strMonthArray[2] = "Mar";
	strMonthArray[3] = "Apr";
	strMonthArray[4] = "May";
	strMonthArray[5] = "Jun";
	strMonthArray[6] = "Jul";
	strMonthArray[7] = "Aug";
	strMonthArray[8] = "Sep";
	strMonthArray[9] = "Oct";
	strMonthArray[10] = "Nov";
	strMonthArray[11] = "Dec";
	//strDate = datefield.value;
	strDate = objName;
	if (strDate.length < 1) {
		return true;
	}
	for (intElementNr = 0; intElementNr < strSeparatorArray.length; intElementNr++) {
		if (strDate.indexOf(strSeparatorArray[intElementNr]) != -1) {
			strDateArray = strDate.split(strSeparatorArray[intElementNr]);
			if (strDateArray.length != 3) {
				err = 1;
				return false;
			}
			else {
				strDay = strDateArray[0];
				strMonth = strDateArray[1];
				strYear = strDateArray[2];
			}
			booFound = true;
	   }
	}
	if (booFound == false) {
		if (strDate.length>5) {
			strDay = strDate.substr(0, 2);
			strMonth = strDate.substr(2, 2);
			strYear = strDate.substr(4);
	   }
	}
	if (strYear.length == 2) {
		strYear = '20' + strYear;
	}
	strTemp = strDay;
	strDay = strMonth;
	strMonth = strTemp;
	intday = parseInt(strDay, 10);
	if (isNaN(intday)) {
		err = 2;
		return false;
	}
	intMonth = parseInt(strMonth, 10);
	if (isNaN(intMonth)) {
		for (i = 0;i<12;i++) {
			if (strMonth.toUpperCase() == strMonthArray[i].toUpperCase()) {
				intMonth = i+1;
				strMonth = strMonthArray[i];
				i = 12;
		   }
		}
		if (isNaN(intMonth)) {
			err = 3;
			return false;
 	    }
	}
	intYear = parseInt(strYear, 10);
	if (isNaN(intYear)) {
		err = 4;
		return false;
	}
	if (intMonth>12 || intMonth<1) {
		err = 5;
		return false;
	}
	if ((intMonth == 1 || intMonth == 3 || intMonth == 5 || intMonth == 7 || intMonth == 8 || intMonth == 10 || intMonth == 12) && (intday > 31 || intday < 1)) {
		err = 6;
		return false;
	}
	if ((intMonth == 4 || intMonth == 6 || intMonth == 9 || intMonth == 11) && (intday > 30 || intday < 1)) {
		err = 7;
		return false;
	}
	if (intMonth == 2) {
		if (intday < 1) {
			err = 8;
			return false;
		}
		if (LeapYear(intYear) == true) {
			if (intday > 29) {
				err = 9;
				return false;
		    }
		}
		else {
			if (intday > 28) {
				err = 10;
				return false;
		    }
	    }
	}
	return true;
}




function Bloqueia_Num(obj){
	var num;
	num = "";
	//separar os n?meros
	for ( var j=0; j<obj.length + 1; j++ ) {
		switch(obj.substr(j,1)){
			case "0":
				num = num + obj.substr(j,1);
 				break;
			case "1":
				num = num + obj.substr(j,1);
 				break;
			case "2":
				num = num + obj.substr(j,1);
 				break;
			case "3":
				num = num + obj.substr(j,1);
 				break;
			case "4":
				num = num + obj.substr(j,1);
 				break;
			case "5":
				num = num + obj.substr(j,1);
 				break;
			case "6":
				num = num + obj.substr(j,1);
 				break;
			case "7":
				num = num + obj.substr(j,1);
 				break;
			case "8":
				num = num + obj.substr(j,1);
 				break;
			case "9":
				num = num + obj.substr(j,1);
 				break;
		}
	}
	return num;
}



function Mascara_CEP(obj) {
	var num;
	var cep;
	num = "";
	//separar os n?meros
	for ( var j=0; j<obj.length + 1; j++ ) {
		switch(obj.substr(j,1)){
			case "0":
				num = num + obj.substr(j,1);
 				break;
			case "1":
				num = num + obj.substr(j,1);
 				break;
			case "2":
				num = num + obj.substr(j,1);
 				break;
			case "3":
				num = num + obj.substr(j,1);
 				break;
			case "4":
				num = num + obj.substr(j,1);
 				break;
			case "5":
				num = num + obj.substr(j,1);
 				break;
			case "6":
				num = num + obj.substr(j,1);
 				break;
			case "7":
				num = num + obj.substr(j,1);
 				break;
			case "8":
				num = num + obj.substr(j,1);
 				break;
			case "9":
				num = num + obj.substr(j,1);
 				break;
		}
	}
	cep = "";	
	switch(num.length){
			case 0:
				cep = "";
 				break;
			case 1:
				cep = num;
 				break;
			case 2:
				cep = num;
 				break;
			case 3:
				cep = num;
 				break;
			case 4:
				cep = num;
 				break;
			case 5:
				cep = num;
 				break;
			case 6:
				cep = num.substring(0,5) + "-" + num.substring(5);
 				break;
			case 7:
				cep = num.substring(0,5) + "-" + num.substring(5,7);
 				break;
			case 8:
				cep = num.substring(0,5) + "-" + num.substring(5,8);
 				break;
 	}
	return cep;
}

//valida se o cep ? v?lido - num?rico, de tamanho = 8 e maior que 0
function valida_cep(numero) {
	
	numero = numero.replace("-","");
	
	if (numero.length != 8) return false;
		
	if (isNaN(numero) || numero <= 0) //valor digitado n?o ? num?rico / ou n?o ? um cep v?lido
	{
		return false;
	}
	else
	{
		return true;
	}
}


function bloqueia_nao_numerico() {
	//colocar esta fun??o no keypress
	if(event.keyCode < 48 || event.keyCode > 57){
		event.keyCode = 0;
		return false;
	}else{
		return true;
	}
}


function Mascara_CPF(obj){
	var cpf;
	var num;
	num = "";
	//separar os n?meros
	for ( var j=0; j<obj.length + 1; j++ ) {
		switch(obj.substr(j,1)){
			case "0":
				num = num + obj.substr(j,1);
 				break;
			case "1":
				num = num + obj.substr(j,1);
 				break;
			case "2":
				num = num + obj.substr(j,1);
 				break;
			case "3":
				num = num + obj.substr(j,1);
 				break;
			case "4":
				num = num + obj.substr(j,1);
 				break;
			case "5":
				num = num + obj.substr(j,1);
 				break;
			case "6":
				num = num + obj.substr(j,1);
 				break;
			case "7":
				num = num + obj.substr(j,1);
 				break;
			case "8":
				num = num + obj.substr(j,1);
 				break;
			case "9":
				num = num + obj.substr(j,1);
 				break;
		}
	}
	cpf = "";
	switch(num.length){
			case 0:
				cpf = "";
 				break;
			case 1:
				cpf = num;
 				break;
			case 2:
				cpf = num;
 				break;
			case 3:
				cpf = num;
 				break;
			case 4:
				cpf = num.substring(0,3) + "." + num.substring(3);
 				break;
			case 5:
				cpf = num.substring(0,3) + "." + num.substring(3,5);
 				break;
			case 6:
				cpf = num.substring(0,3) + "." + num.substring(3,6)
 				break;
			case 7:
				cpf = num.substring(0,3) + "." + num.substring(3,6) + "." + num.substring(6,7);
 				break;
			case 8:
				cpf = num.substring(0,3) + "." + num.substring(3,6) + "." + num.substring(6,8);
 				break;
 			case 9:
				cpf = num.substring(0,3) + "." + num.substring(3,6) + "." + num.substring(6,9);
 				break;
 			case 10:
				cpf = num.substring(0,3) + "." + num.substring(3,6) + "." + num.substring(6,9) + "-" + num.substring(9,10);
 				break;
 			case 11:
				cpf = num.substring(0,3) + "." + num.substring(3,6) + "." + num.substring(6,9) + "-" + num.substring(9,11);
 				break;
 			default:
 				cpf = num.substring(0,3) + "." + num.substring(3,6) + "." + num.substring(6,9) + "-" + num.substring(9,11);
 				break;
 	}
	return cpf;
}



function Mascara_CNPJ(obj)
{
//	alert(obj)
	valor = obj
	if(valor.length == 2)
	{
		valor = valor + ".";
	}
	if(valor.length == 6)
	{
		valor = valor + ".";
	}	
	if(valor.length == 10)
	{
		valor = valor + "/";
	}	
	if(valor.length == 15)
	{
		valor = valor + "-";
	}
	return valor;
}

function retorna_numero(obj){
	var num;
	num = "";
	for ( var j=0; j<obj.length + 1; j++ ) {
		switch(obj.substr(j,1)){
			case "0":
				num = num + obj.substr(j,1);
 				break;
			case "1":
				num = num + obj.substr(j,1);
 				break;
			case "2":
				num = num + obj.substr(j,1);
 				break;
			case "3":
				num = num + obj.substr(j,1);
 				break;
			case "4":
				num = num + obj.substr(j,1);
 				break;
			case "5":
				num = num + obj.substr(j,1);
 				break;
			case "6":
				num = num + obj.substr(j,1);
 				break;
			case "7":
				num = num + obj.substr(j,1);
 				break;
			case "8":
				num = num + obj.substr(j,1);
 				break;
			case "9":
				num = num + obj.substr(j,1);
 				break;
		}
	}
	return num;
}



function Bloqueia_Acento(){

	if(event.keyCode == 94 || event.keyCode == 96 || event.keyCode == 126 || event.keyCode == 180 || event.keyCode == 231 || event.keyCode == 34 || event.keyCode == 39 || event.keyCode > 190){
		event.keyCode = 0;
	   return false;

	} else if (event.keyCode >= 97 && event.keyCode <=122) {
		event.keyCode = parseInt(event.keyCode) - parseInt(32); //Converte para mai?sculas
		return false;

	}
}

function valida_email(email)
	{	//Funcionalidade:	Valida o e-mail retornando True se for
		//					um email v?lido e False caso contr?rio
		// PAR?METROS: 
		//		email: E-mail a ser validado
		
		teste_arroba = "false";         //VAR P/ VERIFICAR SE FOI DIGITADO PELO MENOS 
							            //UM ARROBA NO E-MAIL
		teste_ponto = "false";         //VAR P/ VERIFICAR SE FOI DIGITADO PELO MENOS 
							          //UM PONTO NO E-MAIL
		tamanho_email = email.length;
		
		if (tamanho_email > 4)
		{
			for (i=0; i < tamanho_email; i++)
			{
				if (((email.charAt(i) == "@") || (email.charAt(i) == ".")) && ((i == 0) || (i == parseInt(tamanho_email) - 1)))
				{   //DIGITOU'@' OU '.' NA PRIMEIRA OU ?LTIMA POSI??O
					return (false);
				}
				else
				{
					if (email.charAt(i) == "@") //ACHOU ARROBA
					{
						if (teste_arroba == "true") //ENCONTROU 2 ARROBAS
						{
							return (false);
						}
						else
						{
							teste_arroba = "true";
							if ((email.charAt(i + 1) == ".") || (email.charAt(i - 1) == ".") || (email.charAt(i + 1) == "@"))
							{	//ACHOU "@.", ".@" OU "@@"
								return (false);
							}
						}
					}
					else
					{
						if (email.charAt(i) == ".") //ACHOU PONTO
						{
							teste_ponto = "true";
							if ((email.charAt(i + 1) == ".") || (email.charAt(i - 1) == "."))
							{	//ACHOU ".."
								return (false);
							}
							
						}


					}

				}
			}

			if (teste_arroba == "false" || teste_ponto == "false") //N?O ENCONTROU ARROBA OU PONTO NO EMAIL
			{
				return (false);
			}
		}
		else //email com menos de 5 caracteres
		{
			return (false);
		}

		return (true);
		
	}


//tirar os espa?os das extremidades do valor passado
function trim(valor){
	for (i=0;i<valor.length;i++){
		if(valor.substr(i,1) != " "){
			valor = valor.substr(i);
			break;
		}
		if (i == valor.length-1){
			valor = "";
		}
	}
	for (i=valor.length-1;i>=0;i--){
		if(valor.substr(i,1) != " "){
			valor = valor.substr(0,i+1);
			break;
		}
	}
	return valor;
}

//tirar os espa?os das extremidades do valor passado
function Trim(valor){
   return trim(valor)
}


/*
desenvolvedor: antonio benedito
data: 28/11/2001
objetivo:
mascarar de acordo com a mascara passada
caracteres: # - caracter a ser mascarado
           | - separador de mascaras
modos (exemplos):
mascara simples: "###-####"	                 mascara utilizando a mascara passada
mascara composta: "###-####|####-####"       mascara de acordo com o tamanho (length) do valor passado
mascara din?mica: "[###.]###,##"             multiplica o valor entre colchetes de acordo com o length
											 do valor para que a mascara seja din?mica ex: ###.###.###.###,##
utilizar no onkeyup do objeto
ex: onkeyup="this.value = mascara_global('#####-###',this.value);"

tratar o maxlength do objeto na p?gina (a fun??o n?o trata isso)
*/

function mascara_global(mascara, valor){
	
	var mascara_utilizar;
	var mascara_limpa;
	var temp;
	var i;
	var j;
	var caracter;
	var separador;
	var dif;
	var validar;
	var mult;
	var ret;
	var tam;
	var tvalor;
	var valorm;
	var masct;
	tvalor = "";
	ret = "";
	caracter = "#";
	separador = "|";
	mascara_utilizar = "";
	valor = trim(valor);
	if (valor == "")return valor;
	temp = mascara.split(separador);
	dif = 1000;
	
	valorm = valor;
	//tirando mascara do valor j? existente
	for (i=0;i<valor.length;i++){
		if (!isNaN(valor.substr(i,1))){
			tvalor = tvalor + valor.substr(i,1);
		}
	}
	valor = tvalor;

	//formatar mascara dinamica
	for (i = 0; i<temp.length;i++){
		mult = "";
		validar = 0;
		for (j=0;j<temp[i].length;j++){
			if (temp[i].substr(j,1) == "]"){
				temp[i] = temp[i].substr(j+1);
				break;
			}
			if (validar == 1)mult = mult + temp[i].substr(j,1);
			if (temp[i].substr(j,1) == "[")validar = 1;
		}
		for (j=0;j<valor.length;j++){
			temp[i] = mult + temp[i];
		}
	}
	
	
	//verificar qual mascara utilizar
	if (temp.length == 1){
		mascara_utilizar = temp[0];
		mascara_limpa = "";
		for (j=0;j<mascara_utilizar.length;j++){
			if (mascara_utilizar.substr(j,1) == caracter){
				mascara_limpa = mascara_limpa + caracter;
			}
		}
		tam = mascara_limpa.length;
	}else{
		//limpar caracteres diferente do caracter da m?scara
		for (i=0;i<temp.length;i++){
			mascara_limpa = "";
			for (j=0;j<temp[i].length;j++){
				if (temp[i].substr(j,1) == caracter){
					mascara_limpa = mascara_limpa + caracter;
				}
			}
			
			if (valor.length > mascara_limpa.length){
				if (dif > (valor.length - mascara_limpa.length)){
					dif = valor.length - mascara_limpa.length;
					mascara_utilizar = temp[i];
					tam = mascara_limpa.length;
				}
			}else if (valor.length < mascara_limpa.length){
				if (dif > (mascara_limpa.length - valor.length)){
					dif = mascara_limpa.length - valor.length;
					mascara_utilizar = temp[i];
					tam = mascara_limpa.length;
				}
			}else{
				mascara_utilizar = temp[i];
				tam = mascara_limpa.length;
				break;
			}
		}
	}
	
	//validar tamanho da mascara de acordo com o tamanho do valor
	if (valor.length > tam){
		valor = valor.substr(0,tam);
	}else if (valor.length < tam){
		masct = "";
		j = valor.length;
		for (i = mascara_utilizar.length-1;i>=0;i--){
			if (j == 0) break;
			if (mascara_utilizar.substr(i,1) == caracter){
				j--;
			}
			masct = mascara_utilizar.substr(i,1) + masct;
		}
		mascara_utilizar = masct;
	}
	
	//mascarar
	j = mascara_utilizar.length -1;
	for (i = valor.length - 1;i>=0;i--){
		if (mascara_utilizar.substr(j,1) != caracter){
			ret = mascara_utilizar.substr(j,1) + ret;
			j--;
		}
		ret = valor.substr(i,1) + ret;
		j--;
	}
	return ret;
}

// FEAB - 30/06/2006 - Rotina que calcula DV do SISCOR
function calculaDV(item,evento){
  var unicode=evento.charCode? evento.charCode : evento.keyCode
  if (unicode != 8) {
    if (item.value.length > 11) {
      item.value = item.value.substr(0,11);
    }
    item.value = mascara_global('######/####|######/###|######/##|######/#|######',item.value);
    // Calcula DV a partir do valor do item
    if (item.value.length == 11) {
      item.value = comporDVSiscor(item.value);
    }
  }
}

// FEAB - 30/06/2006 - Rotina que forma o DV do SISCOR
function comporDVSiscor(siscor){
  // Comp?e o DV para o siscor 
  // Decomp?e o Siscor - n1n2n3n4n5n6/a1a2a3a4-d1d2
  n1 = siscor.substr(0,1);
  n2 = siscor.substr(1,1);
  n3 = siscor.substr(2,1);
  n4 = siscor.substr(3,1);
  n5 = siscor.substr(4,1);
  n6 = siscor.substr(5,1);
  a1 = siscor.substr(7,1);
  a2 = siscor.substr(8,1);
  a3 = siscor.substr(9,1);
  a4 = siscor.substr(10,1);
  // C?lculo do d1 
  d = Math.abs(11 - ((10 + parseInt(n1)*9 + parseInt(n2)*8 + parseInt(n3)*7 + parseInt(n4)*6 + parseInt(n5)*5 + parseInt(n6)*4 + parseInt(a3)*3 + parseInt(a4)*2) % 11));
  if (d == 10 || d == 11)
    d1 = 0;
  else
    d1 = d;
  // C?lculo do d2
  h = Math.abs(11 - ((11 + n1*10 + n2*9 + n3*8 + n4*7 + n5*6 + parseInt(n6)*5 + parseInt(a3)*4 + parseInt(a4)*3 + parseInt(d1)*2) % 11));
  if (h == 10 || h == 11)
    d2 = 0;
  else
    d2 = h;
  // Anexa??o ao Siscor
  siscor = siscor + "-" + d1 + d2;
  return siscor;
}

// GGeorge - 03/07/2006 - Rotina para abrir link do PB
function funLinkPb(valor) {
	var lnkPB = 'http://10.200.145.1/aplic/pb/probas.nsf/web/';
	var lnkOD = '?OpenDocument';
	
	if ((!funValidaPB(valor)) && (!funValidaPBUAE (valor)) || (Trim(valor)=="")) {
    	alert("Siga o formato: SUPRE 1206/2006 ou UAE 1206/2006");
    } else {		
		valor = valor.replace('/', '');
		valor = valor.replace(' ', '');
		window.open(lnkPB + valor + lnkOD, 'frmPb');
	}
}	

// GGeorge - 03/07/2006 - Rotina para abrir link do voto
function funLinkVoto(valor) 
{
    //http://10.200.145.1/aplic/ProcessoDecisorio/PDSR51.nsf/web/SUNAF00682006?opendocument 
	//var lnkVoto = 'http://10.200.145.1/aplic/ProcessoDecisorio/PDSR5.nsf/web/';
	
	// AECJ em 19/09/2006 --> Altera��o do Link Voto
	//http://10.200.145.1/aplic/ProcessoDecisorio/PDSR51.nsf/web/" @Left(txtCodvoto;4) + @Right(txtCodvoto;4 )+ ?OpenDocument	
	//var lnkVoto = 'http://10.200.145.1/aplic/ProcessoDecisorio/PDSR51.nsf/web/'
	
 	var lnkVoto = 'http://10.200.145.1/aplic/ProcessoDecisorio/PDSR51.nsf/web/'
	var lnkOD   = '?OpenDocument';	
	if ((!funValidaVoto(valor)) || (Trim(valor)=="")) 
	{
    	alert("Siga o formato: 1206/2006");
    } 
    else 
    {
		valor = valor.replace('/', '');
		//valor = 'SUPCD'+valor;						
		window.open(lnkVoto + valor + lnkOD, 'frmVoto');
	}
}

// SM 10577 - AECJ em 19/09/2006
// prepara a consulta para que o siscor seja pesquisado
function funLinkSiscor(valor) 
{
    //https://homaplic.serpro.gov.br/SiscorWeb/visualiza?nucorrespondencia=nnnnnn/aaaa-dd     
    //var lnkVoto = 'https://homaplic.serpro.gov.br/SiscorWeb/visualiza?nucorrespondencia='
    
    var lnkVoto  = 'https://siscor.portalcorporativo.serpro/SiscorWeb/visualiza?nucorrespondencia='
	var lnkOD   = '?OpenDocument';	
	if ((!funValidaSiscor(valor)) || (Trim(valor)=="")) 
	{
    	alert("Favor para pesquisar pelo n�mero do Siscor siga o formato: 999999/9999-99");
    } 
    else 
    {
		//valor = valor.replace('/', '');
		//valor = valor.replace('-', ''); 				
		//window.open(lnkVoto + valor + lnkOD, 'frmSiscor');
		window.open(lnkVoto + valor, 'frmSiscor');
	}
}

function funValidaSiscor(valor) 
{
   var re = new RegExp("[0-9]{6}[/][0-9]{4}[-][0-9]{2}")
   if (Trim(valor) != "")
      return valor.match(re)
   return true;
}
// SM 10577 - FIM ********************************

//GGeorge - 04/07/2006 - Rotina para validar o PB
function funValidaPB (valor) {
	var re = new RegExp("[a-zA-Z]{5}\\s[0-9]{4}[/][0-9]{4}");
	
	if(Trim(valor)!="")
		return valor.match(re) || funValidaPBUAE (valor) ;
	return true;
}
//CCaminha - 13/10/2006 - Rotina para validar o PB com 3 d�gitos iniciais.
function funValidaPBUAE (valor) {
	var re = new RegExp("[a-zA-Z]{3}\\s[0-9]{4}[/][0-9]{4}");
	
	if(Trim(valor)!="")
		return valor.match(re);
	return true;
}

//GGeorge - 04/07/2006 - Rotina para validar o voto
function funValidaVoto (valor) {
	var re = new RegExp("[0-9]{4}[/][0-9]{4}");
	
	if(Trim(valor)!="")
		return valor.match(re);
	return true;
}

//GGeorge - 05/07/2006 - Rotina para formatar valores negativos
function mascara_global_negativo (mascara, valor) {
	var sinal ='';
	
	if (valor.substr(0,1) == "-") 
		sinal = '-';
	return sinal + mascara_global(mascara, retorna_numero(valor));
}

//CCaminha - 13/10/2006 - Rotina para formatar PB
function formatarPB(src){
    if(src.value.substring(0,3).toUpperCase() == 'UAE'){
      
      formatar(src, '### ####/####');
      
    }
    else
    {
      
      formatar(src, '##### ####/####');
      
    }
}

//FEAB - 05/07/2006 - Rotina para formatar valores

function formatar (src, mask) {
	var i = src.value.length;
	var saida = mask.substring(0,1);
	var texto = mask.substring(i);
	if (texto.substring(0,1) != saida) {
		src.value += texto.substring(0,1);
	}
}

function formatarContratoOriginal(campo) 
{
	campo.value = mascara_global('#####', campo.value);
	if (campo.value.length > 0 && campo.value.indexOf("RG") == -1) {
    	campo.value = 'RG' + campo.value;
	}
}